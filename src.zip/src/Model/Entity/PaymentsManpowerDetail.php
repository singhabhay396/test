<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

class PaymentsManpowerDetail extends Entity
{
    protected $_accessible = [
        '*' => true,
    ];
}