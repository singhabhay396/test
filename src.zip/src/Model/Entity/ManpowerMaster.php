<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;


class ManpowerMaster extends Entity
{
    protected $_accessible = [
        '*' => true,
    ];
}
