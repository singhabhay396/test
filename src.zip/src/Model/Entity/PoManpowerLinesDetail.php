<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

class PoManpowerLinesDetail extends Entity
{
    protected $_accessible = [
        '*' => true,
    ];
}