<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

 
class Mpr extends Entity
{

    protected $_accessible = [
        'project_no' => true,
        'work_order_id' => true,
        'report_month' => true,
        'report_year' => true,
        'submitted_by' => true,
        'uploaded_signed_mpr' => true,
        'uploaded_file1' => true,
        'uploaded_file2' => true,
        'uploaded_file3' => true,
        'uploaded_file4' => true,
        'created' => true
    ];
}
