<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

class ProductsTable extends Table
{

    public function initialize(array $config)
    {
        parent::initialize($config);
        $this->setTable('products');
        $this->setPrimaryKey('id');
        $this->addBehavior('Timestamp');
        $this->belongsTo('Categories', [
            'foreignKey' => 'category_id'
        ]);
        $this->belongsTo('SubCategories', [
            'foreignKey' => 'sub_category_id'
        ]);
         $this->hasMany('ProductImages', [
            'foreignKey' => 'products_id',
            'joinType' => 'LEFT'
        ]);
         $this->hasMany('ProductPackImages', [
            'foreignKey' => 'product_id',
            'joinType' => 'LEFT'
        ]);
         $this->hasMany('UserBillingDetails', [
            'foreignKey' => 'product_id',
            'joinType' => 'LEFT'
        ]);
        
       
        
        
    }

}
