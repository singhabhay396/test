<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

class SubCategoriesImagesTable extends Table
{

    public function initialize(array $config)
    {
        parent::initialize($config);
        $this->setTable('sub_categories_images');
        $this->setPrimaryKey('id');
        $this->addBehavior('Timestamp');
        $this->belongsTo('SubCategories', [
            'foreignKey' => 'category_id'
        ]);
        
    }
}
