<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;
use Cake\Auth\DefaultPasswordHasher;
use Cake\ORM\TableRegistry;

class WalletLogsTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('wallet_logs');
        $this->setPrimaryKey('id');
        $this->belongsTo('addedBy', [
			'className'=>'Users',
            'foreignKey' => 'added_by',
            'joinType' => 'INNER'
        ]);
		$this->belongsTo('addedTo', [
			'className'=>'Users',
            'foreignKey' => 'added_to',
            'joinType' => 'INNER'
        ]);
        
    }
}
