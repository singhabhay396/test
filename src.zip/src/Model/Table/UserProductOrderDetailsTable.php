<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

class UserProductOrderDetailsTable extends Table
{

    public function initialize(array $config)
    {
        parent::initialize($config);
        $this->setTable('user_product_order_details');
        $this->setPrimaryKey('id');
        $this->addBehavior('Timestamp');
        $this->belongsTo('Products', [
            'foreignKey' => 'product_id'
        ]);
		$this->belongsTo('Users', [
            'foreignKey' => 'user_id'
        ]);
		$this->hasOne('PaymentDetails', [
            'foreignKey' => 'razorpay_payment_id'
        ]);
        
    }
}
