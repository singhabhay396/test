<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

class CategoriesTable extends Table
{

    public function initialize(array $config)
    {
        parent::initialize($config);
        $this->setTable('categories');
        $this->setPrimaryKey('id');
        $this->addBehavior('Timestamp');
        $this->hasMany('SubCategories', [
            'foreignKey' => 'category_id',
            'joinType' => 'LEFT'
        ]);
    }

}
