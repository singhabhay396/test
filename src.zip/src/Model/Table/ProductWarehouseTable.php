<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

class ProductWarehouseTable extends Table
{

    public function initialize(array $config)
    {
        parent::initialize($config);
        $this->setTable('product_warehouse');
        $this->setPrimaryKey('id');
        /* $this->belongsTo('Products', [
            'foreignKey' => 'code',
            'joinType' => 'LEFT'
        ]); */
    }  

}
