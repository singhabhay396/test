<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

class SubCategoriesTable extends Table
{

    public function initialize(array $config)
    {
        parent::initialize($config);
        $this->setTable('sub_categories');
        $this->setPrimaryKey('id');
        $this->addBehavior('Timestamp');
        $this->belongsTo('Categories', [
            'foreignKey' => 'category_id'
        ]);
        $this->hasMany('Products', [
            'foreignKey' => 'sub_category_id'
        ]);
        
         $this->hasMany('SubCategoriesImages', [
            'foreignKey' => 'sub_category_id',
            'joinType' => 'LEFT'
        ]);
    }
}
