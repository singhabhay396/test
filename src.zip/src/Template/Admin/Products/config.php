<?php
$keyId = 'Your Razorpay Keyid';
$keySecret = 'Your Razorpay Key Secret';
$displayCurrency = 'INR';
error_reporting(E_ALL);
ini_set('display_errors', 1);
