<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Core\Configure;
use Cake\Event\Event;
use Cake\Network\Exception\NotFoundException;
use Cake\View\Exception\MissingTemplateException;
use Cake\Utility\Text;
use Cake\Mailer\Email;
use Cake\I18n\Time;
use Cake\Routing\Router;
use Cake\Chronos\Chronos;
use Cake\Auth\DefaultPasswordHasher;
use Cake\Validation\Validator;
use Cake\View\View;
use Cake\ORM\TableRegistry;
class ProductsController extends AppController
{
  Public $paginate = [
        'limit' => 10
    ];
    public function initialize()
    {
        parent::initialize();
        $this->viewBuilder()->setLayout('home');
        $this->loadModel('Products');
        $this->loadModel('Categories');
        $this->loadModel('SubCategoriesImages');
        $this->loadModel('SubCategories');
        $this->loadModel('ProductImages');
        $this->loadModel('ProductPackImages');
        $this->Auth->allow(['products','productDetails','getProductDetails','getCartDetails','deleteCartItem']);
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }

    public function products($code = NULL)
    {
        if(empty($code)){
             $products = $this->SubCategories->find()->contain(['Products.ProductImages'])->where(['SubCategories.status'=> 1])->toArray();
        }else{
            $products = $this->SubCategories->find()->contain(['Products.ProductImages'])->where(['SubCategories.status'=> 1,'SubCategories.code LIKE'=>'%'.$code.'%'])->toArray();
        }
        //echo '<pre>';print_r($products);exit;
        $this->set(compact('products'));
    }
	
    public function productDetails($code = null)
    {
        $products = $this->Products->find()->contain(['SubCategories','ProductImages','ProductPackImages'])->where(['Products.status'=> 1,'Products.code LIKE'=>'%'.$code.'%'])->first();
        $category_id = $products->sub_category->category_id;
       // echo '<pre>';print_r($products);exit;
        $getRelatedProducts = $this->Products->find()->contain(['SubCategories','ProductImages','ProductPackImages'])->where(['Products.status'=> 1,'Products.code NOT LIKE'=>'%'.$code.'%','SubCategories.category_id'=>$category_id])->toArray();
        
        $this->set(compact('products','getRelatedProducts'));
    } 

    public function getProductDetails()
    {
        $this->loadModel('Cart');
        $this->viewBuilder()->layout(false);
        $ip_address = $this->getClientIp();
        $result = '';
        $code = $_GET['prodcode'];
        $prod = $this->Products->find()
         ->contain(['ProductImages'=> function ($q) {
         return $q->select(['ProductImages.products_id','ProductImages.filename'])
         ->where(['ProductImages.status' =>1]);
         }])
         ->where(['Products.status'=> 1,'Products.code LIKE'=>'%'.$code.'%'])
         ->first();
         
        if(!empty($prod))
		{ 
             $carts = $this->Cart->find()->select(['id'])->where(['Cart.user_id'=> $this->Auth->user('id'),'Cart.product_code LIKE'=>'%'.$code.'%'])->toArray();
            if(empty($carts))
            {            
                $total_items = count($carts); 
                $product_name = $prod->product_name;
                $product_image = $prod->product_images[0]->filename;
                $product_code = $prod->code;
                $product_after_discount_price = $prod->price_after_discount;
                $cart = $this->Cart->newEntity();      
                $cartRecord = [
                    'ip_address'      => $ip_address,
                    'product_name' => $product_name,
                    'poduct_image'  => $product_image,
                    'user_id'  => $this->Auth->user('id'),
                    'product_after_discount_price'  => $product_after_discount_price,
                    'product_code'  =>  $product_code
                ];
 
                $cart = $this->Cart->patchEntity($cart, $cartRecord);
                if ($result = $this->Cart->save($cart)) {
                    $carts = $this->Cart->find()->select(['id'])->where(['Cart.user_id'=>$this->Auth->user('id')])->toArray();
                    
                    $total_items = count($carts); 
                    echo $total_items;
                }else{
                    echo -1;
                }
            }else{
                echo -3;
            }
        }else{
            echo -2;
        }
        exit;
    } 
   
    public function getCartDetails()
    {
        $this->loadModel('Cart');
        $this->viewBuilder()->layout('ajax');
        $ip_address = $this->getClientIp();
        $result = '';
        $Query = $this->Cart->find('all');
        $Query->select([ 
                      'product_name','poduct_image','product_after_discount_price','id',
                      'count' => $Query->func()->count('*')
                    ])
         ->where(['Cart.ip_address LIKE'=> '%'.$ip_address.'%'])
         ->group('Cart.product_code')
         ->toArray();
        
        
        if(!empty($Query)) 
        {
          $result = $Query;  
        }else{
          $result = '';   
        }
        $this->set('result',$result);
    }
    
   public function deleteCartItem()
    {
        $this->loadModel('Cart');
        $this->viewBuilder()->layout('ajax');
        $ip_address = $this->getClientIp();
        $cart_id = $_GET['cart_id'];
        $result = '';
        $carts = $this->Cart->get($cart_id);
        if ($this->Cart->delete($carts)) {
        $Qry = $this->Cart->find()
        ->select(['id'])
        ->where(['Cart.ip_address LIKE'=> '%'.$carts->ip_address.'%'])
       ->toArray();
                    
        $total_items = count($Qry); 
        echo $total_items;
        } 
        else {
        echo -1;
        }
       exit; 
    } 
    
    public function getClientIp() {
        $ipaddress = '';
        if (getenv('HTTP_CLIENT_IP'))
            $ipaddress = getenv('HTTP_CLIENT_IP');
        else if (getenv('HTTP_X_FORWARDED_FOR'))
            $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
        else if (getenv('HTTP_X_FORWARDED'))
            $ipaddress = getenv('HTTP_X_FORWARDED');
        else if (getenv('HTTP_FORWARDED_FOR'))
            $ipaddress = getenv('HTTP_FORWARDED_FOR');
        else if (getenv('HTTP_FORWARDED'))
            $ipaddress = getenv('HTTP_FORWARDED');
        else if (getenv('REMOTE_ADDR'))
            $ipaddress = getenv('REMOTE_ADDR');
        else
            $ipaddress = 'UNKNOWN';
        return $ipaddress;
    }
   
}
