<?php
/**
 * CakePHP(tm) : Rapid Development Framework (https://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 * @link      https://cakephp.org CakePHP(tm) Project
 * @since     0.2.9
 * @license   https://opensource.org/licenses/mit-license.php MIT License
 */
namespace App\Controller;

use Cake\Cache\Cache;
use Cake\Controller\Controller;
use Cake\Core\Configure;
use Cake\Event\Event;
use Cake\Routing\Router;
use Cake\Utility\Hash;
use App\View\Helper\SilverFormHelper;
use Cake\View\View;
use Cake\ORM\TableRegistry;
use finfo;
use FPDI;

class PDF extends FPDI {
    protected $_tplIdx;
    public function Header()
    {
        if (null === $this->_tplIdx) {
            $this->setSourceFile('letterhead.pdf');
            $this->_tplIdx = $this->importPage(1);
        }
        $this->useTemplate($this->_tplIdx);
    }

    public function Footer(){
        $this->SetY(0);
    }
}

class HPDF extends FPDI {
    protected $_tplIdx;
    public function Header(){
    }

    public function Footer(){
    }
}

class DEMOPDF extends FPDI {
    protected $_tplIdx;
    function Header() {
        //$this->SetFont('','B',40);
        $this->SetTextColor(255, 192, 203);
        //$this->RotatedText(35, 220, 'Preview of Certificate of Origin', 45);
    }

    function RotatedText($x, $y, $txt, $angle) {
        $this->Rotate($angle, $x, $y);
        $this->Text($x, $y, $txt);
        $this->Rotate(0);
    }

    public function Footer(){
    }
}
/**
 * Application Controller
 *
 * Add your application-wide methods in the class below, your controllers
 * will inherit them.
 *
 * @link https://book.cakephp.org/3.0/en/controllers.html#the-app-controller
 */
class AppController extends Controller
{
    
    public $languages;
    
    public $SilverForm;
    /**
     * Initialization hook method.
     *
     * Use this method to add common initialization code like loading components.
     *
     * e.g. `$this->loadComponent('Security');`
     *
     * @return void
     */ 
    public function initialize()
    {
        parent::initialize();

        $this->loadComponent('RequestHandler', [
            'enableBeforeRedirect' => false,
        ]);
        $this->loadComponent('Email');
        $this->loadComponent('Sanitize');
        $this->loadComponent('Flash', ['clear' => true]);
        $this->loadComponent('Paginator');
        $this->loadComponent('Cookie', ['expires' => '2 day']);
        //$this->loadComponent('Csrf');
        $this->loadComponent('Auth', [
             'authenticate' => [
                'Form' => ['login-form' => 'Users',
                    'fields' => [
                        'username' => 'email',
                        'password' => 'password'
                    ]
                ]
            ],
            'loginAction' => [
                'controller' => 'Home',
                'action' => 'index'
            ],
            'loginRedirect' => [
                'controller' => 'Dashboard',
                'action' => 'index'
            ],
            'logoutRedirect' => [
                'controller' => 'Home',
                'action' => 'index'
            ],
             // If unauthorized, return them to page they were just on
            'unauthorizedRedirect' => ['controller' => 'Home', 'action' => 'index'],

            'authorize'            => 'Controller',
            'flash'                => [
                'element' => 'error',
            ],
        ]);

        /*
         * Enable the following component for recommended CakePHP security settings.
         * see https://book.cakephp.org/3.0/en/controllers/components/security.html
         */
        //$this->loadComponent('Security');
        //$this->loadComponent('Csrf');
    }

    public function beforeFilter(Event $event)
    {
        $this->loadModel('Products');
        $this->loadModel('SubCategories');
        $this->loadModel('Categories');
        $this->loadModel('Cart');
        $ip_address = $this->getClientIp();
        $params = $this->request->getAttribute('params');
       
        $this->SilverForm = new SilverFormHelper(new View());
        
        $sesscat = $this->request->session()->read('selectcat');
        if(!empty($sesscat)){
            $cat = $sesscat;
        }else{
            $cat = '';
        }
        if(!empty($cat))
        {
        $subcategories = $this->SubCategories->find()->contain(['Products'])->where(['status'=>1,'SubCategories.category_id'=>$cat])->order(['id' => 'DESC']);
        
        $products = $this->Products->find()->contain(['ProductImages'])->where(['today_deal_status'=>2,'Products.category_id'=>$cat])->toArray();
        }else{
         $subcategories = $this->SubCategories->find()->contain(['Products'])->where(['status'=>1])->order(['id' => 'DESC']);
        
        $products = $this->Products->find()->contain(['ProductImages'])->where(['today_deal_status'=>2])->toArray();   
        }
        $carts = $this->Cart->find()->select(['id'])->where(['Cart.user_id'=> $this->Auth->user('id')])->toArray();
                
        $total_items = count($carts);
        if(empty($cat)){
        $veg_categories = $this->Categories->find()
         ->contain(['SubCategories'=> function ($q) {
         return $q->select(['SubCategories.category_id','SubCategories.name', 'SubCategories.code'])
         ->where(['SubCategories.status' =>1]);
         }])
         ->where(['Categories.status'=> 1,'Categories.id'=>2])
         ->toArray();
        }else{
        if($cat == 2){
        $veg_categories = $this->Categories->find()
         ->contain(['SubCategories'=> function ($q) {
         return $q->select(['SubCategories.category_id','SubCategories.name', 'SubCategories.code'])
         ->where(['SubCategories.status' =>1]);
         }])
         ->where(['Categories.status'=> 1,'Categories.id'=>$cat])
         ->toArray(); 
        }         
        }
         if(empty($cat)){
         $non_veg_categories = $this->Categories->find()
         ->contain(['SubCategories'=> function ($q) {
         return $q->select(['SubCategories.category_id','SubCategories.name', 'SubCategories.code'])
        ->where(['SubCategories.status' =>1]);
       
         }])
         ->where(['Categories.status'=> 1,'Categories.id'=>1])
         ->toArray(); 
         }else{
        if($cat == 1){
            $non_veg_categories = $this->Categories->find()
             ->contain(['SubCategories'=> function ($q) {
             return $q->select(['SubCategories.category_id','SubCategories.name', 'SubCategories.code'])
            ->where(['SubCategories.status' =>1]);
           
             }])
             ->where(['Categories.status'=> 1,'Categories.id'=>$cat])
             ->toArray(); 
            }         
         }
        //echo '<pre>';print_r($products);exit;
        $this->set('veg_categories', $veg_categories);
        $this->set('non_veg_categories', $non_veg_categories);
        $this->set('subcategories', $subcategories);
        $this->set('products', $products);
        $this->set('total_items', $total_items);
        parent::beforeFilter($event);
    }

    public function beforeRender(Event $event)
    {
        $this->viewBuilder()->setClassName('App');
        $this->set('Configure', new Configure);
        $this->set('languages', $this->languages);
    }

    public function isAuthorized($user = null)
    {
        //return (bool) ($user['role_id'] === 1);
        return true;
    }

    

    public function getCurrentLanguage($value='')
    {
        return new Configure;
    }

    /***
     * @param $folder
     * @param $file
     * @param $itemId
     *
     */
    public function uploadFiles($folder, $file, $itemId = null) {
        $folder_url = WWW_ROOT.$folder;
        $rel_url = $folder;
        if(!is_dir($folder_url)) {
            mkdir($folder_url);
        }
        if($itemId) {
            $folder_url = WWW_ROOT.$folder.'/'.$itemId;
            $rel_url = $folder.'/'.$itemId;
            if(!is_dir($folder_url)) {
                mkdir($folder_url);
            }
        }
        // get file mime type
          /*  $fileInfo = finfo_open(FILEINFO_MIME_TYPE);
           $fileType = finfo_file($fileInfo, $file);
            finfo_close($fileInfo);*/

        

        // list of permitted file types, this is only images but documents can be added
        $permitted = array('image/jpeg','image/pjpeg','image/png','application/pdf','application/msword');
        $permitted_name = array('jpg','jpeg','png','pdf','doc','docx');
        $filename = str_replace(' ', '_', $file['name']);

        $typeOK = false;
        $filename_exploded = explode('.',$file['name']);
        //pr($file['type']); die();
        if(!empty($file)){
            $fname   = $file['tmp_name'];
            $finfo   = new finfo(FILEINFO_MIME);
            $fres    =  $finfo->file($fname);
            $infoArr = explode(';',$fres);
            
        }


        /*if(!in_array(end($filename_exploded), $permitted_name)){
            $result['errors'] = "Error uploading $filename. Please try again.";
            //pr($result); die();
        }elseif(!in_array($file['type'] , $permitted)){
            $result['errors'] = "Error uploading $filename. Please try again.";
            //pr($result); die();
        }*/
        if(!in_array(@$infoArr[0] , $permitted)){
            $result['errors'] = "Error uploading $filename. Please try again.";
        }elseif($file['error'] == 0) {
            
            switch($file['error']) {
                case 0:
                    if(!file_exists($folder_url.'/'.$filename)) {
                        $full_url = $folder_url.'/'.$filename;
                        $url = $rel_url.'/'.$filename;
                        $success = move_uploaded_file($file['tmp_name'], $full_url);
                        $newfile = $filename;
                    } else {
                        ini_set('date.timezone', 'Asia/Kolkata');
                        $now = date('Y-m-d-His');
                        $full_url = $folder_url.'/'.$now."_".$filename;
                        $url = $rel_url.'/'.$now."_".$filename;
                        $success = move_uploaded_file($file['tmp_name'], $full_url);
                        $newfile = $now."_".$filename;
                    }
                    if($success) {
                        $result = [
                            'filename'=>$newfile,
                            'url'=> $url,
                            'type'=>$file['type'],
                            'size'=>$file['size']
                        ];
                    } else {
                        $result['errors'] = "Error uploaded $filename. Please try again.";
                    }
                    break;
                case 3:
                    $result['errors'] = "Error uploading $filename. Please try again.";
                    break;
                default:
                    $result['errors'] = "System error uploading $filename. Contact webmaster.";
                    break;
            }
        } elseif($file['error'] == 4) {
            $result['nofiles'] = "No file Selected";
        }else {
            $result['errors'] = "$filename cannot be uploaded. Only Image is allowed.";
        }
        if(!empty($result['errors'])){
            $this->Flash->error($result['errors']);
            //return $this->redirect($this->referer());
        } else {
            return $result;
        }
    }
    
    public function CreatePdfDemoNew($content, $title, $image = NULL) {
        $this->autoRender = false;
        //$pdf = new DEMOPDF();
        $pdf = new HPDF($image);
        $pdf->AddPage();
        $pdf->SetTopMargin(30);
        $pdf->SetLeftMargin(10);
        $pdf->SetFillColor(53, 127, 63);
        $pdf->SetFont('times', 'R', 12);
        $pdf->SetFont('courier', 'R', 12);
        $pdf->SetFont('Helvetica', 'R', 12);
        $pdf->SetTextColor(0, 0, 0);
        $pdf->SetCompression(true);
        $pdf->SetTitle($title);
        $pdf->writeHTML($content, false, false, false, false, 'L');
        $tempfile = $title . date("Y") . '.pdf';
        $filename = WWW_ROOT . "/uploads/" . $tempfile;
        $pdf->Output($filename, 'F');
        return $tempfile;
        //exit();
    }
    
    public function getClientIp() {
        $ipaddress = '';
        if (getenv('HTTP_CLIENT_IP'))
            $ipaddress = getenv('HTTP_CLIENT_IP');
        else if (getenv('HTTP_X_FORWARDED_FOR'))
            $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
        else if (getenv('HTTP_X_FORWARDED'))
            $ipaddress = getenv('HTTP_X_FORWARDED');
        else if (getenv('HTTP_FORWARDED_FOR'))
            $ipaddress = getenv('HTTP_FORWARDED_FOR');
        else if (getenv('HTTP_FORWARDED'))
            $ipaddress = getenv('HTTP_FORWARDED');
        else if (getenv('REMOTE_ADDR'))
            $ipaddress = getenv('REMOTE_ADDR');
        else
            $ipaddress = 'UNKNOWN';
        return $ipaddress;
    }
}
