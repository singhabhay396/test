<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Event\Event;
use Cake\Mailer\Email;
use Cake\ORM\TableRegistry;
use Cake\Error\Exceptions;
use Cake\I18n\Time;
use Cake\Routing\Router;
use Cake\Auth\DefaultPasswordHasher;
use Cake\Utility\Text;
use Cake\Validation\Validator;

/**
 * Users Controller
 *
 * @property \App\Model\Table\UsersTable $Users
 *
 * @method \App\Model\Entity\User[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class UsersController extends AppController
{

    public function initialize()
    {
        parent::initialize();
        $this->Auth->allow(['login', 'forgotPassword', 'resetPassword', 'captcha','registration','emailcheck','mobileexists','jcryption','registrationVerification']);
        // load the Captcha component and set its parameter
        $this->loadComponent('CakephpCaptcha.Captcha');
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }

    /**
     * login method
     *
     * @return \Cake\Network\Response|null
     */
    
    /**
     * forgotPassword method
     *
     * @return \Cake\Network\Response|null
     */

    public function forgotPassword()
    {
        if ($this->request->getSession()->check('Auth.User')) {
            return $this->redirect(['controller' => 'Dashboard', 'action' => 'index']);
        }
        $this->viewBuilder()->setLayout('login');        
        if ($this->request->is('post')) {
            $errors = array();
            $captcha = $this->Captcha->check($this->request->getData('captcha'));
            if (empty($captcha)) {
                $errors['captcha']['_empty'] = 'Invalid captcha. Please try again.';
            }
            if (empty($errors)) {
                if (!empty(trim($this->request->getData('username')))) {
                    $username  = trim($this->request->getData('username'));
                    $validator = new Validator();
                    $validator->email('email');
                    $validError = $validator->errors(['email' => $username]);
                    if (empty($validError)) {
                        $UserExist = $this->Users->findByEmail($username)->first();
                    } else {
                        $UserExist = $this->Users->findByUsername($username)->first();
                    }
                    if ($UserExist) {
                        $UserExist->fp_token    = Text::uuid();
                        $UserExist->fp_token_at = date('Y-m-d H:i:s');
                        if ($this->Users->save($UserExist)) {
                            if (!empty($UserExist)) {
                                $emailData = [
                                    'setHelpers'     => ['Html'],
                                    'setTemplate'    => 'forgot_password',
                                    'setEmailFormat' => 'html',
                                    'setTo'          => trim($UserExist->email),
                                    'setSubject'     => __('Please reset your password'),
                                    'setViewVars'    => ['user' => $UserExist],
                                ];
                                $this->Email->send($emailData);
                            }
                            $this->Flash->success(__('Password reset instructions have been sent to your email address. You have 24 hours to complete the request.'));
                            return $this->redirect(['controller' => 'Users', 'action' => 'login']);
                        } else {
                            $this->Flash->error(__('Email not send successful, try again'));
                            return $this->redirect(['controller' => 'Users', 'action' => 'forgotPassword']);
                        }
                    } else {
                        $this->Flash->error(__('Invalid username, try again'));
                        return $this->redirect(['controller' => 'Users', 'action' => 'forgotPassword']);
                    }
                }
            } else {
                $this->Flash->error(__($errors['captcha']['_empty']));
                return $this->redirect(['controller' => 'Users', 'action' => 'forgotPassword']);
            }
        }
    }

    /**
     * Reset Password method
     *
     * @return \Cake\Http\Response|void
     */

    public function resetPassword($fp_token = null)
    {
        $this->viewBuilder()->setLayout('login');
        $user = $this->Users->newEntity();
        if (isset($fp_token)) {
            $TokenExist = $this->Users->findByFpToken($fp_token)->first();
            if ($TokenExist) {
                $tokenGeneratedDate = $TokenExist['fp_token_at'];
                $convertDate        = date("Y-m-d", strtotime($tokenGeneratedDate));
                if (strtotime($convertDate) <= strtotime('-1 day')) {
                    $TokenExist->fp_token    = "";
                    $TokenExist->fp_token_at = "";
                    $this->Users->save($TokenExist);
                    $this->Flash->error('Your link has been expired, try again.');
                    return $this->redirect(['controller' => 'Users', 'action' => 'forgotPassword']);
                } else {
                    if ($this->request->is('post')) {
                        $errors = [];
                        $captcha = $this->Captcha->check($this->request->getData('captcha'));
                        if (empty($captcha)) {
                            $errors['captcha']['_empty'] = 'Invalid captcha. Please try again.';
                        }
                        if (empty($errors)) {
                            $user = $this->Users->patchEntity($TokenExist, [
                                'new_password'     => $this->request->getData('password'),
                                'password'         => $this->request->getData('password'),
                                'confirm_password' => $this->request->getData('confirm_password'),
                            ], ['validate' => 'password']);
                            $user->fp_token    = "";
                            $user->fp_token_at = "";
                            if ($this->Users->save($user)) {
                                $this->__passwordLog($user);
                                if (!empty($user)) {
                                    /*$emailData = [
                                        'setHelpers'     => ['Html'],
                                        'setTemplate'    => 'resetpassword',
                                        'setEmailFormat' => 'html',
                                        'setTo'          => trim($user->email),
                                        'setSubject'     => __('You Password has changed'),
                                        'setViewVars'    => ['user' => $user],
                                    ];
                                    $this->Email->send($emailData);*/
                                }
                                $this->Flash->success(__('You Password has changed'));
                                return $this->redirect(['controller' => 'Users', 'action' => 'login']);
                            }
                        } else {
                            $this->Flash->error(__($errors['captcha']['_empty']));
                        }
                    }
                }
            } else {
                $this->Flash->error(__('Invalid Token.'));
                return $this->redirect(['controller' => 'Users', 'action' => 'login']);
            }
        } else {
            $this->Flash->error(__('Something missing in URL.'));
            return $this->redirect(['controller' => 'Users', 'action' => 'login']);
        }
        $this->set(compact('fp_token', 'user'));
        $this->set('_serialize', ['fp_token']);
    }

    protected function __passwordLog($user)
    {
        $changePasswordTable = TableRegistry::get('change_password_logs');
        $changePassword = $changePasswordTable->newEntity();
        $ipaddress = $_SERVER['REMOTE_ADDR'];
        if ($ipaddress == '::1') {
            $ipadd = '127.0.0.1';
        } else {
            $ipadd = $ipaddress;
        }
        $changePassword->user_id = $user->id;
        $changePassword->password = $user->password;
        $changePassword->change_time = date('Y-m-d H:i:s');
        $changePassword->ip_address = inet_pton($ipadd);
        $changePasswordTable->save($changePassword);
    }

    public function userLog()
    {
        $this->loadModel('AdminLogs');
        $rid = $this->Auth->user('role_id');
        $adminLog = $this->AdminLogs->find('all')
            ->contain(['Users'])
            ->order(['AdminLogs.id'=>'DESC']);
        if ($rid != 1) {
            $adminLog = $adminLog->where(['uid' => $this->Auth->user('id')]);
        }
        $this->paginate = ['limit' => 20];
        $adminLog = $this->paginate($adminLog);
        $this->set(compact('adminLog'));
    }

    public function changePasswordHistory()
    {
        $changePasswordTable = TableRegistry::get('change_password_logs');
        $changePassword = $changePasswordTable->find('all')->where(['user_id'=>$this->Auth->user('id')]);
        $this->paginate = ['limit' => 20];
        $changePassword = $this->paginate($changePassword);
        $this->set(compact('changePassword'));
    }
    
    /**
     * Change Password method
     *
     * @return \Cake\Http\Response|void
     */

    

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        return $this->redirect(['controller'=>'Users', 'action' => 'login']);
    }


    public function registration()
    {
        $this->viewBuilder()->setLayout('login');
        $user = $this->Users->newEntity();        
        if ($this->request->is('post')) {            
            $jcryption = new \JCryption;
            $jcryption->decrypt();
            $userdata = $_REQUEST;
            $errors = array();
            $captcha = $this->Captcha->check($userdata['captcha']);
            if (empty($captcha)) {
                $errors['captcha']['_empty'] = 'Invalid captcha. Please try again.';
            }            
            if (empty($errors)) {
                $userName = preg_replace('/([^@]*).*/', '$1', $userdata['email']);
                $password = trim($userdata['password']);
                $password = $this->Sanitize->stripAll( $password);
                $password = $this->Sanitize->clean( $password);
                $userRecord = [
                    'name'          => $userdata['name'],
                    'username'      => $userName,
                    'email'         => $userdata['email'],
                    'password'      => $password,
                    'role_id'       => $userdata['role_id'],
                    'status'        => 0,
                    'password_hint' => $userdata['confirm_password'],
                    'fp_token'      => Text::uuid(),
                    'fp_token_at'   => date('Y-m-d H:i:s')
                ];

                $user = $this->Users->patchEntity($user, $userRecord);
                if ($result = $this->Users->save($user)) {
                    $this->loadModel('Registration');
                    $registration = $this->Registration->newEntity();
                    $registration->user_id  = $result->id;                    
                    $registration->gender   = $userdata['gender'];
                    $registration->email    = $userdata['email'];
                    $registration->name     = $userdata['name'];
                    $registration->mobile_number  = $userdata['mobile_number'];
                    if ($this->Registration->save($registration)) {
                        $this->__passwordLog($result);
                        $this->__sendActivationEmail($result->id,$result->fp_token);
                        $this->Flash->success(__('Your account has been created successfully. Please activate your account by clicking on the link sent on your email.'));
                        return $this->redirect(['controller'=>'Users', 'action' => 'login']);
                    } else {
                        $inesrtedUser = $this->Users->get($result->id);
                        $this->Users->delete($inesrtedUser);
                        $this->Flash->error(__('Internal Server Error. Please, try again.'));
                    }
                } else {

                    $this->Flash->error(__('Your online registration could not be completed. Please, try again.'));
                }
            } else {
                if(!empty($errors['captcha']['_empty'])){
                    $this->Flash->error(__($errors['captcha']['_empty']));
                } else {
                    $this->Flash->error(__('Your Captcha is expire. Please refresh the page'));
                }
            }
        }
        $this->set(compact('user'));
    }

    protected function __sendActivationEmail($user_id, $token){
        if (empty($token) && empty($user_id)) {
            $this->Flash->success(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'login']);
        }
        $user = $this->Users->find()->where(['id'=>$user_id])->first();
        $link = Router::url('/en/users/registrationVerification/' . $token.'/'.$user->id, true);
        $to = $user->email;
        $subject = 'Startup – Registration Successful';
        $email = new Email('default');
        $email->template('activation_email')
            ->viewVars(['link'=>$link,'name'=>$user->name]);
            $email->addTo(trim($to));
            $email->addcc('nileshkumar.kushvaha@silvertouch.com');            
            $email->from(['noreply@startupharyana.org.in'])
            ->subject($subject)
            ->emailFormat('html')
            ->send();
    }

    public function registrationVerification($token,$user_id){
        if (empty($token) && empty($user_id)) {
            $this->Flash->success(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'login']);
        }
        $user = $this->Users->find()->where(['id'=>$user_id,'fp_token'=>$token])->first();
        if (empty($user['status'])) {
            $query = $this->Users->query();
            $query->update()
            ->set(['status'=>1,'fp_token'=>'','fp_token_at'=>''])
            ->where(['id' => $user->id])
            ->execute();

            $this->Flash->success(__('Your account has been successfully activated.'));
        } elseif ($user['status'] == 1) {
            $this->Flash->success(__('Your account has already been activated.'));            
        }
        return $this->redirect(['action' => 'login']);
    }

    public function jcryption()
    {
        $this->autoRender = false;
        $jc = new \JCryption;
        $jc->go();
        header('Content-type: text/plain');
    }

    public function captcha()
    {
        $this->autoRender = false;
        echo $this->Captcha->image(5);
    }

    public function emailcheck() {
        $this->viewBuilder()->setLayout('ajax');
        $email = $_POST['email'];        
        $emailResult = $this->Users->find('all', ['conditions' => ['email' => $email], 'fields' => ['email']])->enableHydration(false)->first();
        if (!empty($emailResult)) {
            echo 'false';
        } else {
            echo 'true';
        }
        exit();
    }

    public function mobileexists() {
        $this->loadModel('Registration');
        $this->viewBuilder()->setLayout('ajax');
        $mobileno = trim($_POST['mobile_number']);
        $newmobile = substr($mobileno, -10);
        $mobilenoResult = $this->Registration->find('all', ['conditions' => ['mobile_number' => $newmobile], 'fields' => ['mobile_number']])->enableHydration(false)->first();
        if (!empty($mobilenoResult)) {
            echo 'false';
        } else {
            echo 'true';
        }
        exit();
    }


    

}
