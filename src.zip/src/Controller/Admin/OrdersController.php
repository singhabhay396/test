<?php
namespace App\Controller\Admin;

use Cake\Controller\Controller;
use Cake\Event\Event;
use Cake\Mailer\Email;
use Cake\ORM\TableRegistry;
use Cake\View\View;
use Cake\Filesystem\Folder;
use Cake\Filesystem\File;
use Cake\I18n\Date;

class OrdersController extends AppController
{
    public function initialize()
    {
    parent::initialize();
    
   parent::initialize();
        $this->loadModel('UserProductOrderDetails');
        $this->loadModel('Users');
        $this->loadModel('Products');
        
    }

    public function beforeFilter(Event $event)
    {   
        parent::beforeFilter($event);
		if ($this->request->getSession()->check('Auth.User')) {
        }else{
        $this->Flash->error(__('You are not logged in'));
        return $this->redirect(['controller'=>'home','action'=>'/']);    
        }	
    }

	public function index(){
		$this->loadModel('Users');
        $this->loadModel('UserProductOrderDetails');
        $Query = $this->UserProductOrderDetails->find();
        $Query->select([ 
                      'order_id','order_time','amount',
                      'count' => $Query->func()->count('*')
                    ])
         ->group('UserProductOrderDetails.order_id')
         ->toArray();
       
        
        $this->set(compact('Query'));
	}

  
    
    public function orderInformation($orderid = null)
    {
        $this->loadModel('UserProductOrderDetails');
        if(!empty($orderid))
        {
        $Query = $this->UserProductOrderDetails->find()->contain(['Users','Products'])
         ->where(['order_id LIKE'=> '%'.$orderid.'%'])
         ->toArray();
       }else{
         $Query = '';   
       }
        //echo '<pre>';print_r($Query);exit;
        $this->set(compact('Query','user'));
    }
    
    
}
