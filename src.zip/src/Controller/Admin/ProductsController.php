<?php
namespace App\Controller\Admin;

use Cake\Controller\Controller;
use Cake\Event\Event;
use Cake\Mailer\Email;
use Cake\ORM\TableRegistry;
use Cake\View\View;
use Cake\Filesystem\Folder;
use Cake\Filesystem\File;
use Cake\I18n\Date;
require_once(ROOT . DS . 'webroot' . DS . 'razorpay-php'. DS . 'Razorpay.php');
use Razorpay\Api\Api;
use Razorpay\Api\Errors\SignatureVerificationError;
class ProductsController extends AppController
{
  Public $paginate = [
        'limit' => 10
    ];
    public function initialize()
    {
        parent::initialize();
        $this->loadModel('Categories');
        $this->loadModel('SubCategoriesImages');
        $this->loadModel('SubCategories');
        $this->loadModel('ProductImages');
        $this->loadModel('ProductPackImages');
        $this->loadModel('ProductWarehouse');
        //$this->Auth->allow(['mprPdf']);
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }

    public function index()
    {
        $user_id = $this->Auth->user('id');
        $role_id = $this->Auth->user('role_id');
        $products = $this->Products->find('all', [
            'contain' => ['Categories','SubCategories'],
            'order' => ['Products.id' => 'DESC'],
            'conditions' => ['Products.status'=>1]
        ]);
       // echo '<pre>';print_r($products->toArray());exit;
        $this->set(compact('products'));
    }

    public function view($id = null)
    {
        $products = $this->Products->find()->contain(['Categories','SubCategories','ProductImages','ProductPackImages'])->where(['Products.status'=> 1,'Products.id'=>$id])->first();
         //echo '<pre>';print_r($products);exit;
        $this->set(compact('products'));
    }

    public function add()
    {
        $user_id = $this->Auth->user('id');
        $role_id = $this->Auth->user('role_id');
        
        $products = $this->Products->newEntity();
        if ($this->request->is('post')) {
            $catDetails = $this->request->getData();
            
            $bppiStockDetails['code'] = $catDetails['code'];
            $bppiStockDetails['category_id'] = $catDetails['category_id'];
            $bppiStockDetails['sub_category_id'] = $catDetails['sub_category_id'];
            $bppiStockDetails['product_name'] = $catDetails['product_name'];
            $bppiStockDetails['products_price'] = $catDetails['products_price'];
            $bppiStockDetails['dis_percentage'] = $catDetails['dis_percentage'];
            $bppiStockDetails['price_after_discount'] = $catDetails['price_after_discount'];
            $bppiStockDetails['pack_size'] = $catDetails['pack_size'];
            $bppiStockDetails['no_package'] = $catDetails['no_package'];
            $bppiStockDetails['product_description'] = $catDetails['product_description'];
            $bppiStockDetails['ingredients'] = $catDetails['ingredients'];
            $bppiStockDetails['cook_process'] = $catDetails['cook_process'];
            $bppiStockDetails['brand_name'] = $catDetails['brand_name'];
            $bppiStockDetails['country_origin'] = $catDetails['country_origin'];
            $bppiStockDetails['created'] = date('Y-m-d');
            $bppiStockDetails['status'] = 1;
            if(isset($catDetails['today_deal_status']) && $catDetails['today_deal_status'] != 1){
            $bppiStockDetails['today_deal_status'] = $catDetails['today_deal_status'];
            }else{
            $bppiStockDetails['today_deal_status'] = 1;    
            }
            if(isset($catDetails['feature']) && $catDetails['feature'] != 1){
            $bppiStockDetails['feature'] = $catDetails['feature'];
            }
            $products = $this->Products->newEntity();
            $mpr = $this->Products->patchEntity($products, $bppiStockDetails);
            
            if ($res = $this->Products->save($mpr)) {
                
                if(isset($catDetails['filename']))
                {
                    foreach($catDetails['filename'] as $img)
                    {
                        if(!empty($img['name']) && $img['error'] == 0 && $img['size'] > 0)
                        {
                            $ext = substr(strtolower(strrchr($img['name'], '.')), 1); //get the extension
                            $setNewFileName = time() . "_" . rand(000000, 999999);
                            $file['name'] = $setNewFileName.'.'.$ext;
                            $arr_ext = array('jpg', 'jpeg', 'png'); //set allowed extensions
                            if(in_array($ext, $arr_ext))
                            {
                                $dir = WWW_ROOT . 'uploads/productimg/';
                                if(move_uploaded_file($img['tmp_name'], $dir.$file['name'])) 
                                { 
                                $details['filename'] = $file['name'];
                                $details['products_id'] = $res->id;
                                $details['status'] = 1;
                                $details['created'] = date('Y-m-d');
                                $prodImgEntity = $this->ProductImages->newEntity();
                                $prodImgPatchEntity = $this->ProductImages->patchEntity($prodImgEntity,$details);
                                $res_1 = $this->ProductImages->save($prodImgPatchEntity);	
                                }
                            }
                        }
                    }
                }
                
                if(isset($catDetails['product_pack_image']))
                {
                    foreach($catDetails['product_pack_image'] as $img)
                    {
                        if(!empty($img['name']) && $img['error'] == 0 && $img['size'] > 0)
                        {
                            $ext = substr(strtolower(strrchr($img['name'], '.')), 1); //get the extension
                            $setNewFileName = time() . "_" . rand(000000, 999999);
                            $file['name'] = $setNewFileName.'.'.$ext;
                            $arr_ext = array('jpg', 'jpeg', 'png'); //set allowed extensions
                            if(in_array($ext, $arr_ext))
                            {
                                $dir = WWW_ROOT . 'uploads/productpackimg/';
                                if(move_uploaded_file($img['tmp_name'], $dir.$file['name'])) 
                                { 
                                $details_1['product_pack_image'] = $file['name'];
                                $details_1['product_id'] = $res->id;
                                $details_1['created'] = date('Y-m-d');
                                $details_1['status'] = 1;
                                $prodPackImgEntity = $this->ProductPackImages->newEntity();
                                $prodPackImgPatchEntity = $this->ProductPackImages->patchEntity($prodPackImgEntity,$details_1);
                                $res_1 = $this->ProductPackImages->save($prodPackImgPatchEntity);	
                                }
                            }
                        }
                    }
                }
               
                $this->Flash->success(__('The product has been saved.'));
                return $this->redirect(['action' => 'index']);
            }else{
            $this->Flash->error(__('The product could not be saved. Please, try again.'));
            return $this->redirect(['action' => 'index']);
            }
        }
       $categories = $this->Categories->find('list', ['keyField' => 'id', 'valueField' => 'name'])->where(['status'=>1])->order(['id' => 'ASC']);
       
       
       
        $this->set(compact('products','categories'));
    }
    
    public function edit($id = null)
    {
        $user_id = $this->Auth->user('id');
        $role_id = $this->Auth->user('role_id');
        $products = $this->Products->get($id,['contain' => ['SubCategories','ProductImages','ProductPackImages']]);
         if ($this->request->is(['post', 'put'])) {
            $catDetails = $this->request->getData();
           // echo '<pre>';print_r($catDetails);exit;
           $bppiStockDetails['product_name'] = $catDetails['product_name'];
            $bppiStockDetails['products_price'] = $catDetails['products_price'];
            $bppiStockDetails['dis_percentage'] = $catDetails['dis_percentage'];
            $bppiStockDetails['price_after_discount'] = $catDetails['price_after_discount'];
            $bppiStockDetails['pack_size'] = $catDetails['pack_size'];
            $bppiStockDetails['no_package'] = $catDetails['no_package'];
            $bppiStockDetails['product_description'] = $catDetails['product_description'];
            $bppiStockDetails['ingredients'] = $catDetails['ingredients'];
            $bppiStockDetails['cook_process'] = $catDetails['cook_process'];
            $bppiStockDetails['brand_name'] = $catDetails['brand_name'];
            $bppiStockDetails['country_origin'] = $catDetails['country_origin'];
             if(isset($catDetails['today_deal_status']) && $catDetails['today_deal_status'] != 1){
            $bppiStockDetails['today_deal_status'] = $catDetails['today_deal_status'];
            }else{
            $bppiStockDetails['today_deal_status'] = 1;    
            }
            if(isset($catDetails['feature']) && $catDetails['feature'] != 1){
            $bppiStockDetails['feature'] = $catDetails['feature'];
            }else{
            $bppiStockDetails['feature'] = 1;    
            }
            
            $mpr = $this->Products->patchEntity($products, $bppiStockDetails);
           
            if ($res = $this->Products->save($mpr)) {
                if(isset($catDetails['filename']))
                {
                    foreach($catDetails['filename'] as $img)
                    {
                        if(!empty($img['name']) && $img['error'] == 0 && $img['size'] > 0)
                        {
                            $ext = substr(strtolower(strrchr($img['name'], '.')), 1); //get the extension
                            $setNewFileName = time() . "_" . rand(000000, 999999);
                            $file['name'] = $setNewFileName.'.'.$ext;
                            $arr_ext = array('jpg', 'jpeg', 'png'); //set allowed extensions
                            if(in_array($ext, $arr_ext))
                            {
                                $dir = WWW_ROOT . 'uploads/productimg/';
                                if(move_uploaded_file($img['tmp_name'], $dir.$file['name'])) 
                                { 
                                $details['filename'] = $file['name'];
                                $details['products_id'] = $res->id;
                                $details['status'] = 1;
                                $details['created'] = date('Y-m-d');
                                $prodImgEntity = $this->ProductImages->newEntity();
                                $prodImgPatchEntity = $this->ProductImages->patchEntity($prodImgEntity,$details);
                                $res_1 = $this->ProductImages->save($prodImgPatchEntity);	
                                }
                            }
                        }
                    }
                }
                
                if(isset($catDetails['product_pack_image']))
                {
                    foreach($catDetails['product_pack_image'] as $img)
                    {
                        if(!empty($img['name']) && $img['error'] == 0 && $img['size'] > 0)
                        {
                            $ext = substr(strtolower(strrchr($img['name'], '.')), 1); //get the extension
                            $setNewFileName = time() . "_" . rand(000000, 999999);
                            $file['name'] = $setNewFileName.'.'.$ext;
                            $arr_ext = array('jpg', 'jpeg', 'png'); //set allowed extensions
                            if(in_array($ext, $arr_ext))
                            {
                                $dir = WWW_ROOT . 'uploads/productpackimg/';
                                if(move_uploaded_file($img['tmp_name'], $dir.$file['name'])) 
                                { 
                                $details_1['product_pack_image'] = $file['name'];
                                $details_1['product_id'] = $res->id;
                                $details_1['created'] = date('Y-m-d');
                                $details_1['status'] = 1;
                                $prodPackImgEntity = $this->ProductPackImages->newEntity();
                                $prodPackImgPatchEntity = $this->ProductPackImages->patchEntity($prodPackImgEntity,$details_1);
                                $res_1 = $this->ProductPackImages->save($prodPackImgPatchEntity);	
                                }
                            }
                        }
                    }
                }
                
                $this->Flash->success(__('The product detail has been saved.'));
                return $this->redirect(['action' => 'edit',$id]);
            }else{
                $this->Flash->error(__('The product could not be saved. Please, try again.'));
                return $this->redirect(['action' => 'list']);
            }
            $subcategories = $this->SubCategories->find('list', ['keyField' => 'id', 'valueField' => 'name'])->where(['status'=>1])->order(['id' => 'ASC']);
        }
        $this->set(compact('products','subcategories'));        
    } 
     public function delete($id = null)
    {
        $products = $this->Products->get($id);
        if ($this->Products->delete($products)) {
            $this->Flash->success(__('The product has been deleted.'));
        } else {
            $this->Flash->error(__('The product could not be deleted. Please, try again.'));
        }
        return $this->redirect(['action' => 'index']);
    }
    
    public function deleteProdImg()
    {
        $this->viewBuilder()->layout('ajax');
        $this->loadModel('ProductImages');
        $id = $_REQUEST['id'];
        $file = $_REQUEST['file_name'];
        $folder = $_REQUEST['folder'];
        $product_img = $this->ProductImages->get($id);
        $this->ProductImages->delete($product_img);
        exit;
    }
    
    public function deleteProdPack()
    {
        $this->viewBuilder()->layout('ajax');
        $this->loadModel('ProductPackImages');
        $id = $_REQUEST['id'];
        $file = $_REQUEST['file_name'];
        $folder = $_REQUEST['folder'];
        $product_pack_img = $this->ProductPackImages->get($id);
        $this->ProductPackImages->delete($product_pack_img);
        exit;
    }
    
    public function getSubcategories()
    {
        $this->viewBuilder()->layout('ajax');
        $this->loadModel('SubCategories');
        $category_id = $_GET['category_id'];
        $res = '';
        $subcategories = $this->SubCategories->find()->where(['status'=>1,'category_id'=>$category_id])->order(['id' => 'ASC']);
        if(!empty($subcategories))
        {
         foreach($subcategories as $v){
         $res .='<option value="'.$v->id.'">'.$v->name.'</option>';  
         }
        }
        echo $res;
        exit;
    }
    
    public function getProductCode()
    {
        $this->viewBuilder()->layout('ajax');
        $this->loadModel('ProductWarehouse');
        $category_id = $_GET['category_id'];
        $sub_category_id = $_GET['sub_category_id'];
        $res = '';
        $getProductDetails = $this->ProductWarehouse->find()->select(['product_code','product_name'])->where(['sub_category_id'=>$sub_category_id,'category_id'=>$category_id])->order(['id' => 'ASC']);
        if(!empty($getProductDetails))
        {
         
         foreach($getProductDetails as $v){
         $getProducts = $this->Products->find()->select(['id'])->where(['sub_category_id'=>$sub_category_id,'category_id'=>$category_id,'code LIKE'=>'%'.$v->product_code.'%'])->first();
             if(empty($getProducts)){
             $res .='<option value="'.$v->product_code.'">'.$v->product_name.'</option>';
             }
         }
        }
        echo $res;
        exit;
    }
    
    public function getProductName()
    {
        $this->viewBuilder()->layout('ajax');
        $this->loadModel('ProductWarehouse');
        $category_id = $_GET['category_id'];
        $sub_category_id = $_GET['sub_category_id'];
        $code = $_GET['code'];
        $res = '';
        $getProductDetails = $this->ProductWarehouse->find()->select(['product_code','product_name','product_amount'])->where(['sub_category_id'=>$sub_category_id,'category_id'=>$category_id,'product_code LIKE'=>'%'.$code.'%'])->first();
        
        $res =$getProductDetails->product_name;
        $res1 =$getProductDetails->product_amount;
        echo $res.'@'.$res1;
        exit;
    }
    
   /*  public function pay()
    {
       
    }
    
    public function paymentIntegrate()
    {
        
        $keyId = 'rzp_test_F6SP6iPEe8qGgV';
        $keySecret = 'JdJE9FPJYB1VXoHC627X02CS';
        $api = new Api($keyId, $keySecret);
        $orderData = [
        'receipt' => 3456,
        'amount' => $_POST['amount'] * 100,
        'currency' => $_POST['currency'],
        'payment_capture' => 1
        ];
        
        $razorpayOrder = $api->order->create($orderData);
        $razorpayOrderId = $razorpayOrder['id'];
        $_SESSION['razorpay_order_id'] = $razorpayOrderId;
        $displayAmount = $amount = $orderData['amount'];
        if ($displayCurrency !== 'INR') {
            $url = "https://api.fixer.io/latest?symbols=$displayCurrency&base=INR";
            $exchange = json_decode(file_get_contents($url), true);

            $displayAmount = $exchange['rates'][$displayCurrency] * $amount / 100;
        }
        $data = [
            "key"               => $keyId,
            "amount"            => $amount,
            "name"              => $_POST['item_name'],
            "description"       => $_POST['item_description'],
            "image"             => "",
            "prefill"           => [
            "name"              => $_POST['cust_name'],
            "email"             => $_POST['email'],
            "contact"           => $_POST['contact'],
            ],
            "notes"             => [
            "address"           => $_POST['address'],
            "merchant_order_id" => "12312321",
            ],
            "theme"             => [
            "color"             => "#F37254"
            ],
            "order_id"          => $razorpayOrderId,
        ];

        if ($displayCurrency !== 'INR')
        {
            $data['display_currency']  = $displayCurrency;
            $data['display_amount']    = $displayAmount;
        }

        $json = json_encode($data);
       
        $this->set('json',$json);
       
    }
    
    public function manual()
    {
        $json = $_POST['datajson'];
       
        if(!empty($json))
        {
          $this->set('json',$json);  
        }else{
         return $this->redirect(['controller'=>'products','action' =>'pay']);   
        }
    
    }
    
    public function verify()
    {
        $success = true;

        $error = "Payment Failed";

        if (empty($_POST['razorpay_payment_id']) === false)
        {
            $api = new Api($keyId, $keySecret);

            try
            {
                $attributes = array(
                    'razorpay_order_id' => $_SESSION['razorpay_order_id'],
                    'razorpay_payment_id' => $_POST['razorpay_payment_id'],
                    'razorpay_signature' => $_POST['razorpay_signature']
                );

                $api->utility->verifyPaymentSignature($attributes);
            }
            catch(SignatureVerificationError $e)
            {
                $success = false;
                $error = 'Razorpay Error : ' . $e->getMessage();
            }
        }

        if ($success === true)
        {
            $html = "<p>Your payment was successful</p>
                     <p>Payment ID: {$_POST['razorpay_payment_id']}</p>";
        }
        else
        {
            $html = "<p>Your payment failed</p>
                     <p>{$error}</p>";
        }

        
        $this->set('html',$html);
    } */
}
