<?php
namespace App\Controller\Admin;

use Cake\Controller\Controller;
use Cake\Event\Event;
use Cake\Mailer\Email;
use Cake\ORM\TableRegistry;
use Cake\View\View;
use Cake\Filesystem\Folder;
use Cake\Filesystem\File;
use Cake\I18n\Date;
class CategoriesController extends AppController
{
  Public $paginate = [
        'limit' => 10
    ];
    public function initialize()
    {
        parent::initialize();
        //$this->Auth->allow(['mprPdf']);
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function list()
    {
        $user_id = $this->Auth->user('id');
        $role_id = $this->Auth->user('role_id');
        $categories = $this->Categories->find()->toArray();
        $this->set(compact('categories'));
    }

    public function view($id = null)
    {
            $categories = $this->Categories->find()->where(['Categories.status'=> 1])->toArray();
            $this->set(compact('categories'));
    }

    public function add()
    {
        $user_id = $this->Auth->user('id');
        $role_id = $this->Auth->user('role_id');
           
        $categories = $this->Categories->newEntity();
        if ($this->request->is('post')) {
            $catDetails = $this->request->getData();
            $bppiStockDetails['status'] = 1;
            $bppiStockDetails['created_at'] = date('Y-m-d');
            $bppiStockDetails['name'] = $catDetails['name'];

            $mpr = $this->Categories->patchEntity($categories, $bppiStockDetails);
            if ($res = $this->Categories->save($mpr)) {
                $this->Flash->success(__('The category has been saved.'));
                return $this->redirect(['action' => 'list']);
            }
            $this->Flash->error(__('The category could not be saved. Please, try again.'));
        }
        $this->set(compact('categories'));
    }
    
    public function edit($id = null)
    {
        $user_id = $this->Auth->user('id');
        $role_id = $this->Auth->user('role_id');
        $categories = $this->Categories->get($id);
         if ($this->request->is(['post', 'put'])) {
            $bppiStockDetails = $this->request->getData();
            $data['name'] = $bppiStockDetails['name'];
            $data['modified_at'] = date('Y-m-d');
            $insertEntity = $this->Categories->patchEntity($categories,$data);
            $save_details = $this->Categories->save($insertEntity);
            $this->Flash->success(__('The category detail has been saved.'));
            return $this->redirect(['action' => 'edit',$id]);
        }
        $this->set(compact('categories'));        
    } 
     public function delete($id = null)
    {
        $categories = $this->Categories->get($id);
        if ($this->Categories->delete($categories)) {
            $this->Flash->success(__('The category has been deleted.'));
        } else {
            $this->Flash->error(__('The category could not be deleted. Please, try again.'));
        }
        return $this->redirect(['action' => 'list']);
    }
}
