<?php
namespace App\Controller\Admin;

use Cake\Controller\Controller;
use Cake\Event\Event;
use Cake\Mailer\Email;
use Cake\ORM\TableRegistry;
use Cake\View\View;
use Cake\Filesystem\Folder;
use Cake\Filesystem\File;
use Cake\I18n\Date;

class ProductWarehouseController extends AppController
{
  Public $paginate = [
        'limit' => 10
    ];
    public function initialize()
    {
        parent::initialize();
        $this->loadModel('ProductWarehouse');
        $this->loadModel('Categories');
        $this->loadModel('SubCategories');
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }

    public function index()
    {
        $list = $this->ProductWarehouse->find('all', [
            'order' => ['ProductWarehouse.id' => 'DESC']
        ]);
       // echo '<pre>';print_r($products->toArray());exit;
        $this->set(compact('list'));
    }

    public function view($id = null)
    {
        $prodWareHouse = $this->ProductWarehouse->find()->where(['ProductWarehouse.id'=>$id])->first();
        $this->set(compact('prodWareHouse'));
    }

    public function add()
    {
        $prodWarHouse = $this->ProductWarehouse->newEntity();
        
        if ($this->request->is('post')) {
            $warHouseDetails = $this->request->getData();
            $length = 15;
            $characters = '0123456789ABCDEFGHIJKLMNOPQRST';
            $str_length = substr(str_shuffle($characters), 0, $length);
            if($warHouseDetails['category_id'] == 1){$cat = 'NV';}
            if($warHouseDetails['category_id'] == 2){$cat = 'V';}
            
            $subCatDetails = $this->SubCategories->find()->select(['name'])->where(['SubCategories.id'=>$warHouseDetails['sub_category_id']])->first();
            
            $catDetails = $this->Categories->find()->select(['name'])->where(['Categories.id'=>$warHouseDetails['category_id']])->first();
            
            $subcat = substr($subCatDetails->name, 0, 3);  // returns First 3 Characters
            
            $arr['product_code'] = $cat.$subcat.$str_length;
            $arr['product_amount'] = $warHouseDetails['product_amount'];
            $arr['category_id'] = $warHouseDetails['category_id'];
            $arr['sub_category_id'] = $warHouseDetails['sub_category_id'];
            $arr['sub_category_name'] = $subCatDetails->name;
            $arr['category_name'] = $catDetails->name;
            $arr['product_name'] = $warHouseDetails['product_name'];
            $arr['created_at'] = date('Y-m-d H:i:s');
            $prodWarHouse = $this->ProductWarehouse->patchEntity($prodWarHouse, $arr);
            if ($res = $this->ProductWarehouse->save($prodWarHouse)) {
                $this->Flash->success(__('Detail has been saved.'));
                return $this->redirect(['action' => 'index']);
            }else{
            $this->Flash->error(__('Detail could not be saved.'));
            return $this->redirect(['action' => 'add']);
            }
        }
        $categories = $this->Categories->find('list', ['keyField' => 'id', 'valueField' => 'name'])->where(['status'=>1])->order(['id' => 'ASC']);
        
        $subcategories = $this->SubCategories->find('list', ['keyField' => 'id', 'valueField' => 'name'])->where(['status'=>1])->order(['id' => 'ASC']);
        $this->set(compact('prodWarHouse','categories','subcategories'));
    }
    
    public function edit($id = null)
    {
        
        $prodWarHouse = $this->ProductWarehouse->get($id);
         if ($this->request->is(['post', 'put'])) {
            $warHouseDetails = $this->request->getData();
            $arr['product_amount'] = $warHouseDetails['product_amount'];
            $arr['product_name'] = $warHouseDetails['product_name'];
            $prodWarHouse = $this->ProductWarehouse->patchEntity($prodWarHouse, $arr);
            if ($res = $this->ProductWarehouse->save($prodWarHouse)) {
                $this->Flash->success(__('Detail has been saved.'));
                return $this->redirect(['action' => 'edit',$id]);
            }else{
                $this->Flash->error(__('Detail could not be saved.'));
                return $this->redirect(['action' => 'index']);
            }
            
        }
        $this->set(compact('prodWarHouse'));        
    } 
}
