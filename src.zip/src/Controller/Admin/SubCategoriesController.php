<?php
namespace App\Controller\Admin;

use Cake\Controller\Controller;
use Cake\Event\Event;
use Cake\Mailer\Email;
use Cake\ORM\TableRegistry;
use Cake\View\View;
use Cake\Filesystem\Folder;
use Cake\Filesystem\File;
use Cake\I18n\Date;
class SubCategoriesController extends AppController
{
  Public $paginate = [
        'limit' => 10
    ];
    public function initialize()
    {
        parent::initialize();
        $this->loadModel('Categories');
        $this->loadModel('SubCategoriesImages');
        //$this->Auth->allow(['mprPdf']);
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }

    public function list()
    {
        $user_id = $this->Auth->user('id');
        $role_id = $this->Auth->user('role_id');
        $sub_categories = $this->SubCategories->find('all', [
            'contain' => ['Categories'],
            'order' => ['SubCategories.id' => 'DESC'],
            'conditions' => ['SubCategories.status'=>1]
        ]);
        
        $this->set(compact('sub_categories'));
    }

    public function view($id = null)
    {
        $sub_categories = $this->SubCategories->find()->contain(['Categories','SubCategoriesImages'])->where(['SubCategories.status'=> 1,'SubCategories.id'=>$id])->first();
      //  echo '<pre>';print_r($sub_categories);exit;
        $this->set(compact('sub_categories'));
    }

    public function add()
    {
        $user_id = $this->Auth->user('id');
        $role_id = $this->Auth->user('role_id');
           
        $subcategories = $this->SubCategories->newEntity();
        if ($this->request->is('post')) {
            $catDetails = $this->request->getData();
            $length = 15;
            $characters = '0123456789ABCDEFGHIJKLMNOPQRST#&';
            $str_length = substr(str_shuffle($characters), 0, $length);
            $bppiStockDetails['code'] = $str_length;
            $bppiStockDetails['status'] = 1;
            $bppiStockDetails['created_at'] = date('Y-m-d');
            $bppiStockDetails['category_id'] = $catDetails['category_id'];
            $bppiStockDetails['name'] = $catDetails['name'];

            $mpr = $this->SubCategories->patchEntity($subcategories, $bppiStockDetails);
            if ($res = $this->SubCategories->save($mpr)) {
                
                if(isset($catDetails['image_file']))
                {
                    foreach($catDetails['image_file'] as $img)
                    {
                        if(!empty($img['name']) && $img['error'] == 0 && $img['size'] > 0)
                        {
                            $ext = substr(strtolower(strrchr($img['name'], '.')), 1); //get the extension
                            $setNewFileName = time() . "_" . rand(000000, 999999);
                            $file['name'] = $setNewFileName.'.'.$ext;
                            $arr_ext = array('jpg', 'jpeg', 'png'); //set allowed extensions
                            if(in_array($ext, $arr_ext))
                            {
                                $dir = WWW_ROOT . 'uploads/subcat/';
                                if(move_uploaded_file($img['tmp_name'], $dir.$file['name'])) 
                                { 
                                $details['image_file'] = $file['name'];
                                $details['sub_category_id'] = $res->id;
                                $details['created'] = date('Y-m-d');
                                $subCategoriesEntity = $this->SubCategoriesImages->newEntity();
                                $subcategoriesPatchEntity = $this->SubCategoriesImages->patchEntity($subCategoriesEntity,$details);
                                $res_1 = $this->SubCategoriesImages->save($subcategoriesPatchEntity);	
                                }
                            }
                        }
                    }
                }
               
                $this->Flash->success(__('The sub category has been saved.'));
                return $this->redirect(['action' => 'list']);
            }else{
            $this->Flash->error(__('The sub category could not be saved. Please, try again.'));
            return $this->redirect(['action' => 'list']);
            }
        }
        $categories = $this->Categories->find('list', ['keyField' => 'id', 'valueField' => 'name'])->where(['status'=>1])->order(['id' => 'ASC']);
       
        $this->set(compact('subcategories','categories'));
    }
    
    public function edit($id = null)
    {
        $user_id = $this->Auth->user('id');
        $role_id = $this->Auth->user('role_id');
        $subcategories = $this->SubCategories->get($id,['contain' => ['SubCategoriesImages','Categories']]);
         
         if ($this->request->is(['post', 'put'])) {
            $catDetails = $this->request->getData();
            //echo '<pre>';print_r($catDetails);exit;
            $bppiStockDetails['status'] = 1;
            $bppiStockDetails['modified_at'] = date('Y-m-d');
            $bppiStockDetails['name'] = $catDetails['name'];

            $mpr = $this->SubCategories->patchEntity($subcategories, $bppiStockDetails);
            if ($res = $this->SubCategories->save($mpr)) {
                if(!empty($catDetails['image_file']))
                {
                    foreach($catDetails['image_file'] as $img)
                    {
                        if(!empty($img['name']) && $img['error'] == 0 && $img['size'] > 0)
                        {
                            $ext = substr(strtolower(strrchr($img['name'], '.')), 1); //get the extension
                            $setNewFileName = time() . "_" . rand(000000, 999999);
                            $file['name'] = $setNewFileName.'.'.$ext;
                            $arr_ext = array('jpg', 'jpeg', 'png'); //set allowed extensions
                            if(in_array($ext, $arr_ext))
                            {
                                $dir = WWW_ROOT . 'uploads/subcat/';
                                if(move_uploaded_file($img['tmp_name'], $dir.$file['name'])) 
                                { 
                                $details['image_file'] = $file['name'];
                                $details['sub_category_id'] = $res->id;
                                $details['created'] = date('Y-m-d');
                                $subCategoriesEntity = $this->SubCategoriesImages->newEntity();
                                $subcategoriesPatchEntity = $this->SubCategoriesImages->patchEntity($subCategoriesEntity,$details);
                                $res_1 = $this->SubCategoriesImages->save($subcategoriesPatchEntity);	
                                }
                            }
                        }
                    }
                }
                
                $this->Flash->success(__('The sub category detail has been saved.'));
                return $this->redirect(['action' => 'edit',$id]);
            }else{
                $this->Flash->error(__('The sub category could not be saved. Please, try again.'));
                return $this->redirect(['action' => 'list']);
            }
           
        }
        $this->set(compact('subcategories'));        
    } 
     public function delete($id = null)
    {
        $sub_categories = $this->SubCategories->get($id);
        if ($this->SubCategories->delete($sub_categories)) {
            $this->Flash->success(__('The sub category has been deleted.'));
        } else {
            $this->Flash->error(__('The sub category could not be deleted. Please, try again.'));
        }
        return $this->redirect(['action' => 'list']);
    }
    
     public function deleteFile()
    {
        $this->viewBuilder()->layout('ajax');
        $this->loadModel('SubCategoriesImages');
        $id = $_REQUEST['id'];
        $file = $_REQUEST['file_name'];
        $folder = $_REQUEST['folder'];
        $sub_categories_img = $this->SubCategoriesImages->get($id);
        $this->SubCategoriesImages->delete($sub_categories_img);
        exit;
    }
}
