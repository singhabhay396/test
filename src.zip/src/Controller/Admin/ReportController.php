<?php
namespace App\Controller\Admin;

use Cake\Controller\Controller;
use Cake\Event\Event;
use Cake\Mailer\Email;
use Cake\ORM\TableRegistry;
use Cake\View\View;
use Cake\Filesystem\Folder;
use Cake\Filesystem\File;
use Cake\I18n\Date;

class ReportController extends AppController
{
  Public $paginate = [
        'limit' => 10
    ];
    public function initialize()
    {
        parent::initialize();
        $this->loadModel('Categories');
        $this->loadModel('SubCategoriesImages');
        $this->loadModel('SubCategories');
        $this->loadModel('Products');
        $this->loadModel('ProductImages');
        $this->loadModel('ProductPackImages');
        $this->loadModel('ProductWarehouse');
        $this->loadModel('UserProductOrderDetails');
        $this->loadModel('Users');
        //$this->Auth->allow(['mprPdf']);
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }

    public function index()
    {
		if ($this->request->is('GET')) {
			if (!empty($this->request->query['user_id'])) {
                $user_id = $this->request->query['user_id'];
                $this->set('user_id', $this->request->query['user_id']);
                $search_condition1[] = "Users.id='" . $user_id. "'";
            }

            if (!empty($this->request->query['city'])) {
                $city = $this->request->query['city'];
				$this->set('city', $this->request->query['city']);
                $search_condition1[] = "UserProductOrderDetails.city like '%" . $city . "%'";
            }

            if (!empty($this->request->query['product_id'])) {
				$product_id = $this->request->query['product_id'];
                $this->set('product_id', $this->request->query['product_id']);
                $search_condition1[] = "UserProductOrderDetails.product_id=".$product_id;
            }

			if (!empty($this->request->query['order_time'])) {
				$order_time = date('Y-m-d',strtotime($this->request->query['order_time']));
                $this->set('order_time', $this->request->query['order_time']);
                $search_condition1[] = "UserProductOrderDetails.order_time like '%" . $order_time ."%'";
            }


            if (!empty($search_condition1)) {
                $searchString1 = implode(" AND ", $search_condition1);
            } else {
                $searchString1 = '';
            }
        if(!empty($searchString1)){
        $report = $this->UserProductOrderDetails->find('all', [
            'contain' => ['Users','Products'],
            'order' => ['UserProductOrderDetails.id' => 'DESC'],
			'conditions' => [$searchString1]
        ]);
		}else{
		 $report = $this->UserProductOrderDetails->find('all', [
            'contain' => ['Users','Products','Users.UserBillingDetails','Users.UserDeliveryDetails'],
            'order' => ['UserProductOrderDetails.id' => 'DESC']
        ]);	
		}    
        if (!empty($this->request->query['export_excel'])) {
            $fileName = "REPORT_" . date("d-m-Y H:i:s") . ".xls";
            $headerRow = array("S.No", "CUSTOMER NAME", "PRODUCT NAME", "PRODUCT CODE", "ORDER MODE", "ORDER ID", "PAY AMOUNT", "PAYMENT ID", "ORDER TIME", "CITY","STATE","COUNTRY");
            $data = array();
            $i = 1;
            foreach ($report As $rows) {
               
                $cust_name =$rows->user->name;
                $prod_name =$rows->product->product_name;
                $prod_code =$rows->product->code;
                $payment_method =$rows->payment_method;
                $order_id =$rows->order_id;
                $amount =$rows->amount;
                $razorpay_payment_id =$rows->razorpay_payment_id;
                $order_time =date('d-M-Y', strtotime($rows->order_time));
                $city =$rows->city;
                $state =$rows->state;
                $country =$rows->country;
                
                $data[] = array($i, $cust_name, $prod_name, $prod_code, $payment_method,
                    $order_id, $amount, $razorpay_payment_id, $order_time,$city,$state,$country);
                $i++;
            }
            $this->exportInExcel($fileName, $headerRow, $data);
		}
        }
		$products = $this->Products->find()->select(['id','product_name'])->where(['status'=>1])->toArray();   
		$users = $this->Users->find()->select(['id','name'])->where(['role_id'=>9])->toArray();

		
       // echo '<pre>';print_r($report->toArray());exit;
        $this->set(compact('report','products','users'));
    }
    
    public function view($order = NULL)
    {
        $this->loadModel('Users');
        $this->loadModel('Products');
        $this->loadModel('UserProductOrderDetails');
        $Query = $this->UserProductOrderDetails
        ->find()
        ->contain(['Users','Products'])
        ->where(['UserProductOrderDetails.id'=> $order])
        ->order(['UserProductOrderDetails.id'=>'DESC'])
        ->first();
       
        //echo '<pre>';print_r($Query);exit;
        $this->set(compact('Query'));
    }
    
    public function invoiceList($order = NULL)
    {
        
    }
    
    public function addInvoice()
    {
        
    }
    
    public function editInvoice($invid = NULL)
    {
        
    }
    
    public function viewInvoice($invid = NULL)
    {
        
    }
    
    public function deleteProdImg()
    {
        $this->viewBuilder()->layout('ajax');
        $this->loadModel('ProductImages');
        $id = $_REQUEST['id'];
        $file = $_REQUEST['file_name'];
        $folder = $_REQUEST['folder'];
        $product_img = $this->ProductImages->get($id);
        $this->ProductImages->delete($product_img);
        exit;
    }
    
   
}
