<?php
namespace App\Controller\Admin;

use App\Controller\Admin\AppController;
use Cake\Event\Event;

class BannersController extends AppController
{
    public function initialize()
    {
        parent::initialize();
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }

    public function index()
    {
            $bannerQuery = $this->Banners->find()->where(['status'=>1]);
            $this->paginate = ['limit' => 10];
            $banners = $this->paginate($bannerQuery);
            $this->set(compact('banners'));
    
    }

    public function view($id = null)
    {
        $banner = $this->Banners->get($id);
        $this->set('banner', $banner);
    }

    public function add()
    {
        $banner = $this->Banners->newEntity();
        if ($this->request->is('post')) {
            
            if ($this->request->data['file_name']) {
                if($this->request->data['file_name']['name']!='' && $this->request->data['file_name']['size'] > 0 && $this->request->data['file_name']['error'] == 0)
                {  
                    $ext = substr(strtolower(strrchr($this->request->data['file_name']['name'], '.')), 1); //get the extension
                    $setNewFileName = time() . "_" . rand(000000, 999999);
                    $arr['file_name'] = $setNewFileName.'.'.$ext;
                    $arr_ext = array('jpg', 'jpeg', 'png'); //set allowed extensions
                        if(in_array($ext, $arr_ext))
                        {
                            $dir = WWW_ROOT . 'uploads/banners/';
                            if(move_uploaded_file($this->request->data['file_name']['tmp_name'], $dir.$arr['file_name'])) 
                            {
                               
                                $arr['name'] = $this->request->data['name'];
                               
                                $banner = $this->Banners->patchEntity($banner, $arr);
                                if ($this->Banners->save($banner)) {
                                    $this->Flash->success(__('Banners saved successfully.'));
                                    return $this->redirect(['action' => 'index']);
                                }else{
                                $this->Flash->error(__('The banner could not be saved. Please, try again.')); 
                                }
                            }else{
                            $this->Flash->error(__('Image not uploaed. Please, try again.'));
                            return $this->redirect(['action' => 'add']);                    
                            }
                        }else{
                        $this->Flash->error(__('Only JPEG OR JPG OR PNG extension allow.'));
                        return $this->redirect(['action' => 'add']);    
                        }                    
                }else{
                        $this->Flash->error(__('Please upload proper image.'));
                        return $this->redirect(['action' => 'add']);    
                }   
            } else {
                    $this->Flash->error(__('Image can not be blanked. Please, try again.'));
                    return $this->redirect(['action' => 'add']);    
            }
            
        }
        $this->set(compact('banner'));
    }

    public function edit($id = null)
    {
        $banner = $this->Banners->get($id);
        if ($this->request->is(['patch', 'post', 'put'])) {
            //print_r($this->request->data);exit;
            if (!empty($this->request->data['file_name']['name'])) {
               if( $this->request->data['file_name']['size'] > 0 && $this->request->data['file_name']['error'] == 0)
                {  
                    $ext = substr(strtolower(strrchr($this->request->data['file_name']['name'], '.')), 1); //get the extension
                    $setNewFileName = time() . "_" . rand(000000, 999999);
                    $arr['file_name'] = $setNewFileName.'.'.$ext;
                    $arr_ext = array('jpg', 'jpeg', 'png'); //set allowed extensions
                        if(in_array($ext, $arr_ext))
                        {
                            $dir = WWW_ROOT . 'uploads/banners/';
                            if(move_uploaded_file($this->request->data['file_name']['tmp_name'], $dir.$arr['file_name'])) 
                            {
                                
                                $arr['name'] = $this->request->data['name'];
                                $banner = $this->Banners->patchEntity($banner, $arr);
                                if ($this->Banners->save($banner)) {
                                    $this->Flash->success(__('Banner updated successfully.'));
                                    return $this->redirect(['action' => 'index']);
                                }else{
                                   $this->Flash->error(__('The banner could not be saved. Please, try again.')); 
                                   return $this->redirect(['action' => 'edit',$id]);
                                }
                            }else{
                            $this->Flash->error(__('Image not uploaed. Please, try again.'));
                            return $this->redirect(['action' => 'edit',$id]);                    
                            }
                        }else{
                        $this->Flash->error(__('Only JPEG OR JPG OR PNG extension allow.'));
                        return $this->redirect(['action' => 'edit',$id]);    
                        }
                }else{
                    $this->Flash->error(__('Please upload proper image.'));
                    return $this->redirect(['action' => 'edit',$id]);  
                }
            } else {
                    $arr['file_name'] = $this->request->data['old_banner_image'];
                    $arr['name'] = $this->request->data['name'];
                    $banner = $this->Banners->patchEntity($banner, $arr);
                    if ($this->Banners->save($banner)) {
                        $this->Flash->success(__('Banner updated successfully.'));
                        return $this->redirect(['action' => 'index']);
                    }else{
                       $this->Flash->error(__('The banner could not be saved. Please, try again.')); 
                       return $this->redirect(['action' => 'edit',$id]);
                    }
            }
        } 
        $this->set(compact('banner'));
    }

    
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $banner = $this->Banners->get($id);
        if ($this->Banners->delete($banner)) {
            $this->Flash->success(__('The banner has been deleted.'));
        } else {
            $this->Flash->error(__('The banner could not be deleted. Please, try again.'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
