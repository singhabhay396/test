<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Core\Configure;
use Cake\Event\Event;
use Cake\Network\Exception\NotFoundException;
use Cake\View\Exception\MissingTemplateException;

/**
 * Articles Controller
 *
 * @property \App\Model\Table\ArticlesTable $Articles
 *
 * @method \App\Model\Entity\Article[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class ArticlesController extends AppController
{
    public function initialize()
    {
        parent::initialize();
        $this->viewBuilder()->setLayout('frontend');
        $this->Auth->allow(['home', 'page']);
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }

    private $linkType = [
        'article', 'tender', 'swavlamban',
    ];

    /**
     * Page method
     *
     * @return \Cake\Http\Response|void
     */
    public function page($article_id)
    {
        $select = [
                'id',
                'title'   => "IF(ArticleTranslation.title != '',ArticleTranslation.title,Articles.title)",
                'slug'    => "IF(ArticleTranslation.slug != '',ArticleTranslation.slug,Articles.slug)",
                'excerpt' => "IF(ArticleTranslation.excerpt != '',ArticleTranslation.excerpt,Articles.excerpt)",
                'content' => "IF(ArticleTranslation.content != '',ArticleTranslation.content,Articles.content)",
                'url'     => "IF(ArticleTranslation.url != '',ArticleTranslation.url,Articles.url)",
                'sort_order','header_image','created_at','modified_at','meta_title','meta_keywords','meta_description',
            ];
        $article = $this->Articles->findById($article_id)
            ->select($select)
            ->contain([
                'ArticleTranslation' => function ($q) {
                    if (Configure::check('language')) {
                        $q->where(['ArticleTranslation.culture' => Configure::read('language.culture')]);
                    } else {
                        $q->where(['ArticleTranslation.language_id' => 0]);
                    }
                    return $q;
                },'ArticleImages','ArticleLinks'
            ])
            ->where(['status' => 1])->first();
        if (empty($article)) {
            throw new NotFoundException(__('Article not found'));
        }
        $_template = 'page_' . $article->id;
        
        if (!empty($article->slug)) {
            $_template = 'page_' . $article->slug;
        }

        $linkType  = $this->linkType;
        $this->set(compact('article','linkType'));
        try {
            $this->render($_template);
        } catch (MissingTemplateException $e) {
            $this->render('page');
        }
    }

}
