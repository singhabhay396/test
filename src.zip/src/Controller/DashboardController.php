<?php
namespace App\Controller;

use App\View\Helper\SilverFormHelper;
use Cake\Controller\Controller;
use Cake\Event\Event;
use Cake\Mailer\Email;
use Cake\ORM\TableRegistry;
use Cake\Utility\Text;
use Cake\View\View;
use Cake\Core\Configure;
require_once(ROOT . DS . 'webroot' . DS . 'razorpay-php'. DS . 'Razorpay.php');
use Razorpay\Api\Api;
use Razorpay\Api\Errors\SignatureVerificationError;
/**
 * Users Controller
 *
 * @property \App\Model\Table\UsersTable $Users
 */
class DashboardController extends AppController
{
    public function initialize()
    {
    parent::initialize();
    
    $this->SilverForm = new SilverFormHelper(new View());
    $this->viewBuilder()->setLayout('user');
    }

    public function beforeFilter(Event $event)
    {   
        parent::beforeFilter($event);
		if ($this->request->getSession()->check('Auth.User')) {
        }else{
        $this->Flash->error(__('You are not logged in'));
        return $this->redirect(['controller'=>'home','action'=>'/']);    
        }	
    }

	public function index(){
    $this->loadModel('Users');
    $user = $this->Users->get($this->Auth->user('id'));
    //echo '<pre>';print_r($user);exit;
    $this->set(compact('user'));
	}

  public function editProfile()
    {
        $this->viewBuilder()->layout('user');
        $this->loadModel('Users');
        $user = $this->Users->get($this->Auth->user('id'));
        if($this->request->is(['post','put'])){
            $saveData = $this->Users->patchEntity($user, $this->request->getData());
            
           
            if ($userdata = $this->Users->save($saveData)) {
                
                $this->Flash->success(__("Profile has been updated successfully"));
                return $this->redirect(['controller'=>'Dashboard','action'=>'/']);
            }
        }
        $this->set(compact('user'));
    }
    
    
     public function refer()
    {
        
    }
    
    
    public function billingDetails()
    {
        $this->loadModel('Users');
        $this->loadModel('UserBillingDetails');
        $this->loadModel('UserDeliveryDetails');
        $this->loadModel('Cart');
        $ip_address = $this->getClientIp();
        $user_id = $this->Auth->user('id');
        $user = $this->Users->get($this->Auth->user('id'));
       
            $Query = $this->Cart->query();
            $Query->update()
                ->set(['user_id' => $user_id])
                ->where(['ip_address LIKE' =>  '%'.$ip_address.'%'])
                ->execute();
            $usrBillingDetails = $this->UserBillingDetails->find()->where(['UserBillingDetails.user_id'=>$user_id])->toArray();
            if(!empty($usrBillingDetails))
            {
              $usrBillingDetails = $this->UserBillingDetails->get($usrBillingDetails[0]->id);  
            }else{
             $usrBillingDetails = $this->UserBillingDetails->newEntity(); 
            }
        
            if($this->request->is(['post','put'])){
            $data = $this->request->getData();
            $billingDetails = [
                'user_id'      => $user_id,
                'first_name' => $data['first_name'],
                'last_name'  => $data['last_name'],
                'company'  => $data['company'],
                'address'  => $data['address'],
                'city'  =>  $data['city'],
                'postal_code'  =>  $data['postal_code'],
                'country'  =>  $data['country'],
                'state'  =>  $data['state'],
            ];
           
           $billingDetails = $this->UserBillingDetails->patchEntity($usrBillingDetails,$billingDetails);
            //echo '<pre>';print_r($billingDetails);exit;
            if ($billingDetails = $this->UserBillingDetails->save($billingDetails)) {
            $this->Flash->success(__("Billing details has been updated successfully"));
            return $this->redirect(['controller'=>'Dashboard','action'=>'delivery-details']);
            }else{
            $this->Flash->error(__("Billing details has not been updated"));
            return $this->redirect(['controller'=>'Dashboard','action'=>'billing-details']);   
            }
        }       
        $this->set(compact('usrBillingDetails','user'));
        
    }
    
    public function deliveryDetails()
    {
            $this->loadModel('Users');
            $this->loadModel('UserBillingDetails');
            $this->loadModel('UserDeliveryDetails');
            $user_id = $this->Auth->user('id');
            $user = $this->Users->get($this->Auth->user('id'));
       
            $usrDeliveryDetails = $this->UserDeliveryDetails->find()->where(['UserDeliveryDetails.user_id'=>$user_id])->toArray();
            
            $usrBillingDetails = $this->UserBillingDetails->find()->where(['UserBillingDetails.user_id'=>$user_id])->toArray();
            
            if(!empty($usrDeliveryDetails))
            {
              $usrDeliveryDetails = $this->UserDeliveryDetails->get($usrDeliveryDetails[0]->id);  
            }else{
             $usrDeliveryDetails = $this->UserDeliveryDetails->newEntity(); 
            }
        
            if($this->request->is(['post','put'])){
            $data = $this->request->getData();
            $deliveryDetails = [
                'user_id'      => $user_id,
                'first_name' => $data['first_name'],
                'last_name'  => $data['last_name'],
                'company'  => $data['company'],
                'address'  => $data['address'],
                'city'  =>  $data['city'],
                'postal_code'  =>  $data['postal_code'],
                'country'  =>  $data['country'],
                'state'  =>  $data['state'],
            ];
           
           $deliveryDetails = $this->UserDeliveryDetails->patchEntity($usrDeliveryDetails,$deliveryDetails);
            if ($deliveryDetails = $this->UserDeliveryDetails->save($deliveryDetails)) {
            $this->Flash->success(__("Delivery details has been updated successfully"));
            return $this->redirect(['controller'=>'Dashboard','action'=>'confirm-order']);
            }else{
            $this->Flash->error(__("Delivery details has not been updated"));
            return $this->redirect(['controller'=>'Dashboard','action'=>'delivery-details']);   
            }
        }       
        $this->set(compact('usrDeliveryDetails','user','usrBillingDetails'));
        
    }
    
    
    public function orderInformation($orderid = null)
    {
        $this->loadModel('Users');
        $this->loadModel('UserProductOrderDetails');
        if(!empty($orderid))
        {
        $user = $this->Users->get($this->Auth->user('id'));
        $Query = $this->UserProductOrderDetails->find()->contain(['Users','Products'])
         ->where(['order_id LIKE'=> '%'.$orderid.'%'])
         ->toArray();
       }else{
         $Query = '';   
       }
        //echo '<pre>';print_r($Query);exit;
        $this->set(compact('Query','user'));
    }
    
    public function confirmOrder()
    {
        $this->loadModel('Users');
        $this->loadModel('UserBillingDetails');
        $this->loadModel('UserDeliveryDetails');
        $this->loadModel('Cart');
        $user_id = $this->Auth->user('id');
        $user = $this->Users->get($this->Auth->user('id'));
        
        $Query = $this->Cart->find('all');
        $Query->select([ 
                      'product_name','poduct_image','product_after_discount_price',
                      'count' => $Query->func()->count('*')
                    ])
         ->where(['user_id'=> $user_id])
         ->group('Cart.product_code')
         ->toArray();
        $todate = date('d/m/Y');
        $delivery_expected_date = date('d/m/Y',strtotime('+5 weekday')); 
        //echo $todate;exit;
        $this->set(compact('Query','user','delivery_expected_date','todate'));
    }
    
    public function order()
    {
        
        $this->loadModel('Users');
        $this->loadModel('UserProductOrderDetails');
        $user = $this->Users->get($this->Auth->user('id'));
        $Query = $this->UserProductOrderDetails->find();
        $Query->select([ 
                      'order_id','order_time','amount',
                      'count' => $Query->func()->count('*')
                    ])
         ->where(['user_id'=> $this->Auth->user('id')])
         ->group('UserProductOrderDetails.order_id')
         ->toArray();
       
        //echo '<pre>';print_r($Query);exit;
        $this->set(compact('Query','user'));
    }
    public function changePassword()
    {
        $this->loadModel('Users');
        $user = $this->Users->get($this->Auth->user('id'));
        if(!empty($_REQUEST))
        {
            //$jcryption = new \JCryption;
            //$jcryption->decrypt();
            $userdata = $_REQUEST;
           
            $user = $this->Users->patchEntity($user, [
                    'old_password'      => $userdata['oldpass'],
                    'password'          => $userdata['newpass'],
                    'confirm_password'  => $userdata['cnewpass']
                ],
                    ['validate' => 'password']
            );
            // echo '<pre>';print_r($user);exit;
            if($this->Users->save($user)) 
            {
                //echo 'hi';exit;
                //$this->__passwordLog($user);
                $this->Flash->success('Your password has been changed successfully.');
                //Email code
                return $this->redirect(['controller'=>'Dashboard','action'=>'/']);
            } else {
                if($user->errors()){
                    $error_msg = [];
                    foreach( $user->errors() as $errors){
                        if(is_array($errors)){
                            foreach($errors as $error){
                                $error_msg[]    =   $error;
                            }
                        }else{
                            $error_msg[]    =   $errors;
                        }
                    }
                    if(!empty($error_msg)){
                        $this->Flash->error(
                                    __("Please fix the following error(s):".implode("\r\n", $error_msg))
                        );
                    }
                     return $this->redirect(['controller'=>'Dashboard','action'=>'/']);
                }else{
                    $this->Flash->error('Error changing password. Please try again!');
                    return $this->redirect(['controller'=>'Dashboard','action'=>'/']);
                }
            }
        }
        $this->set('user',$user);
    }
    
    public function wallet()
    {
        $this->loadModel('Users');
        $user = $this->Users->get($this->Auth->user('id'));
        $this->set('user',$user);
    }
    
    public function walletHistory($user_id=NULL)
    {
        $this->loadModel('WalletLogs');
       
        if(!empty($user_id)){
        $id = base64_decode($user_id);
        $walletDetails = $this->WalletLogs->find()->contain(['addedTo','addedBy'])->where(['added_to'=>$id]);
        $this->paginate = ['limit' => 10];
        $wallets = $this->paginate($walletDetails);
        $this->set(compact('wallets'));
        }else{
        $this->Flash->error('Something Wrong. Please try again!');
        return $this->redirect(['controller'=>'Dashboard','action'=>'wallet']);    
        }
    }
    
    public function paymentIntegrate()
    {
        $keyId = 'rzp_live_q1GMYrUevk34VU';
        $keySecret = 'iLlyyjHkacjkIQLxDoEjt2tW';
        $length = 15;
        $characters = '0123456789ABCDEFGHIJKLMNOPQRST#&%$@';
        $str_length = substr(str_shuffle($characters), 0, $length);
        $api = new Api($keyId, $keySecret);
        $orderData = [
        'receipt' => $str_length,
        'amount' => $_POST['amount'] * 100,
        'currency' => $_POST['currency'],
        'payment_capture' => 1
        ];
        
        $razorpayOrder = $api->order->create($orderData);
        $razorpayOrderId = $razorpayOrder['id'];
        $_SESSION['razorpay_order_id'] = $razorpayOrderId;
        $displayAmount = $amount = $orderData['amount'];
        if ($displayCurrency !== 'INR') {
            $url = "https://api.fixer.io/latest?symbols=$displayCurrency&base=INR";
            $exchange = json_decode(file_get_contents($url), true);

            $displayAmount = $exchange['rates'][$displayCurrency] * $amount / 100;
        }
        $data = [
            "key"               => $keyId,
            "amount"            => $amount,
            "name"              => $_POST['item_name'],
            "description"       => $_POST['item_description'],
            "image"             => "",
            "prefill"           => [
            "name"              => $_POST['cust_name'],
            "email"             => $_POST['email'],
            "contact"           => $_POST['contact'],
            ],
            "notes"             => [
            "address"           => $_POST['address'],
            "merchant_order_id" => "GAnzY3Qb5Z6W1G",
            ],
            "theme"             => [
            "color"             => "#F37254"
            ],
            "order_id"          => $razorpayOrderId,
        ];

        if ($displayCurrency !== 'INR')
        {
            $data['display_currency']  = $displayCurrency;
            $data['display_amount']    = $displayAmount;
        }

        $json = json_encode($data);
       
        $this->set('json',$json);
    }
    
    public function manual()
    {
        $json = $_POST['datajson'];
        if(!empty($json))
        {
          $this->set('json',$json); 
        }else{
         return $this->redirect(['controller'=>'dashboard','action' =>'wallet']);   
        }
    }
    
    public function success()
    {
        $this->loadModel('Users');
        $this->loadModel('PaymentDetails');
        $this->loadModel('ProductWarehouse');
        $keyId = 'rzp_live_q1GMYrUevk34VU';
        $keySecret = 'iLlyyjHkacjkIQLxDoEjt2tW';
        $api = new Api($keyId, $keySecret);
       /*  $attributes = array(
                    'razorpay_order_id' => $_SESSION['razorpay_order_id'],
                    'razorpay_payment_id' => $_POST['razorpay_payment_id'],
                    'razorpay_signature' => $_POST['razorpay_signature']
                ); */
        $payment_details = $api->payment->fetch($_POST['razorpay_payment_id']);
        if(!empty($payment_details['card_id'])){
        $card_details = $api->card->fetch($payment_details['card_id']);
        $payment_arr['last4'] = $card_details['last4'];
        $payment_arr['network'] = $card_details['network'];
        $payment_arr['issuer'] = $card_details['issuer'];
        $payment_arr['type'] = $card_details['type'];
        }
        $payload =  $_SESSION['razorpay_order_id'] . '|' . $payment_details['id'];
        $sign = $api->utility->verifySignature($payload, $_POST['razorpay_signature'],$keySecret);
       
        if($sign == 1){
            $payment_arr['user_id'] = $this->Auth->user('id');
            $payment_arr['order_id'] = $payment_details['order_id'];
            $payment_arr['razorpay_payment_id'] = $_POST['razorpay_payment_id'];
            $payment_arr['razorpay_order_id'] = $_SESSION['razorpay_order_id'];
            $payment_arr['razorpay_signature'] = $_POST['razorpay_signature'];
            $payment_arr['entity'] = $payment_details['entity'];
            $payment_arr['amount'] = $payment_details['amount'] / 100;
            $payment_arr['currency'] = $payment_details['currency'];
            $payment_arr['status'] = $payment_details['status'];
            $payment_arr['method'] = $payment_details['method'];
            $payment_arr['amount_refunded'] = $payment_details['amount_refunded'];
            $payment_arr['captured'] = $payment_details['captured'];
            $payment_arr['card_id'] = $payment_details['card_id'];
            $payment_arr['bank'] = $payment_details['bank'];
            $payment_arr['wallet'] = $payment_details['wallet'];
            $payment_arr['vpa'] = $payment_details['vpa'];
            $payment_arr['email'] = $payment_details['email'];
            $payment_arr['contact'] = $payment_details['contact'];
            $payment_arr['address'] = $payment_details->notes['address'];
            $payment_arr['merchant_order_id'] = $payment_details->notes['merchant_order_id'];
            $payment_arr['fee'] = $payment_details['fee'];
            $payment_arr['tax'] = $payment_details['tax'];
            $payment_arr['error_code'] = $payment_details['error_code'];
            $payment_arr['error_description'] = $payment_details['error_description'];
            $payment_arr['error_source'] = $payment_details['error_source'];
            $payment_arr['error_step'] = $payment_details['error_step'];
            $payment_arr['error_reason'] = $payment_details['error_reason'];
            $payment_arr['transaction_id'] = $payment_details->acquirer_data['transaction_id'];
            $payment_arr['transaction_time'] = $payment_details['created_at'];
            $payment_arr['created_at'] = date('Y-m-d H:i:s');
            
            $insert = $this->PaymentDetails->newEntity($payment_arr);
           
            if ($result = $this->PaymentDetails->save($insert)) {
                if($payment_details['status'] == 'captured' && empty($payment_details['error_code']))
                {
                    $user = $this->Users->get($this->Auth->user('id'));
                    $old_amount = $user->wallet_amount;
                    $added_amount = $payment_details['amount'] / 100;
                    $updated_amount = $old_amount + $added_amount;
                    $userRecord = [
                    'wallet_amount' =>  $updated_amount
                    ];
                    
                    $edit_record = $this->Users->patchEntity($user, $userRecord);
                    $this->Users->save($edit_record);
                    $this->__walletLogByCust($added_amount,$this->Auth->user('id'));
                    $this->Flash->success('Amount added successfully!');
                    return $this->redirect(['controller'=>'Dashboard','action'=>'wallet']); 
                }else{
                    $this->Flash->error('Money not added. Please try again!');
                    return $this->redirect(['controller'=>'Dashboard','action'=>'wallet']); 
                }
            }
        }else{
            $this->Flash->error('Something wrong in payment. Please try again!');
            return $this->redirect(['controller'=>'Dashboard','action'=>'wallet']);
        }
        
    }
     protected function __walletLogByCust($data,$added_to)
    {
        $walletLogTable = TableRegistry::get('wallet_logs');
        $Qry = $walletLogTable->newEntity();
        
        $Qry->added_by = $this->Auth->user('id');
        $Qry->added_to = $added_to;
        $Qry->added_date = date('Y-m-d H:i:s');
        $Qry->amount = $data;
       
        $walletLogTable->save($Qry);
    }
    /*************PAYMENT PROCESS FOR PRODUCT ********************/
    
     public function productPaymentIntegrate()
    {
        $keyId = 'rzp_live_q1GMYrUevk34VU';
        $keySecret = 'iLlyyjHkacjkIQLxDoEjt2tW';
        $length = 15;
        $characters = '0123456789ABCDEFGHIJKLMNOPQRST#&%$@';
        $str_length = substr(str_shuffle($characters), 0, $length);
        $api = new Api($keyId, $keySecret);
        $orderData = [
        'receipt' => $str_length,
        'amount' => $_POST['amount'] * 100,
        'currency' => $_POST['currency'],
        'payment_capture' => 1
        ];
        
        $razorpayOrder = $api->order->create($orderData);
        $razorpayOrderId = $razorpayOrder['id'];
        $_SESSION['razorpay_order_id'] = $razorpayOrderId;
        $displayAmount = $amount = $orderData['amount'];
        if ($displayCurrency !== 'INR') {
            $url = "https://api.fixer.io/latest?symbols=$displayCurrency&base=INR";
            $exchange = json_decode(file_get_contents($url), true);

            $displayAmount = $exchange['rates'][$displayCurrency] * $amount / 100;
        }
        $data = [
            "key"               => $keyId,
            "amount"            => $amount,
            "name"              => $_POST['item_name'],
            "description"       => $_POST['item_description'],
            "image"             => "",
            "prefill"           => [
            "name"              => $_POST['cust_name'],
            "email"             => $_POST['email'],
            "contact"           => $_POST['contact'],
            ],
            "notes"             => [
            "address"           => $_POST['address'],
            "merchant_order_id" => "GAnzY3Qb5Z6W1G",
            ],
            "theme"             => [
            "color"             => "#F37254"
            ],
            "order_id"          => $razorpayOrderId,
        ];

        if ($displayCurrency !== 'INR')
        {
            $data['display_currency']  = $displayCurrency;
            $data['display_amount']    = $displayAmount;
        }

        $json = json_encode($data);
       
        $this->set('json',$json);
    }
    
    public function productPaymentManual()
    {
        $json = $_POST['datajson'];
        if(!empty($json))
        {
          $this->set('json',$json); 
        }else{
         return $this->redirect(['controller'=>'dashboard','action' =>'confirm-order']);   
        }
    }
    
    public function productPaymentSuccess()
    {
        $this->loadModel('Users');
        $this->loadModel('PaymentDetails');
        $this->loadModel('UserProductOrderDetails');
        $this->loadModel('Cart');
        $this->loadModel('Products');
        $this->loadModel('UserDeliveryDetails');
        $this->loadModel('UserBillingDetails');
        $this->loadModel('ProductWarehouse');
        $keyId = 'rzp_live_q1GMYrUevk34VU';
        $keySecret = 'iLlyyjHkacjkIQLxDoEjt2tW';
        $api = new Api($keyId, $keySecret);
       /*  $attributes = array(
                    'razorpay_order_id' => $_SESSION['razorpay_order_id'],
                    'razorpay_payment_id' => $_POST['razorpay_payment_id'],
                    'razorpay_signature' => $_POST['razorpay_signature']
                ); */
        $payment_details = $api->payment->fetch($_POST['razorpay_payment_id']);
        if(!empty($payment_details['card_id'])){
        $card_details = $api->card->fetch($payment_details['card_id']);
        $payment_arr['last4'] = $card_details['last4'];
        $payment_arr['network'] = $card_details['network'];
        $payment_arr['issuer'] = $card_details['issuer'];
        $payment_arr['type'] = $card_details['type'];
        }
        $payload =  $_SESSION['razorpay_order_id'] . '|' . $payment_details['id'];
        $sign = $api->utility->verifySignature($payload, $_POST['razorpay_signature'],$keySecret);
       //echo '<pre>';print_r($payment_details['notes']['address']);exit;
        if($sign == 1){
            $payment_arr['user_id'] = $this->Auth->user('id');
            $payment_arr['order_id'] = $payment_details['order_id'];
            $payment_arr['razorpay_payment_id'] = $_POST['razorpay_payment_id'];
            $payment_arr['razorpay_order_id'] = $_SESSION['razorpay_order_id'];
            $payment_arr['razorpay_signature'] = $_POST['razorpay_signature'];
            $payment_arr['entity'] = $c['entity'];
            $payment_arr['amount'] = $payment_details['amount'] / 100;
            $payment_arr['currency'] = $payment_details['currency'];
            $payment_arr['status'] = $payment_details['status'];
            $payment_arr['method'] = $payment_details['method'];
            $payment_arr['amount_refunded'] = $payment_details['amount_refunded'];
            $payment_arr['captured'] = $payment_details['captured'];
            $payment_arr['card_id'] = $payment_details['card_id'];
            $payment_arr['bank'] = $payment_details['bank'];
            $payment_arr['wallet'] = $payment_details['wallet'];
            $payment_arr['vpa'] = $payment_details['vpa'];
            $payment_arr['email'] = $payment_details['email'];
            $payment_arr['contact'] = $payment_details['contact'];
            $payment_arr['address'] = $payment_details->notes['address'];
            $payment_arr['merchant_order_id'] = $payment_details->notes['merchant_order_id'];
            $payment_arr['fee'] = $payment_details['fee'];
            $payment_arr['tax'] = $payment_details['tax'];
            $payment_arr['error_code'] = $payment_details['error_code'];
            $payment_arr['error_description'] = $payment_details['error_description'];
            $payment_arr['error_source'] = $payment_details['error_source'];
            $payment_arr['error_step'] = $payment_details['error_step'];
            $payment_arr['error_reason'] = $payment_details['error_reason'];
            $payment_arr['transaction_id'] = $payment_details->acquirer_data['transaction_id'];
            $payment_arr['transaction_time'] = $payment_details['created_at'];
            $payment_arr['created_at'] = date('Y-m-d H:i:s');
            
            $insert = $this->PaymentDetails->newEntity($payment_arr);
           
            if ($result = $this->PaymentDetails->save($insert)) {
                if($payment_details['status'] == 'captured' && empty($payment_details['error_code']))
                    {
                    
                    $ip_address = $this->getClientIp();
                    $Query = $this->Cart->find('all');
                    $Query->select([ 
                                  'product_name','product_code','product_after_discount_price',
                                  'count' => $Query->func()->count('*')
                                ])
                     ->where(['user_id'=> $this->Auth->user('id')])
                     ->group('Cart.product_code')
                     ->toArray();
                    $arr = 0;
                        foreach($Query as $cart)  
                        {
                             
                            $deliveryDetails = $this->UserDeliveryDetails->find()
                                ->select(['address','city','postal_code','country','state'])
                                ->where(['UserDeliveryDetails.user_id'
                                =>$this->Auth->user('id')])->first();
                            
                            $billingDetails = $this->UserBillingDetails->find()
                            ->select(['address','city','postal_code','country','state'])
                            ->where(['UserBillingDetails.user_id'
                            =>$this->Auth->user('id')])->first();
                            
                           
                            $prodWareHouse = $this->ProductWarehouse
                            ->find()
                            ->where(['product_code LIKE'=> '%'.$cart->product_code.'%'])->toArray();
                             
                            
                            $updated_prod_amount = $prodWareHouse[0]->product_amount - $cart->count;
                           
                           
                            $ProdUpdateQuery = $this->ProductWarehouse->query();
                            $ProdUpdateQuery->update()
                            ->set(['product_amount' => $updated_prod_amount])
                            ->where(['product_code LIKE' =>  '%'.$cart->product_code.'%'])
                            ->execute();
                            
                            $products = $this->Products->find()->select('id')->where(['Products.code LIKE'=>'%'.$cart->product_code.'%'])->first();
                            
                            $payment_arr_1['user_id'] = $this->Auth->user('id');
                            $payment_arr_1['ip_address'] = $ip_address;
                            $payment_arr_1['product_id'] = $products->id;
                            $payment_arr_1['product_code'] = $cart->product_code;
                            $payment_arr_1['product_amount'] = ($cart->count * $cart->product_after_discount_price);
                            $payment_arr_1['per_product_price'] = $cart->product_after_discount_price;
                            $payment_arr_1['number_product'] = $cart->count;
                            $payment_arr_1['amount'] = $payment_details['amount'] / 100;
                            $payment_arr_1['order_id'] = $payment_details['order_id'];
                            $payment_arr_1['razorpay_payment_id'] = $_POST['razorpay_payment_id']; 
                            $payment_arr_1['razorpay_order_id'] = $_SESSION['razorpay_order_id'];
                            $payment_arr_1['razorpay_signature'] = $_POST['razorpay_signature'];
                            $payment_arr_1['payment_method'] = $payment_details['method'];
                            $payment_arr_1['order_time'] = date('Y-m-d H:i:s');
                            
                            $payment_arr_1['user_billing_address'] = ($billingDetails->address.'@'.$billingDetails->country.'@'.$billingDetails->city.'@'.$billingDetails->state.'@'.$billingDetails->postal_code);
                            
                            $payment_arr_1['user_delivery_address'] = ($deliveryDetails->address.'@'.$deliveryDetails->country.'@'.$deliveryDetails->city.'@'.$deliveryDetails->state.'@'.$deliveryDetails->postal_code);
                            
                            $payment_arr_1['city'] = $billingDetails->city;
                            $payment_arr_1['state'] = $billingDetails->state;
                            $payment_arr_1['country'] = $billingDetails->country;
                            $payment_arr_1['delivery_date'] = $payment_details['notes']['address'];
                            
                            $insert = $this->UserProductOrderDetails->newEntity($payment_arr_1);
                          // echo '<pre>';print_r($payment_details);exit;
                           $this->UserProductOrderDetails->save($insert);
                           $arr = ($cart->count * $cart->product_after_discount_price) + $arr;
                            
                        }
                    }
                   
                        $user = $this->Users->get($this->Auth->user('id'));
                        
                        $old_amount = $user->wallet_amount;
                       
                        if($arr >= $old_amount)
                        {
                            if($old_amount > 0){
                            $updated_amount = 0;
                            $userRecord = [
                            'wallet_amount' =>  $updated_amount
                            ];
                        
                            $edit_record = $this->Users->patchEntity($user, $userRecord);
                            $this->Users->save($edit_record);
                            }
                        }
                        if($arr < $old_amount)
                        {
                            
                            $updated_amount = $old_amount - $arr ;
                            $userRecord = [
                            'wallet_amount' =>  $updated_amount
                            ];
                        
                            $edit_record = $this->Users->patchEntity($user, $userRecord);
                            $this->Users->save($edit_record);
                           
                        }
                    
                    $selectQuery = $this->Cart->query();
                    $selectQuery->delete()
                    ->where(['user_id' => $this->Auth->user('id')])
                    ->execute();
                    
                    $this->Flash->success('Payment successfully done!');
                    return $this->redirect(['controller'=>'Dashboard','action'=>'/']); 
                }else{
                    $this->Flash->error('Payment not done. Please try again!');
                    return $this->redirect(['controller'=>'Dashboard','action'=>'confirm-order']); 
                }
        }else{
            $this->Flash->error('Something wrong in payment. Please try again!');
            return $this->redirect(['controller'=>'Dashboard','action'=>'confirm-order']);
        }
        
    }
    /*****************************END*************************************/
}
