<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Core\Configure;
use Cake\Event\Event;
use Cake\Network\Exception\NotFoundException;
use Cake\View\Exception\MissingTemplateException;
use Cake\Utility\Text;
use Cake\Mailer\Email;
use Cake\I18n\Time;
use Cake\Routing\Router;
use Cake\Chronos\Chronos;
use Cake\Auth\DefaultPasswordHasher;
use Cake\Validation\Validator;
use Cake\Validation\Validation;
use Cake\ORM\TableRegistry;
/**
 * Home Controller
 *
 */

class HomeController extends AppController
{
	public function initialize()
    {
        parent::initialize();
        $this->viewBuilder()->setLayout('home');
        $this->Auth->allow(['index', 'subscribe','productDetails','unsubscribe','confirmSubscription','homeSearch','getSuggestiveSearch','message','login', 'forgotPassword', 'resetPassword', 'captcha','registration','emailcheck','mobileexists','jcryption','registrationVerification','contactUs','aboutUs','termsCondition','privacyPolicy','setCategory']);
        $this->loadComponent('CakephpCaptcha.Captcha');
        $this->loadModel('Users');
        $this->loadModel('Products');
        $this->loadModel('Categories');
        $this->loadModel('SubCategoriesImages');
        $this->loadModel('SubCategories');
        $this->loadModel('ProductImages');
        $this->loadModel('ProductPackImages');
        $this->loadModel('Banners');
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }


    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        
         $banners = $this->Banners->find('all')->where(['status'=>1])->toArray();
         //echo '<pre>';print_r($banners);exit;
         $this->set('banners',$banners);
    }
    
    public function setCategory()
    {
         $this->layout = false;
        $this->autoRender = false;
        $cat = $_REQUEST['category'];
        $session = $this->request->session();
        $this->request->session()->write('selectcat', $cat);
        $getSess = $this->request->session()->read('selectcat');
        echo $getSess;
        exit;
    }

    public function login()
    {
            $this->viewBuilder()->setLayout('ajax');
            $token = $this->request->getParam('_csrfToken');
            //$jcryption = new \JCryption;
           // $jcryption->decrypt();
            $this->request->data = $_REQUEST;
            $userdata = $this->request->data;
            $userdtl = $this->Users->find('all')->where(['mobile_number'=>$userdata['email']])->first();
            $email = $userdtl->email;
            $this->request->data['email'] = $userdtl->email;
           
            $errors = array();
            /* $captcha = $this->Captcha->check($userdata['captcha']);
            if (empty($captcha)) {
                $errors['captcha']['_empty'] = 'Invalid captcha. Please try again.';
            } */
            if (empty($errors)) {
               $validator = new Validator();
                $validator->email('email');
                $validError = $validator->errors(['email'=>$this->request->data['email']]);
               
                $cUser = $this->Users->find('all')->where(['email' => $email])->first();
                
                    if (!empty($cUser)) {
                        $uId = $cUser->id;
                    } else {
                        $uId = 0;
                    }
                    
                    $user = $this->Auth->identify();
                  
                    if ($user) {
                       
                        if ($user['role_id'] != 1) {
                            if ($user['status'] == 1) {
                                $role = $this->Users->Roles->find('all')->where(['id' => $user['role_id']])->first();
                               
                                $user['role'] = $role;
                                //$user['registration'] = $registration;
                                $this->Auth->setUser($user);

                                $this->adminLog($user['id'],'Login Successful.');
                                echo 1;
                            } else {
                                $this->adminLog($user['id'],'User is Inctive or blocked.');
                                echo 0;
                            }
                        } else {
                            echo 2;
                        }
                    } else {
                        $this->adminLog($uId,'Login Failed.');
                        echo 3;
                    }
            }else {
               /*  if(!empty($errors['captcha']['_empty'])){
                    $this->Flash->error(__($errors['captcha']['_empty']));
                } else {
                    $this->Flash->error(__('Your Captcha is expire. Please refresh the page'));
                } */
                echo 4;
            }
       exit;
    }
    
    public function logout()
    {
        $this->layout = false;
        $this->autoRender = false;
        $this->Flash->success(__('You have logged out successfully.'));
        $user_id = $this->request->session()->read('Auth.User.id');
        $this->request->session()->destroy();
        $this->adminLog($user_id,'Logout.');
        $this->Auth->logout();
        return $this->redirect(['controller' => 'Home', 'action' => 'index']);
    }

    public function adminLog($uid,$logSms='')
    {
        /* admin log code starts */
        $ipaddress = $_SERVER['REMOTE_ADDR'];
        if($ipaddress=='::1'){
            $ipadd = '127.0.0.1';
        } else {
            $ipadd = $ipaddress;
        }
        $ipaddress = $_SERVER['REMOTE_ADDR'];
        $date_today = date('Y-m-d H:i:s');
        $logtime = Time::createFromFormat('Y-m-d H:i:s', $date_today);
        $adminLogTable = TableRegistry::get('admin_logs');
        $adminLog = $adminLogTable->newEntity();
        $adminLog->uid = $uid;
        $adminLog->logsms = $logSms;
        $adminLog->logtime = $logtime;
        $adminLog->ipaddress = inet_pton($ipadd);//string inet_ntop ( string $in_addr )
        $adminLogTable->save($adminLog);
        /* admin log code ends */
    }

    /**
     * logout method
     *
     * @return \Cake\Network\Response|null
     */

    

    /**
     * forgotPassword method
     *
     * @return \Cake\Network\Response|null
     */

    public function forgotPassword()
    {
        $this->layout = false;
        $this->autoRender = false;
        $mob = $_REQUEST['mobile'];
        $mail = $_REQUEST['mail'];
        
                if(empty($mob)){
                    echo 1;
                }else if(empty($mail)){
                    echo 2;
                }else{
                   $UserExist = $this->Users->find()->where(['mobile_number'=>$mob,'email'=>$mail])->toArray();
                   if(!empty($UserExist))
                   {
                        $id = $UserExist[0]->id;
                        $user  = $this->Users->get($id);
                        $length = 15;
                        $characters = '0123456789ABCDEFGHIJKLMNOPQRSTabcdefghijklmnopqrst!@#$%&';
                        $str_length = substr(str_shuffle($characters), 0, $length);
                        $user = $this->Users->patchEntity($user, [
                                        'password'         => $str_length
                                    ], ['validate' => 'password']);
                         if ($this->Users->save($user)) {
                                $emailData = [
                                        'setHelpers'     => ['Html'],
                                        'setTemplate'    => 'forgot_password',
                                        'setEmailFormat' => 'html',
                                        'setTo'          => trim($mail),
                                        'setSubject'     => __('Forgot Password'),
                                        'setViewVars'    => ['user' => $user,'password'=> $str_length],
                                    ];
                               // $this->Email->send($emailData);
                                echo $str_length;
                         }else{
                             echo 4;
                         }
                   }else{
                       echo 3;
                   }
                   
                }
                exit;
    }

    /**
     * Reset Password method
     *
     * @return \Cake\Http\Response|void
     */

    public function resetPassword($fp_token = null)
    {
        $this->viewBuilder()->setLayout('login');
        $user = $this->Users->newEntity();
        if (isset($fp_token)) {
            $TokenExist = $this->Users->findByFpToken($fp_token)->first();
            if ($TokenExist) {
                $tokenGeneratedDate = $TokenExist['fp_token_at'];
                $convertDate        = date("Y-m-d", strtotime($tokenGeneratedDate));
                if (strtotime($convertDate) <= strtotime('-1 day')) {
                    $TokenExist->fp_token    = "";
                    $TokenExist->fp_token_at = "";
                    $this->Users->save($TokenExist);
                    $this->Flash->error('Your link has been expired, try again.');
                    return $this->redirect(['controller' => 'Users', 'action' => 'forgotPassword']);
                } else {
                    if ($this->request->is('post')) {
                        $errors = [];
                        $captcha = $this->Captcha->check($this->request->getData('captcha'));
                        if (empty($captcha)) {
                            $errors['captcha']['_empty'] = 'Invalid captcha. Please try again.';
                        }
                        if (empty($errors)) {
                            $user = $this->Users->patchEntity($TokenExist, [
                                'new_password'     => $this->request->getData('password'),
                                'password'         => $this->request->getData('password'),
                                'confirm_password' => $this->request->getData('confirm_password'),
                            ], ['validate' => 'password']);
                            $user->fp_token    = "";
                            $user->fp_token_at = "";
                            if ($this->Users->save($user)) {
                                $this->__passwordLog($user);
                                if (!empty($user)) {
                                    /*$emailData = [
                                        'setHelpers'     => ['Html'],
                                        'setTemplate'    => 'resetpassword',
                                        'setEmailFormat' => 'html',
                                        'setTo'          => trim($user->email),
                                        'setSubject'     => __('You Password has changed'),
                                        'setViewVars'    => ['user' => $user],
                                    ];
                                    $this->Email->send($emailData);*/
                                }
                                $this->Flash->success(__('You Password has changed'));
                                return $this->redirect(['controller' => 'Users', 'action' => 'login']);
                            }
                        } else {
                            $this->Flash->error(__($errors['captcha']['_empty']));
                        }
                    }
                }
            } else {
                $this->Flash->error(__('Invalid Token.'));
                return $this->redirect(['controller' => 'Users', 'action' => 'login']);
            }
        } else {
            $this->Flash->error(__('Something missing in URL.'));
            return $this->redirect(['controller' => 'Users', 'action' => 'login']);
        }
        $this->set(compact('fp_token', 'user'));
        $this->set('_serialize', ['fp_token']);
    }

    protected function __passwordLog($user)
    {
       
        $changePasswordTable = TableRegistry::get('change_password_logs');
        $changePassword = $changePasswordTable->newEntity();
        $ipaddress = $_SERVER['REMOTE_ADDR'];
        if ($ipaddress == '::1') {
            $ipadd = '127.0.0.1';
        } else {
            $ipadd = $ipaddress;
        }
        $changePassword->user_id = $user->id;
        $changePassword->password = $user->password;
        $changePassword->change_time = date('Y-m-d H:i:s');
        $changePassword->ip_address = inet_pton($ipadd);
        $changePasswordTable->save($changePassword);
    }

    public function userLog()
    {
        $this->loadModel('AdminLogs');
        $rid = $this->Auth->user('role_id');
        $adminLog = $this->AdminLogs->find('all')
            ->contain(['Users'])
            ->order(['AdminLogs.id'=>'DESC']);
        if ($rid != 1) {
            $adminLog = $adminLog->where(['uid' => $this->Auth->user('id')]);
        }
        $this->paginate = ['limit' => 20];
        $adminLog = $this->paginate($adminLog);
        $this->set(compact('adminLog'));
    }

    public function changePasswordHistory()
    {
        $changePasswordTable = TableRegistry::get('change_password_logs');
        $changePassword = $changePasswordTable->find('all')->where(['user_id'=>$this->Auth->user('id')]);
        $this->paginate = ['limit' => 20];
        $changePassword = $this->paginate($changePassword);
        $this->set(compact('changePassword'));
    }
    
    /**
     * Change Password method
     *
     * @return \Cake\Http\Response|void
     */

    public function changePassword()
    {
        $user = $this->Users->get($this->Auth->user('id'));
        if(!empty($_REQUEST))
        {
            $jcryption = new \JCryption;
            $jcryption->decrypt();
            $userdata = $_REQUEST;
            $user = $this->Users->patchEntity($user, [
                    'old_password'      => $userdata['old_password'],
                    'password'          => $userdata['new_password'],
                    'new_password'      => $userdata['new_password'],
                    'confirm_password'  => $userdata['confirm_password']
                ],
                    ['validate' => 'password']
            );
            if($this->Users->save($user)) 
            {
                $this->__passwordLog($user);
                $this->Flash->success('Your password has been changed successfully.');
                //Email code
                //$this->redirect(['action'=>'view']);
            } else {
                if($user->errors()){
                    $error_msg = [];
                    foreach( $user->errors() as $errors){
                        if(is_array($errors)){
                            foreach($errors as $error){
                                $error_msg[]    =   $error;
                            }
                        }else{
                            $error_msg[]    =   $errors;
                        }
                    }
                    if(!empty($error_msg)){
                        $this->Flash->error(
                                    __("Please fix the following error(s):".implode("\r\n", $error_msg))
                        );
                    }
                }else{
                    $this->Flash->error('Error changing password. Please try again!');
                }
            }
        }
        $this->set('user',$user);
    }

    public function registration()
    {
        $this->viewBuilder()->setLayout('ajax');
        $this->loadModel('Users');
        $user = $this->Users->newEntity();        
            
            $userdata = $_REQUEST;
            $errors = array();
          //  $captcha = $this->Captcha->check($userdata['captcha']);
           // if (empty($captcha)) {
           //     $errors['captcha']['_empty'] = 'Invalid captcha. Please try again.';
           // }            
            if (isset($userdata['agree_status'])) {
                $userName = preg_replace('/([^@]*).*/', '$1', $userdata['email']);
                $password = trim($userdata['password']);
                $password = $this->Sanitize->stripAll( $password);
                $password = $this->Sanitize->clean( $password);
                $userRecord = [
                    'name'          => $userdata['name'],
                    'username'      => $userName,
                    'email'         => $userdata['email'],
                    'mobile_number'         => $userdata['mobile_number'],
                    'password'      => $password,
                    'role_id'       => 9,
                    'status'        => 1,
                    'agree_status'        => 1,
                    'created' => date('Y-m-d H:i:s')
                ];
 
                    $user = $this->Users->patchEntity($user, $userRecord);
                    //$result = $this->Users->save($user);
                   if (empty($user->errors())) {
                    if ($result = $this->Users->save($user)) {
                        $this->__passwordLog($result);
                        
                        //$this->__sendActivationEmail($result->id,$result->fp_token);
                       echo 1;
                    } else {
                        echo 2;
                    }
                   }else{				
                        $error_msg = [];
                        foreach( $user->errors() as $errors){
                            if(is_array($errors)){
                                foreach($errors as $error){
                                    $error_msg[]    =   $error.'<br>';
                                }
                            }else{
                                $error_msg[]    =   $errors;
                            }
                        }
					 echo $err_msg = implode("\n \r", $error_msg);
                    }
                } else {
                        echo 0;
                }
    
    exit;    
    }


    public function contactUs()
    {
        
    }
    
    public function aboutUs()
    {
        
    }
    
    public function privacyPolicy()
    {
        
    }
    
    
    public function termsCondition()
    {
        
    }
    /**
     * Subscribe method
     *
     * @return \Cake\Http\Response|void
     */

    public function subscribe() 
    {
        //$this->viewBuilder()->setLayout('ajax');
        //debug($this->request->data);exit;
        $this->loadModel('Newsletters');
        if (!empty($_POST)) {
            $valid = true;
            $category = '';
            $email    = trim($_POST['email']);
            (int) $categoryId    = trim($_POST['category_id']);
            if ($categoryId == 39) {
                $category = 2;
            } elseif (in_array($categoryId, [40,3])) {
                $category = 3;
            } elseif (in_array($categoryId, [41,4])) {
                $category = 4;
            } else {
                $category = 1;
            }
            if (empty($email)) {
                $message = "The email address field must not be blank";
                $valid = false;
            } else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $message = "You must fill the field with a valid email address";
                $valid = false;
            }
            if ($valid) {
                $dataExists = $this->Newsletters->find('all',[
                    'conditions' => ['email' => $email,'category_id' => $category],
                ])->first();
                if(empty($dataExists)){
                    $newsletters = $this->Newsletters->newEntity();
                    $newsletters->email  = $email;
                    $newsletters->category_id  = $category;
                    $newsletters->status  = 0;
                   
                    if ($this->Newsletters->save($newsletters)) {
                        $nemail = new Email('default');
                        $nemail->template('subscribe');
                        $nemail->emailFormat('html');
                        $nemail->viewVars(['email' => $email]);
                        $nemail->viewVars(['base_url' => Router::url('/', true)]);

                        $status = $nemail->from(['info@silvermail.com' => 'SIDBI'])
                        //$status = $nemail->from(['vanjiwalesiddhant@gmail.com' => 'SIDBI'])
                            ->to($email)
                            ->subject('SIDBI : Please Confirm Subscription')
                            ->send();
                        $message = "You have been successfully subscribed.";
                    } else {
                        $message = "An error occurred, please try again";
                    }
                } else {
                    $message = "This email is already subscribed.";
                }
            }
            echo $message;
            //$data = json_encode($data);
        }
        //$this->autoRender = false;
        exit();
    }

    public function confirmSubscription($value='')
    {
        $this->viewBuilder()->setLayout('email');
        $userEmail   = !empty($this->request->getQuery('q1'))? base64_decode($this->request->getQuery('q1')) : null;
        if (!empty($userEmail)) {
            $this->loadModel('Newsletters');
            $dataExists = $this->Newsletters->find('all',['conditions' => ['email' => $userEmail]])->first();
            if (!empty($dataExists)) {
                $newsletters = $this->Newsletters->get($dataExists['id']);
            } else {
                $newsletters = $this->Newsletters->newEntity();
            }
            $data = [
                'email' => $userEmail,
                'status' => 1
            ];
            $newsletters->email = $userEmail;
            $newsletters->status = 1;
            $newsletters = $this->Newsletters->patchEntity($newsletters, $data);
            if ($this->Newsletters->save($newsletters)) {
                $this->Flash->success(__('Your subscription has been confirmed.'));
            }
        }
    }

    /**
     * Unsubscribe method
     *
     * @return \Cake\Http\Response|void
     */

    public function unsubscribe() 
    {
        $this->viewBuilder()->setLayout('email');
        $this->loadModel('Newsletters');
        if (!empty($_POST)) {
            $valid = true;
            $email    = trim($_POST['email']);
            $reason   = trim($_POST['reason']);
            if (empty($email)) {
                $message = "The email address field must not be blank";
                $valid = false;
            } else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $message = "You must fill the field with a valid email address";
                $valid = false;
            }
            if (empty($reason)) {
                $message = "The reason field must not be blank";
                $valid = false;
            }
            if ($valid) {
                $dataExists = $this->Newsletters->find('all',[
                    'conditions' => ['email' => $email],
                    ])->first();

                if(!empty($dataExists)){
                    $newsletters = $this->Newsletters->newEntity();
                    $newsletters->id              = $dataExists->id;
                    $newsletters->is_unsubscribe  = 1;
                    $newsletters->reason          = $reason;
                    if ($this->Newsletters->save($newsletters)) {                        
                        $message = "You have been successfully unsubscribed.";
                    } else {
                        $message = "An error occurred, please try again";
                    }
                } else {
                    $message = "This email does not exit.";
                }
            }
            $this->Flash->success($message);
            return $this->redirect(['action' => 'message']);
        }        
    }


    /**
     * Search method
     *
     * @return \Cake\Http\Response|void
     */

    

    public function homeSearch()
    {
    }
    
    public function getSuggestiveSearch()
    {
    }

    public function message(){ 
        $this->viewBuilder()->setLayout('email');
    }
    
    public function __generatePasswordToken($user)
    {
        if (empty($user)) {
            return null;
        }
        $token = "";
        // Generate a random string 100 chars in length.
        for ($i = 0; $i < 100; $i++) {
            $d = rand(1, 100000) % 2;
            $d ? $token .= chr(rand(33, 79)) : $token .= chr(rand(80, 126));
        }
        (rand(1, 100000) % 2) ? $token = strrev($token) : $token = $token;

        // Generate a hash of random string
        $hash = Security::hash($token, 'sha256', true);;
        for ($i = 0; $i < 20; $i++) {
            $hash = Security::hash($hash, 'sha256', true);
        }
        $user['User']['reset_password_token'] = $hash;
        $user['User']['token_created_at'] = date('Y-m-d H:i:s');
    }

    public function jcryption()
    {
        $this->autoRender = false;
        $jc = new \JCryption;
        $jc->go();
        header('Content-type: text/plain');
    }
}
