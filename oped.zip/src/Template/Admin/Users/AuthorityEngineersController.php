<?php
namespace App\Controller\Admin;

use App\Controller\Admin\AppController;
use Cake\Event\Event;

/**
 * Roles Controller
 *
 * @property \App\Model\Table\RolesTable $Roles
 *
 * @method \App\Model\Entity\Role[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class TeamLeadsController extends AppController
{

    public function initialize()
    {
        parent::initialize();
		$this->loadModel('Projects');
		$this->loadModel('Users');
		$this->loadModel('States');
        $this->loadModel('ProjectTypes');
        $this->loadModel('ProjectStatus');
        $this->loadModel('ProjectSiteOffice');
        $this->loadModel('ProjectMonitoringUnits');
        $this->loadModel('RegionalOffice');
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }

    /**
     * Index method
     * 
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $search_condition = array();
        $page_length = !empty($this->request->query['page_length']) ? $this->request->query['page_length'] : 10;
        $page = !empty($this->request->query['page']) ? $this->request->query['page'] : 1;
        $data = $this->request->getQuery();
        $data = $this->Sanitize->clean($data);
        $data['name'] = $this->Sanitize->stripAll(isset($data['name'])?$data['name']:'');

        if (!empty($data['name'])) {
            $name = trim($data['name']);
            $this->set('name', $name);
            $search_condition[] = "Users.name like '%" . $name . "%'";
        }
        if (isset($data['email']) && $data['email'] !='') {
            $email = trim($data['email']);
            $this->set('email', $email); 
			$search_condition[] = "Users.email like '%" . $email . "%'";
            //$search_condition[] = "Projects.pmis_id = '" . $pmis_id . "'";
        }
		if (isset($data['contact_no']) && $data['contact_no'] !='') {
            $contact_no = trim($data['contact_no']);
            $this->set('contact_no', $contact_no); 
			$search_condition[] = "Users.contact_no like '%" . $contact_no . "%'";
            //$search_condition[] = "Projects.unique_project_code = '" . $unique_project_code . "'";
        }

        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        if ($page_length != 'all' && is_numeric($page_length)) {
            $this->paginate = [
                'limit' => $page_length,
            ];
        }

        if($this->request->is('get')){
            if(!empty($this->request->query['export_excel'])) {
                $queryExport = $this->Users->find('all',[
                    'conditions'=>[$searchString,'Users.role_id'=>11],
                    'limit' => $page_length, 
                    'page'=> $page,
                    'order' => ['Users.id' => 'asc'],
                ]);
                $queryExport->hydrate(false);
                $ExportResultData = $queryExport->toArray();
                $fileName = "Users-".date("d-m-y:h:s").".xls";
                $headerRow = array("S.No", " Email Address ", 'Contact Number','Status');
                $data = array();
                $i=1;
                $stat = ['0'=>'Inactive', 'Active'];
                foreach($ExportResultData As $project_detail){
                    $data[]=array($i, $project_detail['name'],$project_detail['email'],$project_detail['contact_no'],$stat[$project_detail['status']]); 
                    $i++;
                }
                $this->exportInExcel($fileName, $headerRow, $data);
            }
        }
		$user_ids = $this->Auth->user('id');
        $rolesQuery = $this->Users->find('all', [
            'order' => ['Users.id' => 'asc'],
            'conditions' => [$searchString,'Users.status'=>1,'Users.role_id'=>11]
        ]);
        $this->paginate = ['limit' => 10];
        $projects = $this->paginate($rolesQuery);
        $this->set('selectedLen', $page_length);
        $this->set(compact('projects','pagCatList'));
    }

    /**
     * View method
     *
     * @param string|null $id Role id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $project_detail = $this->Users->get($id);  
		//echo "<pre>"; print_r($project_detail); exit;
        $this->set('project_detail', $project_detail);
    }
    /**
     * Edit method
     *
     * @param string|null $id Role id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $project_detail = $this->Users->get($id);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $data       = $this->request->getData();
            $data       = $this->Sanitize->clean($data);
            $project_detail = $this->Users->patchEntity($project_detail, $data);
			$modi = date("d-m-y h:i:s");
			$project_detail->modified = $modi;
            if ($this->Users->save($project_detail)) {
                $this->Flash->success(__('The Team Leader has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The Team Leader could not be saved. Please, try again.'));
        }
        $this->set(compact('project_detail'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Role id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
		$modi = date("d-m-y h:i:s");
		$query = $this->Users->query();
			$query->update()
			->set(['status' => 0,'modified'=>$modi])
			->where(['id' => $id])
			->execute();  
        if ($query) {
            $this->Flash->success(__('The Team Leader has been deleted.'));
        } else {
            $this->Flash->error(__('The Team Leader could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
