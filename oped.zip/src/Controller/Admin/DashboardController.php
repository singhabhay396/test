<?php
namespace App\Controller\Admin;

use App\Controller\Admin\AppController;
use Cake\Event\Event;

/**
 * Articles Controller
 *
 * @property \App\Model\Table\ArticlesTable $Articles
 *
 * @method \App\Model\Entity\Article[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class DashboardController extends AppController
{
	
    public function initialize()
    {
        parent::initialize();
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }


    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        /* $this->loadModel('StartupApplications');
        $role_id = $this->Auth->user('role_id');
        $total_startup_application = $this->StartupApplications->find()->where(['is_save_draft !='=>1])->orWhere(['is_save_draft IS'=>NULL])->count();
        //pr($total_startup_application); die();
        $approved_startup_application = $this->StartupApplications->find()->where(['application_status_id'=>6])->count();
        $rejected_startup_application = $this->StartupApplications->find()->where(['application_status_id'=>7])->count();
        $pending_array = array('6','7');
        $pending_startup_application = $this->StartupApplications->find()->where(['application_status_id NOT IN'=>$pending_array,'is_save_draft !='=>1])->orWhere(['application_status_id NOT IN'=>$pending_array,'is_save_draft IS'=>NULL])->count();


        $this->loadModel('Incubators');
        $this->loadModel('Partners');
        $this->loadModel('Mentors');
        $total_incubators = $this->Incubators->find()->where(['is_save_draft !='=>1])->orWhere(['is_save_draft IS'=>NULL])->count();
        //pr($total_startup_application); die();
        $approved_incubators = $this->Incubators->find()->where(['application_status_id'=>6])->count();
        $rejected_incubators = $this->Incubators->find()->where(['application_status_id'=>7])->count();
        $pending_array = array('6','7');
        $pending_incubators = $this->Incubators->find()->where(['application_status_id NOT IN'=>$pending_array,'is_save_draft !='=>1])->orWhere(['application_status_id NOT IN'=>$pending_array,'is_save_draft IS'=>NULL])->count();
        
        $total_mentors = $this->Mentors->find()->where(['is_save_draft !='=>1])->orWhere(['is_save_draft IS'=>NULL])->count();
        $approved_mentors = $this->Mentors->find()->where(['application_status_id'=>6])->count();
        $rejected_mentors = $this->Mentors->find()->where(['application_status_id'=>7])->count();
        $pending_array = array('6','7');
        $pending_mentors = $this->Mentors->find()->where(['application_status_id NOT IN'=>$pending_array,'is_save_draft !='=>1])->orWhere(['application_status_id NOT IN'=>$pending_array,'is_save_draft IS'=>NULL])->count();
        
        $total_partners = $this->Partners->find()->where(['is_save_draft !='=>1])->orWhere(['is_save_draft IS'=>NULL])->count();
        $approved_partners = $this->Partners->find()->where(['application_status_id'=>6])->count();
        $rejected_partners = $this->Partners->find()->where(['application_status_id'=>7])->count();
        $pending_array = array('6','7');
        $pending_partners = $this->Partners->find()->where(['application_status_id NOT IN'=>$pending_array,'is_save_draft !='=>1])->orWhere(['application_status_id NOT IN'=>$pending_array,'is_save_draft IS'=>NULL])->count(); */
        $this->set(compact('total_startup_application','approved_startup_application','rejected_startup_application','pending_startup_application','total_incubators','approved_incubators','rejected_incubators','pending_incubators','role_id','total_mentors','approved_mentors','rejected_mentors','pending_mentors','total_partners','approved_partners','rejected_partners','pending_partners'));
    }

}
