<?php
namespace App\Controller\Admin;

use App\Controller\Admin\AppController;
use Cake\Cache\Cache;
use Cake\Event\Event;
use Cake\Network\Exception\NotFoundException;
use Cake\Utility\Hash;
use Cake\Utility\Text;
use Cake\View\Exception\MissingTemplateException;
use Cake\Core\Configure;
use Cake\Filesystem\File;

/**
 * Achievements Controller
 *
 * @property \App\Model\Table\AchievementsTable $Achievements
 *
 * @method \App\Model\Entity\Achievement[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class AchievementsController extends AppController
{
    public function initialize()
    {
        parent::initialize();
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {   
        $search_condition = array();
        $data = $this->Sanitize->clean($this->request->getQuery());
        if (!empty($data['title'])) {
            $postTitle = trim($data['title']); 
            $this->set('title', $postTitle);
            $search_condition[] = "Achievements.title like '%" . $postTitle . "%'";
        }
        
        if (isset($this->request->query['status']) && $data['status'] !='') {
            $status = trim($data['status']);
            $this->set('status', $status);
            $search_condition[] = "Achievements.status = '" . $status . "'";
        }

        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        //pr($search_condition); die;
        $postQuery = $this->Achievements->find('all', [
            'order' => ['Achievements.id' => 'desc'],
            'conditions' => [$searchString]
        ]);

        $achievements = $this->paginate($postQuery);

        $this->set(compact('achievements'));
    }

    /**
     * View method
     *
     * @param string|null $id Achievement id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $achievement = $this->Achievements->get($id, [
            'contain' => ['Users', 'AchievementTranslations']
        ]);

        $this->set('achievement', $achievement);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $achievement = $this->Achievements->newEntity();
        if ($this->request->is('post')) {
            $data = $this->request->getData();
            $achievement_translations = [];
            if (isset($data['achievement_translations'])) {
                $achievement_translations = $data['achievement_translations'];
                unset($data['achievement_translations']);
            }
            $achievement->created = date('Y-m-d H:i:s');
            $achievement = $this->Achievements->patchEntity($achievement, $data);
            if($data['header_image']['name']!=''){
                $headerImage = $this->uploadFiles('achievements', $data['header_image']);
                $achievement->header_image = $headerImage['filename'];
            }
            if ($this->Achievements->save($achievement)) {
                $achievement_id = $achievement->id;
                if (!empty($achievement_translations)) {
                    $this->loadModel('AchievementTranslations');
                    foreach ($achievement_translations as $key => $_translation) {
                        if (empty($_translation['id'])) {
                            unset($achievement_translations[$key]['id']);
                        }
                        $achievement_translations[$key]['achievement_id'] = $achievement_id;
                    }
                    $achievementTranslation  = $this->AchievementTranslations->newEntity();
                    $achievementTranslation  = $this->AchievementTranslations->patchEntities($achievementTranslation, $achievement_translations);
                    $achievementTranslations = $this->AchievementTranslations->saveMany($achievementTranslation);
                }
                $this->Flash->success(__('The achievement has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The achievement could not be saved. Please, try again.'));
        }
    
        $achievementLanguages  = $this->languages;
        $system_languge_id = SYSTEM_LANGUAGE_ID;
        $this->set(compact('achievement', 'achievementLanguages', 'system_languge_id'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Achievement id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $achievement = $this->Achievements->get($id, [
            'contain' => ['AchievementTranslations']
        ]);
        $achievement['achievement_translations'] = Hash::combine($achievement['achievement_translations'], '{n}.language_id', '{n}');

        if ($this->request->is(['patch', 'post', 'put'])) {
            $data                 = $this->request->getData();
            $achievement_translations = [];
            if (isset($data['achievement_translations'])) {
                $achievement_translations = $data['achievement_translations'];
                unset($data['achievement_translations']);
            }
            $achievement->modified = date('Y-m-d H:i:s');
            $achievement = $this->Achievements->patchEntity($achievement, $data);
            if($data['header_image']['name']!=''){
                $headerImage = $this->uploadImage('achievements', $data['header_image']);
                $achievement->header_image = $headerImage['filename'];
            } else {
                $achievement->header_image = $data['old_header_image'];
            }
            if (empty($data['url'])) {
                $achievement->url        = strtolower(Text::slug($data['title']));
            } else {
                $achievement->url        = strtolower(Text::slug($data['url']));
            }
            if ($this->Achievements->save($achievement)) {
                $achievement_id = $achievement->id;
                if (!empty($achievement_translations)) {
                    $this->loadModel('AchievementTranslations');
                    foreach ($achievement_translations as $key => $_translation) {
                        if (empty($_translation['id'])) {
                            unset($achievement_translations[$key]['id']);
                        }
                        $achievement_translations[$key]['achievement_id'] = $achievement_id;
                    }
                    $achievementTranslation  = $this->AchievementTranslations->newEntity();
                    $achievementTranslation  = $this->AchievementTranslations->patchEntities($achievementTranslation, $achievement_translations);
                    $achievementTranslations = $this->AchievementTranslations->saveMany($achievementTranslation);
                }
                $this->Flash->success(__('The achievement has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The achievement could not be saved. Please, try again.'));
        }
        $achievementLanguages  = $this->languages;
        $system_languge_id = SYSTEM_LANGUAGE_ID;
        $this->set(compact('achievement', 'system_languge_id','achievementLanguages'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Achievement id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $achievement = $this->Achievements->get($id);
        if ($this->Achievements->delete($achievement)) {
            $this->Flash->success(__('The achievement has been deleted.'));
        } else {
            $this->Flash->error(__('The achievement could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
