<?php
namespace App\Controller\Admin;

use App\Controller\Admin\AppController;
use Cake\Cache\Cache;
use Cake\Event\Event;
use Cake\Network\Exception\NotFoundException;
use Cake\Utility\Hash;
use Cake\Utility\Text;
use Cake\View\Exception\MissingTemplateException;
use Cake\Core\Configure;
use Cake\Filesystem\File;
use Cake\ORM\TableRegistry;

/**
 * Events Controller
 *
 * @property \App\Model\Table\EventsTable $Events
 *
 * @method \App\Model\Entity\Event[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class EventsController extends AppController
{
    public function initialize()
    {
        parent::initialize();
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {

        $search_condition = array();
        $data = $this->Sanitize->clean($this->request->getQuery());
        if (!empty($data['title'])) {
            $postTitle = trim($data['title']); 
            $this->set('title', $postTitle);
            $search_condition[] = "Events.title like '%" . $postTitle . "%'";
        }
        
        if (isset($data['status']) && $data['status'] !='') {
            $status = trim($data['status']);
            $this->set('status', $status);
            $search_condition[] = "Events.status = '" . $status . "'";
        }

        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        //pr($search_condition); die;
        $postQuery = $this->Events->find('all', [
            'order' => ['Events.id' => 'desc'],
            'conditions' => [$searchString]
        ]);
        $this->paginate = ['limit' => 10];

        $events = $this->paginate($postQuery);

        $this->set(compact('events'));
    }

    /**
     * View method
     *
     * @param string|null $id Event id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $event = $this->Events->get($id, [
            'contain' => ['Users', 'EventTranslations']
        ]);

        $this->set('event', $event);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $event = $this->Events->newEntity();
        if ($this->request->is('post')) {
            $data = $this->request->getData();
            $event_translations = [];
            if (isset($data['event_translations'])) {
                $event_translations = $data['event_translations'];
                unset($data['event_translations']);
            }

            $event_images = [];
            if (isset($data['event_images'])) {
                $event_images = $data['event_images'];
                unset($data['event_images']);
            }
            $event->created = date('Y-m-d H:i:s');
            $event->updated = date('Y-m-d H:i:s');
            $event = $this->Events->patchEntity($event, $data);
            if($data['header_image']['name']!=''){
                $headerImage = $this->uploadFiles('events', $data['header_image']);
                $event->header_image = $headerImage['filename'];
            }
            if (empty($data['url'])) {
                $event->url        = strtolower(Text::slug($data['title']));
            } else {
                $event->url        = strtolower(Text::slug($data['url']));
            }
            if ($this->Events->save($event)) {
                $event_id = $event->id;
                if (!empty($event_translations)) {
                    $this->loadModel('EventTranslations');
                    foreach ($event_translations as $key => $_translation) {
                        if (empty($_translation['id'])) {
                            unset($event_translations[$key]['id']);
                        }
                        $event_translations[$key]['event_id'] = $event_id;
                    }
                    $eventTranslation  = $this->EventTranslations->newEntity();
                    $eventTranslation  = $this->EventTranslations->patchEntities($eventTranslation, $event_translations);
                    $eventTranslations = $this->EventTranslations->saveMany($eventTranslation);
                }

                if(!empty($event_images)){
                    $this->loadModel('EventImages');
                    foreach ($event_images as $key => $_translation) {
                        if (empty($_translation['id'])) {
                            unset($event_images[$key]['id']);
                        }
                        $event_images[$key]['event_id'] = $event_id;

                        if($_translation['event_image']['name']!=''){
                            $image = $this->uploadFiles('events', $_translation['event_image']);
                            $event_images[$key]['event_image'] = $image['filename'];
                        }else{
                            $event_images[$key]['event_image'] = @$_translation['event_image_old'];
                        }
                    }
                    $EventImages  = $this->EventImages->newEntity();
                    $EventImages  = $this->EventImages->patchEntities($EventImages, $event_images);
                    $EventImages = $this->EventImages->saveMany($EventImages);
                }
                $this->Flash->success(__('The event has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The event could not be saved. Please, try again.'));
        }
        $eventLanguages  = $this->languages;
        $system_languge_id = SYSTEM_LANGUAGE_ID;
        $this->set(compact('event', 'system_languge_id','eventLanguages'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Event id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $event = $this->Events->get($id, [
            'contain' => ['EventTranslations','EventImages']
        ]);
        $event['event_translations'] = Hash::combine($event['event_translations'], '{n}.language_id', '{n}');

        if ($this->request->is(['patch', 'post', 'put'])) {
            $data                 = $this->request->getData();
            $event_translations = [];
            if (isset($data['event_translations'])) {
                $event_translations = $data['event_translations'];
                unset($data['event_translations']);
            }

            $event_images = [];
            if (isset($data['event_images'])) {
                $event_images = $data['event_images'];
                unset($data['event_images']);
            }

            $event->updated = date('Y-m-d H:i:s');
            $event = $this->Events->patchEntity($event, $data);
            if($data['header_image']['name']!=''){
                $headerImage = $this->uploadImage('events', $data['header_image']);
                $event->header_image = $headerImage['filename'];
            } else {
                $event->header_image = $data['old_header_image'];
            }
            if ($this->Events->save($event)) {
                $event_id = $event->id;
                if (!empty($event_translations)) {
                    $this->loadModel('EventTranslations');
                    foreach ($event_translations as $key => $_translation) {
                        if (empty($_translation['id'])) {
                            unset($event_translations[$key]['id']);
                        }
                        $event_translations[$key]['event_id'] = $event_id;
                    }
                    $eventTranslation  = $this->EventTranslations->newEntity();
                    $eventTranslation  = $this->EventTranslations->patchEntities($eventTranslation, $event_translations);
                    $eventTranslations = $this->EventTranslations->saveMany($eventTranslation);
                }

                if(!empty($event_images)){
                    $this->loadModel('EventImages');
                    foreach ($event_images as $key => $_translation) {
                        if (empty($_translation['id'])) {
                            unset($event_images[$key]['id']);
                        }
                        $event_images[$key]['event_id'] = $event_id;

                        if($_translation['event_image']['name']!=''){
                            $image = $this->uploadFiles('events', $_translation['event_image']);
                            $event_images[$key]['event_image'] = $image['filename'];
                        }else{
                            $event_images[$key]['event_image'] = @$_translation['event_image_old'];
                        }
                    }
                    $EventImages  = $this->EventImages->newEntity();
                    $EventImages  = $this->EventImages->patchEntities($EventImages, $event_images);
                    $EventImages = $this->EventImages->saveMany($EventImages);
                }

                $this->Flash->success(__('The event has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The event could not be saved. Please, try again.'));
        }
        $eventLanguages  = $this->languages;
        $system_languge_id = SYSTEM_LANGUAGE_ID;
        $this->set(compact('event', 'system_languge_id','eventLanguages'));
    }

    public function removeEventImage()
    {
        $this->viewBuilder()->layout('ajax');
        $id = $_POST['id'];
        $table_name     = 'event_images';
        $custumTable    = TableRegistry::getTableLocator()->get($table_name);
        $removeQuery    = $custumTable->get($id);
        if($custumTable->delete($removeQuery)){
            echo 'removed';
        }
        exit;  
    }

    /**
     * Delete method
     *
     * @param string|null $id Event id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $event = $this->Events->get($id);
        if ($this->Events->delete($event)) {
            $this->Flash->success(__('The event has been deleted.'));
        } else {
            $this->Flash->error(__('The event could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
