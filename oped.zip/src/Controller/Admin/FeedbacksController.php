<?php
namespace App\Controller\Admin;

use App\Controller\Admin\AppController;
use Cake\Cache\Cache;
use Cake\Event\Event;
use Cake\Network\Exception\NotFoundException;
use Cake\Utility\Hash;
use Cake\View\Exception\MissingTemplateException;
use Cake\Core\Configure;
use Cake\ORM\TableRegistry;      

/**
 * Complaints Controller
 *
 * @property \App\Model\Table\ComplaintsTable $Complaints
 *
 * @method \App\Model\Entity\PolicyDownload[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class FeedbacksController extends AppController
{
    
    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */

    public $grievancetype = ['1'=>'Technical Query','2'=>'Public Procurement','3'=>'Regulatory issue'];

    public function index()
    {
        $this->loadModel('Complaints');
        $search_condition = array();
        $data = $this->Sanitize->clean($this->request->getQuery());
        if (!empty($data['full_name'])) {
            $postTitle = trim($data['full_name']); 
            $this->set('full_name', $postTitle);
            $search_condition[] = "Complaints.full_name like '%" . $postTitle . "%'";
        }

        if (!empty($data['reference_number'])) {
            $referenceNumber = trim($data['reference_number']); 
            $this->set('reference_number', $referenceNumber);
            $search_condition[] = "Complaints.reference_number like '%" . $referenceNumber . "%'";
        }

        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        //pr($search_condition); die;
        $postQuery = $this->Complaints->find('all', [
            'order' => ['Complaints.id' => 'desc'],
            'conditions' => [$searchString]
        ]);
        $this->paginate = ['limit' => 10];
        
        $complaints = $this->paginate($postQuery);
        $grievancetype = $this->grievancetype;
        $this->set(compact('complaints','grievancetype'));
    }

    /**
     * View method
     *
     * @param string|null $id Policy Download id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $this->loadModel('Complaints');
        $complaint = $this->Complaints->get($id, [
            'contain' => []
        ]);
        $grievancetype = $this->grievancetype;
        $this->set(compact('complaint','grievancetype'));
    }

    /**   
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    
}
