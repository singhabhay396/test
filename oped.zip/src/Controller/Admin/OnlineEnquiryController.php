<?php
namespace App\Controller\Admin;

use App\Controller\Admin\AppController;
use Cake\Event\Event;
use Cake\Network\Exception\NotFoundException;
use Cake\View\Exception\MissingTemplateException;
use Cake\I18n\Time;

/**
 * OnlineEnquiry Controller
 *
 * @property \App\Model\Table\OnlineEnquiryTable $OnlineEnquiry
 *
 * @method \App\Model\Entity\OnlineEnquiry[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class OnlineEnquiryController extends AppController
{
    public function initialize()
    {
        parent::initialize();
        $this->loadComponent('Paginator');
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $search_condition = array();
        $page_length = !empty($this->request->query['page_length']) ? $this->request->query['page_length'] : 10;
        if (!empty($this->request->getQuery('name'))) {
            $name = trim($this->request->getQuery('name'));
            $this->set('name', $name);
            $search_condition[] = "OnlineEnquiry.name like '%" . $name . "%'";
        }
        if (!empty($this->request->getQuery('emailid'))) {
            $emailid = trim($this->request->getQuery('emailid'));
            $this->set('emailid', $emailid);
            $search_condition[] = "OnlineEnquiry.emailid like '%" . $emailid . "%'";
        }
        if (!empty($this->request->getQuery('mobile_number'))) {
            $mobile_number = trim($this->request->getQuery('mobile_number'));
            $this->set('mobile_number', $mobile_number);
            $search_condition[] = "OnlineEnquiry.mobile_number like '%" . $mobile_number . "%'";
        }
        if (!empty($this->request->getQuery('location'))) {
            $location = trim($this->request->getQuery('location'));
            $this->set('location', $location);
            $search_condition[] = "OnlineEnquiry.location like '%" . $location . "%'";
        }
        if (!empty($this->request->getQuery('fromdate'))) {
            $this->set('fromdate', $this->request->getQuery('fromdate'));
            $date_from = Time::createFromFormat('d-m-Y',$this->request->getQuery('fromdate'));
            $date_from = date('Y-m-d', strtotime($date_from));
            $search_condition[] = "DATE(OnlineEnquiry.created_at) >= '" . $date_from . "'";
        }
        if (!empty($this->request->getQuery('todate'))) {
            $this->set('todate', $this->request->getQuery('todate'));
            $date_to = Time::createFromFormat('d-m-Y',$this->request->getQuery('todate'));
            $date_to = date('Y-m-d', strtotime($date_to));
            $search_condition[] = "DATE(OnlineEnquiry.created_at) <= '" . $date_to . "'";
        }
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        if ($page_length != 'all' && is_numeric($page_length)) {
            $page_length = $page_length;
        }else if ($page_length == 'all') {
            $selectedLen = 'all';
            $page_length = $this->OnlineEnquiry->find('all')->enableHydration('false')->count();
        } else {
            $page_length = $this->OnlineEnquiry->find('all')->enableHydration('false')->count();
        }
        $needOptions = [1=>'Venture Funds',2=>'Refinance',3=>'NBFC assistance',4=>'Loans',5=>'Micro-Finance',6=>'PSIG Programmes',7=>'Small Finance Banks',8=>'Bonds/Debentures/Fixed Deposits',9=>'Others'];

        if(!empty($this->request->getQuery('export_excel'))) {
            $queryExport = $this->OnlineEnquiry->find('all',[
                'conditions'=>[$searchString],
                'order'=>['id'=>'DESC'],
                'limit' =>$page_length
            ])->enableHydration(false)->toArray();

            $fileName = "online_enquiry_".date("YmdHis").".xls";
            $headerRow = array("S.No","Reference Number", "Name", "Email Id", "Location", "Quantum of assistance sought", "Mobile Number", "What do you Need?", "Other Need", "Description", "Enquiry Date & Time");
            $data = array();
            $i=1;
            foreach($queryExport As $rows){
                $data[]=array($i,$rows['reference_number'],$rows['name'],$rows['emailid'],$rows['location'],$rows['qoas'],$rows['mobile_number'],@$needOptions[$rows['need']],$rows['other_need'],$this->strClean($rows['description']),$rows['created_at'],
                );
                $i++;
            }
            $this->exportInExcel($fileName, $headerRow, $data);
        }

        $postQuery = $this->OnlineEnquiry->find('all', [
            'order' => ['OnlineEnquiry.id' => 'desc'],
            'conditions' => [$searchString]
        ]);
        $this->paginate = ['limit' => $page_length,'maxLimit' => $page_length];
        $products = $this->paginate($postQuery);
        $this->set('selectedLen', $page_length);
        $this->set(compact('products','selectedLen'));
    }

    public function complaintsGrievance($value='')
    {
        $this->loadModel('Complaints');
        $search_condition = array();
        $page_length = !empty($this->request->query['page_length']) ? $this->request->query['page_length'] : 10;
        
        if (!empty($this->request->getQuery('name'))) {
            $name = trim($this->request->getQuery('name'));
            $this->set('name', $name);
            $search_condition[] = "Complaints.full_name like '%" . $name . "%'";
        }
        if (!empty($this->request->getQuery('emailid'))) {
            $emailid = trim($this->request->getQuery('emailid'));
            $this->set('emailid', $emailid);
            $search_condition[] = "Complaints.email_id like '%" . $emailid . "%'";
        }
        if (!empty($this->request->getQuery('mobile_number'))) {
            $mobile_number = trim($this->request->getQuery('mobile_number'));
            $this->set('mobile_number', $mobile_number);
            $search_condition[] = "Complaints.mobile_number like '%" . $mobile_number . "%'";
        }
        if (!empty($this->request->getQuery('company_name'))) {
            $company_name = trim($this->request->getQuery('company_name'));
            $this->set('company_name', $company_name);
            $search_condition[] = "Complaints.company_name like '%" . $company_name . "%'";
        }
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }

        if ($page_length != 'all' && is_numeric($page_length)) {
            $page_length = $page_length;
        }else if ($page_length == 'all') {
            $selectedLen = 'all';
            $page_length = $this->OnlineEnquiry->find('all')->enableHydration('false')->count();
        } else {
            $page_length = $this->OnlineEnquiry->find('all')->enableHydration('false')->count();
        }

        if(!empty($this->request->getQuery('export_excel'))) {
            $queryExport = $this->Complaints->find('all',[
                'conditions'=>[$searchString],
                'order'=>['id'=>'DESC'],
                'limit' =>$page_length
            ])->enableHydration(false)->toArray();

            $fileName = "complaints_grievance_".date("YmdHis").".xls";
            $headerRow = array("S.No", "Full Name", "Email Id", "Mobile Number", "Fixed Line Number", "Company Name", "Address", "City", "State", "Country", "Pincode", "Subject", "Comments", "Complaint Date & Time");
            $data = array();
            $c=1;
            foreach($queryExport As $rows){
                $data[]=array($c,$rows['full_name'],$rows['email_id'],$rows['mobile_number'],$rows['fixed_line_number'],$rows['company_name'],$this->strClean($rows['address']),$rows['city'],$rows['state'],$rows['country'],$rows['pincode'],$rows['subject'],$this->strClean($rows['comments']),$rows['created']
                );
                $c++;
            }
            $this->exportInExcel($fileName, $headerRow, $data);
        }
        $postQuery = $this->Complaints->find('all', [
            'order' => ['Complaints.id' => 'desc'],
            'conditions' => [$searchString]
        ]);
        $this->paginate = ['limit' => $page_length,'maxLimit' => $page_length];
        $products = $this->paginate($postQuery);
        $this->set('selectedLen', $page_length);
        $this->set(compact('products','selectedLen'));
    }

    public function complaintsView($id = null)
    {
        $this->loadModel('Complaints');
        $onlineEnquiry = $this->Complaints->get($id, [
            'contain' => []
        ]);

        $this->set('onlineEnquiry', $onlineEnquiry);
    }

    /**
     * View method
     *
     * @param string|null $id Product id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $onlineEnquiry = $this->OnlineEnquiry->get($id, [
            'contain' => []
        ]);

        $this->set('onlineEnquiry', $onlineEnquiry);
    }

    public function loansIndex($value='')
    {
        $this->loadModel('LoanEnquiry');
        $search_condition = array();
        $page_length = !empty($this->request->query['page_length']) ? $this->request->query['page_length'] : 10;
        if (!empty($this->request->getQuery('name'))) {
            $name = trim($this->request->getQuery('name'));
            $this->set('name', $name);
            $search_condition[] = "LoanEnquiry.name like '%" . $name . "%'";
        }
        if (!empty($this->request->getQuery('emailid'))) {
            $emailid = trim($this->request->getQuery('emailid'));
            $this->set('emailid', $emailid);
            $search_condition[] = "LoanEnquiry.emailid like '%" . $emailid . "%'";
        }
        if (!empty($this->request->getQuery('mobile_number'))) {
            $mobile_number = trim($this->request->getQuery('mobile_number'));
            $this->set('mobile_number', $mobile_number);
            $search_condition[] = "LoanEnquiry.mobile_number like '%" . $mobile_number . "%'";
        }
        if (!empty($this->request->getQuery('location'))) {
            $location = trim($this->request->getQuery('location'));
            $this->set('location', $location);
            $search_condition[] = "LoanEnquiry.location like '%" . $location . "%'";
        }
        if (!empty($this->request->getQuery('fromdate'))) {
            $this->set('fromdate', $this->request->getQuery('fromdate'));
            $date_from = Time::createFromFormat('d-m-Y',$this->request->getQuery('fromdate'));
            $date_from = date('Y-m-d', strtotime($date_from));
            $search_condition[] = "DATE(LoanEnquiry.created_at) >= '" . $date_from . "'";
        }
        if (!empty($this->request->getQuery('todate'))) {
            $this->set('todate', $this->request->getQuery('todate'));
            $date_to = Time::createFromFormat('d-m-Y',$this->request->getQuery('todate'));
            $date_to = date('Y-m-d', strtotime($date_to));
            $search_condition[] = "DATE(LoanEnquiry.created_at) <= '" . $date_to . "'";
        }
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        if ($page_length != 'all' && is_numeric($page_length)) {
            $page_length = $page_length;
        }else if ($page_length == 'all') {
            $selectedLen = 'all';
            $page_length = $this->LoanEnquiry->find('all')->enableHydration('false')->count();
        } else {
            $page_length = $this->LoanEnquiry->find('all')->enableHydration('false')->count();
        }

        if(!empty($this->request->getQuery('export_excel'))) {
            $queryExport = $this->LoanEnquiry->find('all',[
                'conditions'=>[$searchString],
                'order'=>['id'=>'DESC'],
                'limit' =>$page_length
            ])->enableHydration(false)->toArray();

            $fileName = "loan_enquiry_".date("YmdHis").".xls";
            $headerRow = array("S.No", "Name", "Email Id", "Location", "Quantum of assistance sought", "Mobile Number", "Product", "Scheme", "Description", "Enquiry Date & Time");
            $data = array();
            $i=1;
            foreach($queryExport As $rows){
                $data[]=array($i,$rows['name'],$rows['emailid'],$rows['location'],$rows['qoas'],$rows['mobile_number'],"Direct Loan",$rows['need'],$this->strClean($rows['description']),$rows['created_at'],
                );
                $i++;
            }
            $this->exportInExcel($fileName, $headerRow, $data);
        }

        $postQuery = $this->LoanEnquiry->find('all', [
            'order' => ['LoanEnquiry.id' => 'desc'],
            'conditions' => [$searchString]
        ]);
        $this->paginate = ['limit' => $page_length,'maxLimit' => $page_length];
        $products = $this->paginate($postQuery);
        $this->set('selectedLen', $page_length);
        $this->set(compact('products','selectedLen'));
    }

    public function loansView($id = null)
    {
        $this->loadModel('LoanEnquiry');
        $loanEnquiry = $this->LoanEnquiry->get($id, [
            'contain' => []
        ]);
        $this->set('loanEnquiry', $loanEnquiry);
    }
}