<?php
namespace App\Controller\Admin;

use App\Controller\Admin\AppController;
use Cake\Event\Event;
use Cake\Utility\Text;
use Cake\Network\Exception\NotFoundException;
use Cake\Utility\Hash;
use Cake\View\Exception\MissingTemplateException;
use Cake\ORM\TableRegistry;

/**
 * Products Controller
 *
 * @property \App\Model\Table\ProductsTable $Products
 *
 * @method \App\Model\Entity\Product[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class ProductsController extends AppController
{
    public function initialize()
    {
        parent::initialize();
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }

    private $productCategory = [
        1 => 'Product',
        2 => 'Investors Relation',
        3 => 'Micro Finance',
        4 => 'Indirect Finance',
        5 => 'Venture Capital',
		6 => 'Other'
    ];

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $search_condition = array();
        if (!empty($this->request->getQuery('title'))) {
            $title = trim($this->request->getQuery('title'));
            $this->set('title', $title);
            $search_condition[] = "Products.title like '%" . $title . "%'";
        }
		
        if (isset($this->request->query['status']) && $this->request->getQuery('status') !='') {
            $status = trim($this->request->getQuery('status'));
            $this->set('status', $status);
            $search_condition[] = "Products.status = '" . $status . "'";
        }
		
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        $postQuery = $this->Products->find('all', [
            'contain' => ['Users'],
            'order' => ['Products.id' => 'desc'],
            'conditions' => [$searchString]
        ]);
        $this->paginate = ['limit' => 10];
        $products = $this->paginate($postQuery);
        $this->set(compact('products'));
    }

    /**
     * View method
     *
     * @param string|null $id Product id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $product = $this->Products->get($id, [
            'contain' => ['ProductTranslations']
        ]);
        $productCategory  = $this->productCategory;
        $this->set(compact('product','productCategory'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $product = $this->Products->newEntity();
        if ($this->request->is('post')) {
            $data                   = $this->request->getData();
            $product_translations   = [];
            if (isset($data['product_translations'])) {
                $product_translations = $data['product_translations'];
                unset($data['product_translations']);
            }
            $product_blocks   = [];
            if (isset($data['product_blocks'])) {
                $product_blocks = $data['product_blocks'];
                unset($data['product_blocks']);
            }
            $tproduct_blocks = [];
            if (isset($product_translations['product_blocks'])) {
                $tproduct_blocks  = $product_translations['product_blocks'];
                unset($product_translations['product_blocks']);
            }
            $product_blocks      = array_merge($product_blocks, $tproduct_blocks);
            $product = $this->Products->patchEntity($product, $data);
            if($data['icon']['name']!=''){
                $doc1 = $this->uploadFiles('product', $data['icon']);
                $product->icon = $doc1['filename'];
            }
            if($data['header_image']['name']!=''){
                $doc2 = $this->uploadFiles('product', $data['header_image']);
                $product->header_image = $doc2['filename'];
            }
            if (empty($data['url'])) {
                $product->url = strtolower(Text::slug($data['title']));
            } else {
                $product->url = strtolower(Text::slug($data['url']));
            }
            if ($this->Products->save($product)) {
                $product_id = $product->id;
                if (!empty($product_translations)) {
                    $this->loadModel('ProductTranslations');
                    foreach ($product_translations as $key => $_translation) {
                        if (empty($_translation['id'])) {
                            unset($product_translations[$key]['id']);
                        }
                        $product_translations[$key]['product_id'] = $product_id;
                    }
                    $productTranslation  = $this->ProductTranslations->newEntity();
                    $productTranslation  = $this->ProductTranslations->patchEntities($productTranslation, $product_translations);
                    $productTranslations = $this->ProductTranslations->saveMany($productTranslation);
                    //$this->News->productCache();
                }
                if (!empty($product_blocks)) {
                    $this->loadModel('ProductBlocks');
                    foreach ($product_blocks as $key => $_blocks) {
                        if (empty($_blocks['id'])) {
                            unset($product_blocks[$key]['id']);
                        }
                        if($_blocks['block_icon']['name']!=''){
                            $proDoc = $this->uploadFiles('product', $_blocks['block_icon']);
                            $product_blocks[$key]['block_icon'] = $proDoc['filename'];
                        }
                        $product_blocks[$key]['product_id'] = $product_id;
                    }
                    $productBlock  = $this->ProductBlocks->newEntity();
                    $productBlock  = $this->ProductBlocks->patchEntities($productBlock, $product_blocks);
                    $productBlocks = $this->ProductBlocks->saveMany($productBlock);
                }
                $this->Flash->success(__('The product has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The product could not be saved. Please, try again.'));
        }
        $productLanguages  = $this->languages;
        $system_languge_id = SYSTEM_LANGUAGE_ID;
        $productCategory  = $this->productCategory;
        $this->set(compact('product', 'productLanguages', 'system_languge_id','productCategory'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Product id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $product = $this->Products->get($id, [
            'contain' => ['ProductTranslations','ProductBlocks']
        ]);
        $product['product_translations'] = Hash::combine($product['product_translations'], '{n}.language_id', '{n}');

        if(!empty($product['product_blocks'])){
            $product['english_block'] = array_filter($product['product_blocks'], function($el) { return $el['language_id'] == 1 ; });
            $product['hindi_block'] = array_filter($product['product_blocks'], function($el) { return $el['language_id'] == 2 ; });
            unset($product['product_blocks']);
        }
        if ($this->request->is(['patch', 'post', 'put'])) {
            $data                   = $this->request->getData();
            $product_translations   = [];
            if (isset($data['product_translations'])) {
                $product_translations = $data['product_translations'];
                unset($data['product_translations']);
            }
            $product_blocks   = [];
            if (isset($data['product_blocks'])) {
                $product_blocks = $data['product_blocks'];
                unset($data['product_blocks']);
            }
            $tproduct_blocks = [];
            if (isset($product_translations['product_blocks'])) {
                $tproduct_blocks  = $product_translations['product_blocks'];
                unset($product_translations['product_blocks']);
            }
            $product_blocks      = array_merge($product_blocks, $tproduct_blocks);
            $product = $this->Products->patchEntity($product, $data);
            if($data['icon']['name']!=''){
                $doc1 = $this->uploadFiles('product', $data['icon']);
                $product->icon = $doc1['filename'];
            } else {
                $product->icon = $data['old_icon'];
            }
            if($data['header_image']['name']!=''){
                $doc2 = $this->uploadFiles('product', $data['header_image']);
                $product->header_image = $doc2['filename'];
            } else {
                $product->header_image = $data['old_header_image'];
            }
            if (empty($data['url'])) {
                $product->url = strtolower(Text::slug($data['title']));
            } else {
                $product->url = strtolower(Text::slug($data['url']));
            }
            if ($this->Products->save($product)) {
                $product_id = $product->id;
                if (!empty($product_translations)) {
                    $this->loadModel('ProductTranslations');
                    foreach ($product_translations as $key => $_translation) {
                        if (empty($_translation['id'])) {
                            unset($product_translations[$key]['id']);
                        }
                        $product_translations[$key]['product_id'] = $product_id;
                    }
                    $productTranslation  = $this->ProductTranslations->newEntity();
                    $productTranslation  = $this->ProductTranslations->patchEntities($productTranslation, $product_translations);
                    $productTranslations = $this->ProductTranslations->saveMany($productTranslation);
                    //$this->News->productCache();
                }
                if (!empty($product_blocks)) {
                    $this->loadModel('ProductBlocks');
                    foreach ($product_blocks as $key => $_blocks) {
                        if (empty($_blocks['id'])) {
                            unset($product_blocks[$key]['id']);
                        }
                        if($_blocks['block_icon']['name']!=''){
                            $proDoc = $this->uploadFiles('product', $_blocks['block_icon']);
                            $product_blocks[$key]['block_icon'] = $proDoc['filename'];
                        } else {
                            $product_blocks[$key]['block_icon'] = $_blocks['old_block_icon'];
                        }
                        $product_blocks[$key]['product_id'] = $product_id;
                    }
                    $productBlock  = $this->ProductBlocks->newEntity();
                    $productBlock  = $this->ProductBlocks->patchEntities($productBlock, $product_blocks);
                    $productBlocks = $this->ProductBlocks->saveMany($productBlock);
                }
                $this->Flash->success(__('The product has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The product could not be saved. Please, try again.'));
        }
        $productLanguages  = $this->languages;
        $system_languge_id = SYSTEM_LANGUAGE_ID;
        $productCategory  = $this->productCategory;
        $this->set(compact('product','productLanguages','system_languge_id','productCategory'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Product id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $product = $this->Products->get($id);
        if ($this->Products->delete($product)) {
            $this->loadModel('ProductTranslations');
            $this->ProductTranslations->deleteAll(['product_id' => $id]);
            $this->Flash->success(__('The product has been deleted.'));
        } else {
            $this->Flash->error(__('The product could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }

    public function deleteRow()
    {
        $this->viewBuilder()->setLayout('ajax');
        $row_id         = $_POST['id'];
        $table_name     = $_POST['table_name'];
        $custumTable    = TableRegistry::getTableLocator()->get($table_name);
        $removeQuery    = $custumTable->get($row_id);
        if($custumTable->delete($removeQuery)){
            echo 'removed';            
        }
        exit;  
    }
}
