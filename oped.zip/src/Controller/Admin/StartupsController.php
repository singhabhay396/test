<?php
namespace App\Controller\Admin;

use App\Controller\Admin\AppController;
use Cake\Core\Configure;
use Cake\Event\Event;
use Cake\Network\Exception\NotFoundException;
use Cake\View\Exception\MissingTemplateException;

/**
 * Startups Controller
 *
 * @property \App\Model\Table\StartupsTable $Startups
 *
 * @method \App\Model\Entity\Startups[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class StartupsController extends AppController
{
    public function initialize()
    {
        parent::initialize();
        $this->Auth->allow(['index']);
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }

    /**
     * Page method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
       return $this->redirect(['action' => 'recognitionList']);
    }
    
    public function recognitionList()
    {
        $this->loadModel('StartupApplications');


        $search_condition = array();
        if (!empty($this->request->getQuery('reference_no'))) {
            $reference_no = trim($this->request->getQuery('reference_no'));
            $this->set('reference_no', $reference_no); 
            $search_condition[] = "StartupApplications.reference_no like '%" . $reference_no . "%'";
        }
        if (!empty($this->request->getQuery('name_of_startup'))) {
            $name_of_startup = trim($this->request->getQuery('name_of_startup'));
            $this->set('name_of_startup', $name_of_startup); 
            $search_condition[] = "StartupApplications.name_of_startup like '%" . $name_of_startup . "%'";
        }    

        if (!empty($this->request->getQuery('recognition_certificate_no'))) {
            $recognition_certificate_no = trim($this->request->getQuery('recognition_certificate_no'));
            $this->set('recognition_certificate_no', $recognition_certificate_no); 
            $search_condition[] = "StartupApplications.recognition_certificate_no like '%" . $recognition_certificate_no . "%'";
        }

        if (!empty($this->request->getQuery('cin_llpin'))) {
            $cin_llpin = trim($this->request->getQuery('cin_llpin'));
            $this->set('cin_llpin', $cin_llpin); 
            $search_condition[] = "StartupApplications.cin_llpin like '%" . $cin_llpin . "%'";
        }
        
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }

        $applications = $this->StartupApplications->find()->contain(['Users','ApplicationStatus'])->order(['StartupApplications.id'=>'DESC'])->where([$searchString,'is_save_draft'=>0]);

        $this->paginate = ['limit' => 10];
        $applications = $this->paginate($applications);
        $this->set(compact('applications'));
    }

    public function recognitionEdit($id)
    {
        $id = base64_decode($id);
        $this->loadModel('StartupApplications');
        $application = $this->StartupApplications->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'recognitionList']);
        }
        if ($application->application_status_id == 7) {
            $this->Flash->error(__('This application has been already rejected.'));
            return $this->redirect(['action' => 'recognitionList']);
        }
        $applications = $this->StartupApplications->get($id,['contain'=>['Users']]);
        if($this->request->is(['post','put'])){
            $data = $this->request->getData();
            $applications = $this->StartupApplications->patchEntity($applications,$data);
            if(!empty($data['approve'])){
                $applications->application_status_id = 2;
                $applications->startup_stage_id = 2;
            }elseif(!empty($data['reject'])){
                $applications->application_status_id = 7;
            }
            $applications->updated = date('Y-m-d H:i:s');
			
			$applications->admin_remark_date = date('Y-m-d');
			if($data['admin_remark_doc']['name']!=''){
                $certificate = $this->uploadFiles('registration', $data['admin_remark_doc']);
                $applications->admin_remark_doc = $certificate['filename'];
            }
            if($this->StartupApplications->save($applications)){
				if(!empty($data['approve'])){
					/*startup_application_file_movements Table*/
					$tableName 					= 'StartupApplicationFileMovements';
					$application_id_columnName 	= 'startup_application_id';
					$startup_application_id 	= $id;
					$comment					= $data['admin_reason'];
					$current_with				= 'Reviewer Officer';
					$initiated_date				= $applications->created;
					$panding_from				= date('Y-m-d');	
					
					$this->fileMovement($tableName, $application_id_columnName, $startup_application_id, $current_with, $comment, $initiated_date, $panding_from, $data);
				}
				$this->Flash->success(__('You have successfully updated the status'));
                return $this->redirect(['action' => 'recognitionList']);
            }else{
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        }
        $this->set(compact('applications'));
    }
	/***
	$tableName = 'StartupApplicationFileMovements';
	$application_id_columnName 	= 'startup_application_id';
	$startup_application_id 	= application id;
	$comment					= reason of officer;
	$current_with				= Sent to officer.  Ex:'Reviewer Officer';
	$initiated_date				= date of application initiated Ex. Created
	$panding_from				= 
	*/
	/* public function fileMovement($tableName,$application_id_columnName, $application_id, $current_with, $comment, $initiated_date, $panding_from){
		$this->loadModel($tableName);
		$filemovement = $this->$tableName->newEntity();
		
		if($data['admin_remark_doc']['name']!=''){
			$certificate = $this->uploadFiles('registration', $data['admin_remark_doc']);
			$filemovement->file_doc = $certificate['filename'];
		}
		$filemovement->$application_id_columnName	= $application_id;
		$filemovement->initiated_by 				= $this->Auth->user('name');
		$filemovement->current_with 				= $current_with;
		$filemovement->comment						= $comment;
		$filemovement->initiated_date 				= $initiated_date;
		$filemovement->panding_from					= $panding_from;
		$filemovement->created						= date('Y-m-d H:s:i');
		//print_r($filemovement);exit;
		$this->$tableName->save($filemovement); 
	} */
	public function recognitionView($id)
    {
		$this->loadModel('StartupApplicationFileMovements');
        $id = base64_decode($id);
        $this->loadModel('StartupApplications');
        $application = $this->StartupApplications->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'recognitionList']);
        }
        $applications = $this->StartupApplications->get($id);
        $startupApplication = $this->StartupApplications->get($id,['contain'=>['Users','RegisteredStates','RegisteredDistricts','CorporateStates','CorporateDistricts','RegionalStates','RegionalDistricts','StartupStages','ApplicationStatus','NatureOfStartup','StartupCategories','Industries','Sectors','IncorporationAuthorities', 'IndustriesOfProduct', 'SectorsOfProduct','StartupDirectors',  'StartupDirectors.DirectorStates', 'StartupDirectors.DirectorDistricts']]);
        
		$categoryOfProduct = [1=>'Innovative',2=>'Proprietary'];
        $currentStartupStage = [1=>'Ideation',2=>'Early Traction',3=>'Scalable business'];
		
		$StartupApplicationFileMovements = $this->StartupApplicationFileMovements->find('all')->where(['StartupApplicationFileMovements.startup_application_id '=>$startupApplication->id])->toArray();
		$nationality= [1=>'Indian'];
		$this->set(compact('startupApplication', 'categoryOfProduct', 'currentStartupStage', 'nationality','applications', 'StartupApplicationFileMovements'));
		//echo "<pre>"; print_r($StartupApplicationFileMovements);exit;
    }

    public function leaseRentalList()
    {
        
        $this->loadModel('StartupLeaseIncentives');
        
        $search_condition = array();
        if (!empty($this->request->getQuery('reference_number'))) {
            $reference_number = trim($this->request->getQuery('reference_number'));
            $this->set('reference_number', $reference_number); 
            $search_condition[] = "StartupLeaseIncentives.reference_number like '%" . $reference_number . "%'";
        }
        if (!empty($this->request->getQuery('startup_name'))) {
            $startup_name = trim($this->request->getQuery('startup_name'));
            $this->set('startup_name', $startup_name); 
            $search_condition[] = "StartupLeaseIncentives.startup_name like '%" . $startup_name . "%'";
        }    

        if (!empty($this->request->getQuery('registration_number'))) {
            $registration_number = trim($this->request->getQuery('registration_number'));
            $this->set('registration_number', $registration_number); 
            $search_condition[] = "StartupLeaseIncentives.registration_number like '%" . $registration_number . "%'";
        }

        if (!empty($this->request->getQuery('rental_amount'))) {
            $rental_amount = trim($this->request->getQuery('rental_amount'));
            $this->set('rental_amount', $rental_amount); 
            $search_condition[] = "StartupLeaseIncentives.rental_amount like '%" . $rental_amount . "%'";
        }
        
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }

        $postQuery = $this->StartupLeaseIncentives->find()->contain(['StartupApplications','Designations','ApplicationStatus'])->order(['StartupLeaseIncentives.id'=>'DESC'])->where([$searchString]);

		//echo "<pre>"; print_r($postQuery->toArray());exit;
        $this->paginate = ['limit' => 10];
        $applications = $this->paginate($postQuery);
        $this->set(compact('applications'));
    }

    public function leaseRentalView($id)
    {
        $id = base64_decode($id);
        $this->loadModel('StartupLeaseIncentives');
		$this->loadModel('StartupLeaseIncentivesFileMovements');
        $application = $this->StartupLeaseIncentives->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'leaseRentalList']);
        }
        $startupLeaseIncentive = $this->StartupLeaseIncentives->get($id,['contain'=>['StartupApplications','Designations','ApplicationStatus','ApplicationStages', 'StartupApplications.Users']]);
		
		$typeOfOffice = [1=>'Registered',2=>'Corporate',3=>'Operational'];
		
		//echo "<pre>";print_r($startupLeaseIncentive);exit;
		$startupLeaseIncentiveFileMovements = $this->StartupLeaseIncentivesFileMovements->find('all')->where(['StartupLeaseIncentivesFileMovements.startup_lease_incentive_id '=>$startupLeaseIncentive->id])->toArray();
        $this->set(compact('startupLeaseIncentive', 'typeOfOffice', 'startupLeaseIncentiveFileMovements'));
    }

    public function leaseRentalEdit($id)
    {
        $id = base64_decode($id);
		$this->loadModel('StartupLeaseIncentives');
        $application = $this->StartupLeaseIncentives->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Something went wrong.'));
            return $this->redirect(['action' => 'leaseRentalList']);
        }
        $startupLeaseIncentive = $this->StartupLeaseIncentives->get($id);
        if($this->request->is(['post','put'])){
            $data = $this->request->getData();
            $startupLeaseIncentive = $this->StartupLeaseIncentives->patchEntity($startupLeaseIncentive,$data);
            $startupLeaseIncentive->admin_reason = $data['admin_reason'];
            if(!empty($data['approve'])){
                $startupLeaseIncentive->application_status_id = 2;
                $startupLeaseIncentive->application_stage_id  = 2;
            }elseif(!empty($data['reject'])){
                $startupLeaseIncentive->application_status_id = 7;
            }
            $startupLeaseIncentive->updated = date('Y-m-d H:i:s');
			
			$startupLeaseIncentive->admin_remark_date = date('Y-m-d');
			/* if($data['admin_remark_doc']['name']!=''){
                $certificate = $this->uploadFiles('lease-rental', $data['admin_remark_doc']);
                $startupLeaseIncentive->admin_remark_doc = $certificate['filename'];
            } */
			
            if($this->StartupLeaseIncentives->save($startupLeaseIncentive)){
				
				if(!empty($data['approve'])){
					/*startup_application_file_movements Table*/
					$tableName 					= 'StartupLeaseIncentivesFileMovements';
					$application_id_columnName 	= 'startup_lease_incentive_id';
					$startup_application_id 	= $id;
					$comment					= $data['admin_reason'];
					$current_with				= 'Reviewer Officer';
					$initiated_date				= $startupLeaseIncentive->created;
					$panding_from				= date('Y-m-d');	
					
					$this->fileMovement($tableName, $application_id_columnName, $startup_application_id, $current_with, $comment, $initiated_date, $panding_from, $data);
				}
				
                $this->Flash->success(__('You have successfully updated the status'));
                return $this->redirect(['action' => 'leaseRentalList']);
            }else{
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        }
        $this->set(compact('startupLeaseIncentive'));
    }

    public function programAppList()
    {

        $this->loadModel('StartupAppIncentives');
        $search_condition = array();
        if (!empty($this->request->getQuery('reference_number'))) {
            $reference_number = trim($this->request->getQuery('reference_number'));
            $this->set('reference_number', $reference_number); 
            $search_condition[] = "StartupAppIncentives.reference_number like '%" . $reference_number . "%'";
        }
        if (!empty($this->request->getQuery('startup_name'))) {
            $startup_name = trim($this->request->getQuery('startup_name'));
            $this->set('startup_name', $startup_name); 
            $search_condition[] = "StartupAppIncentives.startup_name like '%" . $startup_name . "%'";
        }    

        if (!empty($this->request->getQuery('registration_number'))) {
            $registration_number = trim($this->request->getQuery('registration_number'));
            $this->set('registration_number', $registration_number); 
            $search_condition[] = "StartupAppIncentives.registration_number like '%" . $registration_number . "%'";
        }

        if (!empty($this->request->getQuery('incentive_amount'))) {
            $incentive_amount = trim($this->request->getQuery('incentive_amount'));
            $this->set('incentive_amount', $incentive_amount); 
            $search_condition[] = "StartupAppIncentives.incentive_amount like '%" . $incentive_amount . "%'";
        }
        
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
       
        $postQuery = $this->StartupAppIncentives->find()->contain(['StartupApplications','Designations','ApplicationStatus'])->order(['StartupAppIncentives.id'=>'DESC'])->where([$searchString]);

        $this->paginate = ['limit' => 10];
        $applications = $this->paginate($postQuery);
        $this->set(compact('applications'));

    }

    public function programAppView($id)
    {
        $id = base64_decode($id);
        $this->loadModel('StartupAppIncentives');
		$this->loadModel('StartupAppIncentivesFileMovements');
        $application = $this->StartupAppIncentives->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'programAppList']);
        }
        $startupAppIncentive = $this->StartupAppIncentives->get($id,['contain'=>['StartupApplications','Designations','ApplicationStatus','ApplicationStages']]);
		
		$startupAppIncentivesFileMovements = $this->StartupAppIncentivesFileMovements->find('all')->where(['StartupAppIncentivesFileMovements.startup_app_incentive_id '=>$startupAppIncentive->id])->toArray();
		//echo '<pre>'; print_r($appApplicationFileMovements);exit;
        $this->set(compact('startupAppIncentive', 'startupAppIncentivesFileMovements'));
    }

    public function programAppEdit($id)
    {
        $id = base64_decode($id);
        $this->loadModel('StartupAppIncentives');
        $application = $this->StartupAppIncentives->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'programAppList']);
        }
        $startupAppIncentive = $this->StartupAppIncentives->get($id);
        if($this->request->is(['post','put'])){
            $data = $this->request->getData();
            $startupAppIncentive = $this->StartupAppIncentives->patchEntity($startupAppIncentive,$data);
            $startupAppIncentive->admin_reason = $data['admin_reason'];
            if(!empty($data['approve'])){
                $startupAppIncentive->application_status_id = 2;
                $startupAppIncentive->application_stage_id  = 2;
            }elseif(!empty($data['reject'])){
                $startupAppIncentive->application_status_id = 7;
            }
            $startupAppIncentive->updated = date('Y-m-d H:i:s');
            if($this->StartupAppIncentives->save($startupAppIncentive)){
				
				/*Startup App Incentives file movements Table*/
					$tableName 					= 'StartupAppIncentivesFileMovements';
					$application_id_columnName 	= 'startup_app_incentive_id';
					$startup_application_id 	= $id;
					$comment					= $data['admin_reason'];
					$current_with				= 'Reviewer Officer';
					$initiated_date				= $startupAppIncentive->created;
					$panding_from				= date('Y-m-d');	
					
					$this->fileMovement($tableName, $application_id_columnName, $startup_application_id, $current_with, $comment, $initiated_date, $panding_from, $data);
					
                $this->Flash->success(__('You have successfully updated the status'));
                return $this->redirect(['action' => 'programAppList']);
            }else{
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        }
        $this->set(compact('startupAppIncentive'));
    }

    public function patentIncentivesList()
    {
        $this->loadModel('StartupPatentIncentives');
        $query = $this->StartupPatentIncentives->find()->contain(['StartupApplications','Designations','ApplicationStatus'])->order(['StartupPatentIncentives.id'=>'DESC']);
        $applications = $this->paginate($query); //echo '<pre>'; print_r($query); die;
        $this->set(compact('applications')); 
    }

    public function patentIncentivesView($id)
    {
        $id = base64_decode($id);
        $this->loadModel('StartupPatentIncentives');
        $application = $this->StartupPatentIncentives->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'patentIncentivesList']);
        }
        $patentIncentive = $this->StartupPatentIncentives->get($id,['contain'=>['StartupApplications','Designations','ApplicationStatus','ApplicationStages']]);
        $this->set(compact('patentIncentive'));
    }

    public function patentIncentivesEdit($id)
    {
        $id = base64_decode($id);
        $this->loadModel('StartupPatentIncentives');
        $application = $this->StartupPatentIncentives->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'patentIncentivesList']);
        }
        $patentIncentive = $this->StartupPatentIncentives->get($id);
        if($this->request->is(['post','put'])){
            $data = $this->request->getData();
            $patentIncentive = $this->StartupPatentIncentives->patchEntity($patentIncentive,$data);
            $patentIncentive->admin_reason = $data['admin_reason'];
            if(!empty($data['approve'])){
                $patentIncentive->application_status_id = 2;
                $patentIncentive->application_stage_id  = 2;
            }elseif(!empty($data['reject'])){
                $patentIncentive->application_status_id = 7;
            }
            $patentIncentive->updated = date('Y-m-d H:i:s');
            if($this->StartupPatentIncentives->save($patentIncentive)){
                $this->Flash->success(__('You have successfully updated the status'));
                return $this->redirect(['action' => 'patentIncentivesList']);
            }else{
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        }
        $this->set(compact('patentIncentive'));
    }

    public function qualityCertificationList()
    {
        $this->loadModel('StartupQualityCertifications');
        $query = $this->StartupQualityCertifications->find()->contain(['StartupApplications','Designations','ApplicationStatus'])->order(['StartupQualityCertifications.id'=>'DESC']);
        $applications = $this->paginate($query);
        $this->set(compact('applications'));
    }

    public function qualityCertificationView($id)
    {
        $id = base64_decode($id);
        $this->loadModel('StartupQualityCertifications');
        $application = $this->StartupQualityCertifications->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'qualityCertificationList']);
        }
        $qualityIncentive = $this->StartupQualityCertifications->get($id,['contain'=>['StartupApplications','Designations','ApplicationStatus','ApplicationStages']]);
        $this->set(compact('qualityIncentive'));
    }

    public function qualityCertificationEdit($id)
    {
        $id = base64_decode($id);
        $this->loadModel('StartupQualityCertifications');
        $application = $this->StartupQualityCertifications->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'qualityCertificationList']);
        }
        $qualityIncentive = $this->StartupQualityCertifications->get($id);
        if($this->request->is(['post','put'])){
            $data = $this->request->getData();
            $qualityIncentive = $this->StartupQualityCertifications->patchEntity($qualityIncentive,$data);
            $qualityIncentive->admin_reason = $data['admin_reason'];
            if(!empty($data['approve'])){
                $qualityIncentive->application_status_id = 2;
                $qualityIncentive->application_stage_id  = 2;
            }elseif(!empty($data['reject'])){
                $qualityIncentive->application_status_id = 7;
            }
            $qualityIncentive->updated = date('Y-m-d H:i:s');
            if($this->StartupQualityCertifications->save($qualityIncentive)){
                $this->Flash->success(__('You have successfully updated the status'));
                return $this->redirect(['action' => 'qualityCertificationList']);
            }else{
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        }
        $this->set(compact('qualityIncentive'));
    }

    public function observations($id)
    {
        $id = base64_decode($id);
        $this->loadModel('StartupObservations');
        $this->loadModel('StartupApplications');
        $application = $this->StartupApplications->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'index']);
        }        
        $startupObservations = $this->StartupObservations->newEntity();
        if ($this->request->is('post')) {
            $data = $this->request->getData();
            $startupObservations = $this->StartupObservations->patchEntity($startupObservations, $data);
            $currentDate = date('Y-m-d H:i:s');
            $startupObservations->startup_application_id = $id;
            $startupObservations->user_id = $this->Auth->user('id');
            $startupObservations->requested_date = $currentDate;
            $startupObservations->reply_before_date = date('Y-m-d H:i:s', strtotime($currentDate. ' + 15 days'));
            if ($this->StartupObservations->save($startupObservations)) {
                $this->Flash->success(__('The startup observations has been saved.'));
                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The startup observations could not be saved. Please, try again.'));
        }
        $oldObservations = $this->StartupObservations->find()->where(['startup_application_id'=>$id])->enableHydration(false)->toArray();
        $this->set(compact('startupObservations','oldObservations','application'));
    }

    public function downloadFile($filePath) 
    {
        if($filePath){
            $filePath = base64_decode($filePath);
            ob_clean();
            if(file_exists($filePath)){
                $this->response->file($filePath,['download' => true]);
                return $this->response;
            }else{
                $this->Flash->error('File isn\'t available on server.');
                return $this->redirect($this->referer());
            }
        }else{
            $this->Flash->error('Not a valid file.');
            return $this->redirect($this->referer());
        }
    }


}