<?php
namespace App\Controller\Admin;

use App\Controller\Admin\AppController;
use Cake\Cache\Cache;
use Cake\Event\Event;
use Cake\Network\Exception\NotFoundException;
use Cake\Utility\Hash;
use Cake\View\Exception\MissingTemplateException;
use Cake\Core\Configure;
use Cake\ORM\TableRegistry;      

/**
 * PolicyDownloads Controller
 *
 * @property \App\Model\Table\PolicyDownloadsTable $PolicyDownloads
 *
 * @method \App\Model\Entity\PolicyDownload[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class PolicyDownloadsController extends AppController
{
    
    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */

    public $policycategory = ['1'=>'Notifications issued','2'=>'Guidelines for Incubators and Startups','3'=>'Progress Report/ Minutes of meetings','4'=>'Amendments in Acts'];

    public function index()
    {

        $search_condition = array();
        $data = $this->Sanitize->clean($this->request->getQuery());
        if (!empty($data['title'])) {
            $postTitle = trim($data['title']); 
            $this->set('title', $postTitle);
            $search_condition[] = "PolicyDownloads.title like '%" . $postTitle . "%'";
        }
        
        if (isset($data['status']) && $data['status'] !='') {
            $status = trim($data['status']);
            $this->set('status', $status);
            $search_condition[] = "PolicyDownloads.status = '" . $status . "'";
        }

        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        //pr($search_condition); die;
        $postQuery = $this->PolicyDownloads->find('all', [
            'order' => ['PolicyDownloads.id' => 'desc'],
            'conditions' => [$searchString]
        ]);
        $this->paginate = ['limit' => 10];
        
        $policyDownloads = $this->paginate($postQuery);

        $this->set(compact('policyDownloads'));
    }

    /**
     * View method
     *
     * @param string|null $id Policy Download id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $policyDownload = $this->PolicyDownloads->get($id, [
            'contain' => []
        ]);

        $this->set('policyDownload', $policyDownload);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $policyDownload = $this->PolicyDownloads->newEntity();
        if ($this->request->is('post')) {
            $data = $this->request->getData(); 
            $policy_download_translations = [];
            if (isset($data['policy_download_translations'])) {
                $policy_download_translations = $data['policy_download_translations'];
                unset($data['policy_download_translations']);
            }
            $policyDownload = $this->PolicyDownloads->patchEntity($policyDownload, $this->request->getData()); 
            if($data['upload_document']['name']!=''){
                $image = $this->uploadFiles('policy_downloads', $data['upload_document']);
                $policyDownload->upload_document = $image['filename'];
            }

            if ($this->PolicyDownloads->save($policyDownload)) {

                $policyDownload_id = $policyDownload->id;
                if (!empty($policy_download_translations)) {
                    $this->loadModel('PolicyDownloadTranslations');
                    foreach ($policy_download_translations as $key => $_translation) {
                        if (empty($_translation['id'])) {
                            unset($policy_download_translations[$key]['id']);
                        }
                        $policy_download_translations[$key]['policy_download_id'] = $policyDownload_id;
                        $policy_download_translations[$key]['status']    = 1;
                    }
                    $downloadTranslation  = $this->PolicyDownloadTranslations->newEntity();
                    $downloadTranslation  = $this->PolicyDownloadTranslations->patchEntities($downloadTranslation, $policy_download_translations);
                    $downloadTranslations = $this->PolicyDownloadTranslations->saveMany($downloadTranslation); 

                }

                $this->Flash->success(__('The policy download has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The policy download could not be saved. Please, try again.'));
        }
        $policyDownloadLanguages  = $this->languages;
        $policycategory = $this->policycategory;
        $system_languge_id = SYSTEM_LANGUAGE_ID;
        $this->set(compact('policyDownload','policyDownloadLanguages','system_languge_id','policycategory'));

    }

    /**
     * Edit method
     *
     * @param string|null $id Policy Download id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $policyDownload = $this->PolicyDownloads->get($id, [
            'contain' => ['PolicyDownloadTranslations']
        ]); 
        $policyDownload['policy_download_translations'] = Hash::combine($policyDownload['policy_download_translations'], '{n}.language_id', '{n}');
        
        if ($this->request->is(['patch', 'post', 'put'])) {
            $data = $this->request->getData();

            $policy_download_translations = [];
            if (isset($data['policy_download_translations'])) {
                $policy_download_translations = $data['policy_download_translations'];
                unset($data['policy_download_translations']);
            }
            $policyDownload = $this->PolicyDownloads->patchEntity($policyDownload, $data);
            if($data['upload_document']['name']!=''){
                $image = $this->uploadFiles('policy_downloads', $data['upload_document']);
                $policyDownload->upload_document = $image['filename'];
            }else{
                $policyDownload->upload_document = $data['old_upload_document'];
            } 
            if ($this->PolicyDownloads->save($policyDownload)) {
                $policyDownload_id = $policyDownload->id;
                if (!empty($policy_download_translations)) {
                    $this->loadModel('PolicyDownloadTranslations');
                    foreach ($policy_download_translations as $key => $_translation) {
                        if (empty($_translation['id'])) {
                            unset($policy_download_translations[$key]['id']);
                        }
                        $policy_download_translations[$key]['policy_download_id'] = $policyDownload_id;
                        $policy_download_translations[$key]['status']    = 1;
                    }
                    $policyTranslation  = $this->PolicyDownloadTranslations->newEntity();
                    $policyTranslation  = $this->PolicyDownloadTranslations->patchEntities($policyTranslation, $policy_download_translations);
                    $policyTranslations = $this->PolicyDownloadTranslations->saveMany($policyTranslation);
                }
                $this->Flash->success(__('The policy download has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The policy download could not be saved. Please, try again.'));
        }
        $policyDownloadLanguages  = $this->languages;
        $policycategory = $this->policycategory;
        $system_languge_id = SYSTEM_LANGUAGE_ID;
        $this->set(compact('policyDownload','policyDownloadLanguages','system_languge_id','policycategory'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Policy Download id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $policyDownload = $this->PolicyDownloads->get($id);
        if ($this->PolicyDownloads->delete($policyDownload)) {
            $this->Flash->success(__('The policy download has been deleted.'));
        } else {
            $this->Flash->error(__('The policy download could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
