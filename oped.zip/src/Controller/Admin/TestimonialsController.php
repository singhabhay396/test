<?php
namespace App\Controller\Admin;

use App\Controller\Admin\AppController;
use Cake\Cache\Cache;
use Cake\Event\Event;
use Cake\Network\Exception\NotFoundException;
use Cake\Utility\Hash;
use Cake\View\Exception\MissingTemplateException;
use Cake\Core\Configure;
use Cake\Utility\Text;

/**
 * Testimonials Controller
 *
 * @property \App\Model\Table\TestimonialsTable $Testimonials
 *
 * @method \App\Model\Entity\Testimonial[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class TestimonialsController extends AppController
{

    public function initialize()
    {
        parent::initialize();
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $search_condition = array();
        $data = $this->Sanitize->clean($this->request->getQuery());
        if (!empty($data['title'])) {
            $postTitle = trim($data['title']); 
            $this->set('title', $postTitle);
            $search_condition[] = "Testimonials.title like '%" . $postTitle . "%'";
        }
        
        if (isset($this->request->query['status']) && $data['status'] !='') {
            $status = trim($data['status']);
            $this->set('status', $status);
            $search_condition[] = "Testimonials.status = '" . $status . "'";
        }

        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        //pr($search_condition); die;
        $postQuery = $this->Testimonials->find('all', [
            'order' => ['Testimonials.id' => 'desc'],
            'conditions' => [$searchString]
        ]);

        $testimonials = $this->paginate($postQuery);

        $this->set(compact('testimonials'));
    }

    /**
     * View method
     *
     * @param string|null $id Testimonial id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $testimonial = $this->Testimonials->get($id, [
            'contain' => ['Users']
        ]);

        $this->set('testimonial', $testimonial);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $testimonial = $this->Testimonials->newEntity();
        if ($this->request->is('post')) {
            $data = $this->request->getData();
            $testimonial_translations  = [];
            if (isset($data['testimonial_translations'])) {
                $testimonial_translations = $data['testimonial_translations'];
                unset($data['testimonial_translations']);                
            }
            $testimonial = $this->Testimonials->patchEntity($testimonial, $data);
            if($this->request->data['testimonial_image']['name']!=''){
                $testimonialImage = $this->uploadImage('testimonials', $this->request->data['testimonial_image']);
                $testimonial->testimonial_image = $testimonialImage['filename'];
            }
            if ($this->Testimonials->save($testimonial)) {
                $testimonial_id = $testimonial->id;                
                if (!empty($testimonial_translations)) {
                    $this->loadModel('TestimonialTranslations');
                    foreach ($testimonial_translations as $key => $_translation) {
                        if (empty($_translation['id'])) {
                            unset($testimonial_translations[$key]['id']);
                        }
                        $testimonial_translations[$key]['testimonial_id'] = $testimonial_id;
                    }
                    $testimonialTranslation  = $this->TestimonialTranslations->newEntity();
                    $testimonialTranslation  = $this->TestimonialTranslations->patchEntities($testimonialTranslation, $testimonial_translations);
                    $testimonialTranslations = $this->TestimonialTranslations->saveMany($testimonialTranslation);
                }
                $this->Flash->success(__('The testimonial has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The testimonial could not be saved. Please, try again.'));
        }
        $testimonialLanguages  = $this->languages;
        $system_languge_id = SYSTEM_LANGUAGE_ID;
        $this->set(compact('testimonial', 'testimonialLanguages','system_languge_id'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Testimonial id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $testimonial = $this->Testimonials->get($id, [
            'contain' => ['TestimonialTranslations']
        ]);
        $testimonial['testimonial_translations'] = Hash::combine($testimonial['testimonial_translations'], '{n}.language_id', '{n}');
        if ($this->request->is(['patch', 'post', 'put'])) {
            $data = $this->request->getData();
            $testimonial_translations  = [];
            if (isset($data['testimonial_translations'])) {
                $testimonial_translations = $data['testimonial_translations'];
                unset($data['testimonial_translations']);                
            }
            $testimonial = $this->Testimonials->patchEntity($testimonial, $data);
            $testimonial->updated = date('Y-m-d H:i:s');
            if($data['testimonial_image']['name']!=''){
                $testimonialImage = $this->uploadImage('testimonials', $data['testimonial_image']);
                $testimonial->testimonial_image = $testimonialImage['filename'];
            } else {
                $testimonial->testimonial_image = $data['old_page_image'];
            }            
            if ($this->Testimonials->save($testimonial)) {
                $testimonial_id = $testimonial->id;
                if (!empty($testimonial_translations)) {
                    $this->loadModel('TestimonialTranslations');
                    foreach ($testimonial_translations as $key => $_translation) {
                        if (empty($_translation['id'])) {
                            unset($testimonial_translations[$key]['id']);
                        }
                        $testimonial_translations[$key]['testimonial_id'] = $testimonial_id;
                    }
                    $testimonialTranslation  = $this->TestimonialTranslations->newEntity();
                    $testimonialTranslation  = $this->TestimonialTranslations->patchEntities($testimonialTranslation, $testimonial_translations);
                    $testimonialTranslations = $this->TestimonialTranslations->saveMany($testimonialTranslation);
                    //$this->Tenders->testimonialCache();
                }
                $this->Flash->success(__('The testimonial has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The testimonial could not be saved. Please, try again.'));
        }
        $testimonialLanguages  = $this->languages;
        $system_languge_id = SYSTEM_LANGUAGE_ID;
        $this->set(compact('testimonial', 'system_languge_id','testimonialLanguages'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Testimonial id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $testimonial = $this->Testimonials->get($id);
        if ($this->Testimonials->delete($testimonial)) {
            $this->Flash->success(__('The testimonial has been deleted.'));
        } else {
            $this->Flash->error(__('The testimonial could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
