<?php
namespace App\Controller\Admin;

use App\Controller\Admin\AppController;
use Cake\Cache\Cache;
use Cake\Event\Event;
use Cake\Network\Exception\NotFoundException;
use Cake\Utility\Hash;
use Cake\View\Exception\MissingTemplateException;
use Cake\Core\Configure;
use Cake\Utility\Text;
use Cake\ORM\TableRegistry;

/**
 * Tenders Controller
 *
 * @property \App\Model\Table\TendersTable $Tenders
 *
 * @method \App\Model\Entity\Tender[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class TendersController extends AppController
{

    public function initialize()
    {
        parent::initialize();
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }

    private $documentTypes = [
        1 => 'Documents',
        2 => 'Corrignedum',
        3 => 'Annexure'
    ];

	
	/************  Current Tendes Start ****************/
	
	
    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
		$search_condition = array();
		
		if (!empty($this->request->getQuery('title'))) {
            $postTitle = trim($this->request->getQuery('title')); 
            $this->set('title', $postTitle);
            $search_condition[] = "Tenders.title like '%" . $postTitle . "%'";
        }
		
		if (isset($this->request->query['status']) && $this->request->getQuery('status') !='') {
            $status = trim($this->request->getQuery('status'));
            $this->set('status', $status);
            $search_condition[] = "Tenders.status = '" . $status . "'";
        }

        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
		//pr($search_condition); die;
        $postQuery = $this->Tenders->find('all', [
            'contain' => ['Users'],
            'order' => ['Tenders.id' => 'desc'],
			'conditions' => ['tender_date <=' => date('Y-m-d'),'last_date >=' => date('Y-m-d'),$searchString]
        ]);
        $this->paginate = ['limit' => 10];
        $tenders = $this->paginate($postQuery);
        
        $this->set(compact('tenders'));
    }

    /**
     * View method
     *
     * @param string|null $id Tender id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $tender = $this->Tenders->get($id, [
            'contain' => ['Users', 'TenderTranslations']
        ]);

        $this->set('tender', $tender);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $tender = $this->Tenders->newEntity();
        if ($this->request->is('post')) {
            $data                 = $this->request->getData();
            $tender_translations  = [];
            if (isset($data['tender_translations'])) {
                $tender_translations = $data['tender_translations'];
                unset($data['tender_translations']);                
            }
            $tender_documents = [];
            if (isset($data['tender_documents'])) {
                $tender_documents   = $data['tender_documents'];
                unset($data['tender_documents']);
            }
            $ttender_documents = [];
            if (isset($tender_translations['tender_documents'])) {
                $ttender_documents  = $tender_translations['tender_documents'];
                unset($tender_translations['tender_documents']);
            }
            $tender_documents       = array_merge($tender_documents, $ttender_documents);
            $tender->created        = date('Y-m-d H:i:s');
            $tender                 = $this->Tenders->patchEntity($tender, $data);
            $tender->tender_date    = date('Y-m-d',strtotime($data['tender_date']));
            $tender->last_date      = date('Y-m-d',strtotime($data['last_date']));
            if (empty($data['url'])) {
                $tender->url        = strtolower(Text::slug($data['title']));
            } else {
                $tender->url        = strtolower(Text::slug($data['url']));
            }
            if ($this->Tenders->save($tender)) {
                $tender_id = $tender->id;                
                if (!empty($tender_translations)) {
                    $this->loadModel('TenderTranslations');
                    foreach ($tender_translations as $key => $_translation) {
                        if (empty($_translation['id'])) {
                            unset($tender_translations[$key]['id']);
                        }
                        $tender_translations[$key]['tender_id'] = $tender_id;
                    }
                    $tenderTranslation  = $this->TenderTranslations->newEntity();
                    $tenderTranslation  = $this->TenderTranslations->patchEntities($tenderTranslation, $tender_translations);
                    $tenderTranslations = $this->TenderTranslations->saveMany($tenderTranslation);
                }
                if (!empty($tender_documents)) {
                    $this->loadModel('TenderDocuments');
                    foreach ($tender_documents as $key => $_document) {
                        if (empty($_document['id'])) {
                            unset($tender_documents[$key]['id']);
                        }
                        if($_document['documents']['name']!=''){
                            $tenderDoc = $this->uploadFiles('tenders', $_document['documents']);
                            $tender_documents[$key]['documents'] = $tenderDoc['filename'];
                        }
                        $tender_documents[$key]['tender_id'] = $tender_id;
                        $tender_documents[$key]['status']    = 1;
                    }
                    $tenderDocument  = $this->TenderDocuments->newEntity();
                    $tenderDocument  = $this->TenderDocuments->patchEntities($tenderDocument, $tender_documents);
                    $tenderDocuments = $this->TenderDocuments->saveMany($tenderDocument);
                }
                $this->Flash->success(__('The tender has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The tender could not be saved. Please, try again.'));
        }
        $documentTypes = $this->documentTypes;
        $tenderLanguages  = $this->languages;
        $system_languge_id = SYSTEM_LANGUAGE_ID;
        $this->set(compact('tender', 'tenderLanguages', 'system_languge_id','documentTypes'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Tender id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $tender = $this->Tenders->get($id, [
            'contain' => ['TenderTranslations','TenderDocuments']
        ]);
        $tender['tender_translations'] = Hash::combine($tender['tender_translations'], '{n}.language_id', '{n}');
        if(!empty($tender['tender_documents'])){
            $tender['english_document'] = array_filter($tender['tender_documents'], function($el) { return $el['language_id'] == 1 ; });
            $tender['hindi_document'] = array_filter($tender['tender_documents'], function($el) { return $el['language_id'] == 2 ; });
            unset($tender['tender_documents']);
        }

        if ($this->request->is(['patch', 'post', 'put'])) {
            $data                = $this->request->getData();
            $tender_translations = [];
            if (isset($data['tender_translations'])) {
                $tender_translations = $data['tender_translations'];
                unset($data['tender_translations']);
            }
            $tender_documents = [];
            if (isset($data['tender_documents'])) {
                $tender_documents   = $data['tender_documents'];
                unset($data['tender_documents']);
            }
            $ttender_documents = [];
            if (isset($tender_translations['tender_documents'])) {
                $ttender_documents  = $tender_translations['tender_documents'];
                unset($tender_translations['tender_documents']);
            }
            $tender_documents       = array_merge($tender_documents, $ttender_documents);
            $tender->updated        = date('Y-m-d H:i:s');
            $tender                 = $this->Tenders->patchEntity($tender, $data);
            $tender->tender_date    = date('Y-m-d',strtotime($data['tender_date']));
            $tender->last_date      = date('Y-m-d',strtotime($data['last_date']));
            if (empty($data['url'])) {
                $tender->url        = strtolower(Text::slug($data['title']));
            } else {
                $tender->url        = strtolower(Text::slug($data['url']));
            }
            if ($this->Tenders->save($tender)) {
                $tender_id = $tender->id;
                if (!empty($tender_translations)) {
                    $this->loadModel('TenderTranslations');
                    foreach ($tender_translations as $key => $_translation) {
                        if (empty($_translation['id'])) {
                            unset($tender_translations[$key]['id']);
                        }
                        $tender_translations[$key]['tender_id'] = $tender_id;
                    }
                    $tenderTranslation  = $this->TenderTranslations->newEntity();
                    $tenderTranslation  = $this->TenderTranslations->patchEntities($tenderTranslation, $tender_translations);
                    $tenderTranslations = $this->TenderTranslations->saveMany($tenderTranslation);
                    //$this->Tenders->tenderCache();
                }
                if (!empty($tender_documents)) {
                    $this->loadModel('TenderDocuments');
                    foreach ($tender_documents as $key => $_document) {
                        if (empty($_document['id'])) {
                            unset($tender_documents[$key]['id']);
                        }
                        if($_document['documents']['name']!=''){
                            $tenderDoc = $this->uploadFiles('tenders', $_document['documents']);
                            $tender_documents[$key]['documents'] = $tenderDoc['filename'];
                        } else {
                            $tender_documents[$key]['documents'] = $_document['old_documents'];
                        }
                        $tender_documents[$key]['tender_id'] = $tender_id;
                        $tender_documents[$key]['status']    = 1;
                    }
                    $tenderDocument  = $this->TenderDocuments->newEntity();
                    $tenderDocument  = $this->TenderDocuments->patchEntities($tenderDocument, $tender_documents);
                    $tenderDocuments = $this->TenderDocuments->saveMany($tenderDocument);
                }
                $this->Flash->success(__('The tender has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The tender could not be saved. Please, try again.'));
        }
        $documentTypes = $this->documentTypes;
        $tenderLanguages  = $this->languages;
        $system_languge_id = SYSTEM_LANGUAGE_ID;
        $this->set(compact('tender','tenderLanguages','system_languge_id','documentTypes'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Tender id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $tender = $this->Tenders->get($id);
        if ($this->Tenders->delete($tender)) {
            $this->loadModel('TenderDocuments');
            $this->loadModel('TenderTranslations');
            $this->TenderDocuments->deleteAll(['tender_id' => $id]);
            $this->TenderTranslations->deleteAll(['tender_id' => $id]);
            $this->Flash->success(__('The tender has been deleted.'));
        } else {
            $this->Flash->error(__('The tender could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }

    public function deleteRow()
    {
        $this->viewBuilder()->setLayout('ajax');
        $row_id         = $_POST['id'];
        $table_name     = $_POST['table_name'];
        $custumTable    = TableRegistry::getTableLocator()->get($table_name);
        $removeQuery    = $custumTable->get($row_id);
        if($custumTable->delete($removeQuery)){
            echo 'removed';
        }
        exit;  
    }
	
	/******************* Current Tenders Start *************************/
	
	
	
	/******************* Archived Tenders Start *************************/
	
	
	public function archives()
    {
		$search_condition = array();
		
		if (!empty($this->request->getQuery('title'))) {
            $postTitle = trim($this->request->getQuery('title')); 
            $this->set('title', $postTitle);
            $search_condition[] = "Tenders.title like '%" . $postTitle . "%'";
        }
		
		if (isset($this->request->query['status']) && $this->request->getQuery('status') !='') {
            $status = trim($this->request->getQuery('status'));
            $this->set('status', $status);
            $search_condition[] = "Tenders.status = '" . $status . "'";
        }

        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
		//pr($search_condition); die;
        $postQuery = $this->Tenders->find('all', [
            'contain' => ['Users'],
            'order' => ['Tenders.id' => 'desc'],
			'conditions' => ['last_date <' => date('Y-m-d'),$searchString]
        ]);
        $this->paginate = ['limit' => 10];
        $tenders = $this->paginate($postQuery);
        
        $this->set(compact('tenders'));
    }

    /**
     * View method
     *
     * @param string|null $id Tender id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function archiveView($id = null)
    {
        $tender = $this->Tenders->get($id, [
            'contain' => ['Users', 'TenderTranslations']
        ]);

        $this->set('tender', $tender);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function archiveAdd()
    {
        $tender = $this->Tenders->newEntity();
        if ($this->request->is('post')) {
            $data                 = $this->request->getData();
            $tender_translations  = [];
            if (isset($data['tender_translations'])) {
                $tender_translations = $data['tender_translations'];
                unset($data['tender_translations']);                
            }
            $tender_documents = [];
            if (isset($data['tender_documents'])) {
                $tender_documents   = $data['tender_documents'];
                unset($data['tender_documents']);
            }
            $ttender_documents = [];
            if (isset($tender_translations['tender_documents'])) {
                $ttender_documents  = $tender_translations['tender_documents'];
                unset($tender_translations['tender_documents']);
            }
            $tender_documents       = array_merge($tender_documents, $ttender_documents);
            $tender->created        = date('Y-m-d H:i:s');
            $tender                 = $this->Tenders->patchEntity($tender, $data);
            $tender->tender_date    = date('Y-m-d',strtotime($data['tender_date']));
            $tender->last_date      = date('Y-m-d',strtotime($data['last_date']));
            if (empty($data['url'])) {
                $tender->url        = strtolower(Text::slug($data['title']));
            } else {
                $tender->url        = strtolower(Text::slug($data['url']));
            }
            if ($this->Tenders->save($tender)) {
                $tender_id = $tender->id;                
                if (!empty($tender_translations)) {
                    $this->loadModel('TenderTranslations');
                    foreach ($tender_translations as $key => $_translation) {
                        if (empty($_translation['id'])) {
                            unset($tender_translations[$key]['id']);
                        }
                        $tender_translations[$key]['tender_id'] = $tender_id;
                    }
                    $tenderTranslation  = $this->TenderTranslations->newEntity();
                    $tenderTranslation  = $this->TenderTranslations->patchEntities($tenderTranslation, $tender_translations);
                    $tenderTranslations = $this->TenderTranslations->saveMany($tenderTranslation);
                }
                if (!empty($tender_documents)) {
                    $this->loadModel('TenderDocuments');
                    foreach ($tender_documents as $key => $_document) {
                        if (empty($_document['id'])) {
                            unset($tender_documents[$key]['id']);
                        }
                        if($_document['documents']['name']!=''){
                            $tenderDoc = $this->uploadFiles('tenders', $_document['documents']);
                            $tender_documents[$key]['documents'] = $tenderDoc['filename'];
                        }
                        $tender_documents[$key]['tender_id'] = $tender_id;
                        $tender_documents[$key]['status']    = 1;
                    }
                    $tenderDocument  = $this->TenderDocuments->newEntity();
                    $tenderDocument  = $this->TenderDocuments->patchEntities($tenderDocument, $tender_documents);
                    $tenderDocuments = $this->TenderDocuments->saveMany($tenderDocument);
                }
                $this->Flash->success(__('The tender has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The tender could not be saved. Please, try again.'));
        }
        $documentTypes = $this->documentTypes;
        $tenderLanguages  = $this->languages;
        $system_languge_id = SYSTEM_LANGUAGE_ID;
        $this->set(compact('tender', 'tenderLanguages', 'system_languge_id','documentTypes'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Tender id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function archiveEdit($id = null)
    {
        $tender = $this->Tenders->get($id, [
            'contain' => ['TenderTranslations','TenderDocuments']
        ]);
        $tender['tender_translations'] = Hash::combine($tender['tender_translations'], '{n}.language_id', '{n}');
        if(!empty($tender['tender_documents'])){
            $tender['english_document'] = array_filter($tender['tender_documents'], function($el) { return $el['language_id'] == 1 ; });
            $tender['hindi_document'] = array_filter($tender['tender_documents'], function($el) { return $el['language_id'] == 2 ; });
            unset($tender['tender_documents']);
        }

        if ($this->request->is(['patch', 'post', 'put'])) {
            $data                = $this->request->getData();
            $tender_translations = [];
            if (isset($data['tender_translations'])) {
                $tender_translations = $data['tender_translations'];
                unset($data['tender_translations']);
            }
            $tender_documents = [];
            if (isset($data['tender_documents'])) {
                $tender_documents   = $data['tender_documents'];
                unset($data['tender_documents']);
            }
            $ttender_documents = [];
            if (isset($tender_translations['tender_documents'])) {
                $ttender_documents  = $tender_translations['tender_documents'];
                unset($tender_translations['tender_documents']);
            }
            $tender_documents       = array_merge($tender_documents, $ttender_documents);
            $tender->updated        = date('Y-m-d H:i:s');
            $tender                 = $this->Tenders->patchEntity($tender, $data);
            $tender->tender_date    = date('Y-m-d',strtotime($data['tender_date']));
            $tender->last_date      = date('Y-m-d',strtotime($data['last_date']));
            if (empty($data['url'])) {
                $tender->url        = strtolower(Text::slug($data['title']));
            } else {
                $tender->url        = strtolower(Text::slug($data['url']));
            }
            if ($this->Tenders->save($tender)) {
                $tender_id = $tender->id;
                if (!empty($tender_translations)) {
                    $this->loadModel('TenderTranslations');
                    foreach ($tender_translations as $key => $_translation) {
                        if (empty($_translation['id'])) {
                            unset($tender_translations[$key]['id']);
                        }
                        $tender_translations[$key]['tender_id'] = $tender_id;
                    }
                    $tenderTranslation  = $this->TenderTranslations->newEntity();
                    $tenderTranslation  = $this->TenderTranslations->patchEntities($tenderTranslation, $tender_translations);
                    $tenderTranslations = $this->TenderTranslations->saveMany($tenderTranslation);
                    //$this->Tenders->tenderCache();
                }
                if (!empty($tender_documents)) {
                    $this->loadModel('TenderDocuments');
                    foreach ($tender_documents as $key => $_document) {
                        if (empty($_document['id'])) {
                            unset($tender_documents[$key]['id']);
                        }
                        if($_document['documents']['name']!=''){
                            $tenderDoc = $this->uploadFiles('tenders', $_document['documents']);
                            $tender_documents[$key]['documents'] = $tenderDoc['filename'];
                        } else {
                            $tender_documents[$key]['documents'] = $_document['old_documents'];
                        }
                        $tender_documents[$key]['tender_id'] = $tender_id;
                        $tender_documents[$key]['status']    = 1;
                    }
                    $tenderDocument  = $this->TenderDocuments->newEntity();
                    $tenderDocument  = $this->TenderDocuments->patchEntities($tenderDocument, $tender_documents);
                    $tenderDocuments = $this->TenderDocuments->saveMany($tenderDocument);
                }
                $this->Flash->success(__('The archived tender has been updated.'));

                return $this->redirect(['action' => 'archives']);
            }
            $this->Flash->error(__('The tender could not be saved. Please, try again.'));
        }
        $documentTypes = $this->documentTypes;
        $tenderLanguages  = $this->languages;
        $system_languge_id = SYSTEM_LANGUAGE_ID;
        $this->set(compact('tender','tenderLanguages','system_languge_id','documentTypes'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Tender id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function archivDelete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $tender = $this->Tenders->get($id);
        if ($this->Tenders->delete($tender)) {
            $this->loadModel('TenderDocuments');
            $this->loadModel('TenderTranslations');
            $this->TenderDocuments->deleteAll(['tender_id' => $id]);
            $this->TenderTranslations->deleteAll(['tender_id' => $id]);
            $this->Flash->success(__('The tender has been deleted.'));
        } else {
            $this->Flash->error(__('The tender could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
	
	
	/******************* Archived Tenders END *************************/
	
	
	
	/******************* Schedule Tenders Start *************************/
	public function schedules()
    {
		$search_condition = array();
		
		if (!empty($this->request->getQuery('title'))) {
            $postTitle = trim($this->request->getQuery('title')); 
            $this->set('title', $postTitle);
            $search_condition[] = "Tenders.title like '%" . $postTitle . "%'";
        }
		
		if (isset($this->request->query['status']) && $this->request->getQuery('status') !='') {
            $status = trim($this->request->getQuery('status'));
            $this->set('status', $status);
            $search_condition[] = "Tenders.status = '" . $status . "'";
        }

        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
		//pr($search_condition); die;
        $postQuery = $this->Tenders->find('all', [
            'contain' => ['Users'],
            'order' => ['Tenders.id' => 'desc'],
			'conditions' => ['tender_date >' => date('Y-m-d'),$searchString]
        ]);
        $this->paginate = ['limit' => 10];
        $tenders = $this->paginate($postQuery);
        
        $this->set(compact('tenders'));
    }

    /**
     * View method
     *
     * @param string|null $id Tender id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function scheduleView($id = null)
    {
        $tender = $this->Tenders->get($id, [
            'contain' => ['Users', 'TenderTranslations']
        ]);

        $this->set('tender', $tender);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function scheduleAdd()
    {
        $tender = $this->Tenders->newEntity();
        if ($this->request->is('post')) {
            $data                 = $this->request->getData();
            $tender_translations  = [];
            if (isset($data['tender_translations'])) {
                $tender_translations = $data['tender_translations'];
                unset($data['tender_translations']);                
            }
            $tender_documents = [];
            if (isset($data['tender_documents'])) {
                $tender_documents   = $data['tender_documents'];
                unset($data['tender_documents']);
            }
            $ttender_documents = [];
            if (isset($tender_translations['tender_documents'])) {
                $ttender_documents  = $tender_translations['tender_documents'];
                unset($tender_translations['tender_documents']);
            }
            $tender_documents       = array_merge($tender_documents, $ttender_documents);
            $tender->created        = date('Y-m-d H:i:s');
            $tender                 = $this->Tenders->patchEntity($tender, $data);
            $tender->tender_date    = date('Y-m-d',strtotime($data['tender_date']));
            $tender->last_date      = date('Y-m-d',strtotime($data['last_date']));
            if (empty($data['url'])) {
                $tender->url        = strtolower(Text::slug($data['title']));
            } else {
                $tender->url        = strtolower(Text::slug($data['url']));
            }
            if ($this->Tenders->save($tender)) {
                $tender_id = $tender->id;                
                if (!empty($tender_translations)) {
                    $this->loadModel('TenderTranslations');
                    foreach ($tender_translations as $key => $_translation) {
                        if (empty($_translation['id'])) {
                            unset($tender_translations[$key]['id']);
                        }
                        $tender_translations[$key]['tender_id'] = $tender_id;
                    }
                    $tenderTranslation  = $this->TenderTranslations->newEntity();
                    $tenderTranslation  = $this->TenderTranslations->patchEntities($tenderTranslation, $tender_translations);
                    $tenderTranslations = $this->TenderTranslations->saveMany($tenderTranslation);
                }
                if (!empty($tender_documents)) {
                    $this->loadModel('TenderDocuments');
                    foreach ($tender_documents as $key => $_document) {
                        if (empty($_document['id'])) {
                            unset($tender_documents[$key]['id']);
                        }
                        if($_document['documents']['name']!=''){
                            $tenderDoc = $this->uploadFiles('tenders', $_document['documents']);
                            $tender_documents[$key]['documents'] = $tenderDoc['filename'];
                        }
                        $tender_documents[$key]['tender_id'] = $tender_id;
                        $tender_documents[$key]['status']    = 1;
                    }
                    $tenderDocument  = $this->TenderDocuments->newEntity();
                    $tenderDocument  = $this->TenderDocuments->patchEntities($tenderDocument, $tender_documents);
                    $tenderDocuments = $this->TenderDocuments->saveMany($tenderDocument);
                }
                $this->Flash->success(__('The tender has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The tender could not be saved. Please, try again.'));
        }
        $documentTypes = $this->documentTypes;
        $tenderLanguages  = $this->languages;
        $system_languge_id = SYSTEM_LANGUAGE_ID;
        $this->set(compact('tender', 'tenderLanguages', 'system_languge_id','documentTypes'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Tender id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function scheduleEdit($id = null)
    {
        $tender = $this->Tenders->get($id, [
            'contain' => ['TenderTranslations','TenderDocuments']
        ]);
        $tender['tender_translations'] = Hash::combine($tender['tender_translations'], '{n}.language_id', '{n}');
        if(!empty($tender['tender_documents'])){
            $tender['english_document'] = array_filter($tender['tender_documents'], function($el) { return $el['language_id'] == 1 ; });
            $tender['hindi_document'] = array_filter($tender['tender_documents'], function($el) { return $el['language_id'] == 2 ; });
            unset($tender['tender_documents']);
        }

        if ($this->request->is(['patch', 'post', 'put'])) {
            $data                = $this->request->getData();
            $tender_translations = [];
            if (isset($data['tender_translations'])) {
                $tender_translations = $data['tender_translations'];
                unset($data['tender_translations']);
            }
            $tender_documents = [];
            if (isset($data['tender_documents'])) {
                $tender_documents   = $data['tender_documents'];
                unset($data['tender_documents']);
            }
            $ttender_documents = [];
            if (isset($tender_translations['tender_documents'])) {
                $ttender_documents  = $tender_translations['tender_documents'];
                unset($tender_translations['tender_documents']);
            }
            $tender_documents       = array_merge($tender_documents, $ttender_documents);
            $tender->updated        = date('Y-m-d H:i:s');
            $tender                 = $this->Tenders->patchEntity($tender, $data);
            $tender->tender_date    = date('Y-m-d',strtotime($data['tender_date']));
            $tender->last_date      = date('Y-m-d',strtotime($data['last_date']));
            if (empty($data['url'])) {
                $tender->url        = strtolower(Text::slug($data['title']));
            } else {
                $tender->url        = strtolower(Text::slug($data['url']));
            }
            if ($this->Tenders->save($tender)) {
                $tender_id = $tender->id;
                if (!empty($tender_translations)) {
                    $this->loadModel('TenderTranslations');
                    foreach ($tender_translations as $key => $_translation) {
                        if (empty($_translation['id'])) {
                            unset($tender_translations[$key]['id']);
                        }
                        $tender_translations[$key]['tender_id'] = $tender_id;
                    }
                    $tenderTranslation  = $this->TenderTranslations->newEntity();
                    $tenderTranslation  = $this->TenderTranslations->patchEntities($tenderTranslation, $tender_translations);
                    $tenderTranslations = $this->TenderTranslations->saveMany($tenderTranslation);
                    //$this->Tenders->tenderCache();
                }
                if (!empty($tender_documents)) {
                    $this->loadModel('TenderDocuments');
                    foreach ($tender_documents as $key => $_document) {
                        if (empty($_document['id'])) {
                            unset($tender_documents[$key]['id']);
                        }
                        if($_document['documents']['name']!=''){
                            $tenderDoc = $this->uploadFiles('tenders', $_document['documents']);
                            $tender_documents[$key]['documents'] = $tenderDoc['filename'];
                        } else {
                            $tender_documents[$key]['documents'] = $_document['old_documents'];
                        }
                        $tender_documents[$key]['tender_id'] = $tender_id;
                        $tender_documents[$key]['status']    = 1;
                    }
                    $tenderDocument  = $this->TenderDocuments->newEntity();
                    $tenderDocument  = $this->TenderDocuments->patchEntities($tenderDocument, $tender_documents);
                    $tenderDocuments = $this->TenderDocuments->saveMany($tenderDocument);
                }
                $this->Flash->success(__('The scheduled tender has been updated.'));

                return $this->redirect(['action' => 'schedules']);
            }
            $this->Flash->error(__('The tender could not be saved. Please, try again.'));
        }
        $documentTypes = $this->documentTypes;
        $tenderLanguages  = $this->languages;
        $system_languge_id = SYSTEM_LANGUAGE_ID;
        $this->set(compact('tender','tenderLanguages','system_languge_id','documentTypes'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Tender id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function scheduleDelete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $tender = $this->Tenders->get($id);
        if ($this->Tenders->delete($tender)) {
            $this->loadModel('TenderDocuments');
            $this->loadModel('TenderTranslations');
            $this->TenderDocuments->deleteAll(['tender_id' => $id]);
            $this->TenderTranslations->deleteAll(['tender_id' => $id]);
            $this->Flash->success(__('The tender has been deleted.'));
        } else {
            $this->Flash->error(__('The tender could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
	
	
	/******************* Schedule Tenders END *************************/
}
