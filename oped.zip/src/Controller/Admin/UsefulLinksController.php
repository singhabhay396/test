<?php

namespace App\Controller\Admin;

use App\Controller\Admin\AppController;
use Cake\Event\Event;
use Cake\Utility\Hash;

/**
 * GalleryCategories Controller
 *
 * @property \App\Model\Table\GalleryCategoriesTable $GalleryCategories
 *
 * @method \App\Model\Entity\GalleryCategory[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class UsefulLinksController extends AppController {

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index() {
        $this->paginate = [ ];
        $links = $this->paginate($this->UsefulLinks);
        $this->set(compact('links'));
         
    }

    /**
     * View method
     *
     * @param string|null $id Gallery Category id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null) {
        $link= $this->UsefulLinks->get($id, [
            'contain' => []
        ]);
        $this->set('link', $link);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add() {
        $link = $this->UsefulLinks->newEntity();
        if ($this->request->is('post')) {
            $link = $this->UsefulLinks->patchEntity($link, $this->request->getData());
            if ($this->UsefulLinks->save($link)) {
                $this->Flash->success(__('The Useful Link  has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The Links could not be saved. Please, try again.'));
        }
        
        $this->set(compact('link'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Gallery Category id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null) {
        $link = $this->UsefulLinks->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $link = $this->UsefulLinks->patchEntity($link, $this->request->getData());
            if ($this->UsefulLinks->save($link)) {
                $this->Flash->success(__('The Useful Links has been saved.'));
                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The Useful Links could not be saved. Please, try again.'));
        }
       
        $this->set(compact('link'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Gallery Category id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null) {
        $this->request->allowMethod(['post', 'delete']);
        $link = $this->UsefulLinks->get($id);
        if ($this->UsefulLinks->delete($link)) {
            $this->Flash->success(__('The Useful Links has been deleted.'));
        } else {
            $this->Flash->error(__('The Useful Links could not be deleted. Please, try again.'));
        }
        return $this->redirect(['action' => 'index']);
    }

}
