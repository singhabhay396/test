<?php
namespace App\Controller\Admin;

use App\Controller\Admin\AppController;
use Cake\Event\Event;
use Cake\Utility\Hash;

/**
 * Announcements Controller
 *
 * @property \App\Model\Table\AnnouncementsTable $Announcements
 *
 * @method \App\Model\Entity\Announcement[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class AnnouncementsController extends AppController
{
    public function initialize()
    {
        parent::initialize();
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $search_condition = array();
        $data = $this->Sanitize->clean($this->request->getQuery());
        if (!empty($data['title'])) {
            $postTitle = trim($data['title']); 
            $this->set('title', $postTitle);
            $search_condition[] = "Announcements.title like '%" . $postTitle . "%'";
        }
        
        if (isset($this->request->query['status']) && $data['status'] !='') {
            $status = trim($data['status']);
            $this->set('status', $status);
            $search_condition[] = "Announcements.status = '" . $status . "'";
        }

        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        //pr($search_condition); die;
        $postQuery = $this->Announcements->find('all', [
            'order' => ['Announcements.id' => 'desc'],
            'conditions' => [$searchString]
        ]);
        $announcements = $this->paginate($postQuery);
        //print_r($announcements);
        $this->set(compact('announcements'));
    }

    /**
     * View method
     *
     * @param string|null $id Announcement id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $announcement = $this->Announcements->get($id, [
            'contain' => ['Users']
        ]);

        $this->set('announcement', $announcement);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $announcement = $this->Announcements->newEntity();
        if ($this->request->is('post')) {
			$data = $this->request->getData();
            $announcement_translations  = [];
            if (isset($data['announcement_translations'])) {
                $announcement_translations = $data['announcement_translations'];
                unset($data['announcement_translations']);
            }
            $announcement = $this->Announcements->patchEntity($announcement, $this->request->getData());
			if($data['filename']['name']!=''){
                $fileName = $this->uploadFiles('announcements', $data['filename']);
                $announcement->filename  = $fileName['filename'];
                $announcement->filemime  = $fileName['type'];
                $announcement->filesize  = $fileName['size'];
            }  
			
            if ($this->Announcements->save($announcement)) {
                $announcement_id = $announcement->id;
                if (!empty($announcement_translations)) {
                    $this->loadModel('AnnouncementTranslations');
                    foreach ($announcement_translations as $key => $_translation) {
                        if (empty($_translation['id'])) {
                            unset($announcement_translations[$key]['id']);
                        }
                        if($_translation['filename']['name']!=''){
                            $doc2 = $this->uploadFiles('announcements', $_translation['filename']);
                            $announcement_translations[$key]['filename'] = $doc2['filename'];
                        }
                        $announcement_translations[$key]['announcement_id'] = $announcement_id;
                    }
                    $postTranslation  = $this->AnnouncementTranslations->newEntity();
                    $postTranslation  = $this->AnnouncementTranslations->patchEntities($postTranslation, $announcement_translations);
                    $postTranslations = $this->AnnouncementTranslations->saveMany($postTranslation);
                } 
                $this->Flash->success(__('The announcement has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The announcement could not be saved. Please, try again.'));
        }
        $announcementsLanguages  = $this->languages;
        $system_languge_id = SYSTEM_LANGUAGE_ID;
        $users = $this->Announcements->Users->find('list', ['limit' => 200]);
        $this->set(compact('announcement','system_languge_id', 'users', 'announcementsLanguages'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Announcement id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $announcement = $this->Announcements->get($id, [
            'contain' => ['announcementTranslations']
        ]);
        $announcement['announcement_translations'] = Hash::combine($announcement['announcement_translations'], '{n}.language_id', '{n}');

        if ($this->request->is(['patch', 'post', 'put'])) {
			$data = $this->request->getData();
            if (isset($data['announcement_translations'])) {
                $announcement_translations = $data['announcement_translations'];
                unset($data['announcement_translations']);
            }
            $announcement->updated = date('Y-m-d H:i:s');
            $announcement = $this->Announcements->patchEntity($announcement, $data);
			
			if($data['filename']['name']!=''){
                $fileName = $this->uploadFiles('announcements', $data['filename']);
                $announcement->filename  = $fileName['filename'];
                $announcement->filemime  = $fileName['type'];
                $announcement->filesize  = $fileName['size'];
             //pr($announcement->filename); die;   
            } else {
                $announcement->filename  = $data['old_filename'];
                $announcement->filemime  = $data['old_filemime'];
                $announcement->filesize  = $data['old_filesize'];
            } /*
            if($data['filename']['name']!=''){
                $doc1 = $this->uploadFiles('announcements', $data['filename']);
                $announcement->filename = $doc1['filename'];
                pr($doc1); die;
            } else {
                $announcement->filename = $data['old_filename'];
            } */
            if ($this->Announcements->save($announcement)) {
                $announcement_id = $announcement->id;
                if (!empty($announcement_translations)) {
                    $this->loadModel('AnnouncementTranslations');
                    foreach ($announcement_translations as $key => $_translation) {
                        if (empty($_translation['id'])) {
                            unset($announcement_translations[$key]['id']);
                        }  
                        if($_translation['filename']['name']!=''){
                            $doc2 = $this->uploadFiles('announcements', $_translation['filename']); //pr($doc2); die;
                            $announcement_translations[$key]['filename'] = $doc2['filename'];
                           // pr($doc2); die;
                        }  else {
                            $announcement_translations[$key]['filename'] = $_translation['old_filename'];
                        }
                        $announcement_translations[$key]['announcement_id'] = $announcement_id;
                    }
                    $postTranslation  = $this->AnnouncementTranslations->newEntity();
                    $postTranslation  = $this->AnnouncementTranslations->patchEntities($postTranslation, $announcement_translations);
                    $postTranslations = $this->AnnouncementTranslations->saveMany($postTranslation);
                }
                $this->Flash->success(__('The announcement has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The announcement could not be saved. Please, try again.'));
        }
        $announcementsLanguages  = $this->languages;
        $system_languge_id = SYSTEM_LANGUAGE_ID;// pr($system_languge_id); die;
        $users = $this->Announcements->Users->find('list', ['limit' => 200]);
        $this->set(compact('announcement','system_languge_id', 'users','announcementsLanguages'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Announcement id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $announcement = $this->Announcements->get($id);
        if ($this->Announcements->delete($announcement)) {
            $this->loadModel('AnnouncementTranslations');
            $this->AnnouncementTranslations->deleteAll(['announcement_id' => $id]);
            $this->Flash->success(__('The announcement has been deleted.'));
        } else {
            $this->Flash->error(__('The announcement could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
