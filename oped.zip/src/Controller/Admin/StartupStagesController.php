<?php
namespace App\Controller\Admin;

use App\Controller\Admin\AppController;
use Cake\Event\Event;

/**
 * StartupStages Controller
 *
 * @property \App\Model\Table\StartupStagesTable $StartupStages
 *
 * @method \App\Model\Entity\StartupStage[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class StartupStagesController extends AppController
{
    public function initialize()
    {
        parent::initialize();
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $startupStages = $this->paginate($this->StartupStages);

        $this->set(compact('startupStages'));
    }

    /**
     * View method
     *
     * @param string|null $id Startup Stage id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $startupStage = $this->StartupStages->get($id, [
            'contain' => []
        ]);

        $this->set('startupStage', $startupStage);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $startupStage = $this->StartupStages->newEntity();
        if ($this->request->is('post')) {
            $startupStage = $this->StartupStages->patchEntity($startupStage, $this->request->getData());
            if ($this->StartupStages->save($startupStage)) {
                $this->Flash->success(__('The startup stage has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The startup stage could not be saved. Please, try again.'));
        }
        $this->set(compact('startupStage'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Startup Stage id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $startupStage = $this->StartupStages->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $startupStage = $this->StartupStages->patchEntity($startupStage, $this->request->getData());
            if ($this->StartupStages->save($startupStage)) {
                $this->Flash->success(__('The startup stage has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The startup stage could not be saved. Please, try again.'));
        }
        $this->set(compact('startupStage'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Startup Stage id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $startupStage = $this->StartupStages->get($id);
        if ($this->StartupStages->delete($startupStage)) {
            $this->Flash->success(__('The startup stage has been deleted.'));
        } else {
            $this->Flash->error(__('The startup stage could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
