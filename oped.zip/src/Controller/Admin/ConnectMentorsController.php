<?php
namespace App\Controller\Admin;

use App\Controller\Admin\AppController;
use Cake\Validation\Validator;
use Cake\Controller\Controller;
use Cake\Mailer\Email;
use Cake\Error\Exceptions;
use Cake\I18n\Time;
use Cake\Routing\Router;
use Cake\Event\Event;
use Cake\Auth\DefaultPasswordHasher;

/**
 * Incubators Controller
 *
 * @property \App\Model\Table\IncubatorsTable $Incubators
 *
 * @method \App\Model\Entity\Incubators[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class ConnectMentorsController extends AppController
{

	private $form_of_entity = ['1'=>'Government', '2'=>'Private'];
    
	public function initialize() {
        parent::initialize(); 

       // $this->Auth->allow(['index']);
    }

    public function beforeFilter(Event $event){
        parent::beforeFilter($event);
    }

    public function index()
    {
        $this->loadModel('MentorMentees');
        $this->loadModel('Users');

        $search_condition = array();
        $data = $this->Sanitize->clean($this->request->getQuery());
        if (!empty($data['reference_no'])) {
            $reference_no = trim($data['reference_no']);
            $this->set('reference_no', $reference_no); 
            $search_condition[] = "MentorMentees.reference_no like '%" . $reference_no . "%'";
        }
        if (!empty($data['mentor_name'])) {
            $mentor_name = trim($data['mentor_name']);
            $this->set('mentor_name', $mentor_name); 
            $search_condition[] = "MentorMentees.mentor_name like '%" . $mentor_name . "%'";
        }    

        if (!empty($data['certificate_no'])) {
            $certificate_no = trim($data['certificate_no']);
            $this->set('certificate_no', $certificate_no); 
            $search_condition[] = "MentorMentees.certificate_no like '%" . $certificate_no . "%'";
        }

        if (!empty($data['email_id'])) {
            $email_id = trim($data['email_id']);
            $this->set('email_id', $email_id); 
            $search_condition[] = "MentorMentees.email_id like '%" . $email_id . "%'";
        }
        
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }

        $query = $this->MentorMentees->find()->contain(['Users','MentorDetails'])->order(['MentorMentees.id'=>'DESC']);
        $applications = $this->paginate($query);
        //echo "<pre>"; print_r($query); exit;

        $this->set(compact('applications'));
    }
	
    public function update($id) {
        $id = base64_decode($id);
        $this->loadModel('MentorMentees');
        $application = $this->MentorMentees->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'index']);
        }
        $applications = $this->MentorMentees->get($id);
        if ($this->request->is(['POST', 'PUT'])) {
            $data = $this->request->getData();
            $applications = $this->MentorMentees->patchEntity($applications, $data);
            $applications->reasion_reject = $data['reasion_reject'];
            if ($data['action'] == 'Approve') {
                $applications->is_approved = 1;
            } else if ($this->request->data['action'] == 'Reject') {
                $applications->is_approved = 2;
            }
            $applications->accepted_date = date('Y-m-d');
            if ($result = $this->MentorMentees->save($applications)) {
                $startupApplication = $this->MentorMentees->get($result->id, ['contain' => ['Users','MentorDetails']]);
               //echo "<pre>"; print_r($startupApplication); exit;
                //echo $startupApplication['mentor_detail']['email']; exit;
                $nemail = new Email('default');
                $nemail->template('mentoraccepted');
                $nemail->emailFormat('html');
                $nemail->viewVars(['emailData' => $startupApplication]);
                $nemail->viewVars(['email' => $startupApplication['user']['email']]);
                $nemail->viewVars(['base_url' => Router::url('/', true)]);
                $nemail->cc('abhay_singh@silvertouch.com');
                $status = $nemail->to($startupApplication['user']['email'])
                    ->subject('Startup Haryana : Mentor Request Accepted')
                    ->send();
                if($status){
                    $this->Flash->success(__('You have successfully updated the status'));
                    return $this->redirect(['action' => 'mentor-accept-list']);  
                }
                else{
                    $successSms = "Email not send to the requested mentor.";
                    $this->Flash->success($successSms);
                    $this->redirect(['controller' => 'mentor-accept-list']);
                }
                
            }
        }
        $this->set(compact('applications'));
    }

    public function view($id)
    {
        $id = base64_decode($id);
        $this->loadModel('MentorMentees');
        $this->loadModel('Users');
        $application = $this->MentorMentees->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'index']);
        }
        $startupApplication = $this->MentorMentees->get($id, ['contain' => ['Users','MentorDetails']]);
        //echo "<pre>"; print_r($startupApplication); exit;
        $this->set(compact('startupApplication'));
    }

    

}