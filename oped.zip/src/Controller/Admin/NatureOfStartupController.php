<?php
namespace App\Controller\Admin;

use App\Controller\Admin\AppController;
use Cake\Event\Event;

/**
 * NatureOfStartup Controller
 *
 * @property \App\Model\Table\NatureOfStartupTable $NatureOfStartup
 *
 * @method \App\Model\Entity\NatureOfStartup[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class NatureOfStartupController extends AppController
{

    public function initialize()
    {
        parent::initialize();
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $natureOfStartup = $this->paginate($this->NatureOfStartup);

        $this->set(compact('natureOfStartup'));
    }

    /**
     * View method
     *
     * @param string|null $id Nature Of Startup id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $natureOfStartup = $this->NatureOfStartup->get($id, [
            'contain' => ['StartupApplications']
        ]);

        $this->set('natureOfStartup', $natureOfStartup);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $natureOfStartup = $this->NatureOfStartup->newEntity();
        if ($this->request->is('post')) {
            $natureOfStartup = $this->NatureOfStartup->patchEntity($natureOfStartup, $this->request->getData());
            if ($this->NatureOfStartup->save($natureOfStartup)) {
                $this->Flash->success(__('The nature of startup has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The nature of startup could not be saved. Please, try again.'));
        }
        $this->set(compact('natureOfStartup'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Nature Of Startup id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $natureOfStartup = $this->NatureOfStartup->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $natureOfStartup = $this->NatureOfStartup->patchEntity($natureOfStartup, $this->request->getData());
            if ($this->NatureOfStartup->save($natureOfStartup)) {
                $this->Flash->success(__('The nature of startup has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The nature of startup could not be saved. Please, try again.'));
        }
        $this->set(compact('natureOfStartup'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Nature Of Startup id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $natureOfStartup = $this->NatureOfStartup->get($id);
        if ($this->NatureOfStartup->delete($natureOfStartup)) {
            $this->Flash->success(__('The nature of startup has been deleted.'));
        } else {
            $this->Flash->error(__('The nature of startup could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
