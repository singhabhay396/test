<?php
namespace App\Controller\Admin;

use App\Controller\Admin\AppController;
use Cake\Event\Event;
use Cake\Mailer\Email;
use Cake\ORM\TableRegistry;
use Cake\Error\Exceptions;
use Cake\I18n\Time;
use Cake\Routing\Router;
use Cake\Validation\Validator;
use Cake\Auth\DefaultPasswordHasher;

/**
 * Users Controller
 *
 * @property \App\Model\Table\UsersTable $Users
 *
 * @method \App\Model\Entity\User[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class ScreeningCommitteeController extends AppController
{

    public function initialize()
    {
        parent::initialize();
        $this->Auth->allow(['jcryption']);
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }

    public function index()
    {
        $this->loadModel('StartupApplications');
        $applications = $this->paginate($this->StartupApplications->find()->where(['startup_stage_id'=>2])->contain(['Users','ApplicationStatus'])->order(['StartupApplications.id'=>'DESC']));
        $this->set(compact('applications'));
    }

    public function view($id)
    {	
		$this->loadModel('StartupApplicationFileMovements');
        $id = base64_decode($id);
		$this->loadModel('StartupApplications');
        $application = $this->StartupApplications->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'index']);
        }
        $this->loadModel('StartupApplications');
        $applications = $this->StartupApplications->get($id);
        $startupApplication = $this->StartupApplications->get($id,['contain'=>['Users','RegisteredStates','RegisteredDistricts','CorporateStates','CorporateDistricts','RegionalStates','RegionalDistricts','StartupStages','ApplicationStatus','NatureOfStartup','StartupCategories','Industries','Sectors','IncorporationAuthorities', 'IndustriesOfProduct', 'SectorsOfProduct','StartupDirectors',  'StartupDirectors.DirectorStates', 'StartupDirectors.DirectorDistricts']]);
        //echo "<pre>"; print_r($startupApplication);exit;
		$StartupApplicationFileMovements = $this->StartupApplicationFileMovements->find('all')->where(['StartupApplicationFileMovements.startup_application_id '=>$startupApplication->id])->toArray();
		
		$categoryOfProduct = [1=>'Innovative',2=>'Proprietary'];
		$nationality = [1=>'Indian'];
		$this->set(compact('startupApplication','applications', 'categoryOfProduct', 'nationality', 'StartupApplicationFileMovements'));
    }

    public function edit($id)
    {
        $id = base64_decode($id);
        $this->loadModel('StartupApplications');
        $application = $this->StartupApplications->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'index']);
        }
        $applications = $this->StartupApplications->get($id);
        if($this->request->is(['post','put'])){
            $data = $this->request->getData();
            $applications = $this->StartupApplications->patchEntity($applications,$data);
            $applications->updated = date('Y-m-d H:i:s');
            if(!empty($data['approve'])){
                $applications->application_status_id = 4;
                $applications->startup_stage_id = 3;
            }elseif(!empty($data['reject'])){
                $applications->application_status_id = 7;
            }
			
			$applications->screening_remark_date = date('Y-m-d');
			if($data['screening_remark_doc']['name']!=''){
                $certificate = $this->uploadFiles('registration', $data['screening_remark_doc']);
                $applications->screening_remark_doc = $certificate['filename'];
            }
			
			
            if($this->StartupApplications->save($applications)){
				
				if(!empty($data['approve'])){
					/*startup_application_file_movements Table*/
					$tableName 					= 'StartupApplicationFileMovements';
					$application_id_columnName 	= 'startup_application_id';
					$startup_application_id 	= $id;
					$comment					= $data['screening_committee_reason'];
					$current_with				= 'Approval Officer';
					$initiated_date				= $applications->created;
					$panding_from				= date('Y-m-d');	
					
					$this->fileMovement($tableName, $application_id_columnName, $startup_application_id, $current_with, $comment, $initiated_date, $panding_from, $data);
				}
				
                $this->Flash->success(__('You have successfully updated the status'));
                return $this->redirect(['action' => 'index']);
            }else{
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        }
        $this->set(compact('applications','status'));
    }

    public function leaseRentalList()
    {
        $this->loadModel('StartupLeaseIncentives');

         $search_condition = array();
        if (!empty($this->request->getQuery('reference_number'))) {
            $reference_number = trim($this->request->getQuery('reference_number'));
            $this->set('reference_number', $reference_number); 
            $search_condition[] = "StartupLeaseIncentives.reference_number like '%" . $reference_number . "%'";
        }
        if (!empty($this->request->getQuery('startup_name'))) {
            $startup_name = trim($this->request->getQuery('startup_name'));
            $this->set('startup_name', $startup_name); 
            $search_condition[] = "StartupLeaseIncentives.startup_name like '%" . $startup_name . "%'";
        }    

        if (!empty($this->request->getQuery('registration_number'))) {
            $registration_number = trim($this->request->getQuery('registration_number'));
            $this->set('registration_number', $registration_number); 
            $search_condition[] = "StartupLeaseIncentives.registration_number like '%" . $registration_number . "%'";
        }

        if (!empty($this->request->getQuery('rental_amount'))) {
            $rental_amount = trim($this->request->getQuery('rental_amount'));
            $this->set('rental_amount', $rental_amount); 
            $search_condition[] = "StartupLeaseIncentives.rental_amount like '%" . $rental_amount . "%'";
        }
        
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }


        $applications = $this->paginate($this->StartupLeaseIncentives->find()->contain(['StartupApplications','Designations','ApplicationStatus'])->where(['application_stage_id'=>2,$searchString])->order(['StartupLeaseIncentives.id'=>'DESC']));
        $this->set(compact('applications'));
    }

    public function leaseRentalView($id)
    {
        $id = base64_decode($id);
        $this->loadModel('StartupLeaseIncentives');
		$this->loadModel('StartupLeaseIncentivesFileMovements');
        $application = $this->StartupLeaseIncentives->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'leaseRentalList']);
        }
        $startupLeaseIncentive = $this->StartupLeaseIncentives->get($id,['contain'=>['StartupApplications','Designations','ApplicationStatus','ApplicationStages']]);
		
		$startupLeaseIncentiveFileMovements = $this->StartupLeaseIncentivesFileMovements->find('all')->where(['StartupLeaseIncentivesFileMovements.startup_lease_incentive_id '=>$startupLeaseIncentive->id])->toArray();
		
		$typeOfOffice = [1=>'Registered',2=>'Corporate',3=>'Operational'];
		
        $this->set(compact('startupLeaseIncentive', 'startupLeaseIncentiveFileMovements', 'typeOfOffice'));
    }

    public function leaseRentalEdit($id)
    {
        $id = base64_decode($id);
        $this->loadModel('StartupLeaseIncentives');
		$this->loadModel('StartupLeaseIncentivesFileMovements');
        $application = $this->StartupLeaseIncentives->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'leaseRentalList']);
        }
        $startupLeaseIncentive = $this->StartupLeaseIncentives->get($id);
        if($this->request->is(['post','put'])){
            $data = $this->request->getData();
            $startupLeaseIncentive = $this->StartupLeaseIncentives->patchEntity($startupLeaseIncentive,$data);
            if(!empty($data['approve'])){
                $startupLeaseIncentive->application_status_id = 4;
                $startupLeaseIncentive->application_stage_id = 3;
            }elseif(!empty($data['reject'])){
                $startupLeaseIncentive->application_status_id = 7;
            }
            $startupLeaseIncentive->updated = date('Y-m-d H:i:s');
            
			$startupLeaseIncentive->screening_remark_date = date('Y-m-d H:i:s');
			/* if($data['screening_remark_doc']['name']!=''){
                $certificate = $this->uploadFiles('lease-rental', $data['screening_remark_doc']);
                $startupLeaseIncentive->screening_remark_doc = $certificate['filename'];
            } */
			
			if($this->StartupLeaseIncentives->save($startupLeaseIncentive)){
			
				if(!empty($data['approve'])){
					/*startup_application_file_movements Table*/
					$tableName 					= 'StartupLeaseIncentivesFileMovements';
					$application_id_columnName 	= 'startup_lease_incentive_id';
					$startup_application_id 	= $id;
					$comment					= $data['screening_committee_reason'];
					$current_with				= 'Approving Officer';
					$initiated_date				= $startupLeaseIncentive->created;
					$panding_from				= date('Y-m-d');	
					
					$this->fileMovement($tableName, $application_id_columnName, $startup_application_id, $current_with, $comment, $initiated_date, $panding_from, $data);
				}
				
                $this->Flash->success(__('You have successfully updated the status'));
                return $this->redirect(['action' => 'leaseRentalList']);
            }else{
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        }
        $this->set(compact('startupLeaseIncentive'));
	}

    
    public function programAppList()
    {
        $this->loadModel('StartupAppIncentives');
        $query = $this->StartupAppIncentives->find()->contain(['StartupApplications','Designations','ApplicationStatus'])->where(['application_stage_id'=>2])->order(['StartupAppIncentives.id'=>'DESC']);
        $applications = $this->paginate($query);
        $this->set(compact('applications'));
    }

    public function programAppView($id)
    {
        $id = base64_decode($id);
        $this->loadModel('StartupAppIncentives');
		$this->loadModel('StartupAppIncentivesFileMovements');
        $application = $this->StartupAppIncentives->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'programAppList']);
        }
        $startupAppIncentive = $this->StartupAppIncentives->get($id,['contain'=>['StartupApplications','Designations','ApplicationStatus','ApplicationStages']]);
		
		$startupAppIncentivesFileMovements = $this->StartupAppIncentivesFileMovements->find('all')->where(['StartupAppIncentivesFileMovements.startup_app_incentive_id '=>$startupAppIncentive->id])->toArray();
		
        $this->set(compact('startupAppIncentive', 'startupAppIncentivesFileMovements'));
    }

    public function programAppEdit($id)
    {
        $id = base64_decode($id);
        $this->loadModel('StartupAppIncentives');
        $application = $this->StartupAppIncentives->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'programAppList']);
        }
        $startupAppIncentive = $this->StartupAppIncentives->get($id);
        if($this->request->is(['post','put'])){
            $data = $this->request->getData();
            $startupAppIncentive = $this->StartupAppIncentives->patchEntity($startupAppIncentive,$data);
            $startupAppIncentive->screening_committee_reason = $data['screening_committee_reason'];
            if(!empty($data['approve'])){
                $startupAppIncentive->application_status_id = 4;
                $startupAppIncentive->application_stage_id = 3;
            }elseif(!empty($data['reject'])){
                $startupAppIncentive->application_status_id = 7;
            }
            $startupAppIncentive->updated = date('Y-m-d H:i:s');
            if($this->StartupAppIncentives->save($startupAppIncentive)){
				
				/*Startup App Incentives file movements Table*/
					$tableName 					= 'StartupAppIncentivesFileMovements';
					$application_id_columnName 	= 'startup_app_incentive_id';
					$startup_application_id 	= $id;
					$comment					= $data['screening_committee_reason'];
					$current_with				= 'Approving Officer';
					$initiated_date				= $startupAppIncentive->created;
					$panding_from				= date('Y-m-d');	
					
					$this->fileMovement($tableName, $application_id_columnName, $startup_application_id, $current_with, $comment, $initiated_date, $panding_from, $data);
				
                $this->Flash->success(__('You have successfully updated the status'));
                return $this->redirect(['action' => 'programAppList']);
            }else{
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        }
        $this->set(compact('startupAppIncentive'));
    }

    public function patentIncentivesList()
    {
        $this->loadModel('StartupPatentIncentives');
        $query = $this->StartupPatentIncentives->find()->contain(['StartupApplications','Designations','ApplicationStatus'])->where(['application_stage_id'=>2])->order(['StartupPatentIncentives.id'=>'DESC']);
        $applications = $this->paginate($query);
        $this->set(compact('applications'));
    }

    public function patentIncentivesView($id)
    {
        $id = base64_decode($id);
        $this->loadModel('StartupPatentIncentives');
        $application = $this->StartupPatentIncentives->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'patentIncentivesList']);
        }
        $patentIncentive = $this->StartupPatentIncentives->get($id,['contain'=>['StartupApplications','Designations','ApplicationStatus','ApplicationStages']]);
        $this->set(compact('patentIncentive'));
    }

    public function patentIncentivesEdit($id)
    {
        $id = base64_decode($id);
        $this->loadModel('StartupPatentIncentives');
        $application = $this->StartupPatentIncentives->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'patentIncentivesList']);
        }
        $patentIncentive = $this->StartupPatentIncentives->get($id);
        if($this->request->is(['post','put'])){
            $data = $this->request->getData();
            $patentIncentive = $this->StartupPatentIncentives->patchEntity($patentIncentive,$data);
            $patentIncentive->admin_reason = $data['screening_committee_reason'];
            if(!empty($data['approve'])){
                $patentIncentive->application_status_id = 4;
                $patentIncentive->application_stage_id = 3;
            }elseif(!empty($data['reject'])){
                $patentIncentive->application_status_id = 7;
            }
            $patentIncentive->updated = date('Y-m-d H:i:s');
            if($this->StartupPatentIncentives->save($patentIncentive)){
                $this->Flash->success(__('You have successfully updated the status'));
                return $this->redirect(['action' => 'patentIncentivesList']);
            }else{
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        }
        $this->set(compact('patentIncentive'));
    }

    public function qualityCertificationList()
    {
        $this->loadModel('StartupQualityCertifications');
        $query = $this->StartupQualityCertifications->find()->contain(['StartupApplications','Designations','ApplicationStatus'])->where(['application_stage_id'=>2])->order(['StartupQualityCertifications.id'=>'DESC']);
        $applications = $this->paginate($query);
        $this->set(compact('applications'));
    }

    public function qualityCertificationView($id)
    {
        $id = base64_decode($id);
        $this->loadModel('StartupQualityCertifications');
        $application = $this->StartupQualityCertifications->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'qualityCertificationList']);
        }
        $qualityIncentive = $this->StartupQualityCertifications->get($id,['contain'=>['StartupApplications','Designations','ApplicationStatus','ApplicationStages']]);
        $this->set(compact('qualityIncentive'));
    }

    public function qualityCertificationEdit($id)
    {
        $id = base64_decode($id);
        $this->loadModel('StartupQualityCertifications');
        $application = $this->StartupQualityCertifications->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'qualityCertificationList']);
        }
        $qualityIncentive = $this->StartupQualityCertifications->get($id);
        if($this->request->is(['post','put'])){
            $data = $this->request->getData();
            $qualityIncentive = $this->StartupQualityCertifications->patchEntity($qualityIncentive,$data);
            $qualityIncentive->admin_reason = $data['screening_committee_reason'];
            if(!empty($data['approve'])){
                $qualityIncentive->application_status_id = 4;
                $qualityIncentive->application_stage_id = 3;
            }elseif(!empty($data['reject'])){
                $qualityIncentive->application_status_id = 7;
            }
            $qualityIncentive->updated = date('Y-m-d H:i:s');
            if($this->StartupQualityCertifications->save($qualityIncentive)){
                $this->Flash->success(__('You have successfully updated the status'));
                return $this->redirect(['action' => 'qualityCertificationList']);
            }else{
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        }
        $this->set(compact('qualityIncentive'));
    }
}