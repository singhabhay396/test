<?php
namespace App\Controller\Admin;

use App\Controller\Admin\AppController;
use Cake\Event\Event;
use Cake\Mailer\Email;
use Cake\ORM\TableRegistry;
use Cake\Error\Exceptions;
use Cake\I18n\Time;

/**
 * IncubatorsScreeningCommittee Controller
 *
 * @property \App\Model\Table\IncubatorsScreeningCommitteeTable $IncubatorsScreeningCommittee
 *
 * @method \App\Model\Entity\User[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class InvestorsScreeningCommitteeController extends AppController
{
    private $form_of_entity = ['1'=>'Government', '2'=>'Private'];
    
    public function initialize()
    {
        parent::initialize();
        $this->Auth->allow(['jcryption']);
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }
    
    public function index(){
        $this->loadModel('Investors');
        $this->loadModel('Sectors');
        $this->loadModel('Users');
        $this->loadModel('BankDetails');
        $this->loadModel('ThematicFocus');
        $this->loadModel('States');
        $this->loadModel('TypeOfRegistrations');

        $search_condition = array();
        $data = $this->Sanitize->clean($this->request->getQuery());
        if (!empty($data['reference_no'])) {
            $reference_no = trim($data['reference_no']);
            $this->set('reference_no', $reference_no); 
            $search_condition[] = "Investors.reference_no like '%" . $reference_no . "%'";
        }
        if (!empty($data['name_of_entity'])) {
            $name_of_entity = trim($data['name_of_entity']);
            $this->set('name_of_entity',$name_of_entity); 
            $search_condition[] = "Investors.name_of_entity like '%" . $name_of_entity . "%'";
        }    

        if (!empty($data['certificate_no'])) {
            $certificate_no = trim($data['certificate_no']);
            $this->set('certificate_no', $certificate_no); 
            $search_condition[] = "Investors.certificate_no like '%" . $certificate_no . "%'";
        }

        if (!empty($data['type_of_operations'])) {
            $type_of_operations = trim($data['type_of_operations']);
            $this->set('type_of_operations', $type_of_operations); 
            $search_condition[] = "Investors.type_of_operations like '%" . $type_of_operations . "%'";
        }
        
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        $query = $this->Investors->find()->contain(['Users','TypeOfRegistrations','RegisteredStates','ThematicFocus','ApplicationStatus'])->where(['investor_stage_id'=>2])->order(['Investors.id'=>'DESC'])->where([$searchString,'is_save_draft'=>0]);
        $applications = $this->paginate($query);

        $form_of_entity = $this->form_of_entity;
        $this->set(compact('applications', 'form_of_entity'));
    }

    public function update($id)
    {
        $id = base64_decode($id);
        $this->loadModel('Investors');
        $application = $this->Investors->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'index']);
        }
        $applications = $this->Investors->get($id);
        if($this->request->is(['POST', 'PUT'])){
            $data = $this->request->getData();
            $applications = $this->Investors->patchEntity($applications, $data);
            $applications->screening_committee_comment = $data['screening_committee_comment'];
            if($this->request->data['action'] == 'Approve'){
                $applications->application_status_id = 4;
                $applications->investor_stage_id = 3;                
            }else if($this->request->data['action'] == 'Reject'){
                $applications->application_status_id = 7;
            }		
            $applications->screening_remark_date = date('Y-m-d');
            if($data['screening_remark_doc']['name']!=''){
                $certificate = $this->uploadFiles('investor', $data['screening_remark_doc']);
                $applications->screening_remark_doc = $certificate['filename'];
            }
			
            if($this->Investors->save($applications)){		
                if($data['action'] == 'Approve'){
                    /*startup_application_file_movements Table*/
                    $tableName                  = 'InvestorApplicationFileMovements';
                    $application_id_columnName 	= 'investor_application_id';
                    $startup_application_id 	= $id;
                    $comment			= $data['screening_committee_comment'];
                    $current_with		= 'Approving Officer';
                    $initiated_date		= $applications->created;
                    $panding_from		= date('Y-m-d');	

                    $this->fileMovement($tableName, $application_id_columnName, $startup_application_id, $current_with, $comment, $initiated_date, $panding_from, $data);
                }
                $this->Flash->success(__('You have successfully updated the status'));
                return $this->redirect(['action' => 'index']);
            }
        }
        $this->set(compact('applications'));
    }
    public function view($id)
    {
        $id = base64_decode($id);
        $this->loadModel('Investors');
        $this->loadModel('InvestorApplicationFileMovements');
        $application = $this->Investors->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'index']);
        }
        $startupApplication = $this->Investors->get($id, ['contain' => ['Users','TypeOfRegistrations','RegisteredStates','ThematicFocus','ApplicationStatus','RegisteredCities']]);
        $mentorApplicationFileMovements = $this->InvestorApplicationFileMovements->find('all')->where(['InvestorApplicationFileMovements.investor_application_id '=>$startupApplication->id])->toArray();
        $this->set(compact('startupApplication', 'mentorApplicationFileMovements'));
    }

    public function recurringExpenseList()
    {
        $this->loadModel('IncubatorRecurringExpenses');
        $search_condition = array();
        if (!empty($this->request->getQuery('reference_number'))) {
            $reference_number = trim($this->request->getQuery('reference_number'));
            $this->set('reference_number', $reference_number); 
            $search_condition[] = "IncubatorRecurringExpenses.reference_number like '%" . $reference_number . "%'";
        }
        if (!empty($this->request->getQuery('incubator_name'))) {
            $incubator_name = trim($this->request->getQuery('incubator_name'));
            $this->set('incubator_name', $incubator_name); 
            $search_condition[] = "IncubatorRecurringExpenses.incubator_name like '%" . $incubator_name . "%'";
        }    
        if (!empty($this->request->getQuery('registration_number'))) {
            $registration_number = trim($this->request->getQuery('registration_number'));
            $this->set('registration_number', $registration_number); 
            $search_condition[] = "IncubatorRecurringExpenses.registration_number like '%" . $registration_number . "%'";
        }
        if (!empty($this->request->getQuery('actual_expense'))) {
            $actual_expense = trim($this->request->getQuery('actual_expense'));
            $this->set('actual_expense', $actual_expense); 
            $search_condition[] = "IncubatorRecurringExpenses.actual_expense like '%" . $actual_expense . "%'";
        }
        
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        $query = $this->IncubatorRecurringExpenses->find()->contain(['Incubators','Designations','ApplicationStatus'])->order(['IncubatorRecurringExpenses.id'=>'DESC'])->where(['application_stage_id'=>2,$searchString]);
        $applications = $this->paginate($query);
        $this->set(compact('applications'));
    }

    public function recurringExpenseView($id='')
    {
        $this->loadModel('IncubatorRecurringExpenses');
        $id = base64_decode($id);
        $application = $this->IncubatorRecurringExpenses->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'recurringExpenseList']);
        }
        $incubatorRecurringExpense = $this->IncubatorRecurringExpenses->get($id, ['contain' => ['Incubators','ApplicationStatus','Designations']]);
        $this->set(compact('incubatorRecurringExpense'));
    }

    public function recurringExpenseEdit($id='')
    {
        $id = base64_decode($id);
        $this->loadModel('IncubatorRecurringExpenses');
        $application = $this->IncubatorRecurringExpenses->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'recurringExpenseList']);
        }
        $incubatorRecurringExpense = $this->IncubatorRecurringExpenses->get($id);
        if($this->request->is(['post','put'])){
            $data = $this->request->getData();
            
            $incubatorRecurringExpense->screening_committee_comment = $data['screening_committee_comment'];
            $incubatorRecurringExpense->screening_committee_date =  date('Y-m-d H:i:s');
            if(!empty($data['approve'])){
                $incubatorRecurringExpense->application_status_id = 4;
                $incubatorRecurringExpense->application_stage_id  = 3;
            }elseif(!empty($data['reject'])){
                $incubatorRecurringExpense->application_status_id = 7;
            }
            $incubatorRecurringExpense->updated = date('Y-m-d H:i:s');
            if($this->IncubatorRecurringExpenses->save($incubatorRecurringExpense)){
                $this->Flash->success(__('You have successfully updated the status.'));
                return $this->redirect(['action' => 'recurringExpenseList']);
            }else{
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        }
        $this->set(compact('incubatorRecurringExpense'));
    }
    
    public function compititionAssistanceList()
    {
        $this->loadModel('IncubatorCompititionAssistances');
        $search_condition = array();
        if (!empty($this->request->getQuery('reference_number'))) {
            $reference_number = trim($this->request->getQuery('reference_number'));
            $this->set('reference_number', $reference_number); 
            $search_condition[] = "IncubatorCompititionAssistances.reference_number like '%" . $reference_number . "%'";
        }
        if (!empty($this->request->getQuery('incubator_name'))) {
            $incubator_name = trim($this->request->getQuery('incubator_name'));
            $this->set('incubator_name', $incubator_name); 
            $search_condition[] = "IncubatorCompititionAssistances.incubator_name like '%" . $incubator_name . "%'";
        }    

        if (!empty($this->request->getQuery('registration_number'))) {
            $registration_number = trim($this->request->getQuery('registration_number'));
            $this->set('registration_number', $registration_number); 
            $search_condition[] = "IncubatorCompititionAssistances.registration_number like '%" . $registration_number . "%'";
        }

        if (!empty($this->request->getQuery('assistance_amount'))) {
            $assistance_amount = trim($this->request->getQuery('assistance_amount'));
            $this->set('assistance_amount', $assistance_amount); 
            $search_condition[] = "IncubatorCompititionAssistances.assistance_amount like '%" . $assistance_amount . "%'";
        }
        
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        $query = $this->IncubatorCompititionAssistances->find()->contain(['Incubators','Designations','ApplicationStatus'])->order(['IncubatorCompititionAssistances.id'=>'DESC'])->where(['application_stage_id'=>2,$searchString]);
        $applications = $this->paginate($query);
        $this->set(compact('applications'));
    }

    public function compititionAssistanceView($id='')
    {
        $this->loadModel('IncubatorCompititionAssistances');
        $id = base64_decode($id);
        $application = $this->IncubatorCompititionAssistances->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'compititionAssistanceList']);
        }
        $incubatorCompititionAssistance = $this->IncubatorCompititionAssistances->get($id, ['contain' => ['Incubators','ApplicationStatus','Designations']]);
        $this->set(compact('incubatorCompititionAssistance'));
    }

    public function compititionAssistanceEdit($id='')
    {
        $id = base64_decode($id);
        $this->loadModel('IncubatorCompititionAssistances');
        $application = $this->IncubatorCompititionAssistances->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'compititionAssistanceList']);
        }
        $incubatorcompititionAssistance = $this->IncubatorCompititionAssistances->get($id);
        if($this->request->is(['post','put'])){
            $data = $this->request->getData();
            
            $incubatorcompititionAssistance->screening_committee_comment = $data['screening_committee_comment'];
            $incubatorcompititionAssistance->screening_committee_date =  date('Y-m-d H:i:s');

            if(!empty($data['approve'])){
                $incubatorcompititionAssistance->application_status_id = 4;
                $incubatorcompititionAssistance->application_stage_id  = 3;
            }elseif(!empty($data['reject'])){
                $incubatorcompititionAssistance->application_status_id = 7;
            }
            $incubatorcompititionAssistance->updated = date('Y-m-d H:i:s');
            if($this->IncubatorCompititionAssistances->save($incubatorcompititionAssistance)){
                $this->Flash->success(__('You have successfully updated the status.'));
                return $this->redirect(['action' => 'compititionAssistanceList']);
            }else{
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        }
        $this->set(compact('incubatorcompititionAssistance'));
    }

    public function fairExhibitionList()
    {
        $this->loadModel('IncubatorFairExhibitions');
        $search_condition = array();
        if (!empty($this->request->getQuery('reference_number'))) {
            $reference_number = trim($this->request->getQuery('reference_number'));
            $this->set('reference_number', $reference_number); 
            $search_condition[] = "IncubatorFairExhibitions.reference_number like '%" . $reference_number . "%'";
        }
        if (!empty($this->request->getQuery('incubator_name'))) {
            $incubator_name = trim($this->request->getQuery('incubator_name'));
            $this->set('incubator_name', $incubator_name); 
            $search_condition[] = "IncubatorFairExhibitions.incubator_name like '%" . $incubator_name . "%'";
        }
        if (!empty($this->request->getQuery('registration_number'))) {
            $registration_number = trim($this->request->getQuery('registration_number'));
            $this->set('registration_number', $registration_number); 
            $search_condition[] = "IncubatorFairExhibitions.registration_number like '%" . $registration_number . "%'";
        }
        if (!empty($this->request->getQuery('approval_letter_number'))) {
            $approval_letter_number = trim($this->request->getQuery('approval_letter_number'));
            $this->set('approval_letter_number', $approval_letter_number); 
            $search_condition[] = "IncubatorFairExhibitions.approval_letter_number like '%" . $approval_letter_number . "%'";
        }        
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        $query = $this->IncubatorFairExhibitions->find()->contain(['Incubators','ApplicationStatus'])->order(['IncubatorFairExhibitions.id'=>'DESC'])->where(['application_stage_id'=>2,$searchString]);
        $applications = $this->paginate($query);
        $this->set(compact('applications'));
    }

    public function fairExhibitionView($id='')
    {
        $this->loadModel('IncubatorFairExhibitions');
        $id = base64_decode($id);
        $application = $this->IncubatorFairExhibitions->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'fairExhibitionList']);
        }
        $incubatorFairExhibition = $this->IncubatorFairExhibitions->get($id, ['contain' => ['Incubators','ApplicationStatus']]);
        $this->set(compact('incubatorFairExhibition'));
    }

    public function fairExhibitionEdit($id='')
    {
        $id = base64_decode($id);
        $this->loadModel('IncubatorFairExhibitions');
        $application = $this->IncubatorFairExhibitions->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'fairExhibitionList']);
        }
        $incubatorfairExhibition = $this->IncubatorFairExhibitions->get($id);
        if($this->request->is(['post','put'])){
            $data = $this->request->getData();
            
            $incubatorfairExhibition->screening_committee_comment = $data['screening_committee_comment'];
            $incubatorfairExhibition->screening_committee_date =  date('Y-m-d H:i:s');
            if(!empty($data['approve'])){
                $incubatorfairExhibition->application_status_id = 4;
                $incubatorfairExhibition->application_stage_id  = 3;
            }elseif(!empty($data['reject'])){
                $incubatorfairExhibition->application_status_id = 7;
            }
            $incubatorfairExhibition->updated = date('Y-m-d H:i:s');
            if($this->IncubatorFairExhibitions->save($incubatorfairExhibition)){
                $this->Flash->success(__('You have successfully updated the status.'));
                return $this->redirect(['action' => 'fairExhibitionList']);
            }else{
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        }
        $this->set(compact('incubatorfairExhibition'));
    }

    public function mentorTrainingList()
    {
        $this->loadModel('IncubatorMentorTrainings');
        $search_condition = array();
        if (!empty($this->request->getQuery('reference_number'))) {
            $reference_number = trim($this->request->getQuery('reference_number'));
            $this->set('reference_number', $reference_number); 
            $search_condition[] = "IncubatorMentorTrainings.reference_number like '%" . $reference_number . "%'";
        }
        if (!empty($this->request->getQuery('incubator_name'))) {
            $incubator_name = trim($this->request->getQuery('incubator_name'));
            $this->set('incubator_name', $incubator_name); 
            $search_condition[] = "IncubatorMentorTrainings.incubator_name like '%" . $incubator_name . "%'";
        }    

        if (!empty($this->request->getQuery('registration_number'))) {
            $registration_number = trim($this->request->getQuery('registration_number'));
            $this->set('registration_number', $registration_number); 
            $search_condition[] = "IncubatorMentorTrainings.registration_number like '%" . $registration_number . "%'";
        }

        if (!empty($this->request->getQuery('actual_expense'))) {
            $actual_expense = trim($this->request->getQuery('actual_expense'));
            $this->set('actual_expense', $actual_expense); 
            $search_condition[] = "IncubatorMentorTrainings.actual_expense like '%" . $actual_expense . "%'";
        }
        
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        $query = $this->IncubatorMentorTrainings->find()->contain(['Incubators','ApplicationStatus'])->order(['IncubatorMentorTrainings.id'=>'DESC'])->where(['application_stage_id'=>2,$searchString]);
        $applications = $this->paginate($query);
        $this->set(compact('applications'));
    }

    public function mentorTrainingView($id='')
    {
        $this->loadModel('IncubatorMentorTrainings');
        $id = base64_decode($id);
        $application = $this->IncubatorMentorTrainings->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'mentorTrainingList']);
        }
        $incubatorMentorTraining = $this->IncubatorMentorTrainings->get($id, ['contain' => ['Incubators','ApplicationStatus','Designations']]);
        $this->set(compact('incubatorMentorTraining'));
    }

    public function mentorTrainingEdit($id='')
    {
        $id = base64_decode($id);
        $this->loadModel('IncubatorMentorTrainings');
        $application = $this->IncubatorMentorTrainings->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'mentorTrainingList']);
        }
        $incubatorMentorTraining = $this->IncubatorMentorTrainings->get($id);
        if($this->request->is(['post','put'])){
            $data = $this->request->getData();
            $incubatorMentorTraining->screening_committee_comment = $data['screening_committee_comment'];
            $incubatorMentorTraining->screening_committee_date =  date('Y-m-d H:i:s');
            if(!empty($data['approve'])){
                $incubatorMentorTraining->application_status_id = 4;
                $incubatorMentorTraining->application_stage_id  = 3;
            }elseif(!empty($data['reject'])){
                $incubatorMentorTraining->application_status_id = 7;
            }
            $incubatorMentorTraining->updated = date('Y-m-d H:i:s');
            if($this->IncubatorMentorTrainings->save($incubatorMentorTraining)){
                $this->Flash->success(__('You have successfully updated the status.'));
                return $this->redirect(['action' => 'mentorTrainingList']);
            }else{
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        }
        $this->set(compact('incubatorMentorTraining'));
    }

    
    public function rentalChargeExemptionList()
    {
        $this->loadModel('IncubatorRentalCharges');
        $search_condition = array();
        if (!empty($this->request->getQuery('reference_number'))) {
            $reference_number = trim($this->request->getQuery('reference_number'));
            $this->set('reference_number', $reference_number); 
            $search_condition[] = "IncubatorRentalCharges.reference_number like '%" . $reference_number . "%'";
        }
        if (!empty($this->request->getQuery('incubator_name'))) {
            $incubator_name = trim($this->request->getQuery('incubator_name'));
            $this->set('incubator_name', $incubator_name); 
            $search_condition[] = "IncubatorRentalCharges.incubator_name like '%" . $incubator_name . "%'";
        }    

        if (!empty($this->request->getQuery('registration_number'))) {
            $registration_number = trim($this->request->getQuery('registration_number'));
            $this->set('registration_number', $registration_number); 
            $search_condition[] = "IncubatorRentalCharges.registration_number like '%" . $registration_number . "%'";
        }

        if (!empty($this->request->getQuery('amount_incurred'))) {
            $amount_incurred = trim($this->request->getQuery('amount_incurred'));
            $this->set('amount_incurred', $amount_incurred); 
            $search_condition[] = "IncubatorRentalCharges.amount_incurred like '%" . $amount_incurred . "%'";
        }
        
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        $query = $this->IncubatorRentalCharges->find()->contain(['Incubators','ApplicationStatus'])->order(['IncubatorRentalCharges.id'=>'DESC'])->where(['application_stage_id'=>2,$searchString]);
        $applications = $this->paginate($query);
        $this->set(compact('applications'));
    }

    public function rentalChargeExemptionView($id='')
    {
        $this->loadModel('IncubatorRentalCharges');
        $id = base64_decode($id);
        $application = $this->IncubatorRentalCharges->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'rentalChargeExemptionList']);
        }
        $incubatorRentalCharge = $this->IncubatorRentalCharges->get($id, ['contain' => ['Incubators','ApplicationStatus','Designations']]);
        $this->set(compact('incubatorRentalCharge'));
    }

    public function rentalChargeExemptionEdit($id='')
    {
        $id = base64_decode($id);
        $this->loadModel('IncubatorRentalCharges');
        $application = $this->IncubatorRentalCharges->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'rentalChargeExemptionList']);
        }
        $incubatorRentalCharge = $this->IncubatorRentalCharges->get($id);
        if($this->request->is(['post','put'])){
            $data = $this->request->getData();
            
            $incubatorRentalCharge->screening_committee_comment = $data['screening_committee_comment'];
            $incubatorRentalCharge->screening_committee_date =  date('Y-m-d H:i:s');
            if(!empty($data['approve'])){
                $incubatorRentalCharge->application_status_id = 4;
                $incubatorRentalCharge->application_stage_id  = 3;
            }elseif(!empty($data['reject'])){
                $incubatorRentalCharge->application_status_id = 7;
            }
            $incubatorRentalCharge->updated = date('Y-m-d H:i:s');
            if($this->IncubatorRentalCharges->save($incubatorRentalCharge)){
                $this->Flash->success(__('You have successfully updated the status.'));
                return $this->redirect(['action' => 'rentalChargeExemptionList']);
            }else{
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        }
        $this->set(compact('incubatorRentalCharge'));
    }

    public function stampDutyRegistrationList()
    {
        $this->loadModel('IncubatorStampDuties');
        $search_condition = array();
        if (!empty($this->request->getQuery('reference_number'))) {
            $reference_number = trim($this->request->getQuery('reference_number'));
            $this->set('reference_number', $reference_number); 
            $search_condition[] = "IncubatorStampDuties.reference_number like '%" . $reference_number . "%'";
        }
        if (!empty($this->request->getQuery('incubator_name'))) {
            $incubator_name = trim($this->request->getQuery('incubator_name'));
            $this->set('incubator_name', $incubator_name); 
            $search_condition[] = "IncubatorStampDuties.incubator_name like '%" . $incubator_name . "%'";
        }    

        if (!empty($this->request->getQuery('registration_number'))) {
            $registration_number = trim($this->request->getQuery('registration_number'));
            $this->set('registration_number', $registration_number); 
            $search_condition[] = "IncubatorStampDuties.registration_number like '%" . $registration_number . "%'";
        }

        if (!empty($this->request->getQuery('amount_of_stamp_duty'))) {
            $amount_of_stamp_duty = trim($this->request->getQuery('amount_of_stamp_duty'));
            $this->set('amount_of_stamp_duty', $amount_of_stamp_duty); 
            $search_condition[] = "IncubatorStampDuties.amount_of_stamp_duty like '%" . $amount_of_stamp_duty . "%'";
        }
        
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        $query = $this->IncubatorStampDuties->find()->contain(['Incubators','ApplicationStatus'])->order(['IncubatorStampDuties.id'=>'DESC'])->where(['application_stage_id'=>2,$searchString]);
        $applications = $this->paginate($query);
        $this->set(compact('applications'));
    }

    public function stampDutyRegistrationView($id='')
    {
        $this->loadModel('IncubatorStampDuties');
        $id = base64_decode($id);
        $application = $this->IncubatorStampDuties->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'stampDutyRegistrationList']);
        }
        $incubatorStampDuty = $this->IncubatorStampDuties->get($id, ['contain' => ['Incubators','ApplicationStatus','Designations']]);
        $this->set(compact('incubatorStampDuty'));
    }

    public function stampDutyRegistrationEdit($id='')
    {
        $id = base64_decode($id);
        $this->loadModel('IncubatorStampDuties');
        $application = $this->IncubatorStampDuties->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'stampDutyRegistrationList']);
        }
        $incubatorStampDuty = $this->IncubatorStampDuties->get($id);
        if($this->request->is(['post','put'])){
            $data = $this->request->getData();
            
            $incubatorStampDuty->screening_committee_comment = $data['screening_committee_comment'];
            $incubatorStampDuty->screening_committee_date =  date('Y-m-d H:i:s');
            if(!empty($data['approve'])){
                $incubatorStampDuty->application_status_id = 4;
                $incubatorStampDuty->application_stage_id  = 3;
            }elseif(!empty($data['reject'])){
                $incubatorStampDuty->application_status_id = 7;
            }
            $incubatorStampDuty->updated = date('Y-m-d H:i:s');
            if($this->IncubatorStampDuties->save($incubatorStampDuty)){
                $this->Flash->success(__('You have successfully updated the status.'));
                return $this->redirect(['action' => 'stampDutyRegistrationList']);
            }else{
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        }
        $this->set(compact('incubatorStampDuty'));
    }

    public function preApprovalInFairExhibitionList()
    {
        $this->loadModel('IncubatorPreApprovalFairExhibitions');
        $search_condition = array();
        if (!empty($this->request->getQuery('reference_number'))) {
            $reference_number = trim($this->request->getQuery('reference_number'));
            $this->set('reference_number', $reference_number); 
            $search_condition[] = "IncubatorPreApprovalFairExhibitions.reference_number like '%" . $reference_number . "%'";
        }
        if (!empty($this->request->getQuery('incubator_name'))) {
            $incubator_name = trim($this->request->getQuery('incubator_name'));
            $this->set('incubator_name', $incubator_name); 
            $search_condition[] = "IncubatorPreApprovalFairExhibitions.incubator_name like '%" . $incubator_name . "%'";
        }    

        if (!empty($this->request->getQuery('registration_number'))) {
            $registration_number = trim($this->request->getQuery('registration_number'));
            $this->set('registration_number', $registration_number); 
            $search_condition[] = "IncubatorPreApprovalFairExhibitions.registration_number like '%" . $registration_number . "%'";
        }

        if (!empty($this->request->getQuery('assistance_amount'))) {
            $assistance_amount = trim($this->request->getQuery('assistance_amount'));
            $this->set('assistance_amount', $assistance_amount); 
            $search_condition[] = "IncubatorPreApprovalFairExhibitions.assistance_amount like '%" . $assistance_amount . "%'";
        }
        
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        $query = $this->IncubatorPreApprovalFairExhibitions->find()->contain(['Incubators','ApplicationStatus'])->order(['IncubatorPreApprovalFairExhibitions.id'=>'DESC'])->where(['application_stage_id'=>2,$searchString]);
        $applications = $this->paginate($query);
        $this->set(compact('applications'));
    }

    public function preApprovalInFairExhibitionView($id='')
    {
        $this->loadModel('IncubatorPreApprovalFairExhibitions');
        $id = base64_decode($id);
        $application = $this->IncubatorPreApprovalFairExhibitions->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'preApprovalInFairExhibitionList']);
        }
        $preApprovalFairExhibition = $this->IncubatorPreApprovalFairExhibitions->get($id, ['contain' => ['Incubators','ApplicationStatus','Designations']]);
        $this->set(compact('preApprovalFairExhibition'));
    }

    public function preApprovalInFairExhibitionEdit($id='')
    {
        $id = base64_decode($id);
        $this->loadModel('IncubatorPreApprovalFairExhibitions');
        $application = $this->IncubatorPreApprovalFairExhibitions->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'preApprovalInFairExhibitionList']);
        }
        $preApprovalFairExhibition = $this->IncubatorPreApprovalFairExhibitions->get($id);
        if($this->request->is(['post','put'])){
            $data = $this->request->getData();
            
            $preApprovalFairExhibition->screening_committee_comment = $data['screening_committee_comment'];
            $preApprovalFairExhibition->screening_committee_date =  date('Y-m-d H:i:s');
            if(!empty($data['approve'])){
                $preApprovalFairExhibition->application_status_id = 4;
                $preApprovalFairExhibition->application_stage_id  = 3;
            }elseif(!empty($data['reject'])){
                $preApprovalFairExhibition->application_status_id = 7;
            }
            $preApprovalFairExhibition->updated = date('Y-m-d H:i:s');
            if($this->IncubatorPreApprovalFairExhibitions->save($preApprovalFairExhibition)){
                $this->Flash->success(__('You have successfully updated the status.'));
                return $this->redirect(['action' => 'preApprovalInFairExhibitionList']);
            }else{
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        }
        $this->set(compact('preApprovalFairExhibition'));
    }

    public function claimingAssistanceInFairExhibitionList()
    {
        $this->loadModel('IncubatorClaimingAssistanceFairExhibitions');
        $search_condition = array();
        if (!empty($this->request->getQuery('reference_number'))) {
            $reference_number = trim($this->request->getQuery('reference_number'));
            $this->set('reference_number', $reference_number); 
            $search_condition[] = "IncubatorClaimingAssistanceFairExhibitions.reference_number like '%" . $reference_number . "%'";
        }
        if (!empty($this->request->getQuery('incubator_name'))) {
            $incubator_name = trim($this->request->getQuery('incubator_name'));
            $this->set('incubator_name', $incubator_name); 
            $search_condition[] = "IncubatorClaimingAssistanceFairExhibitions.incubator_name like '%" . $incubator_name . "%'";
        }        
        if (!empty($this->request->getQuery('registration_number'))) {
            $registration_number = trim($this->request->getQuery('registration_number'));
            $this->set('registration_number', $registration_number); 
            $search_condition[] = "IncubatorClaimingAssistanceFairExhibitions.registration_number like '%" . $registration_number . "%'";
        }
        if (!empty($this->request->getQuery('letter_no_of_approval'))) {
            $letter_no_of_approval = trim($this->request->getQuery('letter_no_of_approval'));
            $this->set('letter_no_of_approval', $letter_no_of_approval); 
            $search_condition[] = "IncubatorClaimingAssistanceFairExhibitions.letter_no_of_approval like '%" . $letter_no_of_approval . "%'";
        }        
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        $query = $this->IncubatorClaimingAssistanceFairExhibitions->find()->contain(['Incubators','ApplicationStatus'])->order(['IncubatorClaimingAssistanceFairExhibitions.id'=>'DESC'])->where(['application_stage_id'=>2,$searchString]);
        $applications = $this->paginate($query);
        $this->set(compact('applications'));
    }

    public function claimingAssistanceInFairExhibitionView($id='')
    {
        $this->loadModel('IncubatorClaimingAssistanceFairExhibitions');
        $id = base64_decode($id);
        $application = $this->IncubatorClaimingAssistanceFairExhibitions->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'claimingAssistanceInFairExhibitionList']);
        }
        $claimingAssistanceFairExhibition = $this->IncubatorClaimingAssistanceFairExhibitions->get($id, ['contain' => ['Incubators','ApplicationStatus','Designations']]);
        $this->set(compact('claimingAssistanceFairExhibition'));
    }

    public function claimingAssistanceInFairExhibitionEdit($id='')
    {
        $id = base64_decode($id);
        $this->loadModel('IncubatorClaimingAssistanceFairExhibitions');
        $application = $this->IncubatorClaimingAssistanceFairExhibitions->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'claimingAssistanceInFairExhibitionList']);
        }
        $claimingAssistanceFairExhibition = $this->IncubatorClaimingAssistanceFairExhibitions->get($id);
        if($this->request->is(['post','put'])){
            $data = $this->request->getData();
            
            $claimingAssistanceFairExhibition->screening_committee_comment = $data['screening_committee_comment'];
            $claimingAssistanceFairExhibition->screening_committee_date =  date('Y-m-d H:i:s');
            if(!empty($data['approve'])){
                $claimingAssistanceFairExhibition->application_status_id = 4;
                $claimingAssistanceFairExhibition->application_stage_id  = 3;
            }elseif(!empty($data['reject'])){
                $claimingAssistanceFairExhibition->application_status_id = 7;
            }
            $claimingAssistanceFairExhibition->updated = date('Y-m-d H:i:s');
            if($this->IncubatorClaimingAssistanceFairExhibitions->save($claimingAssistanceFairExhibition)){
                $this->Flash->success(__('You have successfully updated the status.'));
                return $this->redirect(['action' => 'claimingAssistanceInFairExhibitionList']);
            }else{
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        }
        $this->set(compact('claimingAssistanceFairExhibition'));
    }

    public function capitalSubsidyPhaseOneList()
    {
        $this->loadModel('IncubatorCapitalSubsidyPhaseOne');
        $search_condition = array();
        if (!empty($this->request->getQuery('reference_number'))) {
            $reference_number = trim($this->request->getQuery('reference_number'));
            $this->set('reference_number', $reference_number); 
            $search_condition[] = "IncubatorCapitalSubsidyPhaseOne.reference_number like '%" . $reference_number . "%'";
        }
        if (!empty($this->request->getQuery('incubator_name'))) {
            $incubator_name = trim($this->request->getQuery('incubator_name'));
            $this->set('incubator_name', $incubator_name); 
            $search_condition[] = "IncubatorCapitalSubsidyPhaseOne.incubator_name like '%" . $incubator_name . "%'";
        }        
        if (!empty($this->request->getQuery('registration_number'))) {
            $registration_number = trim($this->request->getQuery('registration_number'));
            $this->set('registration_number', $registration_number); 
            $search_condition[] = "IncubatorCapitalSubsidyPhaseOne.registration_number like '%" . $registration_number . "%'";
        }
        if (!empty($this->request->getQuery('sanctioned_amount'))) {
            $sanctioned_amount = trim($this->request->getQuery('sanctioned_amount'));
            $this->set('sanctioned_amount', $sanctioned_amount); 
            $search_condition[] = "IncubatorCapitalSubsidyPhaseOne.sanctioned_amount like '%" . $sanctioned_amount . "%'";
        }
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        $query = $this->IncubatorCapitalSubsidyPhaseOne->find()->contain(['Incubators','ApplicationStatus'])->order(['IncubatorCapitalSubsidyPhaseOne.id'=>'DESC'])->where(['application_stage_id'=>2,$searchString]);
        $applications = $this->paginate($query);
        $this->set(compact('applications'));
    }

    public function capitalSubsidyPhaseOneView($id='')
    {
        $this->loadModel('IncubatorCapitalSubsidyPhaseOne');
        $id = base64_decode($id);
        $application = $this->IncubatorCapitalSubsidyPhaseOne->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'capitalSubsidyPhaseOneList']);
        }
        $capitalSubsidyOne = $this->IncubatorCapitalSubsidyPhaseOne->get($id, ['contain' => ['Incubators','ApplicationStatus','Designations']]);
        $this->set(compact('capitalSubsidyOne'));
    }

    public function capitalSubsidyPhaseOneEdit($id='')
    {
        $id = base64_decode($id);
        $this->loadModel('IncubatorCapitalSubsidyPhaseOne');
        $application = $this->IncubatorCapitalSubsidyPhaseOne->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'capitalSubsidyPhaseOneList']);
        }
        $capitalSubsidyOne = $this->IncubatorCapitalSubsidyPhaseOne->get($id);
        if($this->request->is(['post','put'])){
            $data = $this->request->getData();
            
            $capitalSubsidyOne->screening_committee_comment = $data['screening_committee_comment'];
            $capitalSubsidyOne->screening_committee_date =  date('Y-m-d H:i:s');
            if(!empty($data['approve'])){
                $capitalSubsidyOne->application_status_id = 4;
                $capitalSubsidyOne->application_stage_id  = 3;
            }elseif(!empty($data['reject'])){
                $capitalSubsidyOne->application_status_id = 7;
            }
            $capitalSubsidyOne->updated = date('Y-m-d H:i:s');
            if($this->IncubatorCapitalSubsidyPhaseOne->save($capitalSubsidyOne)){
                $this->Flash->success(__('You have successfully updated the status.'));
                return $this->redirect(['action' => 'capitalSubsidyPhaseOneList']);
            }else{
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        }
        $this->set(compact('capitalSubsidyOne'));
    }

    public function capitalSubsidyPhaseTwoList()
    {
        $this->loadModel('IncubatorCapitalSubsidyPhaseTwo');
        $search_condition = array();
        if (!empty($this->request->getQuery('reference_number'))) {
            $reference_number = trim($this->request->getQuery('reference_number'));
            $this->set('reference_number', $reference_number); 
            $search_condition[] = "IncubatorCapitalSubsidyPhaseTwo.reference_number like '%" . $reference_number . "%'";
        }
        if (!empty($this->request->getQuery('incubator_name'))) {
            $incubator_name = trim($this->request->getQuery('incubator_name'));
            $this->set('incubator_name', $incubator_name); 
            $search_condition[] = "IncubatorCapitalSubsidyPhaseTwo.incubator_name like '%" . $incubator_name . "%'";
        }        
        if (!empty($this->request->getQuery('registration_number'))) {
            $registration_number = trim($this->request->getQuery('registration_number'));
            $this->set('registration_number', $registration_number); 
            $search_condition[] = "IncubatorCapitalSubsidyPhaseTwo.registration_number like '%" . $registration_number . "%'";
        }
        if (!empty($this->request->getQuery('sanctioned_amount'))) {
            $sanctioned_amount = trim($this->request->getQuery('sanctioned_amount'));
            $this->set('sanctioned_amount', $sanctioned_amount); 
            $search_condition[] = "IncubatorCapitalSubsidyPhaseTwo.sanctioned_amount like '%" . $sanctioned_amount . "%'";
        }
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        $query = $this->IncubatorCapitalSubsidyPhaseTwo->find()->contain(['Incubators','ApplicationStatus'])->order(['IncubatorCapitalSubsidyPhaseTwo.id'=>'DESC'])->where(['application_stage_id'=>2,$searchString]);
        $applications = $this->paginate($query);
        $this->set(compact('applications'));
    }

    public function capitalSubsidyPhaseTwoView($id='')
    {
        $this->loadModel('IncubatorCapitalSubsidyPhaseTwo');
        $id = base64_decode($id);
        $application = $this->IncubatorCapitalSubsidyPhaseTwo->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'capitalSubsidyPhaseTwoList']);
        }
        $capitalSubsidyTwo = $this->IncubatorCapitalSubsidyPhaseTwo->get($id, ['contain' => ['Incubators','ApplicationStatus','Designations']]);
        $this->set(compact('capitalSubsidyTwo'));
    }

    public function capitalSubsidyPhaseTwoEdit($id='')
    {
        $id = base64_decode($id);
        $this->loadModel('IncubatorCapitalSubsidyPhaseTwo');
        $application = $this->IncubatorCapitalSubsidyPhaseTwo->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'capitalSubsidyPhaseTwoList']);
        }
        $capitalSubsidyTwo = $this->IncubatorCapitalSubsidyPhaseTwo->get($id);
        if($this->request->is(['post','put'])){
            $data = $this->request->getData();
            
            $capitalSubsidyTwo->screening_committee_comment = $data['screening_committee_comment'];
            $capitalSubsidyTwo->screening_committee_date =  date('Y-m-d H:i:s');
            if(!empty($data['approve'])){
                $capitalSubsidyTwo->application_status_id = 4;
                $capitalSubsidyTwo->application_stage_id  = 3;
            }elseif(!empty($data['reject'])){
                $capitalSubsidyTwo->application_status_id = 7;
            }
            $capitalSubsidyTwo->updated = date('Y-m-d H:i:s');
            if($this->IncubatorCapitalSubsidyPhaseTwo->save($capitalSubsidyTwo)){
                $this->Flash->success(__('You have successfully updated the status.'));
                return $this->redirect(['action' => 'capitalSubsidyPhaseTwoList']);
            }else{
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        }
        $this->set(compact('capitalSubsidyTwo'));
    }

    public function capitalSubsidyPhaseThreeList()
    {
        $this->loadModel('IncubatorCapitalSubsidyPhaseThree');
        $search_condition = array();
        if (!empty($this->request->getQuery('reference_number'))) {
            $reference_number = trim($this->request->getQuery('reference_number'));
            $this->set('reference_number', $reference_number); 
            $search_condition[] = "IncubatorCapitalSubsidyPhaseThree.reference_number like '%" . $reference_number . "%'";
        }
        if (!empty($this->request->getQuery('incubator_name'))) {
            $incubator_name = trim($this->request->getQuery('incubator_name'));
            $this->set('incubator_name', $incubator_name); 
            $search_condition[] = "IncubatorCapitalSubsidyPhaseThree.incubator_name like '%" . $incubator_name . "%'";
        }        
        if (!empty($this->request->getQuery('registration_number'))) {
            $registration_number = trim($this->request->getQuery('registration_number'));
            $this->set('registration_number', $registration_number); 
            $search_condition[] = "IncubatorCapitalSubsidyPhaseThree.registration_number like '%" . $registration_number . "%'";
        }
        if (!empty($this->request->getQuery('sanctioned_amount'))) {
            $sanctioned_amount = trim($this->request->getQuery('sanctioned_amount'));
            $this->set('sanctioned_amount', $sanctioned_amount); 
            $search_condition[] = "IncubatorCapitalSubsidyPhaseThree.sanctioned_amount like '%" . $sanctioned_amount . "%'";
        }
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        $query = $this->IncubatorCapitalSubsidyPhaseThree->find()->contain(['Incubators','ApplicationStatus'])->order(['IncubatorCapitalSubsidyPhaseThree.id'=>'DESC'])->where(['application_stage_id'=>2,$searchString]);
        $applications = $this->paginate($query);
        $this->set(compact('applications'));
    }

    public function capitalSubsidyPhaseThreeView($id='')
    {
        $this->loadModel('IncubatorCapitalSubsidyPhaseThree');
        $id = base64_decode($id);
        $application = $this->IncubatorCapitalSubsidyPhaseThree->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'capitalSubsidyPhaseThreeList']);
        }
        $capitalSubsidyThree = $this->IncubatorCapitalSubsidyPhaseThree->get($id, ['contain' => ['Incubators','ApplicationStatus','Designations']]);
        $this->set(compact('capitalSubsidyThree'));
    }

    public function capitalSubsidyPhaseThreeEdit($id='')
    {
        $id = base64_decode($id);
        $this->loadModel('IncubatorCapitalSubsidyPhaseThree');
        $application = $this->IncubatorCapitalSubsidyPhaseThree->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'capitalSubsidyPhaseThreeList']);
        }
        $capitalSubsidyThree = $this->IncubatorCapitalSubsidyPhaseThree->get($id);
        if($this->request->is(['post','put'])){
            $data = $this->request->getData();
            
            $capitalSubsidyThree->screening_committee_comment = $data['screening_committee_comment'];
            $capitalSubsidyThree->screening_committee_date =  date('Y-m-d H:i:s');
            if(!empty($data['approve'])){
                $capitalSubsidyThree->application_status_id = 4;
                $capitalSubsidyThree->application_stage_id  = 3;
            }elseif(!empty($data['reject'])){
                $capitalSubsidyThree->application_status_id = 7;
            }
            $capitalSubsidyThree->updated = date('Y-m-d H:i:s');
            if($this->IncubatorCapitalSubsidyPhaseThree->save($capitalSubsidyThree)){
                $this->Flash->success(__('You have successfully updated the status.'));
                return $this->redirect(['action' => 'capitalSubsidyPhaseThreeList']);
            }else{
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        }
        $this->set(compact('capitalSubsidyThree'));
    }
    

}