<?php
namespace App\Controller\Admin;

use App\Controller\Admin\AppController;
use Cake\Event\Event;
use Cake\Mailer\Email;
use Cake\ORM\TableRegistry;
use Cake\Error\Exceptions;
use Cake\I18n\Time;
use Cake\View\View;

/**
 * IncubatorsSteeringCommittee Controller
 *
 * @property \App\Model\Table\IncubatorsSteeringCommitteeTable $IncubatorsSteeringCommittee
 *
 * @method \App\Model\Entity\User[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class MentorsSteeringCommitteeController extends AppController
{
    private $form_of_entity = ['1'=>'Government', '2'=>'Private'];
    
    public function initialize()
    {
        parent::initialize();
        $this->Auth->allow(['captcha']);
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }
    
    public function index(){
        $this->loadModel('Mentors');

        $search_condition = array();
        $data = $this->Sanitize->clean($this->request->getQuery());
        if (!empty($data['reference_no'])) {
            $reference_no = trim($data['reference_no']);
            $this->set('reference_no', $reference_no); 
            $search_condition[] = "Mentors.reference_no like '%" . $reference_no . "%'";
        }
        if (!empty($data['mentor_name'])) {
            $mentor_name = trim($data['mentor_name']);
            $this->set('mentor_name', $mentor_name); 
            $search_condition[] = "Mentors.mentor_name like '%" . $mentor_name . "%'";
        }    

        if (!empty($data['certificate_no'])) {
            $certificate_no = trim($data['certificate_no']);
            $this->set('certificate_no', $certificate_no); 
            $search_condition[] = "Mentors.certificate_no like '%" . $certificate_no . "%'";
        }

        if (!empty($data['email_id'])) {
            $email_id = trim($data['email_id']);
            $this->set('email_id', $email_id); 
            $search_condition[] = "Mentors.email_id like '%" . $email_id . "%'";
        }
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        
        $query = $this->Mentors->find()->contain(['Users','Sectors','StartupSectors','ApplicationStatus'])->where(['mentor_stage_id'=>3])->order(['Mentors.id'=>'DESC'])->where([$searchString]);
        $applications = $this->paginate($query);
        $form_of_entity = $this->form_of_entity;
        $this->set(compact('applications', 'form_of_entity'));
    }

    public function update($id)
    {
        $id = base64_decode($id);
        $this->loadModel('Mentors');
        $application = $this->Mentors->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'index']);
        }
        $applications = $this->Mentors->get($id);
        if($this->request->is(['POST', 'PUT'])){
            $data = $this->request->getData();
            $applications = $this->Mentors->patchEntity($applications, $data);
            $applications->steering_committee_comment = $data['steering_committee_comment'];
            if(!empty($this->request->data['action'])){                
                $applications->application_status_id = 6;
                $applications->mentor_stage_id = 4;
                $applications->approval_date = date('Y-m-d');
                $applications->certificate_no = $this->generateCertificateNo($applications->id, $applications->form_of_entity);
            }elseif(!empty($this->request->data['reject'])){
                $applications->application_status_id = 7;
            }
			
            $applications->steering_remark_date = date('Y-m-d');
            if($data['steering_remark_doc']['name']!=''){
                $certificate = $this->uploadFiles('mentor', $data['steering_remark_doc']);
                $applications->steering_remark_doc = $certificate['filename'];
            }
			
            if($this->Mentors->save($applications)){
				
                if($applications->application_status_id == 6){
                    $this->recognitionCertificate($applications->id);
                }	
                if($data['action'] == 'Approve'){
                    /*startup_application_file_movements Table*/
                    $tableName 			= 'MentorApplicationFileMovements';
                    $application_id_columnName 	= 'mentors_application_id';
                    $startup_application_id 	= $id;
                    $comment			= $data['steering_committee_comment	'];
                    $current_with		= '';
                    $initiated_date		= $applications->created;
                    $panding_from		= date('Y-m-d');	

                    $this->fileMovement($tableName, $application_id_columnName, $startup_application_id, $current_with, $comment, $initiated_date, $panding_from, $data);
                }
                $this->Flash->success(__('You have successfully updated the status'));
                return $this->redirect(['action' => 'index']);
            }
        }
        $this->set(compact('applications'));
    }

   public function view($id)
    {
        $id = base64_decode($id);
        $this->loadModel('Mentors');
        $this->loadModel('MentorApplicationFileMovements');
        $application = $this->Mentors->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'index']);
        }
        $startupApplication = $this->Mentors->get($id, ['contain' => ['Users','Sectors','StartupSectors','ApplicationStatus']]);
		
        $mentorApplicationFileMovements = $this->MentorApplicationFileMovements->find('all')->where(['MentorApplicationFileMovements.mentors_application_id '=>$startupApplication->id])->toArray();
        //echo "<pre>";print_r($incubatorApplication);exit;
        $this->set(compact('startupApplication', 'mentorApplicationFileMovements'));
    }

    public function generateCertificateNo($id, $form_of_entity)
    {
        $string = '';
        $string.= 'SUH/'.date('Y')."/";
        $string.= str_pad(($id), 5, 0, STR_PAD_LEFT);
        if($form_of_entity==1){
            $string.="/G";
        }else if($form_of_entity==2){
            $string.="/P";
        }
        return $string;
    }

    public function recognitionCertificate($application_id)
    {
        $this->loadModel('Mentors');
        $details = $this->Mentors->find()->where(['id'=>$application_id])->first();
        $view = new View($this->request, $this->response, null);
        $view->viewPath = 'Admin/MentorsSteeringCommittee';
        $view->layout = 'ajax';
        $view->set(compact('details'));
        $content = $view->render('recognition_certificate'); 
        $filename = $this->CreateCertificate($content, $details['certificate_no']);
        return $filename;
    }


    public function recurringExpenseList()
    {
        $this->loadModel('IncubatorRecurringExpenses');
        $search_condition = array();
        if (!empty($this->request->getQuery('reference_number'))) {
            $reference_number = trim($this->request->getQuery('reference_number'));
            $this->set('reference_number', $reference_number); 
            $search_condition[] = "IncubatorRecurringExpenses.reference_number like '%" . $reference_number . "%'";
        }
        if (!empty($this->request->getQuery('incubator_name'))) {
            $incubator_name = trim($this->request->getQuery('incubator_name'));
            $this->set('incubator_name', $incubator_name); 
            $search_condition[] = "IncubatorRecurringExpenses.incubator_name like '%" . $incubator_name . "%'";
        }    

        if (!empty($this->request->getQuery('registration_number'))) {
            $registration_number = trim($this->request->getQuery('registration_number'));
            $this->set('registration_number', $registration_number); 
            $search_condition[] = "IncubatorRecurringExpenses.registration_number like '%" . $registration_number . "%'";
        }

        if (!empty($this->request->getQuery('actual_expense'))) {
            $actual_expense = trim($this->request->getQuery('actual_expense'));
            $this->set('actual_expense', $actual_expense); 
            $search_condition[] = "IncubatorRecurringExpenses.actual_expense like '%" . $actual_expense . "%'";
        }
        
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        $query = $this->IncubatorRecurringExpenses->find()->contain(['Incubators','Designations','ApplicationStatus'])->order(['IncubatorRecurringExpenses.id'=>'DESC'])->where(['application_stage_id'=>3,$searchString]);
        $applications = $this->paginate($query);
        $this->set(compact('applications'));
    }

    public function recurringExpenseView($id='')
    {
        $this->loadModel('IncubatorRecurringExpenses');
        $id = base64_decode($id);
        $application = $this->IncubatorRecurringExpenses->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'recurringExpenseList']);
        }
        $incubatorRecurringExpense = $this->IncubatorRecurringExpenses->get($id, ['contain' => ['Incubators','ApplicationStatus','Designations']]);
        $this->set(compact('incubatorRecurringExpense'));
    }

    public function recurringExpenseEdit($id='')
    {
        $id = base64_decode($id);
        $this->loadModel('IncubatorRecurringExpenses');
        $application = $this->IncubatorRecurringExpenses->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'recurringExpenseList']);
        }
        $incubatorRecurringExpense = $this->IncubatorRecurringExpenses->get($id);
        if($this->request->is(['post','put'])){
            $data = $this->request->getData();
            
            $incubatorRecurringExpense->steering_committee_comment = $data['steering_committee_comment'];
            $incubatorRecurringExpense->approval_date =  date('Y-m-d H:i:s');
            if(!empty($data['approve'])){
                $incubatorRecurringExpense->sanction_amount = $data['sanction_amount'];
                $incubatorRecurringExpense->application_status_id = 6;
                $incubatorRecurringExpense->application_stage_id  = 4;
                $incubatorRecurringExpense->application_number = $this->recurringExpenseApplicationNo();
            }elseif(!empty($data['reject'])){
                $incubatorRecurringExpense->application_status_id = 7;
            }
            $incubatorRecurringExpense->updated = date('Y-m-d H:i:s');
            if($this->IncubatorRecurringExpenses->save($incubatorRecurringExpense)){
                if($incubatorRecurringExpense->application_status_id == 6){
                    $this->recurringCertificate($incubatorRecurringExpense->id);
                }
                $this->Flash->success(__('You have successfully updated the status.'));
                return $this->redirect(['action' => 'recurringExpenseList']);
            }else{
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        }
        $this->set(compact('incubatorRecurringExpense'));
    }

    public function recurringCertificate($application_id)
    {
        $this->loadModel('IncubatorRecurringExpenses');
        $details = $this->IncubatorRecurringExpenses->find()->where(['IncubatorRecurringExpenses.id'=>$application_id])->contain(['Incubators'])->first();
        $view = new View($this->request, $this->response, null);
        $view->viewPath = 'Admin/IncubatorsSteeringCommittee';
        $view->layout = 'ajax';
        $view->set(compact('details'));
        $content = $view->render('recurring_certificate');
        $filename = $this->CreateCertificate($content, $details['application_number']);
        return $filename;
    }

    public function recurringExpenseApplicationNo()
    {
        $this->loadModel('IncubatorRecurringExpenses');
        $last_val = $this->IncubatorRecurringExpenses->find()->where(['application_stage_id'=>4])->count();
        $string = '';
        $string.= 'RE/'.date('dmy').'/';
        $string.= str_pad(($last_val+1), 6, 0, STR_PAD_LEFT);
        return $string;
    }


    public function compititionAssistanceList()
    {
        $this->loadModel('IncubatorCompititionAssistances');
        $search_condition = array();
        if (!empty($this->request->getQuery('reference_number'))) {
            $reference_number = trim($this->request->getQuery('reference_number'));
            $this->set('reference_number', $reference_number); 
            $search_condition[] = "IncubatorCompititionAssistances.reference_number like '%" . $reference_number . "%'";
        }
        if (!empty($this->request->getQuery('incubator_name'))) {
            $incubator_name = trim($this->request->getQuery('incubator_name'));
            $this->set('incubator_name', $incubator_name); 
            $search_condition[] = "IncubatorCompititionAssistances.incubator_name like '%" . $incubator_name . "%'";
        }    

        if (!empty($this->request->getQuery('registration_number'))) {
            $registration_number = trim($this->request->getQuery('registration_number'));
            $this->set('registration_number', $registration_number); 
            $search_condition[] = "IncubatorCompititionAssistances.registration_number like '%" . $registration_number . "%'";
        }

        if (!empty($this->request->getQuery('assistance_amount'))) {
            $assistance_amount = trim($this->request->getQuery('assistance_amount'));
            $this->set('assistance_amount', $assistance_amount); 
            $search_condition[] = "IncubatorCompititionAssistances.assistance_amount like '%" . $assistance_amount . "%'";
        }
        
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        $query = $this->IncubatorCompititionAssistances->find()->contain(['Incubators','Designations','ApplicationStatus'])->order(['IncubatorCompititionAssistances.id'=>'DESC'])->where(['application_stage_id'=>3,$searchString]);
        $applications = $this->paginate($query);
        $this->set(compact('applications'));
    }

    public function compititionAssistanceView($id='')
    {
        $this->loadModel('IncubatorCompititionAssistances');
        $id = base64_decode($id);
        $application = $this->IncubatorCompititionAssistances->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'compititionAssistanceList']);
        }
        $incubatorCompititionAssistance = $this->IncubatorCompititionAssistances->get($id, ['contain' => ['Incubators','ApplicationStatus','Designations']]);
        $this->set(compact('incubatorCompititionAssistance'));
    }

    public function compititionAssistanceEdit($id='')
    {
        $id = base64_decode($id);
        $this->loadModel('IncubatorCompititionAssistances');
        $application = $this->IncubatorCompititionAssistances->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'compititionAssistanceList']);
        }
        $incubatorcompititionAssistance = $this->IncubatorCompititionAssistances->get($id);
        if($this->request->is(['post','put'])){
            $data = $this->request->getData();
            
            $incubatorcompititionAssistance->steering_committee_comment = $data['steering_committee_comment'];
            $incubatorcompititionAssistance->approval_date =  date('Y-m-d H:i:s');

            if(!empty($data['approve'])){
                $incubatorcompititionAssistance->sanction_amount = $data['sanction_amount'];
                $incubatorcompititionAssistance->application_status_id = 6;
                $incubatorcompititionAssistance->application_stage_id  = 4;
                $incubatorcompititionAssistance->application_number = $this->compititionAssistanceApplicationNo();
            }elseif(!empty($data['reject'])){
                $incubatorcompititionAssistance->application_status_id = 7;
            }
            $incubatorcompititionAssistance->updated = date('Y-m-d H:i:s');
            if($this->IncubatorCompititionAssistances->save($incubatorcompititionAssistance)){
                if($incubatorcompititionAssistance->application_status_id == 6){
                    $this->compititionCertificate($incubatorcompititionAssistance->id);
                }
                $this->Flash->success(__('You have successfully updated the status.'));
                return $this->redirect(['action' => 'compititionAssistanceList']);
            }else{
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        }
        $this->set(compact('incubatorcompititionAssistance'));
    }

    public function compititionCertificate($application_id)
    {
        $this->loadModel('IncubatorCompititionAssistances');
        $details = $this->IncubatorCompititionAssistances->find()->where(['IncubatorCompititionAssistances.id'=>$application_id])->contain(['Incubators'])->first();
        $view = new View($this->request, $this->response, null);
        $view->viewPath = 'Admin/IncubatorsSteeringCommittee';
        $view->layout = 'ajax';
        $view->set(compact('details'));
        $content = $view->render('compitition_certificate');
        $filename = $this->CreateCertificate($content, $details['application_number']);
        return $filename;
    }

    public function compititionAssistanceApplicationNo()
    {
        $this->loadModel('IncubatorCompititionAssistances');
        $last_val = $this->IncubatorCompititionAssistances->find()->where(['application_stage_id'=>4])->count();
        $string = '';
        $string.= 'CA/'.date('dmy').'/';
        $string.= str_pad(($last_val+1), 6, 0, STR_PAD_LEFT);
        return $string;
    }


    public function fairExhibitionList()
    {
        $this->loadModel('IncubatorFairExhibitions');
        $search_condition = array();
        if (!empty($this->request->getQuery('reference_number'))) {
            $reference_number = trim($this->request->getQuery('reference_number'));
            $this->set('reference_number', $reference_number); 
            $search_condition[] = "IncubatorFairExhibitions.reference_number like '%" . $reference_number . "%'";
        }
        if (!empty($this->request->getQuery('incubator_name'))) {
            $incubator_name = trim($this->request->getQuery('incubator_name'));
            $this->set('incubator_name', $incubator_name); 
            $search_condition[] = "IncubatorFairExhibitions.incubator_name like '%" . $incubator_name . "%'";
        }
        if (!empty($this->request->getQuery('registration_number'))) {
            $registration_number = trim($this->request->getQuery('registration_number'));
            $this->set('registration_number', $registration_number); 
            $search_condition[] = "IncubatorFairExhibitions.registration_number like '%" . $registration_number . "%'";
        }
        if (!empty($this->request->getQuery('approval_letter_number'))) {
            $approval_letter_number = trim($this->request->getQuery('approval_letter_number'));
            $this->set('approval_letter_number', $approval_letter_number); 
            $search_condition[] = "IncubatorFairExhibitions.approval_letter_number like '%" . $approval_letter_number . "%'";
        }        
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        $query = $this->IncubatorFairExhibitions->find()->contain(['Incubators','ApplicationStatus'])->order(['IncubatorFairExhibitions.id'=>'DESC'])->where(['application_stage_id'=>3,$searchString]);
        $applications = $this->paginate($query);
        $this->set(compact('applications'));
    }

    public function fairExhibitionView($id='')
    {
        $this->loadModel('IncubatorFairExhibitions');
        $id = base64_decode($id);
        $application = $this->IncubatorFairExhibitions->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'fairExhibitionList']);
        }
        $incubatorFairExhibition = $this->IncubatorFairExhibitions->get($id, ['contain' => ['Incubators','ApplicationStatus']]);
        $this->set(compact('incubatorFairExhibition'));
    }

    public function fairExhibitionEdit($id='')
    {
        $id = base64_decode($id);
        $this->loadModel('IncubatorFairExhibitions');
        $application = $this->IncubatorFairExhibitions->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'fairExhibitionList']);
        }
        $incubatorfairExhibition = $this->IncubatorFairExhibitions->get($id);
        if($this->request->is(['post','put'])){
            $data = $this->request->getData();
            
            $incubatorfairExhibition->steering_committee_comment = $data['steering_committee_comment'];
            $incubatorfairExhibition->approval_date =  date('Y-m-d H:i:s');
            if(!empty($data['approve'])){
                $incubatorfairExhibition->sanction_amount = $data['sanction_amount'];
                $incubatorfairExhibition->application_status_id = 6;
                $incubatorfairExhibition->application_stage_id  = 4;
                $incubatorfairExhibition->application_number = $this->fairExhibitionApplicationNo();
            }elseif(!empty($data['reject'])){
                $incubatorfairExhibition->application_status_id = 7;
            }
            $incubatorfairExhibition->updated = date('Y-m-d H:i:s');
            if($this->IncubatorFairExhibitions->save($incubatorfairExhibition)){
                $this->Flash->success(__('You have successfully updated the status.'));
                return $this->redirect(['action' => 'fairExhibitionList']);
            }else{
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        }
        $this->set(compact('incubatorfairExhibition'));
    }


    public function fairExhibitionApplicationNo()
    {
        $this->loadModel('IncubatorFairExhibitions');
        $last_val = $this->IncubatorFairExhibitions->find()->where(['application_stage_id'=>4])->count();
        $string = '';
        $string.= 'FE/'.date('dmy').'/';
        $string.= str_pad(($last_val+1), 6, 0, STR_PAD_LEFT);
        return $string;
    }

    public function mentorTrainingList()
    {
        $this->loadModel('IncubatorMentorTrainings');
        $search_condition = array();
        if (!empty($this->request->getQuery('reference_number'))) {
            $reference_number = trim($this->request->getQuery('reference_number'));
            $this->set('reference_number', $reference_number); 
            $search_condition[] = "IncubatorMentorTrainings.reference_number like '%" . $reference_number . "%'";
        }
        if (!empty($this->request->getQuery('incubator_name'))) {
            $incubator_name = trim($this->request->getQuery('incubator_name'));
            $this->set('incubator_name', $incubator_name); 
            $search_condition[] = "IncubatorMentorTrainings.incubator_name like '%" . $incubator_name . "%'";
        }    

        if (!empty($this->request->getQuery('registration_number'))) {
            $registration_number = trim($this->request->getQuery('registration_number'));
            $this->set('registration_number', $registration_number); 
            $search_condition[] = "IncubatorMentorTrainings.registration_number like '%" . $registration_number . "%'";
        }

        if (!empty($this->request->getQuery('actual_expense'))) {
            $actual_expense = trim($this->request->getQuery('actual_expense'));
            $this->set('actual_expense', $actual_expense); 
            $search_condition[] = "IncubatorMentorTrainings.actual_expense like '%" . $actual_expense . "%'";
        }
        
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        $query = $this->IncubatorMentorTrainings->find()->contain(['Incubators','ApplicationStatus'])->order(['IncubatorMentorTrainings.id'=>'DESC'])->where(['application_stage_id'=>3,$searchString]);
        $applications = $this->paginate($query);
        $this->set(compact('applications'));
    }

    public function mentorTrainingView($id='')
    {
        $this->loadModel('IncubatorMentorTrainings');
        $id = base64_decode($id);
        $application = $this->IncubatorMentorTrainings->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'mentorTrainingList']);
        }
        $incubatorMentorTraining = $this->IncubatorMentorTrainings->get($id, ['contain' => ['Incubators','ApplicationStatus','Designations']]);
        $this->set(compact('incubatorMentorTraining'));
    }

    public function mentorTrainingEdit($id='')
    {
        $id = base64_decode($id);
        $this->loadModel('IncubatorMentorTrainings');
        $application = $this->IncubatorMentorTrainings->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'mentorTrainingList']);
        }
        $incubatorMentorTraining = $this->IncubatorMentorTrainings->get($id);
        if($this->request->is(['post','put'])){
            $data = $this->request->getData();
            $incubatorMentorTraining->steering_committee_comment = $data['steering_committee_comment'];
            $incubatorMentorTraining->approval_date = date('Y-m-d H:i:s');
            if(!empty($data['approve'])){
                $incubatorMentorTraining->sanction_amount = $data['sanction_amount'];
                $incubatorMentorTraining->application_status_id = 6;
                $incubatorMentorTraining->application_stage_id  = 4;
                $incubatorMentorTraining->application_number = $this->mentorTrainingApplicationNo();
            }elseif(!empty($data['reject'])){
                $incubatorMentorTraining->application_status_id = 7;
            }
            $incubatorMentorTraining->updated = date('Y-m-d H:i:s');
            if($this->IncubatorMentorTrainings->save($incubatorMentorTraining)){
                if($incubatorMentorTraining->application_status_id == 6){
                    $this->mentorCertificate($incubatorMentorTraining->id);
                }
                $this->Flash->success(__('You have successfully updated the status.'));
                return $this->redirect(['action' => 'mentorTrainingList']);
            }else{
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        }
        $this->set(compact('incubatorMentorTraining'));
    }

    public function mentorCertificate($application_id)
    {
        $this->loadModel('IncubatorMentorTrainings');
        $details = $this->IncubatorMentorTrainings->find()->where(['IncubatorMentorTrainings.id'=>$application_id])->contain(['Incubators'])->first();
        $view = new View($this->request, $this->response, null);
        $view->viewPath = 'Admin/IncubatorsSteeringCommittee';
        $view->layout = 'ajax';
        $view->set(compact('details'));
        $content = $view->render('mentor_certificate');
        $filename = $this->CreateCertificate($content, $details['application_number']);
        return $filename;
    }

    public function mentorTrainingApplicationNo()
    {
        $this->loadModel('IncubatorMentorTrainings');
        $last_val = $this->IncubatorMentorTrainings->find()->where(['application_stage_id'=>4])->count();
        $string = '';
        $string.= 'MT/'.date('dmy').'/';
        $string.= str_pad(($last_val+1), 6, 0, STR_PAD_LEFT);
        return $string;
    }

    
    public function rentalChargeExemptionList()
    {
        $this->loadModel('IncubatorRentalCharges');
        $search_condition = array();
        if (!empty($this->request->getQuery('reference_number'))) {
            $reference_number = trim($this->request->getQuery('reference_number'));
            $this->set('reference_number', $reference_number); 
            $search_condition[] = "IncubatorRentalCharges.reference_number like '%" . $reference_number . "%'";
        }
        if (!empty($this->request->getQuery('incubator_name'))) {
            $incubator_name = trim($this->request->getQuery('incubator_name'));
            $this->set('incubator_name', $incubator_name); 
            $search_condition[] = "IncubatorRentalCharges.incubator_name like '%" . $incubator_name . "%'";
        }    

        if (!empty($this->request->getQuery('registration_number'))) {
            $registration_number = trim($this->request->getQuery('registration_number'));
            $this->set('registration_number', $registration_number); 
            $search_condition[] = "IncubatorRentalCharges.registration_number like '%" . $registration_number . "%'";
        }

        if (!empty($this->request->getQuery('amount_incurred'))) {
            $amount_incurred = trim($this->request->getQuery('amount_incurred'));
            $this->set('amount_incurred', $amount_incurred); 
            $search_condition[] = "IncubatorRentalCharges.amount_incurred like '%" . $amount_incurred . "%'";
        }
        
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        $query = $this->IncubatorRentalCharges->find()->contain(['Incubators','ApplicationStatus'])->order(['IncubatorRentalCharges.id'=>'DESC'])->where(['application_stage_id'=>3,$searchString]);
        $applications = $this->paginate($query);
        $this->set(compact('applications'));
    }

    public function rentalChargeExemptionView($id='')
    {
        $this->loadModel('IncubatorRentalCharges');
        $id = base64_decode($id);
        $application = $this->IncubatorRentalCharges->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'rentalChargeExemptionList']);
        }
        $incubatorRentalCharge = $this->IncubatorRentalCharges->get($id, ['contain' => ['Incubators','ApplicationStatus','Designations']]);
        $this->set(compact('incubatorRentalCharge'));
    }

    public function rentalChargeExemptionEdit($id='')
    {
        $id = base64_decode($id);
        $this->loadModel('IncubatorRentalCharges');
        $application = $this->IncubatorRentalCharges->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'rentalChargeExemptionList']);
        }
        $incubatorRentalCharge = $this->IncubatorRentalCharges->get($id);
        if($this->request->is(['post','put'])){
            $data = $this->request->getData();
            
            $incubatorRentalCharge->steering_committee_comment = $data['steering_committee_comment'];
            $incubatorRentalCharge->approval_date =  date('Y-m-d H:i:s');
            if(!empty($data['approve'])){
                $incubatorRentalCharge->sanction_amount = $data['sanction_amount'];
                $incubatorRentalCharge->application_status_id = 6;
                $incubatorRentalCharge->application_stage_id  = 4;
                $incubatorRentalCharge->application_number = $this->rentalChargeApplicationNo();
            }elseif(!empty($data['reject'])){
                $incubatorRentalCharge->application_status_id = 7;
            }
            $incubatorRentalCharge->updated = date('Y-m-d H:i:s');
            if($this->IncubatorRentalCharges->save($incubatorRentalCharge)){
                if($incubatorRentalCharge->application_status_id == 6){
                    //$this->rentalChargeCertificate($incubatorRentalCharge->id);
                }
                $this->Flash->success(__('You have successfully updated the status.'));
                return $this->redirect(['action' => 'rentalChargeExemptionList']);
            }else{
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        }
        $this->set(compact('incubatorRentalCharge'));
    }

    public function rentalChargeApplicationNo()
    {
        $this->loadModel('IncubatorRentalCharges');
        $last_val = $this->IncubatorRentalCharges->find()->where(['application_stage_id'=>4])->count();
        $string = '';
        $string.= 'RC/'.date('dmy').'/';
        $string.= str_pad(($last_val+1), 6, 0, STR_PAD_LEFT);
        return $string;
    }

    public function rentalChargeCertificate($application_id)
    {
        $this->loadModel('IncubatorRentalCharges');
        $details = $this->IncubatorRentalCharges->find()->where(['IncubatorRentalCharges.id'=>$application_id])->contain(['Incubators'])->first();
        $view = new View($this->request, $this->response, null);
        $view->viewPath = 'Admin/IncubatorsSteeringCommittee';
        $view->layout = 'ajax';
        $view->set(compact('details'));
        $content = $view->render('rental_charge_certificate');
        $filename = $this->CreateCertificate($content, $details['application_number']);
        return $filename;
    }

    public function stampDutyRegistrationList()
    {
        $this->loadModel('IncubatorStampDuties');
        $search_condition = array();
        if (!empty($this->request->getQuery('reference_number'))) {
            $reference_number = trim($this->request->getQuery('reference_number'));
            $this->set('reference_number', $reference_number); 
            $search_condition[] = "IncubatorStampDuties.reference_number like '%" . $reference_number . "%'";
        }
        if (!empty($this->request->getQuery('incubator_name'))) {
            $incubator_name = trim($this->request->getQuery('incubator_name'));
            $this->set('incubator_name', $incubator_name); 
            $search_condition[] = "IncubatorStampDuties.incubator_name like '%" . $incubator_name . "%'";
        }    

        if (!empty($this->request->getQuery('registration_number'))) {
            $registration_number = trim($this->request->getQuery('registration_number'));
            $this->set('registration_number', $registration_number); 
            $search_condition[] = "IncubatorStampDuties.registration_number like '%" . $registration_number . "%'";
        }

        if (!empty($this->request->getQuery('amount_of_stamp_duty'))) {
            $amount_of_stamp_duty = trim($this->request->getQuery('amount_of_stamp_duty'));
            $this->set('amount_of_stamp_duty', $amount_of_stamp_duty); 
            $search_condition[] = "IncubatorStampDuties.amount_of_stamp_duty like '%" . $amount_of_stamp_duty . "%'";
        }
        
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        $query = $this->IncubatorStampDuties->find()->contain(['Incubators','ApplicationStatus'])->order(['IncubatorStampDuties.id'=>'DESC'])->where(['application_stage_id'=>3,$searchString]);
        $applications = $this->paginate($query);
        $this->set(compact('applications'));
    }

    public function stampDutyRegistrationView($id='')
    {
        $this->loadModel('IncubatorStampDuties');
        $id = base64_decode($id);
        $application = $this->IncubatorStampDuties->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'stampDutyRegistrationList']);
        }
        $incubatorStampDuty = $this->IncubatorStampDuties->get($id, ['contain' => ['Incubators','ApplicationStatus','Designations']]);
        $this->set(compact('incubatorStampDuty'));
    }

    public function stampDutyRegistrationEdit($id='')
    {
        $id = base64_decode($id);
        $this->loadModel('IncubatorStampDuties');
        $application = $this->IncubatorStampDuties->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'stampDutyRegistrationList']);
        }
        $incubatorStampDuty = $this->IncubatorStampDuties->get($id);
        if($this->request->is(['post','put'])){
            $data = $this->request->getData();
            
            $incubatorStampDuty->steering_committee_comment = $data['steering_committee_comment'];
            $incubatorStampDuty->approval_date =  date('Y-m-d H:i:s');
            if(!empty($data['approve'])){
                $incubatorStampDuty->sanction_amount = $data['sanction_amount'];
                $incubatorStampDuty->application_status_id = 6;
                $incubatorStampDuty->application_stage_id  = 4;
                $incubatorStampDuty->application_number = $this->stampDutyApplicationNo();
            }elseif(!empty($data['reject'])){
                $incubatorStampDuty->application_status_id = 7;
            }
            $incubatorStampDuty->updated = date('Y-m-d H:i:s');
            if($this->IncubatorStampDuties->save($incubatorStampDuty)){
                if($incubatorStampDuty->application_status_id == 6){
                    //$this->stampDutyCertificate($incubatorStampDuty->id);
                }
                $this->Flash->success(__('You have successfully updated the status.'));
                return $this->redirect(['action' => 'stampDutyRegistrationList']);
            }else{
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        }
        $this->set(compact('incubatorStampDuty'));
    }

    public function stampDutyApplicationNo()
    {
        $this->loadModel('IncubatorStampDuties');
        $last_val = $this->IncubatorStampDuties->find()->where(['application_stage_id'=>4])->count();
        $string = '';
        $string.= 'SD/'.date('dmy').'/';
        $string.= str_pad(($last_val+1), 6, 0, STR_PAD_LEFT);
        return $string;
    }

    public function stampDutyCertificate($application_id)
    {
        $this->loadModel('IncubatorStampDuties');
        $details = $this->IncubatorStampDuties->find()->where(['IncubatorStampDuties.id'=>$application_id])->contain(['Incubators'])->first();
        $view = new View($this->request, $this->response, null);
        $view->viewPath = 'Admin/IncubatorsSteeringCommittee';
        $view->layout = 'ajax';
        $view->set(compact('details'));
        $content = $view->render('stamp_duty_certificate');
        $filename = $this->CreateCertificate($content, $details['application_number']);
        return $filename;
    }

    public function preApprovalInFairExhibitionList()
    {
        $this->loadModel('IncubatorPreApprovalFairExhibitions');
        $search_condition = array();
        if (!empty($this->request->getQuery('reference_number'))) {
            $reference_number = trim($this->request->getQuery('reference_number'));
            $this->set('reference_number', $reference_number); 
            $search_condition[] = "IncubatorPreApprovalFairExhibitions.reference_number like '%" . $reference_number . "%'";
        }
        if (!empty($this->request->getQuery('incubator_name'))) {
            $incubator_name = trim($this->request->getQuery('incubator_name'));
            $this->set('incubator_name', $incubator_name); 
            $search_condition[] = "IncubatorPreApprovalFairExhibitions.incubator_name like '%" . $incubator_name . "%'";
        }    

        if (!empty($this->request->getQuery('registration_number'))) {
            $registration_number = trim($this->request->getQuery('registration_number'));
            $this->set('registration_number', $registration_number); 
            $search_condition[] = "IncubatorPreApprovalFairExhibitions.registration_number like '%" . $registration_number . "%'";
        }

        if (!empty($this->request->getQuery('assistance_amount'))) {
            $assistance_amount = trim($this->request->getQuery('assistance_amount'));
            $this->set('assistance_amount', $assistance_amount); 
            $search_condition[] = "IncubatorPreApprovalFairExhibitions.assistance_amount like '%" . $assistance_amount . "%'";
        }
        
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        $query = $this->IncubatorPreApprovalFairExhibitions->find()->contain(['Incubators','ApplicationStatus'])->order(['IncubatorPreApprovalFairExhibitions.id'=>'DESC'])->where(['application_stage_id'=>3,$searchString]);
        $applications = $this->paginate($query);
        $this->set(compact('applications'));
    }

    public function preApprovalInFairExhibitionView($id='')
    {
        $this->loadModel('IncubatorPreApprovalFairExhibitions');
        $id = base64_decode($id);
        $application = $this->IncubatorPreApprovalFairExhibitions->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'preApprovalInFairExhibitionList']);
        }
        $preApprovalFairExhibition = $this->IncubatorPreApprovalFairExhibitions->get($id, ['contain' => ['Incubators','ApplicationStatus','Designations']]);
        $this->set(compact('preApprovalFairExhibition'));
    }

    public function preApprovalInFairExhibitionEdit($id='')
    {
        $id = base64_decode($id);
        $this->loadModel('IncubatorPreApprovalFairExhibitions');
        $application = $this->IncubatorPreApprovalFairExhibitions->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'preApprovalInFairExhibitionList']);
        }
        $preApprovalFairExhibition = $this->IncubatorPreApprovalFairExhibitions->get($id);
        if($this->request->is(['post','put'])){
            $data = $this->request->getData();
            
            $preApprovalFairExhibition->steering_committee_comment = $data['steering_committee_comment'];
            $preApprovalFairExhibition->approval_date =  date('Y-m-d H:i:s');
            if(!empty($data['approve'])){
                $preApprovalFairExhibition->sanction_amount = $data['sanction_amount'];
                $preApprovalFairExhibition->application_status_id = 6;
                $preApprovalFairExhibition->application_stage_id  = 4;
                $preApprovalFairExhibition->application_number = $this->preApprovalApplicationNo();
            }elseif(!empty($data['reject'])){
                $preApprovalFairExhibition->application_status_id = 7;
            }
            $preApprovalFairExhibition->updated = date('Y-m-d H:i:s');
            if($this->IncubatorPreApprovalFairExhibitions->save($preApprovalFairExhibition)){
                if($preApprovalFairExhibition->application_status_id == 6){
                    //$this->preApprovalCertificate($preApprovalFairExhibition->id);
                }
                $this->Flash->success(__('You have successfully updated the status.'));
                return $this->redirect(['action' => 'preApprovalInFairExhibitionList']);
            }else{
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        }
        $this->set(compact('preApprovalFairExhibition'));
    }

    public function preApprovalApplicationNo()
    {
        $this->loadModel('IncubatorPreApprovalFairExhibitions');
        $last_val = $this->IncubatorPreApprovalFairExhibitions->find()->where(['application_stage_id'=>4])->count();
        $string = '';
        $string.= 'PA/'.date('dmy').'/';
        $string.= str_pad(($last_val+1), 6, 0, STR_PAD_LEFT);
        return $string;
    }

    public function preApprovalCertificate($application_id)
    {
        $this->loadModel('IncubatorPreApprovalFairExhibitions');
        $details = $this->IncubatorPreApprovalFairExhibitions->find()->where(['IncubatorPreApprovalFairExhibitions.id'=>$application_id])->contain(['Incubators'])->first();
        $view = new View($this->request, $this->response, null);
        $view->viewPath = 'Admin/IncubatorsSteeringCommittee';
        $view->layout = 'ajax';
        $view->set(compact('details'));
        $content = $view->render('pre_approval_fair');
        $filename = $this->CreateCertificate($content, $details['application_number']);
        return $filename;
    }

    public function claimingAssistanceInFairExhibitionList()
    {
        $this->loadModel('IncubatorClaimingAssistanceFairExhibitions');
        $search_condition = array();
        if (!empty($this->request->getQuery('reference_number'))) {
            $reference_number = trim($this->request->getQuery('reference_number'));
            $this->set('reference_number', $reference_number); 
            $search_condition[] = "IncubatorClaimingAssistanceFairExhibitions.reference_number like '%" . $reference_number . "%'";
        }
        if (!empty($this->request->getQuery('incubator_name'))) {
            $incubator_name = trim($this->request->getQuery('incubator_name'));
            $this->set('incubator_name', $incubator_name); 
            $search_condition[] = "IncubatorClaimingAssistanceFairExhibitions.incubator_name like '%" . $incubator_name . "%'";
        }        
        if (!empty($this->request->getQuery('registration_number'))) {
            $registration_number = trim($this->request->getQuery('registration_number'));
            $this->set('registration_number', $registration_number); 
            $search_condition[] = "IncubatorClaimingAssistanceFairExhibitions.registration_number like '%" . $registration_number . "%'";
        }
        if (!empty($this->request->getQuery('letter_no_of_approval'))) {
            $letter_no_of_approval = trim($this->request->getQuery('letter_no_of_approval'));
            $this->set('letter_no_of_approval', $letter_no_of_approval); 
            $search_condition[] = "IncubatorClaimingAssistanceFairExhibitions.letter_no_of_approval like '%" . $letter_no_of_approval . "%'";
        }        
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        $query = $this->IncubatorClaimingAssistanceFairExhibitions->find()->contain(['Incubators','ApplicationStatus'])->order(['IncubatorClaimingAssistanceFairExhibitions.id'=>'DESC'])->where(['application_stage_id'=>3,$searchString]);
        $applications = $this->paginate($query);
        $this->set(compact('applications'));
    }

    public function claimingAssistanceInFairExhibitionView($id='')
    {
        $this->loadModel('IncubatorClaimingAssistanceFairExhibitions');
        $id = base64_decode($id);
        $application = $this->IncubatorClaimingAssistanceFairExhibitions->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'claimingAssistanceInFairExhibitionList']);
        }
        $claimingAssistanceFairExhibition = $this->IncubatorClaimingAssistanceFairExhibitions->get($id, ['contain' => ['Incubators','ApplicationStatus','Designations']]);
        $this->set(compact('claimingAssistanceFairExhibition'));
    }

    public function claimingAssistanceInFairExhibitionEdit($id='')
    {
        $id = base64_decode($id);
        $this->loadModel('IncubatorClaimingAssistanceFairExhibitions');
        $application = $this->IncubatorClaimingAssistanceFairExhibitions->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'claimingAssistanceInFairExhibitionList']);
        }
        $claimingAssistanceFairExhibition = $this->IncubatorClaimingAssistanceFairExhibitions->get($id);
        if($this->request->is(['post','put'])){
            $data = $this->request->getData();
            
            $claimingAssistanceFairExhibition->steering_committee_comment = $data['steering_committee_comment'];
            $claimingAssistanceFairExhibition->approval_date =  date('Y-m-d H:i:s');
            if(!empty($data['approve'])){
                $claimingAssistanceFairExhibition->sanction_amount = $data['sanction_amount'];
                $claimingAssistanceFairExhibition->application_status_id = 6;
                $claimingAssistanceFairExhibition->application_stage_id  = 4;
                $claimingAssistanceFairExhibition->application_number = $this->claimingAssistanceApplicationNo();
            }elseif(!empty($data['reject'])){
                $claimingAssistanceFairExhibition->application_status_id = 7;
            }
            $claimingAssistanceFairExhibition->updated = date('Y-m-d H:i:s');
            if($this->IncubatorClaimingAssistanceFairExhibitions->save($claimingAssistanceFairExhibition)){
                if($claimingAssistanceFairExhibition->application_status_id == 6){
                    //$this->claimingAssistanceCertificate($claimingAssistanceFairExhibition->id);
                }
                $this->Flash->success(__('You have successfully updated the status.'));
                return $this->redirect(['action' => 'claimingAssistanceInFairExhibitionList']);
            }else{
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        }
        $this->set(compact('claimingAssistanceFairExhibition'));
    }

    public function claimingAssistanceApplicationNo()
    {
        $this->loadModel('IncubatorClaimingAssistanceFairExhibitions');
        $last_val = $this->IncubatorClaimingAssistanceFairExhibitions->find()->where(['application_stage_id'=>4])->count();
        $string = '';
        $string.= 'SD/'.date('dmy').'/';
        $string.= str_pad(($last_val+1), 6, 0, STR_PAD_LEFT);
        return $string;
    }

    public function claimingAssistanceCertificate($application_id)
    {
        $this->loadModel('IncubatorClaimingAssistanceFairExhibitions');
        $details = $this->IncubatorClaimingAssistanceFairExhibitions->find()->where(['IncubatorClaimingAssistanceFairExhibitions.id'=>$application_id])->contain(['Incubators'])->first();
        $view = new View($this->request, $this->response, null);
        $view->viewPath = 'Admin/IncubatorsSteeringCommittee';
        $view->layout = 'ajax';
        $view->set(compact('details'));
        $content = $view->render('claiming_fair');
        $filename = $this->CreateCertificate($content, $details['application_number']);
        return $filename;
    }


    public function capitalSubsidyPhaseOneList()
    {
        $this->loadModel('IncubatorCapitalSubsidyPhaseOne');
        $search_condition = array();
        if (!empty($this->request->getQuery('reference_number'))) {
            $reference_number = trim($this->request->getQuery('reference_number'));
            $this->set('reference_number', $reference_number); 
            $search_condition[] = "IncubatorCapitalSubsidyPhaseOne.reference_number like '%" . $reference_number . "%'";
        }
        if (!empty($this->request->getQuery('incubator_name'))) {
            $incubator_name = trim($this->request->getQuery('incubator_name'));
            $this->set('incubator_name', $incubator_name); 
            $search_condition[] = "IncubatorCapitalSubsidyPhaseOne.incubator_name like '%" . $incubator_name . "%'";
        }        
        if (!empty($this->request->getQuery('registration_number'))) {
            $registration_number = trim($this->request->getQuery('registration_number'));
            $this->set('registration_number', $registration_number); 
            $search_condition[] = "IncubatorCapitalSubsidyPhaseOne.registration_number like '%" . $registration_number . "%'";
        }
        if (!empty($this->request->getQuery('sanctioned_amount'))) {
            $sanctioned_amount = trim($this->request->getQuery('sanctioned_amount'));
            $this->set('sanctioned_amount', $sanctioned_amount); 
            $search_condition[] = "IncubatorCapitalSubsidyPhaseOne.sanctioned_amount like '%" . $sanctioned_amount . "%'";
        }
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        $query = $this->IncubatorCapitalSubsidyPhaseOne->find()->contain(['Incubators','ApplicationStatus'])->order(['IncubatorCapitalSubsidyPhaseOne.id'=>'DESC'])->where(['application_stage_id'=>3,$searchString]);
        $applications = $this->paginate($query);
        $this->set(compact('applications'));
    }

    public function capitalSubsidyPhaseOneView($id='')
    {
        $this->loadModel('IncubatorCapitalSubsidyPhaseOne');
        $id = base64_decode($id);
        $application = $this->IncubatorCapitalSubsidyPhaseOne->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'capitalSubsidyPhaseOneList']);
        }
        $capitalSubsidyOne = $this->IncubatorCapitalSubsidyPhaseOne->get($id, ['contain' => ['Incubators','ApplicationStatus','Designations']]);
        $this->set(compact('capitalSubsidyOne'));
    }

    public function capitalSubsidyPhaseOneEdit($id='')
    {
        $id = base64_decode($id);
        $this->loadModel('IncubatorCapitalSubsidyPhaseOne');
        $application = $this->IncubatorCapitalSubsidyPhaseOne->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'capitalSubsidyPhaseOneList']);
        }
        $capitalSubsidyOne = $this->IncubatorCapitalSubsidyPhaseOne->get($id);
        if($this->request->is(['post','put'])){
            $data = $this->request->getData();
            
            $capitalSubsidyOne->steering_committee_comment = $data['steering_committee_comment'];
            $capitalSubsidyOne->approval_date =  date('Y-m-d H:i:s');
            if(!empty($data['approve'])){
                $capitalSubsidyOne->application_status_id = 6;
                $capitalSubsidyOne->application_stage_id  = 4;
                $capitalSubsidyOne->sanction_amount = $data['sanction_amount'];
                $capitalSubsidyOne->application_number = $this->capitalSubsidyPhaseOneApplicationNo();
            }elseif(!empty($data['reject'])){
                $capitalSubsidyOne->application_status_id = 7;
            }
            $capitalSubsidyOne->updated = date('Y-m-d H:i:s');
            if($this->IncubatorCapitalSubsidyPhaseOne->save($capitalSubsidyOne)){
                if($capitalSubsidyOne->application_status_id == 6){
                    //$this->capitalSubsidyPhaseOneCertificate($capitalSubsidyOne->id);
                }
                $this->Flash->success(__('You have successfully updated the status.'));
                return $this->redirect(['action' => 'capitalSubsidyPhaseOneList']);
            }else{
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        }
        $this->set(compact('capitalSubsidyOne'));
    }

    public function capitalSubsidyPhaseOneApplicationNo()
    {
        $this->loadModel('IncubatorCapitalSubsidyPhaseOne');
        $last_val = $this->IncubatorCapitalSubsidyPhaseOne->find()->where(['application_stage_id'=>4])->count();
        $string = '';
        $string.= 'CS1/'.date('dmy').'/';
        $string.= str_pad(($last_val+1), 6, 0, STR_PAD_LEFT);
        return $string;
    }

    public function capitalSubsidyPhaseOneCertificate($application_id)
    {
        $this->loadModel('IncubatorCapitalSubsidyPhaseOne');
        $details = $this->IncubatorCapitalSubsidyPhaseOne->find()->where(['IncubatorCapitalSubsidyPhaseOne.id'=>$application_id])->contain(['Incubators'])->first();
        $view = new View($this->request, $this->response, null);
        $view->viewPath = 'Admin/IncubatorsSteeringCommittee';
        $view->layout = 'ajax';
        $view->set(compact('details'));
        $content = $view->render('subsidy_phase_one');
        $filename = $this->CreateCertificate($content, $details['application_number']);
        return $filename;
    }

    public function capitalSubsidyPhaseTwoList()
    {
        $this->loadModel('IncubatorCapitalSubsidyPhaseTwo');
        $search_condition = array();
        if (!empty($this->request->getQuery('reference_number'))) {
            $reference_number = trim($this->request->getQuery('reference_number'));
            $this->set('reference_number', $reference_number); 
            $search_condition[] = "IncubatorCapitalSubsidyPhaseTwo.reference_number like '%" . $reference_number . "%'";
        }
        if (!empty($this->request->getQuery('incubator_name'))) {
            $incubator_name = trim($this->request->getQuery('incubator_name'));
            $this->set('incubator_name', $incubator_name); 
            $search_condition[] = "IncubatorCapitalSubsidyPhaseTwo.incubator_name like '%" . $incubator_name . "%'";
        }        
        if (!empty($this->request->getQuery('registration_number'))) {
            $registration_number = trim($this->request->getQuery('registration_number'));
            $this->set('registration_number', $registration_number); 
            $search_condition[] = "IncubatorCapitalSubsidyPhaseTwo.registration_number like '%" . $registration_number . "%'";
        }
        if (!empty($this->request->getQuery('sanctioned_amount'))) {
            $sanctioned_amount = trim($this->request->getQuery('sanctioned_amount'));
            $this->set('sanctioned_amount', $sanctioned_amount); 
            $search_condition[] = "IncubatorCapitalSubsidyPhaseTwo.sanctioned_amount like '%" . $sanctioned_amount . "%'";
        }
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        $query = $this->IncubatorCapitalSubsidyPhaseTwo->find()->contain(['Incubators','ApplicationStatus'])->order(['IncubatorCapitalSubsidyPhaseTwo.id'=>'DESC'])->where(['application_stage_id'=>3,$searchString]);
        $applications = $this->paginate($query);
        $this->set(compact('applications'));
    }

    public function capitalSubsidyPhaseTwoView($id='')
    {
        $this->loadModel('IncubatorCapitalSubsidyPhaseTwo');
        $id = base64_decode($id);
        $application = $this->IncubatorCapitalSubsidyPhaseTwo->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'capitalSubsidyPhaseTwoList']);
        }
        $capitalSubsidyTwo = $this->IncubatorCapitalSubsidyPhaseTwo->get($id, ['contain' => ['Incubators','ApplicationStatus','Designations']]);
        $this->set(compact('capitalSubsidyTwo'));
    }

    public function capitalSubsidyPhaseTwoEdit($id='')
    {
        $id = base64_decode($id);
        $this->loadModel('IncubatorCapitalSubsidyPhaseTwo');
        $application = $this->IncubatorCapitalSubsidyPhaseTwo->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'capitalSubsidyPhaseTwoList']);
        }
        $capitalSubsidyTwo = $this->IncubatorCapitalSubsidyPhaseTwo->get($id);
        if($this->request->is(['post','put'])){
            $data = $this->request->getData();
            
            $capitalSubsidyTwo->steering_committee_comment = $data['steering_committee_comment'];
            $capitalSubsidyTwo->approval_date =  date('Y-m-d H:i:s');
            if(!empty($data['approve'])){
                $capitalSubsidyTwo->application_status_id = 6;
                $capitalSubsidyTwo->application_stage_id  = 4;
                $capitalSubsidyTwo->sanction_amount = $data['sanction_amount'];
                $capitalSubsidyTwo->application_number = $this->capitalSubsidyPhaseTwoApplicationNo();
            }elseif(!empty($data['reject'])){
                $capitalSubsidyTwo->application_status_id = 7;
            }
            $capitalSubsidyTwo->updated = date('Y-m-d H:i:s');
            if($this->IncubatorCapitalSubsidyPhaseTwo->save($capitalSubsidyTwo)){
                if($capitalSubsidyTwo->application_status_id == 6){
                    //$this->capitalSubsidyPhaseTwoCertificate($capitalSubsidyTwo->id);
                }
                $this->Flash->success(__('You have successfully updated the status.'));
                return $this->redirect(['action' => 'capitalSubsidyPhaseTwoList']);
            }else{
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        }
        $this->set(compact('capitalSubsidyTwo'));
    }

    public function capitalSubsidyPhaseTwoApplicationNo()
    {
        $this->loadModel('IncubatorCapitalSubsidyPhaseTwo');
        $last_val = $this->IncubatorCapitalSubsidyPhaseTwo->find()->where(['application_stage_id'=>4])->count();
        $string = '';
        $string.= 'CS2/'.date('dmy').'/';
        $string.= str_pad(($last_val+1), 6, 0, STR_PAD_LEFT);
        return $string;
    }

    public function capitalSubsidyPhaseTwoCertificate($application_id)
    {
        $this->loadModel('IncubatorCapitalSubsidyPhaseTwo');
        $details = $this->IncubatorCapitalSubsidyPhaseTwo->find()->where(['IncubatorCapitalSubsidyPhaseTwo.id'=>$application_id])->contain(['Incubators'])->first();
        $view = new View($this->request, $this->response, null);
        $view->viewPath = 'Admin/IncubatorsSteeringCommittee';
        $view->layout = 'ajax';
        $view->set(compact('details'));
        $content = $view->render('subsidy_phase_two');
        $filename = $this->CreateCertificate($content, $details['application_number']);
        return $filename;
    }

    public function capitalSubsidyPhaseThreeList()
    {
        $this->loadModel('IncubatorCapitalSubsidyPhaseThree');
        $search_condition = array();
        if (!empty($this->request->getQuery('reference_number'))) {
            $reference_number = trim($this->request->getQuery('reference_number'));
            $this->set('reference_number', $reference_number); 
            $search_condition[] = "IncubatorCapitalSubsidyPhaseThree.reference_number like '%" . $reference_number . "%'";
        }
        if (!empty($this->request->getQuery('incubator_name'))) {
            $incubator_name = trim($this->request->getQuery('incubator_name'));
            $this->set('incubator_name', $incubator_name); 
            $search_condition[] = "IncubatorCapitalSubsidyPhaseThree.incubator_name like '%" . $incubator_name . "%'";
        }        
        if (!empty($this->request->getQuery('registration_number'))) {
            $registration_number = trim($this->request->getQuery('registration_number'));
            $this->set('registration_number', $registration_number); 
            $search_condition[] = "IncubatorCapitalSubsidyPhaseThree.registration_number like '%" . $registration_number . "%'";
        }
        if (!empty($this->request->getQuery('sanctioned_amount'))) {
            $sanctioned_amount = trim($this->request->getQuery('sanctioned_amount'));
            $this->set('sanctioned_amount', $sanctioned_amount); 
            $search_condition[] = "IncubatorCapitalSubsidyPhaseThree.sanctioned_amount like '%" . $sanctioned_amount . "%'";
        }
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        $query = $this->IncubatorCapitalSubsidyPhaseThree->find()->contain(['Incubators','ApplicationStatus'])->order(['IncubatorCapitalSubsidyPhaseThree.id'=>'DESC'])->where(['application_stage_id'=>3,$searchString]);
        $applications = $this->paginate($query);
        $this->set(compact('applications'));
    }

    public function capitalSubsidyPhaseThreeView($id='')
    {
        $this->loadModel('IncubatorCapitalSubsidyPhaseThree');
        $id = base64_decode($id);
        $application = $this->IncubatorCapitalSubsidyPhaseThree->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'capitalSubsidyPhaseThreeList']);
        }
        $capitalSubsidyThree = $this->IncubatorCapitalSubsidyPhaseThree->get($id, ['contain' => ['Incubators','ApplicationStatus','Designations']]);
        $this->set(compact('capitalSubsidyThree'));
    }

    public function capitalSubsidyPhaseThreeEdit($id='')
    {
        $id = base64_decode($id);
        $this->loadModel('IncubatorCapitalSubsidyPhaseThree');
        $application = $this->IncubatorCapitalSubsidyPhaseThree->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'capitalSubsidyPhaseThreeList']);
        }
        $capitalSubsidyThree = $this->IncubatorCapitalSubsidyPhaseThree->get($id);
        if($this->request->is(['post','put'])){
            $data = $this->request->getData();
            
            $capitalSubsidyThree->steering_committee_comment = $data['steering_committee_comment'];
            $capitalSubsidyThree->approval_date =  date('Y-m-d H:i:s');
            if(!empty($data['approve'])){
                $capitalSubsidyThree->application_status_id = 6;
                $capitalSubsidyThree->application_stage_id  = 4;
                $capitalSubsidyThree->sanction_amount = $data['sanction_amount'];
                $capitalSubsidyThree->application_number = $this->capitalSubsidyPhaseThreeApplicationNo();
            }elseif(!empty($data['reject'])){
                $capitalSubsidyThree->application_status_id = 7;
            }
            $capitalSubsidyThree->updated = date('Y-m-d H:i:s');
            if($this->IncubatorCapitalSubsidyPhaseThree->save($capitalSubsidyThree)){
                if($capitalSubsidyThree->application_status_id == 6){
                    //$this->capitalSubsidyPhaseThreeCertificate($capitalSubsidyThree->id);
                }
                $this->Flash->success(__('You have successfully updated the status.'));
                return $this->redirect(['action' => 'capitalSubsidyPhaseThreeList']);
            }else{
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        }
        $this->set(compact('capitalSubsidyThree'));
    }
    
    public function capitalSubsidyPhaseThreeApplicationNo()
    {
        $this->loadModel('IncubatorCapitalSubsidyPhaseThree');
        $last_val = $this->IncubatorCapitalSubsidyPhaseThree->find()->where(['application_stage_id'=>4])->count();
        $string = '';
        $string.= 'CS2/'.date('dmy').'/';
        $string.= str_pad(($last_val+1), 6, 0, STR_PAD_LEFT);
        return $string;
    }

    public function capitalSubsidyPhaseThreeCertificate($application_id)
    {
        $this->loadModel('IncubatorCapitalSubsidyPhaseThree');
        $details = $this->IncubatorCapitalSubsidyPhaseThree->find()->where(['IncubatorCapitalSubsidyPhaseThree.id'=>$application_id])->contain(['Incubators'])->first();
        $view = new View($this->request, $this->response, null);
        $view->viewPath = 'Admin/IncubatorsSteeringCommittee';
        $view->layout = 'ajax';
        $view->set(compact('details'));
        $content = $view->render('subsidy_phase_two');
        $filename = $this->CreateCertificate($content, $details['application_number']);
        return $filename;
    }

    
    public function CreateCertificate($content, $title)
    {
        $this->autoRender = false;
        $pdf = new DEMOPDF();
        $pdf->AddPage('L');
        $pdf->SetFillColor(53,127,63);
        $pdf->SetFont('times', 'R', 11);
        $pdf->SetFont('courier', 'R', 11);
        $pdf->SetFont('Helvetica', 'R', 11);
        $pdf->SetTextColor(0,0,0);
        $pdf->SetCompression(true);
        $pdf->SetTitle($title);
        $pdf->writeHTML($content, false, false, false, false, 'L');
        $title = str_replace('/', '-', $title);
        $tempfile = $title.'.pdf';
        $filename = WWW_ROOT."/files/certificate/".$tempfile;
        $pdf->Output($filename,'F');
        return $tempfile;
        //exit;
    }
    
}