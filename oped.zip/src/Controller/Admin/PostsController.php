<?php
namespace App\Controller\Admin;

use App\Controller\Admin\AppController;
use Cake\Cache\Cache;
use Cake\Event\Event;
use Cake\Network\Exception\NotFoundException;
use Cake\Utility\Hash;
use Cake\View\Exception\MissingTemplateException;
use Cake\Core\Configure;
use Cake\ORM\TableRegistry;

/**
 * Posts Controller
 *
 * @property \App\Model\Table\PostsTable $Posts
 *
 * @method \App\Model\Entity\Post[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class PostsController extends AppController
{

    public function initialize()
    {
        parent::initialize();
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }

    private $documentTypes = [
        1 => 'Documents',
        2 => 'Other',
    ];

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $search_condition = array();
        $page_length = !empty($this->request->getQuery('page_length')) ? $this->request->getQuery('page_length') : 10;
        $page = !empty($this->request->getQuery('page')) ? $this->request->getQuery('page') : 1;
        if (!empty($this->request->getQuery('post_title'))) {
            $postTitle = trim($this->request->getQuery('post_title'));
            $this->set('post_title', $postTitle);
            $search_condition[] = "Posts.title like '%" . $postTitle . "%'";
        }
        if(!empty($this->request->getQuery('parent_id'))) {
            $selectedparent = $this->request->getQuery('parent_id');
            $this->set('selectedparent', $selectedparent);
            $search_condition[] = "Posts.parent_id = '" . $selectedparent . "'";
        }else{
            $search_condition[] = "Posts.parent_id = 0";
        }
        if (!empty($this->request->getQuery('sub_title'))) {
            $subTitle = trim($this->request->getQuery('sub_title'));
            $this->set('sub_title', $subTitle);
            $search_condition[] = "Posts.subtitle like '%" . $subTitle . "%'";
        }
        if (!empty($this->request->getQuery('article_id'))) {
            $objectType = trim($this->request->getQuery('article_id'));
            $this->set('objectType', $objectType);
            $search_condition[] = "Posts.article_id = '" . $objectType . "'";
        }
        if (isset($this->request->query['status']) && $this->request->getQuery('status') !='') {
            $status = trim($this->request->getQuery('status'));
            $this->set('status', $status);
            $search_condition[] = "Posts.status = '" . $status . "'";
        }

        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }

        $postQuery = $this->Posts->find('all', [
            'contain' => ['Articles', 'ParentPosts'],
            'order' => ['Posts.id' => 'desc'],
            'conditions' => [$searchString]
        ]);

        $this->paginate = ['limit' => 10];
        $posts = $this->paginate($postQuery);
        $this->set('selectedLen', $page_length);
        //Get Articales
        $this->loadModel('Articles');
        $articlesList = $this->Articles->find('list',['conditions' => ['status'=>1]]);
        $this->set(compact('posts','articlesList'));
    }

    /**
     * View method
     *
     * @param string|null $id Post id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $post = $this->Posts->get($id, [
            'contain' => ['PostDocuments','Articles','Users']
        ]);
        $this->loadModel('Articles');
        $articlesList = $this->Articles->find('list',['conditions' => ['status'=>1]]);
        $documentTypes        = $this->documentTypes;
        $this->set(compact('post','documentTypes','articlesList'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $post = $this->Posts->newEntity();
        if ($this->request->is('post')) {
            $data              = $this->request->getData();
            $post_translations = [];
            if (isset($data['post_translations'])) {
                $post_translations = $data['post_translations'];
                unset($data['post_translations']);
            }
            $post_documents = [];
            if (isset($data['post_documents'])) {
                $post_documents   = $data['post_documents'];
                unset($data['post_documents']);
            }
            $tpost_documents = [];
            if (isset($post_translations['post_documents'])) {
                $tpost_documents  = $post_translations['post_documents'];
                unset($post_translations['post_documents']);
            }
            $post_documents       = array_merge($post_documents, $tpost_documents);
            $post = $this->Posts->patchEntity($post, $data);
            if($data['post_image']['name'] != ''){
                $postImage = $this->uploadImage('posts', $data['post_image']);
                $post->post_image = $postImage['filename'];
            }
            if ($this->Posts->save($post)) {
                $post_id = $post->id;
                if (!empty($post_translations)) {
                    $this->loadModel('PostTranslations');
                    foreach ($post_translations as $key => $_translation) {
                        if (empty($_translation['id'])) {
                            unset($post_translations[$key]['id']);
                        }
                        $post_translations[$key]['post_id'] = $post_id;
                    }
                    $postTranslation  = $this->PostTranslations->newEntity();
                    $postTranslation  = $this->PostTranslations->patchEntities($postTranslation, $post_translations);
                    $postTranslations = $this->PostTranslations->saveMany($postTranslation);
                }
                if (!empty($post_documents)) {
                    $this->loadModel('PostDocuments');
                    foreach ($post_documents as $key => $_document) {
                        if (empty($_document['id'])) {
                            unset($post_documents[$key]['id']);
                        }
                        if($_document['documents']['name']!=''){
                            $postDoc = $this->uploadFiles('posts', $_document['documents']);
                            $post_documents[$key]['documents'] = $postDoc['filename'];
                        }
                        $post_documents[$key]['post_id'] = $post_id;
                    }
                    $postDocument  = $this->PostDocuments->newEntity();
                    $postDocument  = $this->PostDocuments->patchEntities($postDocument, $post_documents);
                    $postDocuments = $this->PostDocuments->saveMany($postDocument);
                }
                $this->Flash->success(__('The post has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The post could not be saved. Please, try again.'));
        }

        $postLanguages  = $this->languages;
        $system_languge_id = SYSTEM_LANGUAGE_ID;
        $documentTypes = $this->documentTypes;
        $parentPosts = $this->Posts->ParentPosts->find('list', ['conditions' => ['parent_id'=>0],'limit' => 200]);
        //Get Articales
        $this->loadModel('Articles');
        $articlesList = $this->Articles->find('list',['conditions' => ['status'=>1]]);
        $this->set(compact('post', 'articlesList', 'parentPosts', 'users','postLanguages','system_languge_id','documentTypes'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Post id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $post = $this->Posts->get($id, [
            'contain' => ['PostTranslations','PostDocuments']
        ]);
        $post['post_translations'] = Hash::combine($post['post_translations'], '{n}.language_id', '{n}');
        if(!empty($post['post_documents'])){
            $post['english_document'] = array_filter($post['post_documents'], function($el) { return $el['language_id'] == 1 ; });
            $post['hindi_document'] = array_filter($post['post_documents'], function($el) { return $el['language_id'] == 2 ; });
            unset($post['post_documents']);
        }
        if ($this->request->is(['patch', 'post', 'put'])) {
            $data              = $this->request->getData();
            $post_translations = [];
            if (isset($data['post_translations'])) {
                $post_translations = $data['post_translations'];
                unset($data['post_translations']);
            }
            $post_documents = [];
            if (isset($data['post_documents'])) {
                $post_documents   = $data['post_documents'];
                unset($data['post_documents']);
            }
            $tpost_documents = [];
            if (isset($post_translations['post_documents'])) {
                $tpost_documents  = $post_translations['post_documents'];
                unset($post_translations['post_documents']);
            }
            $post_documents       = array_merge($post_documents, $tpost_documents);
            $post->updated = date('Y-m-d H:i:s');
            $post = $this->Posts->patchEntity($post, $data);
            if($data['post_image']['name'] != ''){
                $postImage = $this->uploadImage('posts', $data['post_image']);
                $post->post_image = $postImage['filename'];
            } else {
                $post->post_image = $data['old_post_image'];
            }
            if ($this->Posts->save($post)) {
                $post_id = $post->id;
                if (!empty($post_translations)) {
                    $this->loadModel('PostTranslations');
                    foreach ($post_translations as $key => $_translation) {
                        if (empty($_translation['id'])) {
                            unset($post_translations[$key]['id']);
                        }
                        $post_translations[$key]['post_id'] = $post_id;
                    }
                    $postTranslation  = $this->PostTranslations->newEntity();
                    $postTranslation  = $this->PostTranslations->patchEntities($postTranslation, $post_translations);
                    $postTranslations = $this->PostTranslations->saveMany($postTranslation);
                }
                if (!empty($post_documents)) {
                    $this->loadModel('PostDocuments');
                    foreach ($post_documents as $key => $_document) {
                        if (empty($_document['id'])) {
                            unset($post_documents[$key]['id']);
                        }
                        if($_document['documents']['name']!=''){
                            $postDoc = $this->uploadFiles('posts', $_document['documents']);
                            $post_documents[$key]['documents'] = $postDoc['filename'];
                        } else {
                            $post_documents[$key]['documents'] = $_document['old_documents'];
                        }
                        $post_documents[$key]['post_id'] = $post_id;
                    }
                    $postDocument  = $this->PostDocuments->newEntity();
                    $postDocument  = $this->PostDocuments->patchEntities($postDocument, $post_documents);
                    $postDocuments = $this->PostDocuments->saveMany($postDocument);
                }
                $this->Flash->success(__('The post has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The post could not be saved. Please, try again.'));
        }
        $documentTypes = $this->documentTypes;
        $postLanguages  = $this->languages;
        $system_languge_id = SYSTEM_LANGUAGE_ID;
        $parentPosts = $this->Posts->ParentPosts->find('list', ['conditions' => ['parent_id'=>0],'limit' => 200]);
        //Get Articales
        $this->loadModel('Articles');
        $articlesList = $this->Articles->find('list',['conditions' => ['status'=>1]]);
        $this->set(compact('post', 'articlesList', 'parentPosts', 'users','postLanguages','system_languge_id','documentTypes'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Post id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $post = $this->Posts->get($id);
        if ($this->Posts->delete($post)) {
            $this->loadModel('PostTranslations');
            $this->PostTranslations->deleteAll(['post_id' => $id]);
            $this->Flash->success(__('The post has been deleted.'));
        } else {
            $this->Flash->error(__('The post could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }

    public function deleteRow()
    {
        $this->viewBuilder()->setLayout('ajax');
        $row_id         = $_POST['id'];
        $table_name     = $_POST['table_name'];
        $custumTable    = TableRegistry::getTableLocator()->get($table_name);
        $removeQuery    = $custumTable->get($row_id);
        if($custumTable->delete($removeQuery)){
            echo 'removed';            
        }
        exit;  
    }
}
