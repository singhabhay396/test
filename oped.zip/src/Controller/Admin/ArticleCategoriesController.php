<?php
namespace App\Controller\Admin;

use App\Controller\Admin\AppController;
use Cake\Event\Event;

/**
 * StartupCategories Controller
 *
 * @property \App\Model\Table\StartupCategoriesTable $StartupCategories
 *
 * @method \App\Model\Entity\StartupCategory[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class ArticleCategoriesController extends AppController
{
    public function initialize()
    {
        parent::initialize();
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
		$this->loadModel('ArticleCategories');
        $startupCategories = $this->paginate($this->ArticleCategories);

        $this->set(compact('startupCategories'));
    }

    /**
     * View method
     *
     * @param string|null $id Startup Category id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
		$this->loadModel('ArticleCategories');
        $startupCategory = $this->ArticleCategories->get($id, [
            'contain' => []
        ]);

        $this->set('startupCategory', $startupCategory);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
		$this->loadModel('ArticleCategories');
        $startupCategory = $this->ArticleCategories->newEntity();
        if ($this->request->is('post')) {
            $startupCategory = $this->ArticleCategories->patchEntity($startupCategory, $this->request->getData());
            if ($this->ArticleCategories->save($startupCategory)) {
                $this->Flash->success(__('The article category has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The article category could not be saved. Please, try again.'));
        }
        $this->set(compact('startupCategory'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Startup Category id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $startupCategory = $this->ArticleCategories->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $startupCategory = $this->ArticleCategories->patchEntity($startupCategory, $this->request->getData());
            if ($this->ArticleCategories->save($startupCategory)) {
                $this->Flash->success(__('The article category has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The article category could not be saved. Please, try again.'));
        }
        $this->set(compact('startupCategory'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Startup Category id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $startupCategory = $this->ArticleCategories->get($id);
        if ($this->ArticleCategories->delete($startupCategory)) {
            $this->Flash->success(__('The article category has been deleted.'));
        } else {
            $this->Flash->error(__('The article category could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
