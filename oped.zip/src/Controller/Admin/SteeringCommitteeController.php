<?php
namespace App\Controller\Admin;

use App\Controller\Admin\AppController;
use Cake\Event\Event;
use Cake\Mailer\Email;
use Cake\ORM\TableRegistry;
use Cake\Error\Exceptions;
use Cake\I18n\Time;
use Cake\Routing\Router;
use Cake\View\View;

/**
 * Users Controller
 *
 * @property \App\Model\Table\UsersTable $Users
 *
 * @method \App\Model\Entity\User[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class SteeringCommitteeController extends AppController
{

    public function initialize()
    {
        parent::initialize();
        $this->Auth->allow(['captcha']);
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }

    public function index()
    {
        $this->loadModel('StartupApplications');

        $search_condition = array();
        if (!empty($this->request->getQuery('reference_no'))) {
            $reference_no = trim($this->request->getQuery('reference_no'));
            $this->set('reference_no', $reference_no); 
            $search_condition[] = "StartupApplications.reference_no like '%" . $reference_no . "%'";
        }
        if (!empty($this->request->getQuery('name_of_startup'))) {
            $name_of_startup = trim($this->request->getQuery('name_of_startup'));
            $this->set('name_of_startup', $name_of_startup); 
            $search_condition[] = "StartupApplications.name_of_startup like '%" . $name_of_startup . "%'";
        }     

        if (!empty($this->request->getQuery('recognition_certificate_no'))) {
            $recognition_certificate_no = trim($this->request->getQuery('recognition_certificate_no'));
            $this->set('recognition_certificate_no', $recognition_certificate_no); 
            $search_condition[] = "StartupApplications.recognition_certificate_no like '%" . $recognition_certificate_no . "%'";
        }

        if (!empty($this->request->getQuery('cin_llpin'))) {
            $cin_llpin = trim($this->request->getQuery('cin_llpin'));
            $this->set('cin_llpin', $cin_llpin); 
            $search_condition[] = "StartupApplications.cin_llpin like '%" . $cin_llpin . "%'";
        }
        
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }

        $applications = $this->paginate($this->StartupApplications->find()->where(['startup_stage_id'=>3,$searchString])->contain(['Users','ApplicationStatus']));
        $this->set(compact('applications'));
    }

    public function edit($id)
    {
        $id = base64_decode($id);
        $this->loadModel('StartupApplications');
        $application = $this->StartupApplications->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'index']);
        }
        $applications = $this->StartupApplications->get($id);
        if($this->request->is(['post','put'])){
            $data = $this->request->getData();
            $applications = $this->StartupApplications->patchEntity($applications,$data);
            $applications->updated = date('Y-m-d H:i:s');

            if(!empty($data['approve'])){
                $applications->application_status_id = 6;
                $applications->startup_stage_id = 4;
                $applications->recognition_certificate_no = $this->generateCertificateNo($applications->eligibility_criteria);
            }elseif(!empty($data['reject'])){
                $applications->application_status_id = 4;
            }
			
			$applications->steering_remark_date = date('Y-m-d');
			if($data['steering_remark_doc']['name']!=''){
                $certificate = $this->uploadFiles('registration', $data['steering_remark_doc']);
                $applications->steering_remark_doc = $certificate['filename'];
            }
            if($this->StartupApplications->save($applications)){
                if($applications->application_status_id == 6){
                    $this->recognitionCertificate($applications->id);
                }
				
				if(!empty($data['approve'])){
					/*startup_application_file_movements Table*/
					$tableName 					= 'StartupApplicationFileMovements';
					$application_id_columnName 	= 'startup_application_id';
					$startup_application_id 	= $applications->id;
					$comment					= $data['steering_committee_reason'];
					$current_with				= '';
					$initiated_date				= $applications->created;
					$panding_from				= date('Y-m-d');	
					
					$this->fileMovement($tableName, $application_id_columnName, $startup_application_id, $current_with, $comment, $initiated_date, $panding_from, $data);
				}
                $this->Flash->success(__('You have successfully updated the status'));
                return $this->redirect(['action' => 'index']);
            }else{
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        }
        $this->set(compact('applications'));
    }

    public function generateCertificateNo($category)
    {
        $this->loadModel('StartupApplications');
        $last_val = $this->StartupApplications->find()->where(['startup_stage_id'=>4])->count();
        $string = '';
        $string.= 'SUH/'.date('Y').'/';
        $string.= str_pad(($last_val+1), 6, 0, STR_PAD_LEFT);
        $string.= '/'.strtoupper($category);
        return $string;
    }

    public function recognitionCertificate($application_id)
    {
        $this->loadModel('StartupApplications');
        $this->loadModel('StartupCategories');
        $details = $this->StartupApplications->find('all')->contain(['NatureOfStartup'])->where(['StartupApplications.id'=>$application_id])->first();
        $this->set(compact('details'));

        $view = new View($this->request, $this->response, null);
        $view->viewPath = 'Admin/SteeringCommittee';
        $view->layout = 'ajax';
        $view->set(compact('details'));
        $content = $view->render('recognition_certificate');
        $filename = $this->CreateCertificate($content, $details['recognition_certificate_no']);
        return $filename;
    }

    public function view($id)
    {
        $id = base64_decode($id);
        $this->loadModel('StartupApplications');
		$this->loadModel('StartupApplicationFileMovements');
        $application = $this->StartupApplications->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'recognitionList']);
        }
        $applications = $this->StartupApplications->get($id);
        $startupApplication = $this->StartupApplications->get($id,['contain'=>['Users','RegisteredStates','RegisteredDistricts','CorporateStates','CorporateDistricts','RegionalStates','RegionalDistricts','StartupStages','ApplicationStatus','NatureOfStartup','StartupCategories','Industries','Sectors','IncorporationAuthorities', 'IndustriesOfProduct', 'SectorsOfProduct','StartupDirectors',  'StartupDirectors.DirectorStates', 'StartupDirectors.DirectorDistricts']]);
		$categoryOfProduct = [1=>'Innovative',2=>'Proprietary'];
		$nationality = [1=>'Indian'];
        //echo "<pre>"; print_r($startupApplication);exit;
		$StartupApplicationFileMovements = $this->StartupApplicationFileMovements->find('all')->where(['StartupApplicationFileMovements.startup_application_id '=>$startupApplication->id])->toArray();
        $this->set(compact('startupApplication','applications', 'categoryOfProduct', 'nationality', 'StartupApplicationFileMovements'));
	}
    public function leaseRentalList()
    {
        $this->loadModel('StartupLeaseIncentives');

        $search_condition = array();
        if (!empty($this->request->getQuery('reference_number'))) {
            $reference_number = trim($this->request->getQuery('reference_number'));
            $this->set('reference_number', $reference_number); 
            $search_condition[] = "StartupLeaseIncentives.reference_number like '%" . $reference_number . "%'";
        }
        if (!empty($this->request->getQuery('startup_name'))) {
            $startup_name = trim($this->request->getQuery('startup_name'));
            $this->set('startup_name', $startup_name); 
            $search_condition[] = "StartupLeaseIncentives.startup_name like '%" . $startup_name . "%'";
        }    

        if (!empty($this->request->getQuery('registration_number'))) {
            $registration_number = trim($this->request->getQuery('registration_number'));
            $this->set('registration_number', $registration_number); 
            $search_condition[] = "StartupLeaseIncentives.registration_number like '%" . $registration_number . "%'";
        }

        if (!empty($this->request->getQuery('incentive_amount'))) {
            $incentive_amount = trim($this->request->getQuery('incentive_amount'));
            $this->set('incentive_amount', $incentive_amount); 
            $search_condition[] = "StartupLeaseIncentives.incentive_amount like '%" . $incentive_amount . "%'";
        }
        
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }

        $applications = $this->paginate($this->StartupLeaseIncentives->find()->contain(['StartupApplications','Designations','ApplicationStatus'])->where(['application_stage_id'=>3,$searchString])->order(['StartupLeaseIncentives.id'=>'DESC']));
        $this->set(compact('applications'));
    }

    public function leaseRentalView($id)
    {
        $id = base64_decode($id);
        $this->loadModel('StartupLeaseIncentives');
		$this->loadModel('StartupLeaseIncentivesFileMovements');
        $application = $this->StartupLeaseIncentives->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'leaseRentalList']);
        }
        $startupLeaseIncentive = $this->StartupLeaseIncentives->get($id,['contain'=>['StartupApplications','Designations','ApplicationStatus','ApplicationStages']]);
		
		$startupLeaseIncentiveFileMovements = $this->StartupLeaseIncentivesFileMovements->find('all')->where(['StartupLeaseIncentivesFileMovements.startup_lease_incentive_id '=>$startupLeaseIncentive->id])->toArray();
		
		$typeOfOffice = [1=>'Registered',2=>'Corporate',3=>'Operational'];
		
        $this->set(compact('startupLeaseIncentive', 'startupLeaseIncentiveFileMovements', 'typeOfOffice'));
    }

    public function leaseRentalEdit($id)
    {
        $id = base64_decode($id);
        $this->loadModel('StartupLeaseIncentives');
        $application = $this->StartupLeaseIncentives->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'leaseRentalList']);
        }
        $startupLeaseIncentive = $this->StartupLeaseIncentives->get($id);
        if($this->request->is(['post','put'])){
            $data = $this->request->getData();
            $startupLeaseIncentive = $this->StartupLeaseIncentives->patchEntity($startupLeaseIncentive,$data);
            $startupLeaseIncentive->updated = date('Y-m-d H:i:s');
            if(!empty($data['approve'])){
                $startupLeaseIncentive->application_status_id = 6;
                $startupLeaseIncentive->application_stage_id = 4;
                $startupLeaseIncentive->application_number = $this->generateLeaseApplicationNo();
            }elseif(!empty($data['reject'])){
                $startupLeaseIncentive->application_status_id = 4;
            }
			
			$startupLeaseIncentive->steering_remark_date = date('Y-m-d');
			/* if($data['file_doc']['name']!=''){
                $certificate = $this->uploadFiles('lease-rental', $data['steering_remark_doc']);
                $startupLeaseIncentive->steering_remark_doc = $certificate['filename'];
            } */
			
            if($this->StartupLeaseIncentives->save($startupLeaseIncentive)){
				
				if(!empty($data['approve'])){
					/*startup_application_file_movements Table*/
					$tableName 					= 'StartupLeaseIncentivesFileMovements';
					$application_id_columnName 	= 'startup_lease_incentive_id';
					$startup_application_id 	= $id;
					$comment					= $data['steering_committee_reason'];
					$current_with				= '';
					$initiated_date				= $startupLeaseIncentive->created;
					$panding_from				= date('Y-m-d');	
					
					$this->fileMovement($tableName, $application_id_columnName, $startup_application_id, $current_with, $comment, $initiated_date, $panding_from, $data);
				}
                if($startupLeaseIncentive->application_status_id == 6){
                    $this->leaseCertificate($startupLeaseIncentive->id);
                }
                $this->Flash->success(__('You have successfully updated the status'));
                return $this->redirect(['action' => 'leaseRentalList']);
            }else{
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        }
        $this->set(compact('startupLeaseIncentive'));
    }

    public function leaseCertificate($application_id)
    {
        $this->loadModel('StartupLeaseIncentives');
        $details = $this->StartupLeaseIncentives->find()->where(['StartupLeaseIncentives.id'=>$application_id])->contain(['StartupApplications'])->first();
        $view = new View($this->request, $this->response, null);
        $view->viewPath = 'Admin/SteeringCommittee';
        $view->layout = 'ajax';
        $view->set(compact('details'));
        $content = $view->render('lease_certificate');
        $filename = $this->CreateCertificate($content, $details['application_number']);
        return $filename;
    }

    public function generateLeaseApplicationNo()
    {
        $this->loadModel('StartupLeaseIncentives');
        $last_val = $this->StartupLeaseIncentives->find()->where(['application_stage_id'=>4])->count();
        $string = '';
        $string.= 'L/'.date('dmy').'/';
        $string.= str_pad(($last_val+1), 6, 0, STR_PAD_LEFT);
        return $string;
    }
    
    public function programAppList()
    {
        $this->loadModel('StartupAppIncentives');

        $search_condition = array();
        if (!empty($this->request->getQuery('reference_number'))) {
            $reference_number = trim($this->request->getQuery('reference_number'));
            $this->set('reference_number', $reference_number); 
            $search_condition[] = "StartupAppIncentives.reference_number like '%" . $reference_number . "%'";
        }
        if (!empty($this->request->getQuery('startup_name'))) {
            $startup_name = trim($this->request->getQuery('startup_name'));
            $this->set('startup_name', $startup_name); 
            $search_condition[] = "StartupAppIncentives.startup_name like '%" . $startup_name . "%'";
        }    

        if (!empty($this->request->getQuery('registration_number'))) {
            $registration_number = trim($this->request->getQuery('registration_number'));
            $this->set('registration_number', $registration_number); 
            $search_condition[] = "StartupAppIncentives.registration_number like '%" . $registration_number . "%'";
        }

        if (!empty($this->request->getQuery('incentive_amount'))) {
            $incentive_amount = trim($this->request->getQuery('incentive_amount'));
            $this->set('incentive_amount', $incentive_amount); 
            $search_condition[] = "StartupAppIncentives.incentive_amount like '%" . $incentive_amount . "%'";
        }
        
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }

        $query = $this->StartupAppIncentives->find()->contain(['StartupApplications','Designations','ApplicationStatus'])->where(['application_stage_id'=>3,$searchString])->order(['StartupAppIncentives.id'=>'DESC']);
        $applications = $this->paginate($query);
        $this->set(compact('applications'));
    }

    public function programAppView($id)
    {
        $id = base64_decode($id);
        $this->loadModel('StartupAppIncentives');
		$this->loadModel('StartupAppIncentivesFileMovements');
        $application = $this->StartupAppIncentives->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'programAppList']);
        }
        $startupAppIncentive = $this->StartupAppIncentives->get($id,['contain'=>['StartupApplications','Designations','ApplicationStatus','ApplicationStages']]);
		
		$startupAppIncentivesFileMovements = $this->StartupAppIncentivesFileMovements->find('all')->where(['StartupAppIncentivesFileMovements.startup_app_incentive_id '=>$startupAppIncentive->id])->toArray();
		
        $this->set(compact('startupAppIncentive', 'startupAppIncentivesFileMovements'));
    }

    public function programAppEdit($id)
    {
        $id = base64_decode($id);
        $this->loadModel('StartupAppIncentives');
        $application = $this->StartupAppIncentives->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'programAppList']);
        }
        $startupAppIncentive = $this->StartupAppIncentives->get($id);
        if($this->request->is(['post','put'])){
            $data = $this->request->getData();
            $startupAppIncentive = $this->StartupAppIncentives->patchEntity($startupAppIncentive,$data);
            $startupAppIncentive->steering_committee_reason = $data['steering_committee_reason'];
            if(!empty($data['approve'])){
                $startupAppIncentive->application_status_id = 6;
                $startupAppIncentive->application_stage_id = 4;
                $startupAppIncentive->application_number = $this->generateAppCertificateNo();
            }elseif(!empty($data['reject'])){
                $startupAppIncentive->application_status_id = 4;
            }
            $startupAppIncentive->updated = date('Y-m-d H:i:s');
            if($this->StartupAppIncentives->save($startupAppIncentive)){
                if($startupAppIncentive->application_status_id == 6){
                    $this->appCertificate($startupAppIncentive->id);
                }
				
				/*Startup App Incentives file movements Table*/
					$tableName 					= 'StartupAppIncentivesFileMovements';
					$application_id_columnName 	= 'startup_app_incentive_id';
					$startup_application_id 	= $id;
					$comment					= $data['steering_committee_reason'];
					$current_with				= '';
					$initiated_date				= $startupAppIncentive->created;
					$panding_from				= date('Y-m-d');	
					
					$this->fileMovement($tableName, $application_id_columnName, $startup_application_id, $current_with, $comment, $initiated_date, $panding_from, $data);
					
                $this->Flash->success(__('You have successfully updated the status'));
                return $this->redirect(['action' => 'programAppList']);
            }else{
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        }
        $this->set(compact('startupAppIncentive'));
    }

    public function appCertificate($application_id)
    {
        $this->loadModel('StartupAppIncentives');
        $details = $this->StartupAppIncentives->find()->where(['StartupAppIncentives.id'=>$application_id])->contain(['StartupApplications'])->first();
        $view = new View($this->request, $this->response, null);
        $view->viewPath = 'Admin/SteeringCommittee';
        $view->layout = 'ajax';
        $view->set(compact('details'));
        $content = $view->render('app_certificate');
        $filename = $this->CreateCertificate($content, $details['application_number']);
        return $filename;
    }

    public function generateAppCertificateNo()
    {
        $this->loadModel('StartupAppIncentives');
        $last_val = $this->StartupAppIncentives->find()->where(['application_stage_id'=>4])->count();
        $string = '';
        $string.= 'PA/'.date('dmy').'/';
        $string.= str_pad(($last_val+1), 6, 0, STR_PAD_LEFT);
        return $string;
    }

    public function patentIncentivesList()
    {
        $this->loadModel('StartupPatentIncentives');

        $data = $this->Sanitize->clean($this->request->getQuery());
        if (!empty($data['reference_number'])) {
            $reference_number = trim($data['reference_number']);
            $this->set('reference_number', $reference_number); 
            $search_condition[] = "StartupPatentIncentives.reference_number like '%" . $reference_number . "%'";
        }
        if (!empty($data['startup_name'])) {
            $startup_name = trim($data['startup_name']);
            $this->set('startup_name', $startup_name); 
            $search_condition[] = "StartupPatentIncentives.startup_name like '%" . $startup_name . "%'";
        }     

        if (!empty($data['registration_number'])) {
            $registration_number = trim($data['registration_number']);
            $this->set('registration_number', $registration_number); 
            $search_condition[] = "StartupPatentIncentives.registration_number like '%" . $registration_number . "%'";
        }

        if (isset($data['status']) && $data['status'] !='') {
            $status = trim($data['status']);  
            $this->set('status', $status);
            $search_condition[] = "StartupPatentIncentives.status = '" . $status . "'";
        }
        
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }

        $query = $this->StartupPatentIncentives->find()->contain(['StartupApplications','Designations','ApplicationStatus'])->where(['application_stage_id'=>3,$searchString])->order(['StartupPatentIncentives.id'=>'DESC']);
        $applications = $this->paginate($query);
        $this->set(compact('applications'));
    }

    public function patentIncentivesView($id)
    {
        $id = base64_decode($id);
        $this->loadModel('StartupPatentIncentives');
        $application = $this->StartupPatentIncentives->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'patentIncentivesList']);
        }
        $patentIncentive = $this->StartupPatentIncentives->get($id,['contain'=>['StartupApplications','Designations','ApplicationStatus','ApplicationStages']]);
        $this->set(compact('patentIncentive'));
    }

    public function patentIncentivesEdit($id)
    {
        $id = base64_decode($id);
        $this->loadModel('StartupPatentIncentives');
        $application = $this->StartupPatentIncentives->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'patentIncentivesList']);
        }
        $patentIncentive = $this->StartupPatentIncentives->get($id);
        if($this->request->is(['post','put'])){
            $data = $this->request->getData();
            $patentIncentive = $this->StartupPatentIncentives->patchEntity($patentIncentive,$data);
            $patentIncentive->admin_reason = $data['steering_committee_reason'];
            if(!empty($data['approve'])){
                $patentIncentive->application_status_id = 6;
                $patentIncentive->application_stage_id = 4;
                $patentIncentive->application_number = $this->generatePatentCertificateNo();
            }elseif(!empty($data['reject'])){
                $patentIncentive->application_status_id = 4;
            }
            $patentIncentive->updated = date('Y-m-d H:i:s');
            if($this->StartupPatentIncentives->save($patentIncentive)){
                if($patentIncentive->application_status_id == 6){
                    $this->patentCertificate($patentIncentive->id);
                }
                $this->Flash->success(__('You have successfully updated the status'));
                return $this->redirect(['action' => 'patentIncentivesList']);
            }else{
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        }
        $this->set(compact('patentIncentive'));
    }

    public function patentCertificate($application_id)
    {
        $this->loadModel('StartupPatentIncentives');
        $details = $this->StartupPatentIncentives->find()->where(['StartupPatentIncentives.id'=>$application_id])->contain(['StartupApplications'])->first();
        $view = new View($this->request, $this->response, null);
        $view->viewPath = 'Admin/SteeringCommittee';
        $view->layout = 'ajax';
        $view->set(compact('details'));
        $content = $view->render('patent_certificate');
        $filename = $this->CreateCertificate($content, $details['application_number']);
        return $filename;
    }

    public function generatePatentCertificateNo()
    {
        $this->loadModel('StartupPatentIncentives');
        $last_val = $this->StartupPatentIncentives->find()->where(['application_stage_id'=>4])->count();
        $string = '';
        $string.= 'P/'.date('dmy').'/';
        $string.= str_pad(($last_val+1), 6, 0, STR_PAD_LEFT);
        return $string;
    }
    
    public function qualityCertificationList()
    {
        $this->loadModel('StartupQualityCertifications');

        $search_condition = array();
        $data = $this->Sanitize->clean($this->request->getQuery());
        if (!empty($data['reference_number'])) {
            $reference_number = trim($data['reference_number']);
            $this->set('reference_number', $reference_number); 
            $search_condition[] = "StartupQualityCertifications.reference_number like '%" . $reference_number . "%'";
        }
        if (!empty($data['startup_name'])) {
            $startup_name = trim($data['startup_name']);
            $this->set('startup_name', $startup_name); 
            $search_condition[] = "StartupQualityCertifications.startup_name like '%" . $startup_name . "%'";
        }     

        if (!empty($data['registration_number'])) {
            $registration_number = trim($data['registration_number']);
            $this->set('registration_number', $registration_number); 
            $search_condition[] = "StartupQualityCertifications.registration_number like '%" . $registration_number . "%'";
        }

        if (isset($data['status']) && $data['status'] !='') {
            $status = trim($data['status']);  
            $this->set('status', $status);
            $search_condition[] = "StartupQualityCertifications.status = '" . $status . "'";
        }
        
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }

        $query = $this->StartupQualityCertifications->find()->contain(['StartupApplications','Designations','ApplicationStatus'])->where(['application_stage_id'=>3,$searchString])->order(['StartupQualityCertifications.id'=>'DESC']);
        $applications = $this->paginate($query);
        $this->set(compact('applications'));
    }

    public function qualityCertificationView($id)
    {
        $id = base64_decode($id);
        $this->loadModel('StartupQualityCertifications');
        $application = $this->StartupQualityCertifications->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'qualityCertificationList']);
        }
        $qualityIncentive = $this->StartupQualityCertifications->get($id,['contain'=>['StartupApplications','Designations','ApplicationStatus','ApplicationStages']]);
        $this->set(compact('qualityIncentive'));
    }

    public function qualityCertificationEdit($id)
    {
        $id = base64_decode($id);
        $this->loadModel('StartupQualityCertifications');
        $application = $this->StartupQualityCertifications->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'qualityCertificationList']);
        }
        $qualityIncentive = $this->StartupQualityCertifications->get($id);
        if($this->request->is(['post','put'])){
            $data = $this->request->getData();
            $qualityIncentive = $this->StartupQualityCertifications->patchEntity($qualityIncentive,$data);
            $qualityIncentive->admin_reason = $data['steering_committee_reason'];
            if(!empty($data['approve'])){
                $qualityIncentive->application_status_id = 6;
                $qualityIncentive->application_stage_id = 4;
                $qualityIncentive->application_number = $this->generateQualityCertificateNo();
            }elseif(!empty($data['reject'])){
                $qualityIncentive->application_status_id = 4;
            }
            $qualityIncentive->updated = date('Y-m-d H:i:s');
            if($this->StartupQualityCertifications->save($qualityIncentive)){
                if($qualityIncentive->application_status_id == 6){
                    $this->patentCertificate($qualityIncentive->id);
                }
                $this->Flash->success(__('You have successfully updated the status.'));
                return $this->redirect(['action' => 'qualityCertificationList']);
            }else{
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        }
        $this->set(compact('qualityIncentive'));
    }

    public function qualityCertificate($application_id)
    {
        $this->loadModel('StartupQualityCertifications');
        $details = $this->StartupQualityCertifications->find()->where(['StartupQualityCertifications.id'=>$application_id])->contain(['StartupApplications'])->first();
        $view = new View($this->request, $this->response, null);
        $view->viewPath = 'Admin/SteeringCommittee';
        $view->layout = 'ajax';
        $view->set(compact('details'));
        $content = $view->render('quality_certificate');
        $filename = $this->CreateCertificate($content, $details['application_number']);
        return $filename;
    }

    public function generateQualityCertificateNo()
    {
        $this->loadModel('StartupQualityCertifications');
        $last_val = $this->StartupQualityCertifications->find()->where(['application_stage_id'=>4])->count();
        $string = '';
        $string.= 'QC/'.date('dmy').'/';
        $string.= str_pad(($last_val+1), 6, 0, STR_PAD_LEFT);
        return $string;
    }


    public function CreateCertificate($content, $title)
    {
        $this->autoRender = false; 
        $pdf = new DEMOPDF();
        $pdf->AddPage('L');
        $pdf->SetFillColor(53,127,63);
        $pdf->SetFont('times', 'R', 11);
        $pdf->SetFont('courier', 'R', 11);
        $pdf->SetFont('Helvetica', 'R', 11);
        $pdf->SetTextColor(0,0,0);
        $pdf->SetCompression(true);
        $pdf->SetTitle($title);
        $pdf->writeHTML($content, false, false, false, false, 'L');
        $title = str_replace('/', '-', $title);
        $tempfile = $title.'.pdf';
        $filename = WWW_ROOT."/files/certificate/".$tempfile;
        $pdf->Output($filename,'F');
        return $tempfile;
    }

}