<?php
namespace App\Controller\Admin;

use App\Controller\Admin\AppController;

/**
 * SuccessStories Controller
 *
 * @property \App\Model\Table\SuccessStoriesTable $SuccessStories
 *
 * @method \App\Model\Entity\SuccessStory[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class SuccessStoriesController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {

        $search_condition = array();
        $data = $this->Sanitize->clean($this->request->getQuery());
        if (!empty($data['title'])) {
            $postTitle = trim($data['title']); 
            $this->set('title', $postTitle);
            $search_condition[] = "SuccessStories.title like '%" . $postTitle . "%'";
        }
        
        if (isset($data['status']) && $data['status'] !='') {
            $status = trim($data['status']);
            $this->set('status', $status);
            $search_condition[] = "SuccessStories.status = '" . $status . "'";
        }

        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        //pr($search_condition); die;
        $postQuery = $this->SuccessStories->find('all', [
            'order' => ['SuccessStories.id' => 'desc'],
            'conditions' => [$searchString]
        ]);
        $this->paginate = ['limit' => 10];

        $successStories = $this->paginate($postQuery);

        $this->set(compact('successStories'));
    }

    /**
     * View method
     *
     * @param string|null $id Success Story id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $successStory = $this->SuccessStories->get($id, [
            'contain' => ['SuccessStoryTranslation']
        ]);

        $this->set('successStory', $successStory);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $successStory = $this->SuccessStories->newEntity();
        if ($this->request->is('post')) {
            $data = $this->request->getData();
            $success_story_translation = [];
            if (isset($data['success_story_translation'])) {
                $success_story_translation = $data['success_story_translation'];
                unset($data['success_story_translation']);
            }
            $successStory = $this->SuccessStories->patchEntity($successStory, $this->request->getData());
            if($data['image']['name']!=''){
                $image = $this->uploadFiles('success_stories', $data['image']);
                $successStory->image = $image['filename'];
            }
            if ($this->SuccessStories->save($successStory)) {

                $successStory_id = $successStory->id;
                if (!empty($success_story_translation)) {
                    $this->loadModel('SuccessStoryTranslation');
                    foreach ($success_story_translation as $key => $_translation) {
                        if (empty($_translation['id'])) {
                            unset($success_story_translation[$key]['id']);
                        }
                        $success_story_translation[$key]['success_story_id'] = $successStory_id;
                    }
                    $storyTranslation  = $this->SuccessStoryTranslation->newEntity();
                    $storyTranslation  = $this->SuccessStoryTranslation->patchEntities($storyTranslation, $success_story_translation);
                    $storyTranslations = $this->SuccessStoryTranslation->saveMany($storyTranslation);
                }

                $this->Flash->success(__('The success story has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The success story could not be saved. Please, try again.'));
        }
        $successStoryLanguages  = $this->languages;
        $system_languge_id = SYSTEM_LANGUAGE_ID;
        $this->set(compact('successStory','successStoryLanguages','system_languge_id'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Success Story id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $successStory = $this->SuccessStories->get($id, [
            'contain' => ['SuccessStoryTranslation']
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $data = $this->request->getData();
            $success_story_translation = [];
            if (isset($data['success_story_translation'])) {
                $success_story_translation = $data['success_story_translation'];
                unset($data['success_story_translation']);
            }
            $successStory = $this->SuccessStories->patchEntity($successStory, $this->request->getData());
            if($data['image']['name']!=''){
                $image = $this->uploadFiles('success_stories', $data['image']);
                $successStory->image = $image['filename'];
            }else{
                $successStory->image = $data['old_image'];
            }
            if ($this->SuccessStories->save($successStory)) {
                $successStory_id = $successStory->id;
                if (!empty($success_story_translation)) {
                    $this->loadModel('SuccessStoryTranslation');
                    foreach ($success_story_translation as $key => $_translation) {
                        if (empty($_translation['id'])) {
                            unset($success_story_translation[$key]['id']);
                        }
                        $success_story_translation[$key]['success_story_id'] = $successStory_id;
                    }
                    $storyTranslation  = $this->SuccessStoryTranslation->newEntity();
                    $storyTranslation  = $this->SuccessStoryTranslation->patchEntities($storyTranslation, $success_story_translation);
                    $storyTranslations = $this->SuccessStoryTranslation->saveMany($storyTranslation);
                }
                $this->Flash->success(__('The success story has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The success story could not be saved. Please, try again.'));
        }
        $successStoryLanguages  = $this->languages;
        $system_languge_id = SYSTEM_LANGUAGE_ID;
        $this->set(compact('successStory','successStoryLanguages','system_languge_id'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Success Story id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $successStory = $this->SuccessStories->get($id);
        if ($this->SuccessStories->delete($successStory)) {
            $this->Flash->success(__('The success story has been deleted.'));
        } else {
            $this->Flash->error(__('The success story could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
