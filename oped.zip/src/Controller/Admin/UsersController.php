<?php
namespace App\Controller\Admin;

use App\Controller\Admin\AppController;
use Cake\Cache\Cache;
use Cake\Event\Event;
use Cake\Mailer\Email;
use Cake\ORM\TableRegistry;
use Cake\Error\Exceptions;
use Cake\I18n\Time;
use Cake\Utility\Hash;
use Cake\Utility\Text;
use Cake\Routing\Router;
use Cake\Validation\Validator;
use Cake\Auth\DefaultPasswordHasher;
use Cake\View\Exception\MissingTemplateException;
use Cake\Core\Configure;
use Cake\Filesystem\File;

/**
 * Users Controller
 *
 * @property \App\Model\Table\UsersTable $Users
 *
 * @method \App\Model\Entity\User[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class UsersController extends AppController
{

    public function initialize()
    {
        parent::initialize();
        //$this->loadComponent('CakephpCaptcha.Captcha');
        $this->Auth->allow(['jcryption', 'forgotPassword','resetPassword','captcha','getUserField','checkMail','registrationVerification']);
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }


    /**
     * login method
     *
     * @return \Cake\Network\Response|null
     */
	public function checkMail() 
    {
        $username = 'singhabhay396@gmail.com';
        $UserExist = $this->Users->findByEmail($username)->first();

        $emailData = [
            'setHelpers'     => ['Html'],
            'setTemplate'    => 'startup_mail',
            'setEmailFormat' => 'html',
            'setTo'          => trim($UserExist->email),
            'setSubject'     => __('OP ED'),
            'setViewVars'    => ['user' => $UserExist],
        ];
        $this->Email->sendMail($emailData);
        die('Test Mail Send');
    }
    public function login()
    {
        $this->viewBuilder()->setLayout('login');
        if ($this->request->getSession()->check('Auth.User')) {
            return $this->redirect(['controller' => 'Articles', 'action' => 'index']);
        }

        if ($this->request->is('post')) {
            $token = $this->request->getParam('_csrfToken');
            $jcryption = new \JCryption;
            $jcryption->decrypt();
            @$this->request->data = $_REQUEST;            
            $userdata = @$this->request->data;
            $errors = array();
            /* $captcha = $this->Captcha->check($userdata['captcha']);
            if (empty($captcha)) {
                $errors['captcha']['_empty'] = 'Invalid captcha. Please try again.';
            } */
            
            $uname = $userdata['email'];
            $login_attempts_id = '';
            $previousFailedAttempt = '';
            if (empty($errors)) {

                /***   Checking for login attempts   ***/
                $attempt_status = 0;
                $usersTable = TableRegistry::get('users');
                $usersResult = $usersTable->find('all', ['conditions' => ['email' => $uname]]);
                $usersResult->enableHydration(false);
                $usersResultArr = $usersResult->toArray();
                
                if (!empty($usersResultArr)) {
                    $uid = $usersResultArr[0]['id'];
                } else {
                    $uid = 0;
                }
                $ip = $_SERVER['REMOTE_ADDR'];

                if ($ip == '::1') {
                    $ipadd = '127.0.0.1';
                } else {
                    $ipadd = $ip;
                }

                $failed_attempts = 1;

                $login_attemptsTable = TableRegistry::get('login_attempts');
                $login_attemptsResult = $login_attemptsTable->find('all', ['conditions' => ['ipaddress' => $ipadd, 'last_attempt >' => new Time('-15 minutes')]]);
                $login_attemptsResult->enableHydration(false);
                $login_attemptsResultArr = $login_attemptsResult->toArray();

                //for deleting all records before 15 minutes
                $attempts_15minBefore = $login_attemptsTable->find('all', ['conditions' => ['ipaddress' => $ipadd, 'last_attempt <' => new Time('-15 minutes')]])->enableHydration(false)->toArray();
                
                if (!empty($attempts_15minBefore)) {
                    foreach ($attempts_15minBefore as $keyA => $valueA) {
                        $recordIdToDelete = $valueA['id'];
                        $recordEntity = $login_attemptsTable->get($recordIdToDelete);
                        $login_attemptsTable->delete($recordEntity);
                    }
                }

                if (empty($login_attemptsResultArr)) {
                    $login_attempts = $login_attemptsTable->newEntity();
                    $login_attempt_data = array(
                        'uid' => $uid,
                        'ipaddress' => $ipadd,
                        'failed_attempts' => $failed_attempts,
                    );
                    $login_attempts = $login_attemptsTable->patchEntity($login_attempts, $login_attempt_data);
                    $result = $login_attemptsTable->save($login_attempts);

                    if ($result) {
                        $attempt_status = 1;
                    } else {
                        $attempt_status = 0;
                    }
                } else {
                    $login_attempts_id = $login_attemptsResultArr[0]['id'];
                    $previousFailedAttempt = $login_attemptsResultArr[0]['failed_attempts'];
                    $login_attempts = $login_attemptsTable->get($login_attemptsResultArr[0]['id']);
                    $login_attempt_data['failed_attempts'] = $login_attempts->failed_attempts + 1;
                    $login_attempt_data['uid'] = $uid;

                    $login_attempts = $login_attemptsTable->patchEntity($login_attempts, $login_attempt_data);
                    $result = $login_attemptsTable->save($login_attempts);
                    //if($result['failed_attempts'] >= 6 && $hours==0 && $minutes<=15){
                    if ($result['failed_attempts'] >= 6) {
                        $attempt_status = 0;
                    } else {
                        $attempt_status = 1;
                    }
                }

                /***   Ends   ***/
                $auth = $this->Auth->identify();
                if ($attempt_status == 1) {
                    if ($auth) {
                        $user_id = $auth['id'];
                        // for check already login or not.
                        $adminLogsTable = TableRegistry::get('admin_logs');
                        $loggedInCheck = $adminLogsTable->find('all', [
                                'conditions' => ['uid' => $user_id]
                            ])->last();
                        //if ($loggedInCheck['flag'] == 0) {
                            $loginAttemptsTable = TableRegistry::get('login_attempts');
                            $UserLoginExistsQ = $loginAttemptsTable->find('all', [
                                'conditions' => ['uid' => $user_id, 'last_attempt >' => new Time('-15 minutes')]
                            ]);
                            $UserLoginExists = $UserLoginExistsQ->enableHydration(false)->toArray();

                            if ($auth['status']) {
                                /* admin log code starts */
                                $ipaddress = $_SERVER['REMOTE_ADDR'];
                                if ($ipaddress == '::1') {
                                    $ipadd = '127.0.0.1';
                                } else {
                                    $ipadd = $ipaddress;
                                }
                                $uid = $auth['id'];
                                $adminLogTable = TableRegistry::get('admin_logs');
                                $adminLog = $adminLogTable->newEntity();
                                $adminLog->uid = $uid;
                                $adminLog->flag = 1;
                                $adminLog->logtime = date('Y-m-d H:i:s');
                                $adminLog->ipaddress = inet_pton($ipadd);//string inet_ntop ( string $in_addr )
                                $adminLogTable->save($adminLog);
                                /* admin log code ends */

                                $this->Auth->setUser($auth);
                                // code for updating login attempt status for already login
                                $UserLoginExistsQ = $loginAttemptsTable->find('all', [
                                    'conditions' => ['uid' => $user_id, 'last_attempt >' => new Time('-15 minutes')],
                                ]);
                                $UserLoginExists = $UserLoginExistsQ->enableHydration(false)->toArray();
                                if (!empty($UserLoginExists)) {
                                    $userLoggedInStatus = end($UserLoginExists)['login_flag'];
                                    $loginUserAttemptFlagEntity = $loginAttemptsTable->get(end($UserLoginExists)['id']);
                                    $loginUAttemptFlagData = [
                                        'login_flag' => 1,
                                    ];
                                    $loginUserAttemptFlagEntityPatch = $loginAttemptsTable->patchEntity($loginUserAttemptFlagEntity, $loginUAttemptFlagData);
                                    $loginAttemptsTable->save($loginUserAttemptFlagEntityPatch);
                                }
                                //ends here.
                                if ($login_attempts_id) {
                                    $this->set('userd', $this->Auth->user());
                                    $entity1 = $login_attemptsTable->get($login_attempts_id);
                                    $entityData = $login_attemptsTable->patchEntity($entity1, ['failed_attempts' => 0]);
                                    $login_attemptsTable->save($entityData);
									
                                }
								$role_id = $this->Auth->user('role_id');
									
								if($role_id == 1){
									return $this->redirect(['controller' => 'articles','action'=>'index']);
								}
								else{
									return $this->redirect(['controller' => 'new-articles','action'=>'pending-articles']);
								}
								
                                //return $this->redirect($this->Auth->redirectUrl());
                            } else {
                                $this->Flash->error(__('User is deactivated or blocked.'));
                                return $this->redirect($this->referer());
                            }
                        /*} else {
                            $this->Flash->error(__('Multiple login not allowed.'));
                        }*/
                    } else {
                        $this->Flash->error(__('Invalid credentials.'));
                    }
                } else {
                    $this->Flash->error(__('You have entered wrong credentials 5 or more times, User is blocked.'));
                    return $this->redirect($this->referer());
                }
            } /* else {
                if(!empty($errors['captcha']['_empty'])){
                    $this->Flash->error(__($errors['captcha']['_empty']));
                } else {
                    $this->Flash->error(__('Your Captcha is expire. Please refresh the page'));
                }
            } */
        }
    }

    /**
     * logout method
     *
     * @return \Cake\Network\Response|null
     */

    public function logout()
    {
        $this->Flash->success(__('You are logged out '));
        $user_id = $this->request->session()->read('Auth.User.id');

        /* $adminLogTable = TableRegistry::get('admin_logs');
        $loggedInUser = $adminLogTable->find('all',[
            'conditions' => ['uid'=>$user_id],
        ])->last();

        $adminLog = $adminLogTable->get($loggedInUser['id']);
        $adminLog->flag = 0;
        $adminLogTable->save($adminLog); */

        $loginAttemptsTable = TableRegistry::get('login_attempts');
        $UserLoginExists = $loginAttemptsTable->find('all',[
            'conditions' => ['uid'=>$user_id,'last_attempt >'=>new Time('-15 minutes')],
        ])->enableHydration(false)->toArray();
        if(!empty($UserLoginExists)){
            $loginUserAttemptFlagEntity = $loginAttemptsTable->get(end($UserLoginExists)['id']);
            $loginUserAttemptFlagEntityPatch = $loginAttemptsTable->patchEntity($loginUserAttemptFlagEntity, ['login_flag'=>0]);
            $loginAttemptsTable->save($loginUserAttemptFlagEntityPatch);
        }
        $ip = $_SERVER['REMOTE_ADDR'];
        if($ip=='::1'){
            $ipadd = '127.0.0.1';
        } else {
            $ipadd = $ip;
        }
        $login_attempts_ipArr = $loginAttemptsTable->find('all', ['conditions' => ['ipaddress' => $ipadd]])->enableHydration(false)->toArray();

        $login_attempts_id = $login_attempts_ipArr[0]['id'];
        if($login_attempts_id){
            $entity = $loginAttemptsTable->get($login_attempts_id);
            $entityData = $loginAttemptsTable->patchEntity($entity, ['failed_attempts'=>0]);
            $loginAttemptsTable->save($entity);
        }
        //$this->Auth->config('logoutRedirect', ['controller' => 'Users', 'action' => 'login']);
        $this->redirect($this->Auth->logout());
    }

    /**
     * forgotPassword method
     *
     * @return \Cake\Network\Response|null
     */

    public function forgotPassword()
    {
        if ($this->request->getSession()->check('Auth.User')) {
            return $this->redirect(['controller' => 'Dashboard', 'action' => 'index']);
        }
        $this->viewBuilder()->setLayout('login');        
        if (!empty($this->request->getData())) {
           // $captcha = $this->Captcha->check($this->request->getData('captcha'));
		   $token = '';
            if (empty($captcha)) {
                if (empty($this->request->getData('email'))) {
                    $this->Flash->error('Please Provide email ');
                } else {
                    $username  = trim($this->request->getData('email'));
                    $validator = new Validator();
                    $validator->email('email');
                    $validError = $validator->errors(['email' => $username]);
                    if (empty($validError)) {
                        $UserExist = $this->Users->findByEmail($username)->first();
                    } else {
                        $UserExist = $this->Users->findByUsername($username)->first();
                    }
					$token = $this->__generateToken();
					
					if ($UserExist) {
						$query = $this->Users->query();
						$query->update()
						->set(['fp_token' => $token,'fp_token_at'=>date('Y-m-d H:i:s')])
						->where(['id' => $UserExist['id']])
						->execute();
						$link = Router::url('/admin/en/users/reset-password/' . $token.'/'.$UserExist['id'], true);
						$emailData = [
							'setHelpers'     => ['Html'],
							'setTemplate'    => 'forgot_password',
							'setEmailFormat' => 'html',
							'setTo'          => trim($UserExist->email),
							'setSubject'     => __('Forgot Password Reset'),
							'setViewVars'    => ['user' => $UserExist,'link'=>$link],
						];
						$this->Email->sendMail($emailData);
                   
						$this->Flash->success('Check your inbox for a password reset email.');

					}
				}
            } else {
                $this->Flash->error(__('Invalid captcha. Please try again.'));
            }
        }
    }

    public function userLog()
    {
        $this->loadModel('AdminLogs');
        $rid = $this->Auth->user('role_id');
        $adminLog = $this->AdminLogs->find('all')
            ->contain(['Users'])
            ->order(['AdminLogs.id'=>'DESC']);
        if ($rid != 1) {
            $adminLog = $adminLog->where(['uid' => $this->Auth->user('id')]);
        }
        $this->paginate = ['limit' => 20];
        $adminLog = $this->paginate($adminLog);
        $this->set(compact('adminLog'));
    }

    public function changePasswordHistory()
    {
        $changePasswordTable = TableRegistry::get('change_password_logs');
        $changePassword = $changePasswordTable->find('all')->where(['user_id'=>$this->Auth->user('id')]);
        $this->paginate = ['limit' => 20];
        $changePassword = $this->paginate($changePassword);
        $this->set(compact('changePassword'));
    }
    
    /**
     * Change Password method
     *
     * @return \Cake\Http\Response|void
     */

    public function changePassword()
    {
        $user = $this->Users->get($this->Auth->user('id'));
        if(!empty($_REQUEST))
        {
            $jcryption = new \JCryption;
            $jcryption->decrypt();
            $userdata = $_REQUEST;
            $user = $this->Users->patchEntity($user, [
                    'old_password'      => $userdata['old_password'],
                    'password'          => $userdata['new_password'],
                    'new_password'      => $userdata['new_password'],
                    'confirm_password'  => $userdata['confirm_password']
                ],
                    ['validate' => 'password']
            );
            if($this->Users->save($user)) 
            {
                $changePasswordTable = TableRegistry::get('change_password_logs');
                $changePassword = $changePasswordTable->newEntity();
                $ipaddress = $_SERVER['REMOTE_ADDR'];
                if ($ipaddress == '::1') {
                    $ipadd = '127.0.0.1';
                } else {
                    $ipadd = $ipaddress;
                }
                $changePassword->user_id = $user->id;
                $changePassword->password = $user->password;
                $changePassword->change_time = date('Y-m-d H:i:s');
                $changePassword->ip_address = inet_pton($ipadd);
                $changePasswordTable->save($changePassword);
                $this->Flash->success('Your password has been changed successfully.');
                //Email code
                //$this->redirect(['action'=>'view']);
            } else {
                if($user->errors()){
                    $error_msg = [];
                    foreach( $user->errors() as $errors){
                        if(is_array($errors)){
                            foreach($errors as $error){
                                $error_msg[]    =   $error;
                            }
                        }else{
                            $error_msg[]    =   $errors;
                        }
                    }
                    if(!empty($error_msg)){
                        $this->Flash->error(
                                    __("Please fix the following error(s):".implode("\r\n", $error_msg))
                        );
                    }
                }else{
                    $this->Flash->error('Error changing password. Please try again!');
                }
            }
        }
        $this->set('user',$user);
    }

    /**
     * Change User Password method
     *
     * @return \Cake\Http\Response|void
     */

    public function changeUserPassword($userId=null)
    {
        if (empty($userId)) {
            $this->Flash->success('Select user for change password.');
            return $this->redirect(['controller'=>'Registration','action'=>'index']);
        }

        $user = $this->Users->get($userId);        
        if(!empty($this->request->data)){
            $user = $this->Users->patchEntity($user, [
                    'password' => $this->request->data['new_password'],
                    'password_hint' =>  $this->request->data['new_password']
                ]
            );
            if($this->Users->save($user)) {
                $this->Flash->success('Your password has been changed successfully');
                $this->redirect(['controller'=>'Registers','action'=>'index']);
            } else {
                if($user->errors()){
                    $error_msg = [];
                    foreach( $user->errors() as $errors){
                        if(is_array($errors)){
                            foreach($errors as $error){
                                $error_msg[]    =   $error;
                            }
                        }else{
                            $error_msg[]    =   $errors;
                        }
                    }
                    if(!empty($error_msg)){
                        $this->Flash->error(
                                    __("Please fix the following error(s):".implode("\r\n", $error_msg))
                        );
                    }
                }else{
                    $this->Flash->error('Error changing password. Please try again!');
                }
            }
        }
        $this->set('user',$user);
    }
    
    /**
     * Reset Password method
     *
     * @return \Cake\Http\Response|void
     */

	public function resetPassword($fp_token = null)
    {
        $this->loadModel('Users');
        if ($this->request->getSession()->check('Auth.User')) {
            return $this->redirect(['controller' => 'NewArticles', 'action' => 'pending-articles']);
        }
        $this->viewBuilder()->setLayout('login'); 
        $user = $this->Users->newEntity();
        if (isset($fp_token)) {
            $TokenExist = $this->Users->findByFpToken($fp_token)->first();
            if ($TokenExist) {
                $tokenGeneratedDate = $TokenExist['fp_token_at'];
                $convertDate        = date("Y-m-d", strtotime($tokenGeneratedDate));
                if (strtotime($convertDate) <= strtotime('-1 day')) {
                    $TokenExist->fp_token    = "";
                    $TokenExist->fp_token_at = "";
                    $this->Users->save($TokenExist);
                    $this->Flash->error('Your link has been expired, try again.');
                    return $this->redirect(['controller' => 'Users', 'action' => 'login']);
                } else {
                    if ($this->request->is('post')) {
                        $errors = [];
                       /* if ($this->Captcha->getCode('securitycode') != $this->request->getData('securitycode')) {
                            $errors['captcha']['_empty'] = 'Invalid captcha,try again.';
                        }*/
                        if (empty($errors)) {
                            $user = $this->Users->patchEntity($TokenExist, [
                                'password'         => $this->request->getData('password'),
                                'confirm_password' => $this->request->getData('confirm_password'),
                            ]);
                            $user->fp_token    = "";
                            $user->status    = 1;
                            $user->fp_token_at = date('Y-m-d H:i:s');
                           // echo "<pre>"; print_r($user); exit;
                            if($this->request->getData('confirm_password') == $this->request->getData('password')){
                                if ($this->Users->save($user)) {
                                   
                                    $this->Flash->success(__('Your Password is changed'));
                                    return $this->redirect(['controller' => 'Users', 'action' => 'login']);
                                }
                            }
                            else{
                                $this->Flash->error(__('The passwords does not match!'));
                            }
                        } else {
                            $this->Flash->error(__($errors['captcha']['_empty']));
                        }
                    }
                }
            } else {
                $this->Flash->error(__('Invalid Token.'));
                return $this->redirect(['controller' => 'Users', 'action' => 'login']);
            }
        } else {
            $this->Flash->error(__('Something missing in URL.'));
            return $this->redirect(['controller' => 'Users', 'action' => 'login']);
        }
        $this->set(compact('fp_token', 'user'));
        $this->set('_serialize', ['fp_token']);
    }

    /*
	public function resetPassword($val=null)
    {
        $this->viewBuilder()->setLayout('login');
        $user_id   = !empty($this->request->query['q1'])? base64_decode($this->request->query['q1']) : null;
        $current_time  = !empty($this->request->query['q2'])? base64_decode($this->request->query['q2']) : null;
        $expire_time   = $current_time + 10*60;
        if(time() < $expire_time){
            if(!empty($user_id)) {
                $user = $this->Users->get($user_id);
                if ($this->request->is(['post','put','patch'])) {
                    $password = $this->request->data['password'];
                    $confirmPassword = $this->request->data['confirm_password'];
                    if($password==$confirmPassword){
                        $user = $this->Users->patchEntity($user, ['password' => $password]);
                        $user->password_hint = $confirmPassword;
                        if ($this->Users->save($user)) {
                            $this->Flash->success(__('Your password has been changed successfully.'));
                            $this->redirect(['controller' => 'Users', 'action' => 'login']);
                        } else {
                        $this->Flash->error(__('The password could not be changed. Please, try again.'));
                        }
                    }else{
                        $this->Flash->error(__('Confirm password does not match. Please, try again.'));
                    }
                }
            } else {
            //$this->redirect(['controller' => 'Users', 'action' => 'pnLogin']);
            }
        } else {
        $this->Flash->error(__('Your time is expire. Please, try again.'));
        }
    } */ 

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */  
    public function index() 
    {
		$role = $this->Auth->user('role_id');
		$id = $this->Auth->user('id');
		if($role ==3){
			$query = $this->Users->find()->contain(['Roles','Languages'])->order(['Users.id'=>'DESC'])->where(['Users.id'=>$id])->orWhere(['user_id' => $id]);
       
		}
		else{
			$query = $this->Users->find()->contain(['Roles','Languages'])->order(['Users.id'=>'DESC']);
		}
         $users = $this->paginate($query);
		//echo "<pre>"; print_r($users); exit;
        //$users = $this->paginate($this->Users);
        $this->set(compact('users'));
    }

    /**
     * View method
     *
     * @param string|null $id User id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $user = $this->Users->get($id, [
            'contain' => ['Roles','Registration']
        ]);
//echo "<pre>"; print_r($user); exit;
        $this->set('user', $user);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function addUser()
    {
		$this->loadModel('States');
		$this->loadModel('Registration');
		$this->loadModel('Languages');
		$user_id = $this->Auth->user('id');
        $user = $this->Users->newEntity();
        if ($this->request->is('post')) {
            $token = $this->__generateToken();
			$userdata = $this->request->data;
			$userName = preg_replace('/([^@]*).*/', '$1', $userdata['email']);
			$password = trim('Ritam@123');
			$password = $this->Sanitize->stripAll( $password);
			$password = $this->Sanitize->clean( $password);
			$userRecord = [
				'name'          => $userdata['name'],
				'username'      => $userName,
				'email'         => $userdata['email'],
				'password'      => $password,
				'user_id'       => $user_id,
				'role_id'       => $userdata['role_id'],
				'language_id'   => isset($userdata['language_id']) && $userdata['language_id'] !=''?$userdata['language_id']:0,
				'state_id'      => isset($userdata['state_id']) && $userdata['state_id'] !=''?$userdata['state_id']:0,
				'mobile_no'     => isset($userdata['mobile_no']) && $userdata['mobile_no'] !=''?$userdata['mobile_no']:'',
				'status'        => 1,
				//'password_hint' => $userdata['confirm_password'],
				'fp_token'      => $token,
				'fp_token_at'   => date('Y-m-d H:i:s')
			];
			$user = $this->Users->patchEntity($user, $userRecord);
			//echo "<pre>"; print_r($user); exit;
            if ($result = $this->Users->save($user)) {
               $UserExist = $this->Users->get($result->id);
			  /*  $mob = isset($UserExist['mobile_no']) && $UserExist['mobile_no'] !=''?$UserExist['mobile_no']:'';
				$link = Router::url('/admin/en/users/reset-password/' . $token.'/'.$result->id, true);
				$link2 = Router::url('/admin/en/users/login/', true);
				$emailData = [
					'setHelpers'     => ['Html'],
					'setTemplate'    => 'activation_email',
					'setEmailFormat' => 'html',
					'setTo'          => trim($UserExist->email),
					'setSubject'     => __('Ritam – Registration Successful'),
					'setViewVars'    => ['name' => $userdata['name'],'link'=>$link,'link2'=>$link2,'email'=>$UserExist->email,'mobile'=>$mob],
				];
				$this->Email->sendMail($emailData); */
				$this->loadModel('Registration');
				$registration = $this->Registration->newEntity();
				$registration->user_id  = $result->id;
				$registration->email    = $userdata['email'];
				$registration->state_id    = isset($userdata['state_id']) && $userdata['state_id'] !=''?$userdata['state_id']:0;
				$registration->country_id = 'India';
				if(!empty($userdata['pincode'])){
                        $registration->pincode = $userdata['pincode'];
                    } else {
                        $registration->pincode = null;
                    }
				if(!empty($userdata['address'])){
					$registration->address = $userdata['address'];
				}
				if(!empty($userdata['gender'])){
					$registration->gender     = $userdata['gender'];
				}
				//echo "<pre>"; print_r($registration); exit;
				if ($this->Registration->save($registration)) {	
					
					/*$sample_data = array('authorDescription'=>($application->application_number),'authorName' => $application->producer_name, 'email' => $application->state_name,'id'=>$application->district_name,'languages'=>$application->city_name,'profileUrl'=>$application->email,'ratings'=>(int)$application->contact,'topics'=>$application->address_1.' '.$application->address_2);
                        $data_string = json_encode($sample_data);
                        $url = 'http://staging.ritamdigital.org/services/ritam/api/authors/external';
						
                        $ch = curl_init($url);
                        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
                        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
                        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                            'Content-Type: application/json',
                            'Content-Length: ' . strlen($data_string))
                        );
                        $response = curl_exec($ch);*/
						//echo "<pre>"; print_r($response); exit;
					//	$this->getApplicationAppId(json_decode($response),$application->id);
						
						//echo "<pre>"; print_r(json_decode($response)); exit;
                        //curl_close($ch);
				
					
				}
				$this->Flash->success(__('user has been added and email has been sent to him.'));
					return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The user could not be saved. Please, try again.'));
        }
		$role_id = $this->Auth->user('role_id');
		$language_id = $this->Auth->user('language_id');
        if($role_id == 3){
			$roles = $this->Users->Roles->find('list', array(
				'conditions' => array('Roles.id' => 2)
			));
			$lang = $this->Languages->find('list',array('conditions'=>array('id'=>$language_id)));
		}
		else if($role_id == 1){
			$lang = $this->Languages->find('list', ['limit' => 200]);
			$roles = $this->Users->Roles->find('list');
		}
		
        
        $states = $this->States->find('list', ['limit' => 200]);
		//echo "<pre>"; print_r($states); exit;
        $this->set(compact('user', 'roles','lang','states'));
    }
	public function __generateToken($length = 12) {
        $characters = '123456789ABCDEFGHIJKLMNPQRSTUVWXYZabcdefghijklmnpqrstuvwxyz';
        $string = '';

        for ($i = 0; $i < $length; $i++) {
            $string .= $characters[mt_rand(0, strlen($characters) - 1)];
        }

        return $string;
    }
	protected function __sendActivationEmail($user_id, $token)
    {
        if (empty($token) && empty($user_id)) {
            $this->Flash->success(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'login']);
        }
        $user = $this->Users->find()->where(['id'=>$user_id])->first();
        $link = Router::url('/admin/en/users/reset-password/' . $token.'/'.$user->id, true);
         $to = $user['email'];
        $subject = 'Ritam – Registration Successful';
        $email = new Email('default');
        $email->template('activation_email')
            ->viewVars(['link'=>$link,'name'=>$user['name']]);
            $email->addTo(trim($to));
            $email->from(['singhabhay396@gmail.com'])
            ->subject($subject)
            ->emailFormat('html')
            ->send();
    }

    public function registrationVerification($token,$user_id)
    {
        if (empty($token) && empty($user_id)) {
            $this->Flash->success(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'login']);
        }
        $user = $this->Users->find()->where(['id'=>$user_id,'fp_token'=>$token])->first();
        if (empty($user['status'])) {
            $query = $this->Users->query();
            $query->update()
            ->set(['status'=>1,'fp_token'=>null,'fp_token_at'=>null])
            ->where(['id' => $user->id])
            ->execute();

            $this->Flash->success(__('Your account has been successfully activated.'));
        } elseif ($user['status'] == 1) {
            $this->Flash->success(__('Your account has already been activated.'));            
        }
        return $this->redirect(['action' => 'login']);
    }


    /**
     * Edit method
     *
     * @param string|null $id User id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
		$this->loadModel('Languages');
		$this->loadModel('States');
        $user = $this->Users->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $user = $this->Users->patchEntity($user, $this->request->getData());
            if ($this->Users->save($user)) {
                $this->Flash->success(__('The user has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The user could not be saved. Please, try again.'));
        }
		$lang = $this->Languages->find('list', ['limit' => 200]);
        $states = $this->States->find('list', ['limit' => 200]);
        $roles = $this->Users->Roles->find('list', ['limit' => 200]);
        $this->set(compact('user', 'roles','lang','states'));
    }

    /**
     * Delete method
     *
     * @param string|null $id User id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $user = $this->Users->get($id);
        $loginUser = $this->Auth->user();
        if ($user->id != $loginUser['id']) {
            if ($user->role_id != 1) {
                if ($this->Users->delete($user)) {
                    $this->Flash->success(__('The user has been deleted.'));
                } else {
                    $this->Flash->error(__('The user could not be deleted. Please, try again.'));
                }
            } else {
                $this->Flash->error(__('You are not authorized to delete this user.'));
            }
        } else {
            $this->Flash->error(__('You can not delete currently logged in User.'));
        }

        return $this->redirect(['action' => 'index']);
    }

    public function __generatePasswordToken($user)
    {
        if (empty($user)) {
            return null;
        }
        $token = "";
        // Generate a random string 100 chars in length.
        for ($i = 0; $i < 100; $i++) {
            $d = rand(1, 100000) % 2;
            $d ? $token .= chr(rand(33, 79)) : $token .= chr(rand(80, 126));
        }
        (rand(1, 100000) % 2) ? $token = strrev($token) : $token = $token;

        // Generate a hash of random string
        $hash = Security::hash($token, 'sha256', true);;
        for ($i = 0; $i < 20; $i++) {
            $hash = Security::hash($hash, 'sha256', true);
        }
        $user['User']['reset_password_token'] = $hash;
        $user['User']['token_created_at'] = date('Y-m-d H:i:s');
    }

    public function jcryption()
    {
        $this->autoRender = false;
        $jc = new \JCryption;
        $jc->go();
        header('Content-type: text/plain');
    }

    public function captcha()
    {
        $this->autoRender = false;
        echo $this->Captcha->image(5);
    }
	public function updateProfile($id = null){
		$this->loadModel('Languages');
		$this->loadModel('States');
		$this->loadModel(ArticleCategories);
		$article_categories = $this->ArticleCategories->find('all')->toArray();
		/*$user = $this->Users->get($id, [
            'contain' => ['Registration','Roles','Registration.States']
        ]);*/
        $user = $this->Users->get($id, [
            'contain' => ['Roles']
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $data = $this->request->getData();
			//echo "<pre>"; print_r($data); exit;
            $event = $this->Users->patchEntity($user, $data);
            if($data['profile_image']['name']!=''){
				
				$image = $this->uploadFiles('events', $data['profile_image']);
				$event->profile_photo = $image['filename'];
				
			}else{
				$event->profile_photo = @$data['profile_image_old'];
			}
			$event->created = date('Y-m-d H:i:s');
			$event->state_id = $data['state_id'];
			//echo "<pre>"; print_r($event); exit;
            if ($this->Users->save($event)) {
				$this->loadModel('UserInterests');
				$role_id = $this->Auth->user('role_id');
				$article_id = $id;
				$this->UserInterests->deleteAll(['user_id' => $article_id]);
				$cat_id = explode(',',$data['cat_id']);
				for($i=0;$i<sizeof($cat_id);$i++){
					//$referenceData = $this->ArticleTags->find()->where(['name' => $tag[$i],'article_id'=>$article_id])->toArray();
						$tags[$i]['cat_id'] = $cat_id[$i];
						$tags[$i]['user_id'] = $article_id;
				}
					$tags_en  = $this->UserInterests->newEntity();
					$artic  = $this->UserInterests->patchEntities($tags_en, $tags);
					$articleLinss = $this->UserInterests->saveMany($artic);
                $this->Flash->success(__('Profile has been updated'));
				if($role_id ==1){
					return $this->redirect(['controller'=>'users','action' => 'index']);
				}
				else {
					return $this->redirect(['controller'=>'new-articles','action' => 'pending-articles']);
				}
                
            }
            $this->Flash->error(__('The profile could not be saved. Please, try again.'));
        }
		$lang = $this->Languages->find('list', ['limit' => 200]);
        $states = $this->States->find('list', ['limit' => 200]);
        $role_id = $this->Auth->user('role_id');
        if($role_id == 3){
			$roles = $this->Users->Roles->find('list', array(
				'conditions' => array('Roles.id' => 2)
			));
		}
		else{
			$roles = $this->Users->Roles->find('list');
		}
		//echo "<pre>"; print_r($user); exit;
        $this->set(compact('event','user', 'roles','lang','states','article_categories'));
	}
	public function getUserField(){
		$this->viewBuilder()->layout('ajax');
        $district_id = $_POST['district_id'];
        $this->loadModel('States');
		$this->loadModel('Registration');
		$this->loadModel('Languages');
        $role_id = $this->Auth->user('role_id');
        if($role_id == 3){
			$roles = $this->Users->Roles->find('list', array(
				'conditions' => array('Roles.id' => 2)
			));
		}
		else{
			$roles = $this->Users->Roles->find('list');
		}
        $lang = $this->Languages->find('list', ['limit' => 200]);
        $states = $this->States->find('list', ['limit' => 200]);
        $this->set(compact('roles','lang','states'));
	}

}