<?php
namespace App\Controller\Admin;

use App\Controller\Admin\AppController;
use Cake\Event\Event;
use Cake\Utility\Hash;

/**
 * GalleryCategories Controller
 *
 * @property \App\Model\Table\GalleryCategoriesTable $GalleryCategories
 *
 * @method \App\Model\Entity\GalleryCategory[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class PressCategoriesController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
		$this->loadModel('PressCategory');
        $this->paginate = [ ];
        $pcCategories = $this->paginate($this->PressCategories);

        $this->set(compact('pcCategories'));
    }

    /**
     * View method
     *
     * @param string|null $id Gallery Category id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $pressCategory = $this->PressCategories->get($id, [
            'contain' => [ ]
        ]);

        $this->set('pressCategory', $pressCategory);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $PressCategory = $this->PressCategories->newEntity();
        if ($this->request->is('post')) {
			$data = $this->request->getData();
            $PressCategory = $this->PressCategories->patchEntity($PressCategory, $this->request->getData());
			if($data['filename']['name']!=''){
                $fileName = $this->uploadFiles('presscoverage', $data['filename']);
                $PressCategory->filename  = $fileName['filename'];
                $PressCategory->filemime  = $fileName['type'];
                $PressCategory->filesize  = $fileName['size'];
            }
            if ($this->PressCategories->save($PressCategory)) {
                $this->Flash->success(__('The Press category has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The Press category could not be saved. Please, try again.'));
        }
       
        $this->set(compact('PressCategory'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Gallery Category id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $PressCategory = $this->PressCategories->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
			$data = $this->request->getData();
            $PressCategory = $this->PressCategories->patchEntity($PressCategory, $this->request->getData());
			if($data['filename']['name']!=''){
                $fileName = $this->uploadFiles('presscoverage', $data['filename']);
                $PressCategory->filename  = $fileName['filename'];
                $PressCategory->filemime  = $fileName['type'];
                $PressCategory->filesize  = $fileName['size'];
            } else {
                $PressCategory->filename  = $data['old_filename'];
                $PressCategory->filemime  = $data['old_filemime'];
                $PressCategory->filesize  = $data['old_filesize'];
            }
            if ($this->PressCategories->save($PressCategory)) {
                $this->Flash->success(__('The press category has been saved.'));
                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The press category could not be saved. Please, try again.'));
        }
       
        $this->set(compact('PressCategory'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Gallery Category id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $PressCategory = $this->PressCategories->get($id);
        if ($this->PressCategories->delete($PressCategory)) {
            $this->Flash->success(__('The press category has been deleted.'));
        } else {
            $this->Flash->error(__('The press category could not be deleted. Please, try again.'));
        }
        return $this->redirect(['action' => 'index']);
    }
	
	
}
