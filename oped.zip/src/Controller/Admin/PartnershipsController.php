<?php
namespace App\Controller\Admin;

use App\Controller\Admin\AppController;
use Cake\Cache\Cache;
use Cake\Event\Event;
use Cake\Network\Exception\NotFoundException;
use Cake\Utility\Hash;
use Cake\Utility\Text;
use Cake\View\Exception\MissingTemplateException;

/**
 * Partnerships Controller
 *
 * @property \App\Model\Table\PartnershipsTable $Partnerships
 *
 * @method \App\Model\Entity\Partnership[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class PartnershipsController extends AppController
{
    public function initialize()
    {
        parent::initialize();
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {

        $search_condition = array();
        $data = $this->Sanitize->clean($this->request->getQuery());
        if (!empty($data['title'])) {
            $postTitle = trim($data['title']); 
            $this->set('title', $postTitle);
            $search_condition[] = "Partnerships.title like '%" . $postTitle . "%'";
        }
        
        if (isset($this->request->query['status']) && $data['status'] !='') {
            $status = trim($data['status']);
            $this->set('status', $status);
            $search_condition[] = "Partnerships.status = '" . $status . "'";
        }

        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        //pr($search_condition); die;
        $postQuery = $this->Partnerships->find('all', [
            'order' => ['Partnerships.id' => 'desc'],
            'conditions' => [$searchString]
        ]);
        
        $partnerships = $this->paginate($postQuery);

        $this->set(compact('partnerships'));
    }

    /**
     * View method
     *
     * @param string|null $id Partnership id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $partnership = $this->Partnerships->get($id, [
            'contain' => ['Users', 'PartnershipTranslations']
        ]);

        $this->set('partnership', $partnership);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $partnership = $this->Partnerships->newEntity();
        if ($this->request->is('post')) {
            $data = $this->request->getData();
            $partnership_translations = [];
            if (isset($data['partnership_translations'])) {
                $partnership_translations = $data['partnership_translations'];
                unset($data['partnership_translations']);
            }
            $partnership->created = date('Y-m-d H:i:s');
            $partnership = $this->Partnerships->patchEntity($partnership, $data);
            if($data['logo_image']['name']!=''){
                $logoImage = $this->uploadImage('partnerships', $data['logo_image']);
                $partnership->logo_image = $logoImage['filename'];
            }
            if ($this->Partnerships->save($partnership)) {
                $partnership_id = $partnership->id;
                if (!empty($partnership_translations)) {
                    $this->loadModel('PartnershipTranslations');
                    foreach ($partnership_translations as $key => $_translation) {
                        if (empty($_translation['id'])) {
                            unset($partnership_translations[$key]['id']);
                        }
                        $partnership_translations[$key]['partnership_id'] = $partnership_id;
                    }
                    $partnershipTranslation  = $this->PartnershipTranslations->newEntity();
                    $partnershipTranslation  = $this->PartnershipTranslations->patchEntities($partnershipTranslation, $partnership_translations);
                    $partnershipTranslations = $this->PartnershipTranslations->saveMany($partnershipTranslation);
                }
                $this->Flash->success(__('The partnership has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The partnership could not be saved. Please, try again.'));
        }
        $partnershipLanguages  = $this->languages;
        $system_languge_id = SYSTEM_LANGUAGE_ID;
        $this->set(compact('partnership','partnershipLanguages','system_languge_id'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Partnership id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $partnership = $this->Partnerships->get($id, [
            'contain' => ['PartnershipTranslations']
        ]);
        $partnership['partnership_translations'] = Hash::combine($partnership['partnership_translations'], '{n}.language_id', '{n}');

        if ($this->request->is(['patch', 'post', 'put'])) {
            $data = $this->request->getData();
            $partnership_translations = [];
            if (isset($data['partnership_translations'])) {
                $partnership_translations = $data['partnership_translations'];
                unset($data['partnership_translations']);
            }            
            $partnership = $this->Partnerships->patchEntity($partnership, $data);
            $partnership->modified = date('Y-m-d H:i:s');
            if($data['logo_image']['name']!=''){
                $logoImage = $this->uploadImage('partnerships', $data['logo_image']);
                $partnership->logo_image = $logoImage['filename'];
            } else {
                $partnership->logo_image = $data['old_logo_image'];
            }
            if (empty($data['url'])) {
                $partnership->url        = strtolower(Text::slug($data['title']));
            } else {
                $partnership->url        = strtolower(Text::slug($data['url']));
            }
            if ($this->Partnerships->save($partnership)) {
                $partnership_id = $partnership->id;
                if (!empty($partnership_translations)) {
                    $this->loadModel('PartnershipTranslations');
                    foreach ($partnership_translations as $key => $_translation) {
                        if (empty($_translation['id'])) {
                            unset($partnership_translations[$key]['id']);
                        }
                        $partnership_translations[$key]['partnership_id'] = $partnership_id;
                    }
                    $partnershipTranslation  = $this->PartnershipTranslations->newEntity();
                    $partnershipTranslation  = $this->PartnershipTranslations->patchEntities($partnershipTranslation, $partnership_translations);
                    $partnershipTranslations = $this->PartnershipTranslations->saveMany($partnershipTranslation);
                }
                $this->Flash->success(__('The partnership has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The partnership could not be saved. Please, try again.'));
        }
        $partnershipLanguages  = $this->languages;
        $system_languge_id = SYSTEM_LANGUAGE_ID;
        $this->set(compact('partnership','partnershipLanguages','system_languge_id'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Partnership id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $partnership = $this->Partnerships->get($id);
        if ($this->Partnerships->delete($partnership)) {
            $this->Flash->success(__('The partnership has been deleted.'));
        } else {
            $this->Flash->error(__('The partnership could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
