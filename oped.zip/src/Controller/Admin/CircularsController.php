<?php
namespace App\Controller\Admin;

use App\Controller\Admin\AppController;
use Cake\Cache\Cache;
use Cake\Event\Event;
use Cake\Network\Exception\NotFoundException;
use Cake\Utility\Hash;
use Cake\View\Exception\MissingTemplateException;
use Cake\Core\Configure;
use Cake\Utility\Text;
use Cake\ORM\TableRegistry;

/**
 * Circulations Controller
 *
 *
 * @method \App\Model\Entity\Circulation[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class CircularsController extends AppController
{

    public function initialize()
    {
        parent::initialize();
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }

    private $documentTypes = [
        1 => 'Documents',
        2 => 'Corrignedum',
        3 => 'Annexure'
    ];

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {

        $search_condition = array();
        
        if (!empty($this->request->getQuery('title'))) {
            $postTitle = trim($this->request->getQuery('title')); 
            $this->set('title', $postTitle);
            $search_condition[] = "Circulars.title like '%" . $postTitle . "%'";
        }
        
        if (isset($this->request->query['status']) && $this->request->getQuery('status') !='') {
            $status = trim($this->request->getQuery('status'));
            $this->set('status', $status);
            $search_condition[] = "Circulars.status = '" . $status . "'";
        }

        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
       
        $postQuery = $this->Circulars->find('all', [
            'contain' => ['Users'],
            'order' => ['Circulars.id' => 'desc'],
            'conditions' => [$searchString]
        ]);
        $this->paginate = ['limit' => 10];
        $circulars = $this->paginate($postQuery);
        
        $this->set(compact('circulars'));
    }

    /**
     * View method
     *
     * @param string|null $id Circulation id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $circular = $this->Circulars->get($id, [
            'contain' => []
        ]);

        $this->set('circular', $circular);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $circular = $this->Circulars->newEntity();
        if ($this->request->is('post')) {
            $data                 = $this->request->getData();
			
            $circular_translations  = [];
            if (isset($data['circular_translations'])) {
                $circular_translations = $data['circular_translations'];
                unset($data['circular_translations']);                
            }
            $circular_documents = [];
            if (isset($data['circular_documents'])) {
                $circular_documents   = $data['circular_documents'];
                unset($data['circular_documents']);
            }
            $tcircular_documents = [];
            if (isset($circular_translations['circular_documents'])) {
                $tcircular_documents  = $circular_translations['circular_documents'];
                unset($circular_translations['circular_documents']);
            }  
            $circular_documents       = array_merge($circular_documents, $tcircular_documents);  
            $circular->created        = date('Y-m-d H:i:s');
            $circular                 = $this->Circulars->patchEntity($circular, $data); 
            $circular->circulation_date    = date('Y-m-d',strtotime($data['circulation_date']));
            $circular->last_date      = date('Y-m-d',strtotime($data['last_date']));
            if (empty($data['url'])) {
                $circular->url        = strtolower(Text::slug($data['title']));
            } else {
                $circular->url        = strtolower(Text::slug($data['url']));
            }
           // debug($circular); die;
            if ($abc = $this->Circulars->save($circular)) {
                $circular_id = $circular->id;                 
                if (!empty($circular_translations)) {
                    $this->loadModel('CircularTranslations');
                    foreach ($circular_translations as $key => $_translation) {
                        if (empty($_translation['id'])) {
                            unset($circular_translations[$key]['id']);
                        }
                        $circular_translations[$key]['circular_id'] = $circular_id;
                    }
                    $circularTranslation  = $this->CircularTranslations->newEntity();
                    $circularTranslation  = $this->CircularTranslations->patchEntities($circularTranslation, $circular_translations);
                    $circularTranslations = $this->CircularTranslations->saveMany($circularTranslation);  
                } 
                if (!empty($circular_documents)) {
                    $this->loadModel('CircularDocuments');
                    foreach ($circular_documents as $key => $_document) {
                        if (empty($_document['id'])) {
                            unset($circular_documents[$key]['id']);
                        }
                        if($_document['documents']['name']!=''){
                            $circularDoc = $this->uploadFiles('circulars', $_document['documents']);
                            $circular_documents[$key]['documents'] = $circularDoc['filename'];
                        }
                        $circular_documents[$key]['circular_id'] = $circular_id;
                        $circular_documents[$key]['status']    = 1;
                    }
                    $circularDocument  = $this->CircularDocuments->newEntity();
                    $circularDocument  = $this->CircularDocuments->patchEntities($circularDocument, $circular_documents);
                    $circularDocuments = $this->CircularDocuments->saveMany($circularDocument); 
                } 
                $this->Flash->success(__('The Circular has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The Circular could not be saved. Please, try again.'));
        }
        $documentTypes = $this->documentTypes; 
        $circularLanguages  = $this->languages;
        $system_languge_id = SYSTEM_LANGUAGE_ID;
        $this->set(compact('circular', 'circularLanguages', 'system_languge_id','documentTypes'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Circulation id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $circular = $this->Circulars->get($id, [
            'contain' => ['CircularTranslations','CircularDocuments']
        ]);
        $circular['circular_translations'] = Hash::combine($circular['circular_translations'], '{n}.language_id', '{n}');
        if(!empty($circular['circular_documents'])){
            $circular['english_document'] = array_filter($circular['circular_documents'], function($el) { return $el['language_id'] == 1 ; });
            $circular['hindi_document'] = array_filter($circular['circular_documents'], function($el) { return $el['language_id'] == 2 ; });
            unset($circular['circular_documents']);
        }

        if ($this->request->is(['patch', 'post', 'put'])) {
            $data                = $this->request->getData();
            $circular_translations = [];
            if (isset($data['circular_translations'])) {
                $circular_translations = $data['circular_translations'];
                unset($data['circular_translations']);
            }
            $circular_documents = [];
            if (isset($data['circular_documents'])) {
                $circular_documents   = $data['circular_documents'];
                unset($data['circular_documents']);
            }
            $tcircular_documents = [];
            if (isset($circular_translations['circular_documents'])) {
                $tcircular_documents  = $circular_translations['circular_documents'];
                unset($circular_translations['circular_documents']);
            }
            $circular_documents       = array_merge($circular_documents, $tcircular_documents);
            $circular->updated        = date('Y-m-d H:i:s');
            $circular                 = $this->Circulars->patchEntity($circular, $data);
            $circular->circulation_date    = date('Y-m-d',strtotime($data['circulation_date'])); 
            $circular->last_date      = date('Y-m-d',strtotime($data['last_date']));
            if (empty($data['url'])) {
                $circular->url        = strtolower(Text::slug($data['title']));
            } else {
                $circular->url        = strtolower(Text::slug($data['url']));
            }
            if ($this->Circulars->save($circular)) {
                $circular_id = $circular->id;
                if (!empty($circular_translations)) {
                    $this->loadModel('CircularTranslations');
                    foreach ($circular_translations as $key => $_translation) {
                        if (empty($_translation['id'])) {
                            unset($circular_translations[$key]['id']);
                        }
                        $circular_translations[$key]['circular_id'] = $circular_id;
                    }
                    $circularTranslation  = $this->CircularTranslations->newEntity();
                    $circularTranslation  = $this->CircularTranslations->patchEntities($circularTranslation, $circular_translations);
                    $circularTranslations = $this->CircularTranslations->saveMany($circularTranslation);
                    //$this->Tenders->tenderCache();
                }
                if (!empty($circular_documents)) {
                    $this->loadModel('CircularDocuments');
                    foreach ($circular_documents as $key => $_document) {
                        if (empty($_document['id'])) {
                            unset($circular_documents[$key]['id']);
                        }
                        if($_document['documents']['name']!=''){
                            $circularDoc = $this->uploadFiles('circulars', $_document['documents']);
                            $circular_documents[$key]['documents'] = $circularDoc['filename'];
                        } else {
                            $circular_documents[$key]['documents'] = $_document['old_documents'];
                        }
                        $circular_documents[$key]['circular_id'] = $circular_id;
                        $circular_documents[$key]['status']    = 1;
                    }
                    $circularDocument  = $this->CircularDocuments->newEntity();
                    $circularDocument  = $this->CircularDocuments->patchEntities($circularDocument, $circular_documents);
                    $circularDocuments = $this->CircularDocuments->saveMany($circularDocument);
                }
                $this->Flash->success(__('The circular has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The circular could not be saved. Please, try again.'));
        }
        $documentTypes = $this->documentTypes;
        $circularLanguages  = $this->languages;
        $system_languge_id = SYSTEM_LANGUAGE_ID;
        $this->set(compact('circular','circularLanguages','system_languge_id','documentTypes'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Circulation id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $circular = $this->Circulars->get($id);
        if ($this->Circulars->delete($circular)) {
			$this->loadmodel('CircularDocuments');
            $this->loadmodel('CircularTranslations');
            $this->CircularDocuments->deleteAll(['circular_id' => $id]);
            $this->CircularTranslations->deleteAll(['circular_id' => $id]);
            $this->Flash->success(__('The Circular has been deleted.'));
        } else {
            $this->Flash->error(__('The Circular could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }

    public function deleteRow()
    {
        $this->viewBuilder()->setLayout('ajax');
        $row_id         = $_POST['id'];
        $table_name     = $_POST['table_name'];
        $custumTable    = TableRegistry::getTableLocator()->get($table_name);
        $removeQuery    = $custumTable->get($row_id);
        if($custumTable->delete($removeQuery)){
            echo 'removed';            
        }
        exit;  
    }
}
