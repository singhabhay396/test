<?php
namespace App\Controller\Admin;

use App\Controller\Admin\AppController;

/**
 * GovernmentBodies Controller
 *
 * @property \App\Model\Table\GovernmentBodiesTable $GovernmentBodies
 *
 * @method \App\Model\Entity\GovernmentBody[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class GovernmentBodiesController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $search_condition = array();
        $data = $this->Sanitize->clean($this->request->getQuery());
        if (!empty($data['title'])) {
            $postTitle = trim($data['title']); 
            $this->set('title', $postTitle);
            $search_condition[] = "GovernmentBodies.title like '%" . $postTitle . "%'";
        }
        
        if (isset($data['status']) && $data['status'] !='') {
            $status = trim($data['status']);
            $this->set('status', $status);
            $search_condition[] = "GovernmentBodies.status = '" . $status . "'";
        }

        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        //pr($search_condition); die;
        $postQuery = $this->GovernmentBodies->find('all', [
            'order' => ['GovernmentBodies.id' => 'desc'],
            'conditions' => [$searchString]
        ]);
        $this->paginate = ['limit' => 10];

        $governmentBodies = $this->paginate($postQuery);

        $this->set(compact('governmentBodies'));
    }

    /**
     * View method
     *
     * @param string|null $id Government Body id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $governmentBody = $this->GovernmentBodies->get($id, [
            'contain' => []
        ]);

        $this->set('governmentBody', $governmentBody);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $governmentBody = $this->GovernmentBodies->newEntity();
        if ($this->request->is('post')) {
            $data = $this->request->getData();
            $governmentBody = $this->GovernmentBodies->patchEntity($governmentBody, $this->request->getData());
            if($data['image']['name']!=''){
                $image = $this->uploadFiles('government_bodies', $data['image']);
                $governmentBody->image = $image['filename'];
            }
            if ($this->GovernmentBodies->save($governmentBody)) {

                $this->Flash->success(__('The government body has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The government body could not be saved. Please, try again.'));
        }
        $this->set(compact('governmentBody'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Government Body id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $governmentBody = $this->GovernmentBodies->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $data = $this->request->getData();
            $governmentBody = $this->GovernmentBodies->patchEntity($governmentBody, $this->request->getData());
            if($data['image']['name']!=''){
                $image = $this->uploadFiles('government_bodies', $data['image']);
                $governmentBody->image = $image['filename'];
            }else{
                $governmentBody->image = $data['old_image'];
            }
            if ($this->GovernmentBodies->save($governmentBody)) {
                $this->Flash->success(__('The government body has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The government body could not be saved. Please, try again.'));
        }
        $this->set(compact('governmentBody'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Government Body id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $governmentBody = $this->GovernmentBodies->get($id);
        if ($this->GovernmentBodies->delete($governmentBody)) {
            $this->Flash->success(__('The government body has been deleted.'));
        } else {
            $this->Flash->error(__('The government body could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
