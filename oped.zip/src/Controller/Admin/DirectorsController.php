<?php
namespace App\Controller\Admin;

use App\Controller\Admin\AppController;
use Cake\Cache\Cache;
use Cake\Event\Event;
use Cake\Network\Exception\NotFoundException;
use Cake\Utility\Hash;
use Cake\View\Exception\MissingTemplateException;
use Cake\Core\Configure;
use Cake\Utility\Text;


/**
 * Directors Controller
 *
 * @property \App\Model\Table\DirectorsTable $Directors
 *
 * @method \App\Model\Entity\Director[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class DirectorsController extends AppController
{

    public function initialize()
    {
        parent::initialize();
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        
        $search_condition = array();
        $data = $this->Sanitize->clean($this->request->getQuery());
        if (!empty($data['title'])) {
            $postTitle = trim($data['title']); 
            $this->set('title', $postTitle);
            $search_condition[] = "Directors.title like '%" . $postTitle . "%'";
        }
        
        if (isset($this->request->query['status']) && $data['status'] !='') {
            $status = trim($data['status']);
            $this->set('status', $status);
            $search_condition[] = "Directors.status = '" . $status . "'";
        }

        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        //pr($search_condition); die;
        $postQuery = $this->Directors->find('all', [
            'order' => ['Directors.id' => 'desc'],
            'conditions' => [$searchString]
        ]);

        $directors = $this->paginate($postQuery);

        $this->set(compact('directors'));
    }

    /**
     * View method
     *
     * @param string|null $id Director id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $director = $this->Directors->get($id, [
            'contain' => ['Users', 'DirectorTranslations']
        ]);

        $this->set('director', $director);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $director = $this->Directors->newEntity();
        if ($this->request->is('post')) {
            $data                   = $this->request->getData();
            $director_translations   = [];
            if (isset($data['director_translations'])) {
                $director_translations = $data['director_translations'];
                unset($data['director_translations']);
            }
            $director = $this->Directors->patchEntity($director, $data);
            if($data['images']['name']!=''){
                $doc1 = $this->uploadFiles('director', $data['images']);
                $director->images = $doc1['filename'];
            }
            if($data['header_image']['name']!=''){
                $doc2 = $this->uploadFiles('director', $data['header_image']);
                $director->header_image = $doc2['filename'];
            }
            if (empty($data['url'])) {
                $director->url = strtolower(Text::slug($data['title']));
            } else {
                $director->url = strtolower(Text::slug($data['url']));
            }
            if ($this->Directors->save($director)) {
                $director_id = $director->id;
                if (!empty($director_translations)) {
                    $this->loadModel('DirectorTranslations');
                    foreach ($director_translations as $key => $_translation) {
                        if (empty($_translation['id'])) {
                            unset($director_translations[$key]['id']);
                        }
                        $director_translations[$key]['director_id'] = $director_id;
                    }
                    $directorTranslation  = $this->DirectorTranslations->newEntity();
                    $directorTranslation  = $this->DirectorTranslations->patchEntities($directorTranslation, $director_translations);
                    $directorTranslations = $this->DirectorTranslations->saveMany($directorTranslation);
                    //$this->Directors->directorCache();
                }
                $this->Flash->success(__('The director has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The director could not be saved. Please, try again.'));
        }
        $directorLanguages = $this->languages;
        $system_languge_id = SYSTEM_LANGUAGE_ID;
        $this->set(compact('director', 'directorLanguages', 'system_languge_id'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Director id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $director = $this->Directors->get($id, [
            'contain' => ['DirectorTranslations']
        ]);
        $director['director_translations'] = Hash::combine($director['director_translations'], '{n}.language_id', '{n}');
        if ($this->request->is(['patch', 'post', 'put'])) {
            $data                   = $this->request->getData();
            $director_translations   = [];
            if (isset($data['director_translations'])) {
                $director_translations = $data['director_translations'];
                unset($data['director_translations']);
            }
            $director = $this->Directors->patchEntity($director, $data);
            if($data['images']['name']!=''){
                $doc1 = $this->uploadFiles('director', $data['images']);
                $director->images = $doc1['filename'];
            } else {
                $director->images = $data['old_images'];
            }
            if($data['header_image']['name']!=''){
                $doc2 = $this->uploadFiles('director', $data['header_image']);
                $director->header_image = $doc2['filename'];
            } else {
                $director->header_image = $data['old_header_image'];
            }
            if (empty($data['url'])) {
                $director->url = strtolower(Text::slug($data['title']));
            } else {
                $director->url = strtolower(Text::slug($data['url']));
            }
            if ($this->Directors->save($director)) {
                $director_id = $director->id;
                if (!empty($director_translations)) {
                    $this->loadModel('DirectorTranslations');
                    foreach ($director_translations as $key => $_translation) {
                        if (empty($_translation['id'])) {
                            unset($director_translations[$key]['id']);
                        }
                        $director_translations[$key]['director_id'] = $director_id;
                    }
                    $directorTranslation  = $this->DirectorTranslations->newEntity();
                    $directorTranslation  = $this->DirectorTranslations->patchEntities($directorTranslation, $director_translations);
                    $directorTranslations = $this->DirectorTranslations->saveMany($directorTranslation);
                    //$this->Directors->directorCache();
                }
                $this->Flash->success(__('The director has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The director could not be saved. Please, try again.'));
        }
        $directorLanguages = $this->languages;
        $system_languge_id = SYSTEM_LANGUAGE_ID;
        $this->set(compact('director', 'directorLanguages', 'system_languge_id'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Director id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $director = $this->Directors->get($id);
        if ($this->Directors->delete($director)) {
            $this->loadModel('DirectorTranslations');
            $this->DirectorTranslations->deleteAll(['director_id' => $id]);
            $this->Flash->success(__('The director has been deleted.'));
        } else {
            $this->Flash->error(__('The director could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
