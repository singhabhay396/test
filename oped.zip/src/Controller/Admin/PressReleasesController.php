<?php
namespace App\Controller\Admin;

use App\Controller\Admin\AppController;
use Cake\Event\Event;
use Cake\Utility\Text;
use Cake\Network\Exception\NotFoundException;
use Cake\Utility\Hash;
use Cake\View\Exception\MissingTemplateException;

/**
 * PressReleases Controller
 *
 * @property \App\Model\Table\PressReleasesTable $PressReleases
 *
 * @method \App\Model\Entity\PressRelease[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class PressReleasesController extends AppController
{
    public function initialize()
    {
        parent::initialize();
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
		
		$search_condition = array();
        if (!empty($this->request->getQuery('title'))) {
            $title = trim($this->request->getQuery('title'));
            $this->set('title', $title);
            $search_condition[] = "PressReleases.title like '%" . $title . "%'";
        }
        if (isset($this->request->query['status']) && $this->request->getQuery('status') !='') {
            $status = trim($this->request->getQuery('status'));
            $this->set('status', $status);
            $search_condition[] = "PressReleases.status = '" . $status . "'";
        }
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        $postQuery = $this->PressReleases->find('all', [
            'contain' => ['Users'],
            'order' => ['PressReleases.id' => 'desc'],
            'conditions' => [$searchString]
        ]);

        $this->paginate = ['limit' => 10];
        $pressReleases = $this->paginate($postQuery);

        $this->set(compact('pressReleases'));
		/*
        $this->paginate = [
            'contain' => ['Users']
        ];
        $pressReleases = $this->paginate($this->PressReleases);

        $this->set(compact('pressReleases')); */
    }

    /**
     * View method
     *
     * @param string|null $id Press Release id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $pressRelease = $this->PressReleases->get($id, [
            'contain' => ['Users', 'PressReleaseTranslations']
        ]);

        $this->set('pressRelease', $pressRelease);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $pressRelease = $this->PressReleases->newEntity();
        if ($this->request->is('post')) {
            $data              = $this->request->getData();
            $press_release_translations = [];
            if (isset($data['press_release_translations'])) {
                $press_release_translations = $data['press_release_translations'];
                unset($data['press_release_translations']);
            }
            $pressRelease = $this->PressReleases->patchEntity($pressRelease, $data);
            if($data['upload_document_1']['name']!=''){
                $doc1 = $this->uploadFiles('pressrelease', $data['upload_document_1']);
                $pressRelease->upload_document_1 = $doc1['filename'];
            }
            if($data['upload_document_2']['name']!=''){
                $doc2 = $this->uploadFiles('pressrelease', $data['upload_document_2']);
                $pressRelease->upload_document_2 = $doc2['filename'];
            }
            $pressRelease->url = strtolower(Text::slug($data['title']));
            if ($this->PressReleases->save($pressRelease)) {
                $press_release_id = $pressRelease->id;
                if (!empty($press_release_translations)) {
                    $this->loadModel('PressReleaseTranslations');
                    foreach ($press_release_translations as $key => $_translation) {
                        if (empty($_translation['id'])) {
                            unset($press_release_translations[$key]['id']);
                        }
                        $press_release_translations[$key]['press_release_id'] = $press_release_id;
                    }
                    $pressreleaseTranslation  = $this->PressReleaseTranslations->newEntity();
                    $pressreleaseTranslation  = $this->PressReleaseTranslations->patchEntities($pressreleaseTranslation, $press_release_translations);
                    $pressreleaseTranslations = $this->PressReleaseTranslations->saveMany($pressreleaseTranslation);
                    //$this->News->pressreleaseCache();
                }
                $this->Flash->success(__('The press release has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The press release could not be saved. Please, try again.'));
        }
        $pressReleaseLanguages  = $this->languages;
        $system_languge_id = SYSTEM_LANGUAGE_ID;
        $this->set(compact('pressRelease', 'pressReleaseLanguages', 'system_languge_id'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Press Release id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $pressRelease = $this->PressReleases->get($id, [
            'contain' => ['PressReleaseTranslations']
        ]);
        $pressRelease['press_release_translations'] = Hash::combine($pressRelease['press_release_translations'], '{n}.language_id', '{n}');
        if ($this->request->is(['patch', 'post', 'put'])) {
            $data              = $this->request->getData();
            $press_release_translations = [];
            if (isset($data['press_release_translations'])) {
                $press_release_translations = $data['press_release_translations'];
                unset($data['press_release_translations']);
            }
            $pressRelease = $this->PressReleases->patchEntity($pressRelease, $data);
            if($data['upload_document_1']['name']!=''){
                $doc1 = $this->uploadFiles('pressrelease', $data['upload_document_1']);
                $pressRelease->upload_document_1 = $doc1['filename'];
            } else {
                $pressRelease->upload_document_1 = $data['old_upload_document_1'];
            }
            if($data['upload_document_2']['name']!=''){
                $doc2 = $this->uploadFiles('pressrelease', $data['upload_document_2']);
                $pressRelease->upload_document_2 = $doc2['filename'];
            } else {
                $pressRelease->upload_document_2 = $data['old_upload_document_2'];
            }
            $pressRelease->url = strtolower(Text::slug($data['title']));
            if ($this->PressReleases->save($pressRelease)) {
                $press_release_id = $pressRelease->id;
                if (!empty($press_release_translations)) {
                    $this->loadModel('PressReleaseTranslations');
                    foreach ($press_release_translations as $key => $_translation) {
                        if (empty($_translation['id'])) {
                            unset($press_release_translations[$key]['id']);
                        }
                        $press_release_translations[$key]['press_release_id'] = $press_release_id;
                    }
                    $pressreleaseTranslation  = $this->PressReleaseTranslations->newEntity();
                    $pressreleaseTranslation  = $this->PressReleaseTranslations->patchEntities($pressreleaseTranslation, $press_release_translations);
                    $pressreleaseTranslations = $this->PressReleaseTranslations->saveMany($pressreleaseTranslation);
                    //$this->News->pressreleaseCache();
                }
                $this->Flash->success(__('The press release has been saved.'));
                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The press release could not be saved. Please, try again.'));
        }
        $pressReleaseLanguages  = $this->languages;
        $system_languge_id = SYSTEM_LANGUAGE_ID;
        $this->set(compact('pressRelease', 'pressReleaseLanguages', 'system_languge_id'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Press Release id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $pressRelease = $this->PressReleases->get($id);
        if ($this->PressReleases->delete($pressRelease)) {
            $this->loadModel('PressReleaseTranslations');
            $this->PressReleaseTranslations->deleteAll(['press_release_id' => $id]);
            $this->Flash->success(__('The press release has been deleted.'));
        } else {
            $this->Flash->error(__('The press release could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
