<?php
namespace App\Controller\Admin;

use App\Controller\Admin\AppController;
use Cake\Core\Configure;
use Cake\Event\Event;
use Cake\Network\Exception\NotFoundException;
use Cake\View\Exception\MissingTemplateException;

/**
 * ProductShowcases Controller
 *
 * @property \App\Model\Table\ProductShowcasesTable $ProductShowcases
 *
 * @method \App\Model\Entity\Article[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class ProductShowcasesController extends AppController
{
    public function initialize()
    {
        parent::initialize();
        $this->Auth->allow([]);
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }

    private $productStatus = [
        1=> 'Ideation',
        2=> 'Validation',
        3=> 'Early Traction',
        4=> 'Scaling'
    ];

    public function index($value='')
    {
        $search_condition = array();
        if (!empty($this->request->getQuery('product_name'))) {
            $product_name = trim($this->request->getQuery('product_name'));
            $this->set('product_name', $product_name);
            $search_condition[] = "ProductShowcases.product_name like '%" . $product_name . "%'";
        }
        if (!empty($this->request->getQuery('product_status'))) {
            $product_status = trim($this->request->getQuery('product_status'));
            $this->set('product_status', $product_status);
            $search_condition[] = "ProductShowcases.product_status = '" . $product_status . "'";
        }
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        $postQuery = $this->ProductShowcases->find('all', [
            'contain' => ['Users'],
            'order' => ['ProductShowcases.id' => 'desc'],
            'conditions' => [$searchString]
        ]);
        $this->paginate = ['limit' => 10];
        $productShowcases = $this->paginate($postQuery);
        $productStatus = $this->productStatus;
        $this->set(compact('productShowcases','productStatus'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Post id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function viewDetail($id = null)
    {
        $productShowcase = $this->ProductShowcases->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $data = $this->request->getData();
            
            if ($data['approve']) {
                $productShowcase->status = 1;
            } elseif (@$data['reject']) {
                $productShowcase->status = 2;
            } else {
                $productShowcase->status = 0;
            }
            $productShowcase->updated = date('Y-m-d H:i:s');            
            if ($this->ProductShowcases->save($productShowcase)) {
                $this->Flash->success(__('The product showcases has been saved.'));
                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The product showcases could not be saved. Please, try again.'));
        }
        $productStatus = $this->productStatus;
        $this->set(compact('productShowcase','productStatus'));
    }
}