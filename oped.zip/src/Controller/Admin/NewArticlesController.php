<?php
namespace App\Controller\Admin;

use App\Controller\Admin\AppController;
use Cake\Cache\Cache;
use Cake\Event\Event;
use Cake\Mailer\Email;
use Cake\Network\Exception\NotFoundException;
use Cake\Utility\Hash;
use Cake\View\Exception\MissingTemplateException;
use Cake\Core\Configure;
use Cake\Filesystem\File;
use Cake\ORM\TableRegistry;

/**
 * Articles Controller
 *
 * @property \App\Model\Table\ArticlesTable $Articles
 *
 * @method \App\Model\Entity\Article[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class NewArticlesController extends AppController
{

    public function initialize()
    {
        parent::initialize();
		$this->loadModel('ArticalDetails');
		$this->loadModel('ArticleOptionFiels');
		$this->loadModel('Languages');
		$this->loadModel('ArticleCategories');
		$this->loadModel('Tags');
		$this->loadModel('ArticleTags');
		$this->loadModel('Users');
		$this->loadModel('OptionFields');
		$this->Auth->allow(['add','getFieldName','forwordEditorialDesk']);
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
		$this->viewBuilder()->setLayout('default');
    }

    private $linkRedirection = [
        'self'       => 'Self',
        'new-window' => 'New Window',
    ];

    private $linkType = [
        'custom' => 'Custom',
        'article' => 'Article',
        'tender' => 'Tender',
        'swavlamban' =>'Swavlamban',
        'internal' => 'Internal',
    ];

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
		$this->loadModel('ArticalDetails');
		return $this->redirect(['action' => 'pending-articles']);
        $search_condition = array();
        if (!empty($this->request->getQuery('title'))) {
            $title = trim($this->request->getQuery('title'));
            $this->set('title', $title);
            $search_condition[] = "ArticalDetails.title like '%" . $title . "%'";
        }
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
		$role_id = $this->Auth->user('role_id');
		
		$id = $this->Auth->user('id');
		//echo $role_id."-".$id; exit;
		if($role_id ==1){
			$postQuery = $this->ArticalDetails->find('all', [
            'contain' => ['Users','ArticleCategories','ApplicationStatus'],
            'order' => ['ArticalDetails.id' => 'desc'],
            'conditions' => [$searchString]
        ]);
		}
		else if($role_id ==3){
			$postQuery = $this->ArticalDetails->find('all', [
            'contain' => ['Users','ArticleCategories','ApplicationStatus'],
            'order' => ['ArticalDetails.id' => 'desc'],
            'conditions' => [$searchString,'editorial_id'=>$id,'article_stage_id !='=>8]
        ]);
		}
		else if($role_id ==4){
			$postQuery = $this->ArticalDetails->find('all', [
            'contain' => ['Users','ArticleCategories','ApplicationStatus'],
            'order' => ['ArticalDetails.id' => 'desc'],
            'conditions' => [$searchString,'approval_id'=>$id,'article_stage_id !='=>8]
        ]);
		}
		else{
			$postQuery = $this->ArticalDetails->find('all', [
            'contain' => ['Users','ArticleCategories','ApplicationStatus'],
            'order' => ['ArticalDetails.id' => 'desc'],
            'conditions' => [$searchString,'user_id'=>$id,'article_stage_id !='=>8]
        ]);
		}
        
        $this->paginate = ['limit' => 10];
        $articles = $this->paginate($postQuery);
        $this->set(compact('articles','role_id'));

    }
	
	
	public function pendingArticles()
    {
		$this->loadModel('ArticalDetails');
		
        $search_condition = array();
        if (!empty($this->request->getQuery('title'))) {
            $title = trim($this->request->getQuery('title'));
            $this->set('title', $title);
            $search_condition[] = "ArticalDetails.title like '%" . $title . "%'";
        }
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
		$role_id = $this->Auth->user('role_id');
		$pass_change = $this->Auth->user('pass_change');
		
		$id = $this->Auth->user('id');
		//echo $role_id."-".$id; exit;
		if($role_id ==1){
			$postQuery = $this->ArticalDetails->find('all', [
            'contain' => ['Users','ArticleCategories','ApplicationStatus','Languages'],
            'order' => ['ArticalDetails.id' => 'desc'],
            'conditions' => [$searchString]
        ]);
		}
		else if($role_id ==3){
			$postQuery = $this->ArticalDetails->find('all', [
            'contain' => ['Users','ArticleCategories','ApplicationStatus','Languages'],
            'order' => ['ArticalDetails.id' => 'desc'],
            'conditions' => [$searchString,'editorial_id'=>$id,'article_stage_id !=' =>8]
        ]);
		}
		else if($role_id ==4){
		    
			$postQuery = $this->ArticalDetails->find('all', [
            'contain' => ['Users','ArticleCategories','ApplicationStatus','Languages'],
            'order' => ['ArticalDetails.id' => 'desc'],
            'conditions' => [$searchString,'approval_id'=>$id,'article_stage_id !=' =>8]
        ]);
		}
		else{
			$postQuery = $this->ArticalDetails->find('all', [
            'contain' => ['Users','ArticleCategories','ApplicationStatus','Languages'],
            'order' => ['ArticalDetails.id' => 'desc'],
            'conditions' => [$searchString,'ArticalDetails.user_id'=>$id,'article_stage_id !=' =>8]
        ]);
		}
       // ,'ArticalDetails.status'=>1
        $this->paginate = ['limit' => 10];
        $articles = $this->paginate($postQuery);
		//echo "<pre>"; print_r($articles); exit;
        $this->set(compact('articles','role_id','pass_change'));

    }
    /**
     * View method
     *
     * @param string|null $id Article id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {   
		$ip = $_SERVER['REMOTE_ADDR'];
        $this->loadModel('ArticalDetails');
        $this->loadModel('ArticalMovementHistory');
		$role_id = $this->Auth->user('role_id');
		$user_ids = $this->Auth->user('id');
        $article = $this->ArticalDetails->find()->contain(['ArticleTags','Languages','ArticleCategories','Users'])->where(['ArticalDetails.id' => $id])->first();
		$articleHistory = $this->ArticalMovementHistory->find('all')->where(['ArticalMovementHistory.artical_id '=>$id])->toArray();
		if ($this->request->is(['post','put'])) {
			$data = $this->request->getData();
			if($role_id == 2){
				if(!empty($this->request-data['forward_to_ditorial'])){
							
					//$user_id = $this->Auth->user('id');
					$language_id = $this->Auth->user('language_id');
					$article = $this->ArticalDetails->get($id);
					$user_id = $article['user_id'];
					$noti_type = "Article";
					$message = $article['title'];
					$editorial_id = $this->getEditorialId($article['language_id']);
					if(isset($editorial_id) && count($editorial_id)>0){
					foreach($editorial_id as $val){
						$this->notification($article->id,$val['id'],$user_id,$noti_type,$message);
						$query = $this->ArticalDetails->query();
						$query->update()
						->set(['editorial_id' => $val['id'],'final_submit'=>1,'is_draft'=>1,'article_stage_id'=>1,'artical_status'=>1])
						->where(['id' => $article['id']])
						->execute(); 
					}
					if ($ip == '::1') {
						$ipadd = '127.0.0.1';
					}
					else {
						$this->__sendEditorEmail($id, 'New Article Request');
						$tableName  				= 'ArticalMovementHistory';
						$application_id_columnName = 'artical_id';
						$Article    				= $article['id'];
						$comment                   = '';
						$current_with              = 'Editorial Desk';
						$initiated_date            = $article->created_date;
						$panding_from              = date('Y-m-d');

						$this->fileMovement($tableName, $application_id_columnName, $Article, $current_with, $comment, $initiated_date, $panding_from, $data);
						//echo "Article Forward to Editorial Desk"; exit;	
						$this->Flash->success(__('Article Forward to Editorial Desk'));
						return $this->redirect(['controller'=>'new-articles','action' => 'pending-articles']);
					}
					}
					else{
						$this->Flash->error(__('No Editor Active'));
						return $this->redirect(['controller'=>'new-articles','action' => 'view',$id]);
					}		
				}
			}	
			if($role_id == 4){
				$applications = $this->ArticalDetails->get($id);
				$cr_id = $applications['user_id'];
				$edit = $applications['editorial_id'];
				$language_id = $this->Auth->user('language_id');
				$data = $this->request->getData();
				$applications = $this->ArticalDetails->patchEntity($applications, $data);
				$noti_type = "Article";
				$message = $applications['title'];
				$editorial_id = $this->getApprovalId($applications['language_id']);
			
				$editor = isset($editorial_id[0]['id'])?$editorial_id[0]['id']:0;
				
				//foreach($approved_id as $val){
					if ($data['action'] == 'Publish') {
						$applications->approval_date = date('Y-m-d');
						$applications->approved_comment = isset($data['admin_comment'])?$data['admin_comment']:'';
						$applications->artical_status = 6;
						$applications->article_stage_id = 8;
						$applications->publish_date = date('Y-m-d H:i:s');
						$applications->approved_by = $user_ids;
						if ($ip == '::1') {
						$ipadd = '127.0.0.1';
						}
						else {
							$this->getCurtCall($id);
							$this->__sendAuthorEmail($id, 'Published');
							$this->__sendEditorEmail($id, 'Published');
						}
						
						$this->notification($applications['id'],$cr_id,$user_ids,$noti_type,$message);
						$this->notification($applications['id'],$edit,$user_ids,$noti_type,$message);
						$this->notification($applications['id'],1,$user_ids,$noti_type,$message);
					} else if ($this->request->data['action'] == 'Send Back to Editor for Edit') {
						$applications->artical_status = 3;
						$applications->article_stage_id = 4;
						$applications->is_draft = 1;
						//$this->__sendAuthorEmail($id, 'Publish');
						if ($ip == '::1') {
						$ipadd = '127.0.0.1';
						}
						else {
							$this->__sendEditorEmail($id, 'Change Request');
						}
						
						$this->notification($applications['id'],$edit,$user_ids,$noti_type,$message);
						$this->notification($applications['id'],1,$user_ids,$noti_type,$message);
					}
					
				//}
			}	
			if($role_id == 3){
				$applications = $this->ArticalDetails->get($id);
				//echo "<pre>"; print_r(applications); exit;
				$cr_id = $applications['user_id'];
				//$cr_id = $applications['_id'];
				$editorial_id = $this->getApprovalId($applications['language_id']);
				$language_id = $this->Auth->user('language_id');
				$data = $this->request->getData();
				$applications = $this->ArticalDetails->patchEntity($applications, $data);
				$noti_type = "Article";
				$message = $applications['title'];
				$editor = isset($editorial_id[0]['id'])?$editorial_id[0]['id']:0;
				if($editor == 0){
					$this->Flash->error(__('No Mentor Active'));
					return $this->redirect(['controller'=>'new-articles','action' => 'add',$id]);
				}
				if ($data['action'] == 'Publish' && $editor > 0) {
						$applications->approval_date = date('Y-m-d');
						$applications->approved_comment = isset($data['admin_comment'])?$data['admin_comment']:'';
						$applications->artical_status = 6;
						$applications->article_stage_id = 8;
						$applications->publish_date = date('Y-m-d H:i:s');
						$applications->approved_by = $user_ids;
						if ($ip == '::1') {
						$ipadd = '127.0.0.1';
						}
						
						else {
							$this->getCurtCall($id);
							$this->__sendAuthorEmail($id, 'Published');
							$this->__sendEditorEmail($id, 'Published');
						}					
						$this->notification($applications['id'],$cr_id,$user_ids,$noti_type,$message);
						$this->notification($applications['id'],1,$user_ids,$noti_type,$message);
						}
					
				else if ($data['action'] == 'Send to Mentor') {
					$applications->artical_status = 2;
					$applications->article_stage_id = 2;
					$applications->approval_id = $editor;
					if ($ip == '::1') {
						$ipadd = '127.0.0.1';
						}
						
						else {
							$this->__sendMentorEmail($id, 'New Article Request');
							$this->notification($applications['id'],$editor,$user_ids,$noti_type,$message);
							$this->notification($applications['id'],1,$user_ids,$noti_type,$message);
						}
					}			

				else if ($this->request->data['action'] == 'Send Back to Author for Edit') {
					$applications->artical_status = 3;
					$applications->article_stage_id = 3;
					$applications->is_draft = 0;
					$applications->final_submit = 0;
					if ($ip == '::1') {
						$ipadd = '127.0.0.1';
					}
					else {
						$this->__sendAuthorEmail($id, 'Change Request');
					}
					
					//$this->__sendEditorEmail($id, 'Publish');
					$this->notification($applications['id'],$cr_id,$user_ids,$noti_type,$message);
					$this->notification($applications['id'],1,$user_ids,$noti_type,$message);
				}
			}
           
            if ($this->ArticalDetails->save($applications)) {
					
                if ($data['action'] == 'Send to Mentor') {
					
                    $tableName  				= 'ArticalMovementHistory';
					$application_id_columnName = 'artical_id';
					$Article    				= $id;
					$comment                   = $data['admin_comment'];
					$current_with              = 'Send to Mentor';
					$initiated_date            = $applications->created_date;
					$panding_from              = date('Y-m-d');
					$this->fileMovement($tableName, $application_id_columnName, $Article, $current_with, $comment, $initiated_date, $panding_from, $data);
				}
				else if($data['action'] == 'Publish'){
					$tableName  				= 'ArticalMovementHistory';
					$application_id_columnName = 'artical_id';
					$Article    				= $id;
					$comment                   = $data['admin_comment'];
					$current_with              = 'Publish';
					$initiated_date            = $applications->created_date;
					$panding_from              = date('Y-m-d');
					$this->fileMovement($tableName, $application_id_columnName, $Article, $current_with, $comment, $initiated_date, $panding_from, $data);
				}
				else if($data['action'] == 'Send Back to Author for Edit'){
					$tableName  				= 'ArticalMovementHistory';
					$application_id_columnName = 'artical_id';
					$Article    				= $id;
					$comment                   = $data['admin_comment'];
					$current_with              = 'Resend to Author';
					$initiated_date            = $applications->created_date;
					$panding_from              = date('Y-m-d');
					$this->fileMovement($tableName, $application_id_columnName, $Article, $current_with, $comment, $initiated_date, $panding_from, $data);
				}
				else if($data['action'] == 'Send Back to Editor for Edit'){
					$tableName  				= 'ArticalMovementHistory';
					$application_id_columnName = 'artical_id';
					$Article    				= $id;
					$comment                   = $data['admin_comment'];
					$current_with              = 'Resend to Editor';
					$initiated_date            = $applications->created_date;
					$panding_from              = date('Y-m-d');
					$this->fileMovement($tableName, $application_id_columnName, $Article, $current_with, $comment, $initiated_date, $panding_from, $data);
				}
				if ($data['action'] == 'Publish') {
					$this->Flash->success(__('Article has been approved'));
				}
				else if ($this->request->data['action'] == 'Send Back to Editor for Edit') {
					$this->Flash->success(__('Article has been back to editorial desk.'));
				}
				else if ($this->request->data['action'] == 'Send Back to Author for Edit') {
					$this->Flash->success(__('Article has been back to author.'));
				}
				else if ($this->request->data['action'] == 'Send to Mentor') {
					$this->Flash->success(__('Article has been sended for mentor.'));
				}
               
                
                return $this->redirect(['action' => 'pending-articles']);
            }
			else{
				$this->Flash->success(__('The article has been not saved.'));
				return $this->redirect(['controller'=>'new-articles','action' => 'upload-articles',$article_id]);	
			}
		}
		$this->set(compact('article', 'articleHistory','role_id'));
    }
	
	
	public function preview($id = null)
    {   
        $this->loadModel('ArticalDetails');
        $article = $this->ArticalDetails->find()->contain(['ArticleTags','Languages','ArticleCategories','Users'])->where(['ArticalDetails.id' => $id])->first();
		if ($this->request->is(['post','put'])) {
			$data                 = $this->request->getData();
			$article_id = $data['article_id'];
			$user_id = $this->Auth->user('id');
			$language_id = $this->Auth->user('language_id');
			$article = $this->ArticalDetails->get($this->Sanitize->clean($article_id));
			$noti_type = "Article";
			$message = $article['title'];
			$editorial_id = $this->getEditorialId($article['language_id']);
			
			$editor = isset($editorial_id[0]['id'])?$editorial_id[0]['id']:0;
			if($editor > 0){
				$this->notification($article->id,$editor,$user_id,$noti_type,$message);
				$query = $this->ArticalDetails->query();
				$query->update()
					->set(['editorial_id' => $editor,'final_submit'=>1,'is_draft'=>1,'article_stage_id'=>1,'artical_status'=>1])
					->where(['id' => $article_id])
					->execute(); 
				$this->__sendEditorEmail($article_id, 'New Article Request');
				$tableName  				= 'ArticalMovementHistory';
				$application_id_columnName = 'artical_id';
				$Article    				= $article_id;
				$comment                   = '';
				$current_with              = 'Editorial Desk';
				$initiated_date            = $article->created_date;
				$panding_from              = date('Y-m-d');
	
				$this->fileMovement($tableName, $application_id_columnName, $Article, $current_with, $comment, $initiated_date, $panding_from, $data);
				$this->Flash->success(__('Article Forward to Editorial Desk'));
				return $this->redirect(['controller'=>'new-articles','action' => 'pending-articles']);	
			}
			else{
				$this->Flash->error(__('No Editorial Desk Active'));
				return $this->redirect(['controller'=>'new-articles','action' => 'preview',$article_id]);	
			}
		}
		/* else{
			
			return $this->redirect(['controller'=>'articles','action' => 'preview',$id]);	
		}
		 */
        $this->set('article', $article);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add($id =NULL)
    {
		$ip = $_SERVER['REMOTE_ADDR'];
		$user_id = $this->Auth->user('id');
		$role_id = $this->Auth->user('role_id');
		if($id > 0){
			$article = $this->ArticalDetails->get($this->Sanitize->clean($id), [
            'contain' => ['ArticleTags','Languages','ArticleCategories','Users'],
        ]);
			//$article = $this->ArticalDetails->get($this->Sanitize->clean($id,));
		}
		else{
			$article = $this->ArticalDetails->newEntity();
		}
        
        if ($this->request->is(['post','put'])) {
			
            $data  = $this->request->getData();
			//echo "<pre>"; print_r($data); exit;
			if($role_id == 2 && $id > 0 && !empty($data['forward_to_ditorial']) && $data['forward_to_ditorial'] =='Forword To Editorial Desk'){
				/* if(!empty($this->request-data['forward_to_ditorial'])){ */
							
					//$user_id = $this->Auth->user('id');
					$language_id = $this->Auth->user('language_id');
					$article = $this->ArticalDetails->get($id);
					$user_id = $article['user_id'];
					$noti_type = "Article";
					$message = $article['title'];
					$editorial_id = $this->getEditorialId($article['language_id']);
					if(isset($editorial_id) && count($editorial_id)> 0){
					foreach($editorial_id as $val){
						$this->notification($article->id,$val['id'],$user_id,$noti_type,$message);
						$this->notification($article->id,1,$user_id,$noti_type,$message);
						$query = $this->ArticalDetails->query();
						$query->update()
						->set(['editorial_id' => $val['id'],'final_submit'=>1,'is_draft'=>1,'article_stage_id'=>1,'artical_status'=>1])
						->where(['id' => $article['id']])
						->execute(); 
					}
					if ($ip == '::1') {
						$ipadd = '127.0.0.1';
					}
					else {
						$this->__sendEditorEmail($id, 'New Article Request');
					}
					}
					else{
						$this->Flash->error(__('No Editor Active'));
						return $this->redirect(['controller'=>'new-articles','action' => 'add',$id]);
						
					}
					$tableName  				= 'ArticalMovementHistory';
					$application_id_columnName = 'artical_id';
					$Article    				= $article['id'];
					$comment                   = '';
					$current_with              = 'Editorial Desk';
					$initiated_date            = $article->created;
					$panding_from              = date('Y-m-d');

					$this->fileMovement($tableName, $application_id_columnName, $Article, $current_with, $comment, $initiated_date, $panding_from, $data);
					//echo "Article Forward to Editorial Desk"; exit;	
					$this->Flash->success(__('Article Forward to Editorial Desk'));
					return $this->redirect(['controller'=>'new-articles','action' => 'pending-articles']);
						
				//}
			}
			if($role_id == 4 && empty($data['save_as_draft'])){
				$user_ids = $this->Auth->user('id');
				$applications = $this->ArticalDetails->get($id);
				$cr_id = $applications['user_id'];
				$edit = $applications['editorial_id'];
				$language_id = $this->Auth->user('language_id');
				$data = $this->request->getData();
				$applications = $this->ArticalDetails->patchEntity($applications, $data);
				if ($data['intro_image']['name'] != '') {
					$certificate  = $this->uploadFiles('article/artical_intro', $data['intro_image']);
					$applications->intro_image = $certificate['filename'];
				} else {
					$applications->intro_image = @$data['intro_image_old'];
				}
				if ($data['artical_image']['name'] != '') {
					$certificates  = $this->uploadFiles('article/artical_image', $data['artical_image']);
					$applications->artical_image = $certificates['filename'];
				} else {
					$applications->artical_image = @$data['artical_image_old'];
				}
				$noti_type = "Article";
				$message = $applications['title'];
				$editorial_id = $this->getApprovalId($applications['language_id']);
			
				$editor = isset($editorial_id[0]['id'])?$editorial_id[0]['id']:0;
				//foreach($approved_id as $val){
				if ($data['action'] == 'Publish') {
					$applications->approval_date = date('Y-m-d');
					$applications->approved_comment = isset($data['admin_comment'])?$data['admin_comment']:'';
					$applications->artical_status = 6;
					$applications->article_stage_id = 8;
					$applications->publish_date = date('Y-m-d H:i:s');
					$applications->approved_by = $user_ids;
					if ($ip == '::1') {
						$ipadd = '127.0.0.1';
					}
					else {
						$this->getCurtCall($id);
						$this->__sendAuthorEmail($id, 'Published');
						$this->__sendEditorEmail($id, 'Published');
					}
					
					$this->getCurtCall($id);
					$this->notification($applications['id'],$cr_id,$user_ids,$noti_type,$message);
					$this->notification($applications['id'],$edit,$user_ids,$noti_type,$message);
					$this->notification($applications['id'],1,$user_ids,$noti_type,$message);
				} else if ($this->request->data['action'] == 'Send Back to Editor for Edit') {
					$applications->artical_status = 3;
					$applications->article_stage_id = 4;
					$applications->is_draft = 1;
					if ($ip == '::1') {
						$ipadd = '127.0.0.1';
					}
					else {
						$this->__sendEditorEmail($id, 'Mentor request for changes');
					}
					
					$this->notification($applications['id'],$edit,$user_ids,$noti_type,$message);
					$this->notification($applications['id'],1,$user_ids,$noti_type,$message);
				}
					//$this->notification($applications['id'],$editor,$user_ids,$noti_type,$message);
           
            if ($this->ArticalDetails->save($applications)) {
					
                 if ($data['action'] == 'Send to Mentor') {
					
                    $tableName  				= 'ArticalMovementHistory';
					$application_id_columnName = 'artical_id';
					$Article    				= $id;
					$comment                   = $data['admin_comment'];
					$current_with              = 'Send to Mentor';
					$initiated_date            = $applications->created_date;
					$panding_from              = date('Y-m-d');
					$this->fileMovement($tableName, $application_id_columnName, $Article, $current_with, $comment, $initiated_date, $panding_from, $data);
				}
				else if($data['action'] == 'Publish'){
					$tableName  				= 'ArticalMovementHistory';
					$application_id_columnName = 'artical_id';
					$Article    				= $id;
					$comment                   = $data['admin_comment'];
					$current_with              = 'Publish';
					$initiated_date            = $applications->created_date;
					$panding_from              = date('Y-m-d');
					$this->fileMovement($tableName, $application_id_columnName, $Article, $current_with, $comment, $initiated_date, $panding_from, $data);
				}
				else if($data['action'] == 'Send Back to Author for Edit'){
					$tableName  				= 'ArticalMovementHistory';
					$application_id_columnName = 'artical_id';
					$Article    				= $id;
					$comment                   = $data['admin_comment'];
					$current_with              = 'Resend to Author';
					$initiated_date            = $applications->created_date;
					$panding_from              = date('Y-m-d');
					$this->fileMovement($tableName, $application_id_columnName, $Article, $current_with, $comment, $initiated_date, $panding_from, $data);
				}
				else if($data['action'] == 'Send Back to Editor for Edit'){
					$tableName  				= 'ArticalMovementHistory';
					$application_id_columnName = 'artical_id';
					$Article    				= $id;
					$comment                   = $data['admin_comment'];
					$current_with              = 'Resend to Editor';
					$initiated_date            = $applications->created_date;
					$panding_from              = date('Y-m-d');
					$this->fileMovement($tableName, $application_id_columnName, $Article, $current_with, $comment, $initiated_date, $panding_from, $data);
				}
				if ($data['action'] == 'Publish') {
					$this->Flash->success(__('Article has been approved'));
				}
				else if ($this->request->data['action'] == 'Send Back to Editor for Edit') {
					$this->Flash->success(__('Article has been back to editorial desk.'));
				}
				else if ($this->request->data['action'] == 'Send Back to Author for Edit') {
					$this->Flash->success(__('Article has been back to author.'));
				}
				else if ($this->request->data['action'] == 'Send to Mentor') {
					$this->Flash->success(__('Article has been sended for approval.'));
				}
               
                
                return $this->redirect(['action' => 'pending-articles']);
            }
				//}
			}	
			if($role_id == 3 && empty($data['save_as_draft'])){
				$user_ids = $this->Auth->user('id');
				$applications = $this->ArticalDetails->get($id);
				//echo "<pre>"; print_r($applications); exit;
				$language_id = $this->Auth->user('language_id');
				$cr_id = $applications['user_id'];
				$data = $this->request->getData();
				$applications = $this->ArticalDetails->patchEntity($applications, $data);
				$noti_type = "Article";
				$message = $applications['title'];
				$editorial_id = $this->getApprovalId($applications['language_id']);
				$editor = isset($editorial_id[0]['id'])?$editorial_id[0]['id']:0;
				if ($data['intro_image']['name'] != '') {
					$certificate  = $this->uploadFiles('article/artical_intro', $data['intro_image']);
					$applications->intro_image = $certificate['filename'];
				} else {
					$applications->intro_image = @$data['intro_image_old'];
				}
				if ($data['artical_image']['name'] != '') {
					$certificates  = $this->uploadFiles('article/artical_image', $data['artical_image']);
					$applications->artical_image = $certificates['filename'];
				} else {
					$applications->artical_image = @$data['artical_image_old'];
				}
				/* $applications->editorial_remark_date = date('Y-m-d');
				$applications->editorial_comment = $data['admin_comment']; */
				if ($data['action'] == 'Publish') {
						$applications->approval_date = date('Y-m-d');
						$applications->approved_comment = isset($data['admin_comment'])?$data['admin_comment']:'';
						$applications->artical_status = 6;
						$applications->article_stage_id = 8;
						$applications->publish_date = date('Y-m-d H:i:s');
						$applications->approved_by = $user_ids;$this->__sendAuthorEmail($id, 'Published');
						if ($ip == '::1') {
						$ipadd = '127.0.0.1'; 
						}
						else {
							$this->getCurtCall($id);
							$this->__sendEditorEmail($id, 'Published');
						}
						
						$this->notification($applications['id'],$cr_id,$user_ids,$noti_type,$message);
						$this->notification($applications['id'],1,$user_ids,$noti_type,$message);
				
					}
				else if ($data['action'] == 'Send to Mentor') {
					$applications->artical_status = 2;
					$applications->article_stage_id = 2;
					$applications->approval_id = $editor;
					if ($ip == '::1') {
					$ipadd = '127.0.0.1';
					}
					else {
						if($editor > 0){
						$this->__sendMentorEmail($id,$editor, 'New Article Request');
						}
						else{
							
							$this->Flash->success(__('No mentor Active'));
							return $this->redirect(['controller'=>'new-articles','action' => 'add',$id]);
						}
					}
					
					$this->notification($applications['id'],$editor,$user_ids,$noti_type,$message);
					$this->notification($applications['id'],1,$user_ids,$noti_type,$message);
					
				} else if ($this->request->data['action'] == 'Send Back to Author for Edit') {
					$applications->artical_status = 3;
					$applications->article_stage_id = 3;
					$applications->is_draft = 0;
					$applications->final_submit = 0;
					if ($ip == '::1') {
					$ipadd = '127.0.0.1';
					}
					else {
						$this->__sendAuthorEmail($id, 'Change Request');
					}
					
					$this->notification($applications['id'],$cr_id,$user_ids,$noti_type,$message);
					$this->notification($applications['id'],1,$user_ids,$noti_type,$message);
				}
				//$this->notification($applications['id'],$editor,$user_ids,$noti_type,$message);
           
            if ($this->ArticalDetails->save($applications)) {
					
                 if ($data['action'] == 'Send to Mentor') {
					
                    $tableName  				= 'ArticalMovementHistory';
					$application_id_columnName = 'artical_id';
					$Article    				= $id;
					$comment                   = $data['admin_comment'];
					$current_with              = 'Send to Mentor';
					$initiated_date            = $applications->created_date;
					$panding_from              = date('Y-m-d');
					$this->fileMovement($tableName, $application_id_columnName, $Article, $current_with, $comment, $initiated_date, $panding_from, $data);
				}
				else if($data['action'] == 'Publish'){
					$tableName  				= 'ArticalMovementHistory';
					$application_id_columnName = 'artical_id';
					$Article    				= $id;
					$comment                   = $data['admin_comment'];
					$current_with              = 'Publish';
					$initiated_date            = $applications->created_date;
					$panding_from              = date('Y-m-d');
					$this->fileMovement($tableName, $application_id_columnName, $Article, $current_with, $comment, $initiated_date, $panding_from, $data);
				}
				if ($data['action'] == 'Publish') {
					$this->Flash->success(__('Article has been approved'));
				}
				else if ($this->request->data['action'] == 'Send Back to Editor for Edit') {
					$this->Flash->success(__('Article has been back to editorial desk.'));
				}
				else if ($this->request->data['action'] == 'Send Back to Author for Edit') {
					$this->Flash->success(__('Article has been back to author.'));
				}
				else if ($this->request->data['action'] == 'Send to Mentor') {
					$this->Flash->success(__('Article has been sended for approval.'));
				}
               
                
                return $this->redirect(['action' => 'pending-articles']);
            }
            
			}
			if(!empty($data['save_as_draft'])){
				//echo "<pre>"; print_r($data); exit;
				$user_ids = $this->Auth->user('id');
			$tag = explode(',',$data['tag_id']);
            $article             = $this->ArticalDetails->patchEntity($article, $data);
			$article->created_at = date('Y-m-d H:i:s');
			if($article['id'] ==''){
				$article->user_id = $user_ids;
			}
			$article->updated_by = $user_ids;
            $error = $article->errors();
			if ($data['intro_image']['name'] != '') {
				$certificate  = $this->uploadFiles('article/artical_intro', $data['intro_image']);
				$article->intro_image = $certificate['filename'];
			} else {
				$article->intro_image = @$data['intro_image_old'];
			}
			if ($data['artical_image']['name'] != '') {
				$certificates  = $this->uploadFiles('article/artical_image', $data['artical_image']);
				$article->artical_image = $certificates['filename'];
			} else {
				$article->artical_image = @$data['artical_image_old'];
			}
            if(!empty($error['title']['_empty'])){

                $this->Flash->error(__("Please fill the Article Title"));
            }
            else if(!empty($error['introduction']['_empty'])){

                $this->Flash->error(__("Please fill the Introducation details"));
            }
            else if(!empty($error['body_desc']['_empty'])){

                $this->Flash->error(__("Please fill the Body details"));
            }
            else if(!empty($error['tag_id']['_empty'])){

                $this->Flash->error(__("Please fill the Article Type"));
            }
            else{
			if(isset($data['save_as_draft']) && $data['save_as_draft'] =='Save As Draft'){
				if($role_id == 2){
					$article->is_draft = 0;
				}
				else{
					$article->is_draft = 1;
					
				}
				
			}
			else{
				$article->is_draft = 0;
			}
			
			//echo "<pre>"; print_r($article); exit;
            if ($this->ArticalDetails->save($article)) {
                $article_id = $article->id;
				$referenceData = array();
				$this->ArticleTags->deleteAll(['article_id' => $article_id]);
				for($i=0;$i<sizeof($tag);$i++){
					//$referenceData = $this->ArticleTags->find()->where(['name' => $tag[$i],'article_id'=>$article_id])->toArray();
						$tags[$i]['name'] = $tag[$i];
						$tags[$i]['article_id'] = $article_id;
				}
					$tags_en  = $this->ArticleTags->newEntity();
					$artic  = $this->ArticleTags->patchEntities($tags_en, $tags);
					$articleLinss = $this->ArticleTags->saveMany($artic);
				
				
				if(!empty($this->request->data['save_as_draft'])){
					$this->Flash->success(__('The article has been saved as draft.'));
					return $this->redirect(['controller'=>'new-articles','action' => 'add',$article_id]);
				}/* else{
					$this->Flash->success(__('The article has been saved.'));
					return $this->redirect(['controller'=>'new-articles','action' => 'preview',$article_id]);	
				} */
                

                //return $this->redirect(['action' => 'index']);
            }
			
            else{
                $this->Flash->error(__('The article could not be saved. Please, try again.'));
            }
        }
            
        }
		if(!empty($data['preview'])){
			return $this->redirect(['controller'=>'new-articles','action' => 'preview',$id]);
			
		}
        }
 
		$lang = $this->Languages->find('list', ['limit' => 200]);
		$article_categories = $this->ArticleCategories->find('list', ['limit' => 200]);
		$tag = $this->Tags->find('list', ['limit' => 200]);
		$option_fields = $this->OptionFields->find('all', ['limit' => 200]);
        $this->set(compact('article','lang','article_categories','tag','id','option_fields','role_id'));
    }
	
	
    /**
     * Delete method
     *
     * @param string|null $id Article id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
		$this->loadModel('ArticalDetails');
        $this->request->allowMethod(['post', 'delete']);
        $article = $this->ArticalDetails->get($id);
		$user_id = $this->Auth->user('id');
		$query = $this->ArticalDetails->query();
		$vd = $query->update()
				->set(['status' => 0,'final_submit'=>0,'final_submit'=>0,'deleted_by'=>$user_id,'editorial_id'=>0,'approval_id'=>0,'artical_status'=>5,'article_stage_id'=>5])
				->where(['id' => $id])
				->execute();
        if ($vd) {
            $this->Flash->success(__('The article has been deleted.'));
        } else {
            $this->Flash->error(__('The article could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'pending-articles']);
    }

	protected function __sendAuthorEmail($id, $type)
    {
        if (empty($token) && empty($id)) {
            $this->Flash->success(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'login']);
        }
        $article = $this->ArticalDetails->find()->where(['id'=>$id])->first();
		$user = $this->Users->find()->where(['id'=>$article['user_id']])->first();
		//$dd = 'abhay_singh@silvertouch.com';
        $to = $user['email'];
        $subject = $type.' – '.$article['title'];
        $email = new Email('default');
        $email->template('published_temp')
            ->viewVars(['title'=>$article['title'],'name'=>$user['name'],'type'=>$type]);
            $email->addTo(trim($to));
            $email->from(['singhabhay396@gmail.com'])
            ->subject($subject)
            ->emailFormat('html')
            ->send();
    }
	protected function __sendEditorEmail($id, $type)
    {
        if (empty($token) && empty($id)) {
            $this->Flash->success(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'login']);
        }
        $article = $this->ArticalDetails->find()->where(['id'=>$id])->first();
		$user = $this->Users->find()->where(['id'=>$article['editorial_id']])->first();
		$dd = 'abhay_singh@silvertouch.com';
        $to = $user['email'];
        $subject = $type.' – '.$article['title'];
        $email = new Email('default');
        $email->template('published_temp')
            ->viewVars(['title'=>$article['title'],'name'=>$user['name'],'type'=>$type]);
            $email->addTo(trim($to));
            $email->from(['singhabhay396@gmail.com'])
            ->subject($subject)
            ->emailFormat('html')
            ->send();
    }
	protected function __sendMentorEmail($id, $app,$type)
    {
        if (empty($token) && empty($id)) {
            $this->Flash->success(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'login']);
        }
        $article = $this->ArticalDetails->find()->where(['id'=>$id])->first();
		$user = $this->Users->find()->where(['id'=>$app])->first();
		$dd = 'abhay_singh@silvertouch.com';
        $to = $user['email'];
        $subject = $type.' – '.$article['title'];
        $email = new Email('default');
        $email->template('published_temp')
            ->viewVars(['title'=>$article['title'],'name'=>$user['name'],'type'=>$type]);
            $email->addTo(trim($to));
            $email->from(['singhabhay396@gmail.com'])
            ->subject($subject)
            ->emailFormat('html')
            ->send();
    }
	public function update($id) {
        //$id = base64_decode($id);
        
		$this->loadModel('ArticalDetails');
        $article = $this->ArticalDetails->find()->contain(['ArticleTags','Languages','ArticleCategories','Users'])->where(['ArticalDetails.id' => $id])->first();
        $application = $this->ArticalDetails->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'pending-articles']);
        }
		$role_id = $this->Auth->user('role_id');
        $applications = $this->ArticalDetails->get($id);
        if ($this->request->is(['POST', 'PUT'])) {
			$editorial_id = $this->getApprovalId($applications['language_id']);
			$user_id = $this->Auth->user('id');
			
			$language_id = $this->Auth->user('language_id');
            $data = $this->request->getData();
            $applications = $this->ArticalDetails->patchEntity($applications, $data);
			$noti_type = "Article";
			$message = $applications['title'];	
			$editor = isset($editorial_id[0]['id'])?$editorial_id[0]['id']:0;
			if($role_id == 4){
				$applications->approval_date = date('Y-m-d');
				$applications->approved_comment = $data['admin_comment'];
				if ($data['action'] == 'Publish') {
					$applications->artical_status = 6;
					$applications->article_stage_id = 8;
					$applications->publish_date = date('Y-m-d H:i:s');
					//$applications->approval_id = $editor;
				} else if ($this->request->data['action'] == 'Send Back to Editor for Edit') {
					$applications->artical_status = 3;
					$applications->article_stage_id = 4;
					$applications->is_draft = 1;
				}
			}	
			else{
				
				$applications->editorial_remark_date = date('Y-m-d');
				$applications->editorial_comment = $data['admin_comment'];
				if ($data['action'] == 'Send to Mentor') {
					$applications->artical_status = 2;
					$applications->article_stage_id = 2;
					$applications->approval_id = $editor;
				} else if ($this->request->data['action'] == 'Send Back to Author for Edit') {
					$applications->artical_status = 3;
					$applications->article_stage_id = 3;
					$applications->is_draft = 0;
					$applications->final_submit = 0;
				}
            
			}	
           //echo "<pre>"; print_r($applications); exit; 
			$this->notification($applications['id'],$editor,$user_id,$noti_type,$message);
           
            if ($this->ArticalDetails->save($applications)) {
					
                 if ($data['action'] == 'Send to Approval') {
					
                    $tableName  				= 'ArticalMovementHistory';
					$application_id_columnName = 'artical_id';
					$Article    				= $id;
					$comment                   = $data['admin_comment'];
					$current_with              = 'Send for Mentor';
					$initiated_date            = $applications->created_date;
					$panding_from              = date('Y-m-d');
					$this->fileMovement($tableName, $application_id_columnName, $Article, $current_with, $comment, $initiated_date, $panding_from, $data);
				}
				else if($data['action'] == 'Publish'){
					$tableName  				= 'ArticalMovementHistory';
					$application_id_columnName = 'artical_id';
					$Article    				= $id;
					$comment                   = $data['admin_comment'];
					$current_with              = 'Publish';
					$initiated_date            = $applications->created_date;
					$panding_from              = date('Y-m-d');
					$this->fileMovement($tableName, $application_id_columnName, $Article, $current_with, $comment, $initiated_date, $panding_from, $data);
				}
				if ($data['action'] == 'Publish') {
					$this->Flash->success(__('Article has been approved'));
				}
				else if ($this->request->data['action'] == 'Send Back to Editor for Edit') {
					$this->Flash->success(__('Article has been back to editorial desk.'));
				}
				else if ($this->request->data['action'] == 'Send Back to Author for Edit') {
					$this->Flash->success(__('Article has been back to author.'));
				}
				else if ($this->request->data['action'] == 'Send to Approval') {
					$this->Flash->success(__('Article has been sended for mentor.'));
				}
               
                
                return $this->redirect(['action' => 'pending-articles']);
            }
        }
        $this->set(compact('applications','role_id','article'));
    }
	public function getFieldName()
    {
       
        $this->viewBuilder()->layout('ajax');
        $len = $_POST['len'];
        		
		$vals = explode(',',$len);
		$data['title'] =$data['snapsis']=$data['intro']=$data['body']=$data['concl']='';
		for($i=0;$i<sizeof($vals);$i++){
			if($vals[$i] == 1){
				$data['title'] = 'title_view';
			}
			elseif($vals[$i] == 2){
				$data['snapsis'] = 'snapsis_view';
			}
			elseif($vals[$i] == 3){
				$data['intro'] = 'intro_view';
			}
			elseif($vals[$i] == 4){
				$data['body'] = 'body_view';
			}
			elseif($vals[$i] == 5){
				$data['concl'] = 'conclusion_view';
			} 
			
		}
		//echo "<pre>"; print_r($data); exit;
		echo json_encode($data); exit;
    }
	public function forwordEditorialDesk(){
		$this->viewBuilder()->layout('ajax');
        $ids = $_POST['ids'];
		if($ids > 0){
			$user_id = $this->Auth->user('id');
			$language_id = $this->Auth->user('language_id');
			$article = $this->ArticalDetails->get($this->Sanitize->clean($ids));
			$noti_type = "Article";
			$message = $article['title'];
			$editorial_id = $this->getEditorialId($article['language_id']);
			
			$editor = isset($editorial_id[0]['id'])?$editorial_id[0]['id']:0;
			$this->notification($article->id,$editor,$user_id,$noti_type,$message);
			$query = $this->ArticalDetails->query();
			$query->update()
				->set(['editorial_id' => $editor,'final_submit'=>1])
				->where(['id' => $ids])
				->execute(); 
			$tableName  				= 'ArticalMovementHistory';
			$application_id_columnName = 'artical_id';
			$Article    				= $ids;
			$comment                   = '';
			$current_with              = 'Editorial Desk';
			$initiated_date            = $article->created_date;
			$panding_from              = date('Y-m-d');

			$this->fileMovement($tableName, $application_id_columnName, $Article, $current_with, $comment, $initiated_date, $panding_from, $data);
			echo "Article Forward to Editorial Desk"; exit;			
		}
		else{
			echo "Articlenot forward to editorial desk"; exit;
		}
		
	}
	public function fetchWebsites($id =NULL){
		$user_id = $this->Auth->user('id');
		$language_id = $this->Auth->user('language_id');
		if($id > 0){
			$article = $this->ArticalDetails->get($this->Sanitize->clean($id), [
            'contain' => ['ArticleTags','Languages','ArticleCategories','Users'],
        ]);
			//$article = $this->ArticalDetails->get($this->Sanitize->clean($id,));
		}
		else{
			$article = $this->ArticalDetails->newEntity();
		}
        
        if ($this->request->is(['post','put'])) {
            $data                 = $this->request->getData();
			//echo "<pre>"; print_r($data); exit;
			if(!empty($this->request->data['save'])){
				$tag = explode(',',$data['tag_id']);
				$article             = $this->ArticalDetails->patchEntity($article, $data);
				$article->created_at = date('Y-m-d H:i:s');
				$article->user_id = $data['author_id'];
				$article->assign_by = $user_id;
				$article->editorial_id = $user_id;
				$article->final_submit = 1;
				$article->artical_status = 6;
				$article->article_stage_id = 8;
				$article->approval_date = date('Y-m-d');
				$article->publish_date = date('Y-m-d H:i:s');
				$article->approved_comment = "Mentor By Editorial desk";
				$error = $article->errors();
				
				if ($this->ArticalDetails->save($article)) {
					$article_id = $article->id;
					$referenceData = array();
					$this->ArticleTags->deleteAll(['article_id' => $article_id]);
					for($i=0;$i<sizeof($tag);$i++){
							$tags[$i]['name'] = $tag[$i];
							$tags[$i]['article_id'] = $article_id;
					}
						$tags_en  = $this->ArticleTags->newEntity();
						$artic  = $this->ArticleTags->patchEntities($tags_en, $tags);
						$articleLinss = $this->ArticleTags->saveMany($artic);
					
						$this->Flash->success(__('The article has been published.'));
						return $this->redirect(['controller'=>'new-articles','action' => 'fetch-websites',$article_id]);
				}
				else{
					$this->Flash->error(__('The article could not be saved. Please, try again.'));
				}
			}
				else if(!empty($this->request-data['forward_to_ditorial'])){
					if($id > 0){
						
						//$user_id = $this->Auth->user('id');
						$language_id = $this->Auth->user('language_id');
						$article = $this->ArticalDetails->get($id);
						$user_id = $article['user_id'];
						$noti_type = "Article";
						$message = $article['title'];
						$editorial_id = $this->getEditorialId($article['language_id']);
						//echo "<pre>"; print_r($editorial_id); exit;
						$editor = isset($editorial_id[0]['id'])?$editorial_id[0]['id']:0;
						$this->notification($article->id,$editor,$user_id,$noti_type,$message);
						$query = $this->ArticalDetails->query();
						$query->update()
							->set(['editorial_id' => $editor,'final_submit'=>1,'is_draft'=>1,'article_stage_id'=>1,'artical_status'=>1])
							->where(['id' => $article['id']])
							->execute(); 
						$tableName  				= 'ArticalMovementHistory';
						$application_id_columnName = 'artical_id';
						$Article    				= $article['id'];
						$comment                   = '';
						$current_with              = 'Editorial Desk';
						$initiated_date            = $article->created_date;
						$panding_from              = date('Y-m-d');

						$this->fileMovement($tableName, $application_id_columnName, $Article, $current_with, $comment, $initiated_date, $panding_from, $data);
						//echo "Article Forward to Editorial Desk"; exit;	
						$this->Flash->success(__('Article Forward to Editorial Desk'));
						return $this->redirect(['controller'=>'new-articles','action' => 'pending-articles']);
					}
					else{
						//echo "Articlenot forward to editorial desk"; exit;
						$this->Flash->success(__('Article not forward to editorial desk'));
						return $this->redirect(['controller'=>'new-articles','action' => 'fetch-websites',$article_id]);
					}
					
				}
				else{
					$this->Flash->success(__('The article has been not saved.'));
					return $this->redirect(['controller'=>'new-articles','action' => 'fetch-websites',$article_id]);	
				}
        }
		$role_id = $this->Auth->user('role_id');
		if($role_id ==2){
			$auther_list = $this->Users->find('list',['keyField'=>'id','valueField'=>'name'])->where(['language_id'=>$language_id,'id'=>$user_id]);
		}
		else{
			$auther_list = $this->Users->find('list',['keyField'=>'id','valueField'=>'name'])->where(['language_id'=>$language_id,'role_id'=>2]);
		}
		
		$lang = $this->Languages->find('list', ['limit' => 200]);
		$article_categories = $this->ArticleCategories->find('list', ['limit' => 200]);
		
        $this->set(compact('article','lang','article_categories','id','auther_list','role_id'));
		
	}
	public function uploadArticles($id =NULL){
		$user_id = $this->Auth->user('id');
		$role_id = $this->Auth->user('role_id');
		$language_id = $this->Auth->user('language_id');
		if($id > 0){
			$article = $this->ArticalDetails->get($this->Sanitize->clean($id), [
            'contain' => ['ArticleTags','Languages','ArticleCategories','Users'],
        ]);
			//$article = $this->ArticalDetails->get($this->Sanitize->clean($id,));
		}
		else{
			$article = $this->ArticalDetails->newEntity();
		}
        
        if ($this->request->is(['post','put'])) {
            $data  = $this->request->getData();
			//echo "<pre>"; print_r($data); exit;
			if(!empty($this->request->data['save'])){
				$tag = explode(',',$data['tag_id']);
				$article             = $this->ArticalDetails->patchEntity($article, $data);
				$article->created_at = date('Y-m-d H:i:s');
				$article->user_id = $data['author_id'];
				if($role_id ==3){
					$article->editorial_id = $user_id;
				}
				$article->assign_by = $user_id;
				 if ($data['artical_image']['name'] != '') {
				$certificate  = $this->uploadFiles('article/artical_image', $data['artical_image']);
				//echo "<pre>"; print_r($certificate); exit;
				$article->artical_image = $certificate['filename'];
				} else {
					$article->artical_image = @$data['artical_image_old'];
				} 
				if ($data['intro_image']['name'] != '') {
				$certificate2  = $this->uploadFiles('article/artical_upload', $data['intro_image']);
				//echo "<pre>"; print_r($certificate); exit;
				$article->uploaded_articles = $certificate2['filename'];
				} else {
					$article->uploaded_articles = @$data['intro_image_old'];
				}
				
				$filename = 'https://op-eds.ritamdigital.org/files/article/artical_upload/'.$certificate2['filename'];
				//$filename = 'http://localhost/abhay_panel/files/article/artical_upload/'.$certificate2['filename'];
				//$file = file_get_contents($filename);
					//$article->body_desc = $file;
					//$article->title = "Demo";
				$i=0;
				$file = fopen($filename, "r");
                $members = array();
                
                while (!feof($file)) {
                   $members[] = fgets($file);
                }
				//echo $file;
				
				$l=0;
				$str = '';
				for($m=0;$m<count($members);$m++){
					if($l == 0 && $members[$m] !=''){
						$article->title = substr($members[$m], 0, 200);
					}
					else{
						if($members[$m] !=''){
							if($str == ''){
								$str = $members[$m];
							}
							else{
								$str = $str."<br>".$members[$m];
							}
							
						}	
					}
					$l++;
				}
				$article->body_desc = $str;
				if($role_id ==3){
					$article->final_submit = 1;
					$article->artical_status = 1;
					$article->article_stage_id = 1;
					$article->is_draft = 1;
				}
				else{
					$article->final_submit = 0;
				}
				$error = $article->errors();
				if ($this->ArticalDetails->save($article)) {
					$article_id = $article->id;
					$referenceData = array();
					$this->ArticleTags->deleteAll(['article_id' => $article_id]);
					for($i=0;$i<sizeof($tag);$i++){
							$tags[$i]['name'] = $tag[$i];
							$tags[$i]['article_id'] = $article_id;
					}
					$tags_en  = $this->ArticleTags->newEntity();
					$artic  = $this->ArticleTags->patchEntities($tags_en, $tags);
					$articleLinss = $this->ArticleTags->saveMany($artic);				
					$this->Flash->success(__('The article has been saved.'));
					return $this->redirect(['controller'=>'new-articles','action' => 'add',$article_id]);
				}
				else{
					$this->Flash->error(__('The article could not be saved. Please, try again.'));
				}
			}
			else if(!empty($this->request->data['forward_to_ditorial'])){					
				//$user_id = $this->Auth->user('id');
				$language_id = $this->Auth->user('language_id');
				$article = $this->ArticalDetails->get($id);
				$user_id = $article['user_id'];
				$noti_type = "Article";
				$message = $article['title'];
				$editorial_id = $this->getEditorialId($article['language_id']);
				//echo "<pre>"; print_r($editorial_id); exit;
				$editor = isset($editorial_id[0]['id'])?$editorial_id[0]['id']:0;
				if($editor > 0){
				$this->notification($article->id,$editor,$user_id,$noti_type,$message);
				$query = $this->ArticalDetails->query();
				$query->update()
					->set(['editorial_id' => $editor,'final_submit'=>1,'is_draft'=>1,'article_stage_id'=>1,'artical_status'=>1])
					->where(['id' => $article['id']])
					->execute(); 
				$tableName  				= 'ArticalMovementHistory';
				$application_id_columnName = 'artical_id';
				$Article    				= $article['id'];
				$comment                   = '';
				$current_with              = 'Editorial Desk';
				$initiated_date            = $article->created_date;
				$panding_from              = date('Y-m-d');

				$this->fileMovement($tableName, $application_id_columnName, $Article, $current_with, $comment, $initiated_date, $panding_from, $data);
				//echo "Article Forward to Editorial Desk"; exit;	
				$this->Flash->success(__('Article Forward to Editorial Desk'));
				return $this->redirect(['controller'=>'new-articles','action' => 'pending-articles']);
				}
				else{
					$this->Flash->error(__('No Editor Desk Active'));
					return $this->redirect(['controller'=>'new-articles','action' => 'add',$article['id']]);
				}
				
			}
			else if(!empty($this->request->data['forward_to_approval'])){					
				$article = $this->ArticalDetails->get($id);
				$user_id = $article['user_id'];
				$noti_type = "Article";
				$message = $article['title'];
				$editorial_id = $this->getApprovalId($article['language_id']);
				//echo "<pre>"; print_r($editorial_id); exit;
				$editor = isset($editorial_id[0]['id'])?$editorial_id[0]['id']:0;
				if($editor){
					$this->notification($article->id,$editor,$user_id,$noti_type,$message);
					$query = $this->ArticalDetails->query();
					$query->update()
						->set(['artical_status' => 2,'article_stage_id'=>2,'approval_id'=>$editor])
						->where(['id' => $article['id']])
						->execute(); 
					$tableName  				= 'ArticalMovementHistory';
					$application_id_columnName = 'artical_id';
					$Article    				= $article['id'];
					$comment                   = '';
					$current_with              = 'Mentor Desk';
					$initiated_date            = $article->created_date;
					$panding_from              = date('Y-m-d');

					$this->fileMovement($tableName, $application_id_columnName, $Article, $current_with, $comment, $initiated_date, $panding_from, $data);
					//echo "Article Forward to Editorial Desk"; exit;	
					$this->Flash->success(__('Article Forward to Mentor Desk'));
					return $this->redirect(['controller'=>'new-articles','action' => 'pending-articles']);
				}
				else{
					$this->Flash->error(__('No Mentor Desk Active'));
					return $this->redirect(['controller'=>'new-articles','action' => 'upload-articles',$article['id']]);
				}
				
			}
			else{
				$this->Flash->success(__('The article has been not saved.'));
				return $this->redirect(['controller'=>'new-articles','action' => 'upload-articles',$article_id]);	
			}
        }
		
		if($role_id ==2){
			$auther_list = $this->Users->find('list',['keyField'=>'id','valueField'=>'name'])->where(['language_id'=>$language_id,'role_id'=>2,'id'=>$user_id]);
		}
		else{
			$auther_list = $this->Users->find('list',['keyField'=>'id','valueField'=>'name'])->where(['language_id'=>$language_id,'role_id'=>2]);
		}
		
		$lang = $this->Languages->find('list', ['limit' => 200]);
		$article_categories = $this->ArticleCategories->find('list', ['limit' => 200]);
		
        $this->set(compact('article','lang','article_categories','id','auther_list','role_id'));
		
	}
	public function getCurtCall($id){
		$this->loadModel('ArticalDetails');
		$this->loadModel('ArticleCategories');
		$this->loadModel('Users');
		$postQuery = $this->ArticalDetails->find('all', [
            'contain' => ['Languages','ArticleCategories'],
            'order' => ['ArticalDetails.id' => 'desc'],
            'conditions' => ['ArticalDetails.id'=>$id]])->first();
		$pub_date = date("d-m-Y H:m:s",strtotime($postQuery['publish_date'])); 
		$user_id = $postQuery['user_id'];
		$user = $this->Users->find()->contain(['Roles','Languages'])->where(['Users.id'=>$user_id])->first();
		$cat = explode(',',$user['cat_id']);
		for($i=0;$i<count($cat);$i++){
			$article = $this->ArticleCategories->find()->where(['id'=>$cat[$i]])->first();
			//echo "<pre>"; print_r($article); exit;
			$art[]= $article['name'];
		}
		$art_detail = implode(',',$art);
		$url = "https://ritamdigital.org/api/authenticate";
		$auth_data = array('username'=>"ubaskpbuzg",'password'=>"WusfPGFun9qpY2vR");
		$auth_data = json_encode($auth_data);
		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
		curl_setopt($ch, CURLOPT_POSTFIELDS, $auth_data);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array(
			'Content-Type: application/json',
			'Content-Length: ' . strlen($auth_data))
		);
		$response = curl_exec($ch);
		$token = json_decode($response);
		curl_close($ch);
		$sample_data = array('token'=>$token->id_token,'id'=>(string)$user->id,'authorDescription'=>$user->description,'authorName' => $user->name, 'email' => $user->email,'languages'=>array($user['language']['name']),'profileUrl'=>'https://op-eds.ritamdigital.org/files/events/'.$user->profile_photo,'topics'=>array($art_detail));
		$data_string = json_encode($sample_data);
		$url = 'https://ritamdigital.org/services/ritam/api/authors/external';
		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array(
			'Content-Type: application/json',
			'Content-Length: ' . strlen($data_string))
		);
		$response = curl_exec($ch);
		curl_close($ch);
		
		$article_data = array('token'=>$token->id_token,'authorId'=>(string)$user_id,'id'=>(string)$postQuery['id'],'title'=>$postQuery['title'],'authorName' => $user->name,'content'=>$postQuery['body_desc'], 'description' => $postQuery['snopsis'],'languages'=>$postQuery['language']['name'],'imageUrl'=>'http://op-eds.ritamdigital.org/files/article/artical_image/'.$postQuery->artical_image,'pubDate'=>(string)$pub_date,'category'=>$postQuery['article_category']['name'],'dateFormat'=>"dd-MM-yyyy HH:mm:ss",'tags'=>array($postQuery['tag_id']));
		$data_string2 = json_encode($article_data);	
		$url ="https://ritamdigital.org/services/ritam/api/posts/author/external";
		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string2);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array(
			'Content-Type: application/json',
			'Content-Length: ' . strlen($data_string2))
		);
		$response2 = curl_exec($ch);
		$postId = json_decode($response2);
		curl_close($ch);
		$query = $this->ArticalDetails->query();
		$query->update()
		->set(['postId' => $postId->postId])
		->where(['id' => $id])
		->execute(); 
		
	}
	
	
}
