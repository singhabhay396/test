<?php
namespace App\Controller\Admin;

use App\Controller\Admin\AppController;
use Cake\Cache\Cache;
use Cake\Event\Event;
use Cake\Network\Exception\NotFoundException;
use Cake\Utility\Hash;
use Cake\View\Exception\MissingTemplateException;
use Cake\Core\Configure;
use Cake\ORM\TableRegistry;      

/**
 * Grievances Controller
 *
 * @property \App\Model\Table\GrievancesTable $Grievances
 *
 * @method \App\Model\Entity\PolicyDownload[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class GrievancesController extends AppController
{
    
    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */

    public $grievancetype = ['1'=>'Technical Query','2'=>'Public Procurement','3'=>'Regulatory issue'];

    public function index()
    {

        $search_condition = array();
        $data = $this->Sanitize->clean($this->request->getQuery());
        if (!empty($data['subject'])) {
            $postTitle = trim($data['subject']); 
            $this->set('subject', $postTitle);
            $search_condition[] = "Grievances.subject like '%" . $postTitle . "%'";
        }
        
        if (isset($data['status']) && $data['status'] !='') {
            $status = trim($data['status']);
            $this->set('status', $status);
            $search_condition[] = "Grievances.status = '" . $status . "'";
        }

        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        //pr($search_condition); die;
        $postQuery = $this->Grievances->find('all', [
            'order' => ['Grievances.id' => 'desc'],
            'conditions' => [$searchString]
        ]);
        $this->paginate = ['limit' => 10];
        
        $grievances = $this->paginate($postQuery);
        $grievancetype = $this->grievancetype;
        $this->set(compact('grievances','grievancetype'));
    }

    /**
     * View method
     *
     * @param string|null $id Policy Download id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $grievance = $this->Grievances->get($id, [
            'contain' => []
        ]);
        $grievancetype = $this->grievancetype;
        $this->set(compact('grievance','grievancetype'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    
}
