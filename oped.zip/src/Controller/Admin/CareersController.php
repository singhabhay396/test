<?php
namespace App\Controller\Admin;

use App\Controller\Admin\AppController;
use Cake\Cache\Cache;
use Cake\Event\Event;
use Cake\Network\Exception\NotFoundException;
use Cake\Utility\Hash;
use Cake\View\Exception\MissingTemplateException;
use Cake\Core\Configure;
use Cake\Utility\Text;
use Cake\ORM\TableRegistry;

/**
 * Careers Controller
 *
 * @property \App\Model\Table\CareersTable $Careers
 *
 * @method \App\Model\Entity\Career[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class CareersController extends AppController
{
    public function initialize()
    {
        parent::initialize();
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }

    private $careerTypes = [
        1 => 'Advertisement',
        2 => 'Application Form',
        3 => 'Others'
    ];

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {   
	    $search_condition = array();
        if (!empty($this->request->getQuery('title'))) {
            $title = trim($this->request->getQuery('title'));
            $this->set('title', $title);
            $search_condition[] = "Careers.title like '%" . $title . "%'";
        }
        if (isset($this->request->query['status']) && $this->request->getQuery('status') !='') {
            $status = trim($this->request->getQuery('status'));
            $this->set('status', $status);
            $search_condition[] = "Careers.status = '" . $status . "'";
        }
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        $postQuery = $this->Careers->find('all', [
            'contain' => ['Users'],
            'order' => ['Careers.id' => 'desc'],
            'conditions' => [$searchString]
        ]);

        $this->paginate = ['limit' => 10];
        $careers = $this->paginate($postQuery);

        $this->set(compact('careers')); 
		 
	    /*
        $postQuery = $this->Careers->find('all', [
            'contain' => ['Users'],
            'order' => ['Careers.id' => 'desc']
        ]);
        $this->paginate = ['limit' => 10];
        $careers = $this->paginate($postQuery);

        $this->set(compact('careers')); */
    }

    /**
     * View method
     *
     * @param string|null $id Career id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $career = $this->Careers->get($id, [
            'contain' => ['Users', 'CareerDocuments', 'CareerTranslations']
        ]);
        $careerTypes = $this->careerTypes;
        $this->set(compact('career', 'careerTypes'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $career = $this->Careers->newEntity();
        if ($this->request->is('post')) {
            $data                 = $this->request->getData();
            $career_translations  = [];
            if (isset($data['career_translations'])) {
                $career_translations = $data['career_translations'];
                unset($data['career_translations']);                
            }
            $career_documents = [];
            if (isset($data['career_documents'])) {
                $career_documents   = $data['career_documents'];
                unset($data['career_documents']);
            }
            $tcareer_documents = [];
            if (isset($career_translations['career_documents'])) {
                $tcareer_documents  = $career_translations['career_documents'];
                unset($career_translations['career_documents']);
            }
            $career_documents       = array_merge($career_documents, $tcareer_documents);
            $career->created        = date('Y-m-d H:i:s');
            $career                 = $this->Careers->patchEntity($career, $data);
            $career->start_date     = date('Y-m-d',strtotime($data['start_date']));
            if ($data['is_archive'] == 1 && empty($data['expiry_date'])) {
                $career->expiry_date    = date('Y-m-d');
            } else {
                $career->expiry_date    = date('Y-m-d',strtotime($data['expiry_date']));
            }
            if (empty($data['url'])) {
                $career->url        = strtolower(Text::slug($data['title']));
            } else {
                $career->url        = strtolower(Text::slug($data['url']));
            }
            if ($this->Careers->save($career)) {
                $career_id = $career->id;                
                if (!empty($career_translations)) {
                    $this->loadModel('CareerTranslations');
                    foreach ($career_translations as $key => $_translation) {
                        if (empty($_translation['id'])) {
                            unset($career_translations[$key]['id']);
                        }
                        $career_translations[$key]['career_id'] = $career_id;
                    }
                    $careerTranslation  = $this->CareerTranslations->newEntity();
                    $careerTranslation  = $this->CareerTranslations->patchEntities($careerTranslation, $career_translations);
                    $careerTranslations = $this->CareerTranslations->saveMany($careerTranslation);
                }
                if (!empty($career_documents)) {
                    $this->loadModel('CareerDocuments');
                    foreach ($career_documents as $key => $_document) {
                        if (empty($_document['id'])) {
                            unset($career_documents[$key]['id']);
                        }
                        if($_document['documents']['name']!=''){
                            $careerDoc = $this->uploadFiles('careers', $_document['documents']);
                            $career_documents[$key]['documents'] = $careerDoc['filename'];
                        }
                        $career_documents[$key]['career_id'] = $career_id;
                        $career_documents[$key]['status']    = 1;
                    }
                    $careerDocument  = $this->CareerDocuments->newEntity();
                    $careerDocument  = $this->CareerDocuments->patchEntities($careerDocument, $career_documents);
                    $careerDocuments = $this->CareerDocuments->saveMany($careerDocument);
                }
                $this->Flash->success(__('The career has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The career could not be saved. Please, try again.'));
        }
        $careerTypes = $this->careerTypes;
        $careerLanguages  = $this->languages;
        $system_languge_id = SYSTEM_LANGUAGE_ID;
        $this->set(compact('career', 'careerLanguages', 'system_languge_id','careerTypes'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Career id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $career = $this->Careers->get($id, [
            'contain' => ['CareerDocuments', 'CareerTranslations']
        ]);
        $career['career_translations'] = Hash::combine($career['career_translations'], '{n}.language_id', '{n}');
        if(!empty($career['career_documents'])){
            $career['english_document'] = array_filter($career['career_documents'], function($el) { return $el['language_id'] == 1 ; });
            $career['hindi_document'] = array_filter($career['career_documents'], function($el) { return $el['language_id'] == 2 ; });
            unset($career['career_documents']);
        }
        if ($this->request->is(['patch', 'post', 'put'])) {
            $data                 = $this->request->getData();
            $career_translations  = [];
            if (isset($data['career_translations'])) {
                $career_translations = $data['career_translations'];
                unset($data['career_translations']);                
            }
            $career_documents = [];
            if (isset($data['career_documents'])) {
                $career_documents   = $data['career_documents'];
                unset($data['career_documents']);
            }
            $tcareer_documents = [];
            if (isset($career_translations['career_documents'])) {
                $tcareer_documents  = $career_translations['career_documents'];
                unset($career_translations['career_documents']);
            }
            $career_documents       = array_merge($career_documents, $tcareer_documents);
            $career->created        = date('Y-m-d H:i:s');
            $career                 = $this->Careers->patchEntity($career, $data);
            $career->start_date     = date('Y-m-d',strtotime($data['start_date']));
            if ($data['is_archive'] == 1 && empty($data['expiry_date'])) {
                $career->expiry_date    = date('Y-m-d');
            } else {
                $career->expiry_date    = date('Y-m-d',strtotime($data['expiry_date']));
            }
            if (empty($data['url'])) {
                $career->url        = strtolower(Text::slug($data['title']));
            } else {
                $career->url        = strtolower(Text::slug($data['url']));
            }
            if ($this->Careers->save($career)) {
                $career_id = $career->id;                
                if (!empty($career_translations)) {
                    $this->loadModel('CareerTranslations');
                    foreach ($career_translations as $key => $_translation) {
                        if (empty($_translation['id'])) {
                            unset($career_translations[$key]['id']);
                        }
                        $career_translations[$key]['career_id'] = $career_id;
                    }
                    $careerTranslation  = $this->CareerTranslations->newEntity();
                    $careerTranslation  = $this->CareerTranslations->patchEntities($careerTranslation, $career_translations);
                    $careerTranslations = $this->CareerTranslations->saveMany($careerTranslation);
                }
                if (!empty($career_documents)) {
                    $this->loadModel('CareerDocuments');
                    foreach ($career_documents as $key => $_document) {
                        if (empty($_document['id'])) {
                            unset($career_documents[$key]['id']);
                        }
                        if($_document['documents']['name']!=''){
                            $careerDoc = $this->uploadFiles('careers', $_document['documents']);
                            $career_documents[$key]['documents'] = $careerDoc['filename'];
                        } else {
                            $career_documents[$key]['documents'] = $_document['old_documents'];
                        }
                        $career_documents[$key]['career_id'] = $career_id;
                        $career_documents[$key]['status']    = 1;
                    }
                    $careerDocument  = $this->CareerDocuments->newEntity();
                    $careerDocument  = $this->CareerDocuments->patchEntities($careerDocument, $career_documents);
                    $careerDocuments = $this->CareerDocuments->saveMany($careerDocument);
                }
                $this->Flash->success(__('The career has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The career could not be saved. Please, try again.'));
        }
        $careerTypes = $this->careerTypes;
        $careerLanguages  = $this->languages;
        $system_languge_id = SYSTEM_LANGUAGE_ID;
        $this->set(compact('career', 'careerLanguages', 'system_languge_id','careerTypes'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Career id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $career = $this->Careers->get($id);
        if ($this->Careers->delete($career)) {
            $this->loadModel('CareerDocuments');
            $this->loadModel('CareerTranslations');
            $this->CareerDocuments->deleteAll(['career_id' => $id]);
            $this->CareerTranslations->deleteAll(['career_id' => $id]);
            $this->Flash->success(__('The career has been deleted.'));
        } else {
            $this->Flash->error(__('The career could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }

    public function deleteRow()
    {
        $this->viewBuilder()->setLayout('ajax');
        $row_id         = $_POST['id'];
        $table_name     = $_POST['table_name'];
        $custumTable    = TableRegistry::getTableLocator()->get($table_name);
        $removeQuery    = $custumTable->get($row_id);
        if($custumTable->delete($removeQuery)){
            echo 'removed';            
        }
        exit;  
    }
}
