<?php
namespace App\Controller\Admin;

use App\Controller\Admin\AppController;
use Cake\Cache\Cache;
use Cake\Event\Event;
use Cake\Network\Exception\NotFoundException;
use Cake\Utility\Hash;
use Cake\View\Exception\MissingTemplateException;
use Cake\Core\Configure;
use Cake\Filesystem\File;
use Cake\ORM\TableRegistry;
use Cake\View\View;

/**
 * Articles Controller
 *
 * @property \App\Model\Table\ArticlesTable $Articles
 *
 * @method \App\Model\Entity\Article[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class MessageBoxsController extends AppController
{

    public function initialize()
    {
        parent::initialize();
		$this->loadModel('ArticalDetails');
		$this->loadModel('ArticleOptionFiels');
		$this->loadModel('Languages');
		$this->loadModel('ArticleCategories');
		$this->loadModel('Tags');
		$this->loadModel('ArticleTags');
		$this->loadModel('OptionFields');
		$this->viewBuilder()->setLayout('default');
		$this->Auth->allow(['add','getFieldName','forwordEditorialDesk','changeNotificationStatus']);
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
		
    }

    private $linkRedirection = [
        'self'       => 'Self',
        'new-window' => 'New Window',
    ];

   

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
		$this->loadModel('Notifications');
		
        $search_condition = array();
        /* if (!empty($this->request->getQuery('title'))) {
            $title = trim($this->request->getQuery('title'));
            $this->set('title', $title);
            $search_condition[] = "ArticalDetails.title like '%" . $title . "%'";
        }
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
		$role_id = $this->Auth->user('role_id');
		
		$id = $this->Auth->user('id');
		//echo $role_id."-".$id; exit;
		if($role_id ==1){
			$postQuery = $this->ArticalDetails->find('all', [
            'contain' => ['Users','ArticleCategories','ApplicationStatus'],
            'order' => ['ArticalDetails.id' => 'desc'],
            'conditions' => [$searchString]
        ]);
		}
		else if($role_id ==3){
			$postQuery = $this->ArticalDetails->find('all', [
            'contain' => ['Users','ArticleCategories','ApplicationStatus'],
            'order' => ['ArticalDetails.id' => 'desc'],
            'conditions' => [$searchString,'editorial_id'=>$id,'article_stage_id !='=>8]
        ]);
		}
		else if($role_id ==4){
			$postQuery = $this->ArticalDetails->find('all', [
            'contain' => ['Users','ArticleCategories','ApplicationStatus'],
            'order' => ['ArticalDetails.id' => 'desc'],
            'conditions' => [$searchString,'approval_id'=>$id,'article_stage_id !='=>8]
        ]);
		}
		else{
			$postQuery = $this->ArticalDetails->find('all', [
            'contain' => ['Users','ArticleCategories','ApplicationStatus'],
            'order' => ['ArticalDetails.id' => 'desc'],
            'conditions' => [$searchString,'user_id'=>$id,'article_stage_id !='=>8]
        ]);
		} */
		 $notifications = TableRegistry::get('Notifications');
		$value = $notifications->find()->where(['to_user_id'=>$this->request->session()->read('Auth.User')['id'],'view_status'=>0])->count();
        $postQuery = $this->Notifications->find('all', [
            'contain' => ['Users','ArticalDetails','ArticalDetails.ArticleCategories','ArticalDetails.ApplicationStatus','ArticalDetails.Languages','ArticalDetails.Users'],
            'order' => ['Notifications.id' => 'desc'],
            'conditions' => ['Notifications.to_user_id'=>$this->request->session()->read('Auth.User')['id'],'Notifications.view_status'=>0]]);
        $this->paginate = ['limit' => 10];
        $articles = $this->paginate($postQuery);
		 /* echo $value;
		echo "<pre>"; print_r($articles); exit; */ 
        $this->set(compact('articles','role_id'));

    }
	
	
	public function published()
    {
		$this->loadModel('ArticalDetails');
		
        $search_condition = array();
        if (!empty($this->request->getQuery('title'))) {
            $title = trim($this->request->getQuery('title'));
            $this->set('title', $title);
            $search_condition[] = "ArticalDetails.title like '%" . $title . "%'";
        }
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
		$role_id = $this->Auth->user('role_id');
		
		$id = $this->Auth->user('id');
		//echo $role_id."-".$id; exit;
		if($role_id ==1){
			$postQuery = $this->ArticalDetails->find('all', [
            'contain' => ['Users','ArticleCategories','ApplicationStatus','Languages'],
            'order' => ['ArticalDetails.id' => 'desc'],
            'conditions' => [$searchString]
        ]);
		}
		else if($role_id ==3){
			$postQuery = $this->ArticalDetails->find('all', [
            'contain' => ['Users','ArticleCategories','ApplicationStatus','Languages'],
            'order' => ['ArticalDetails.id' => 'desc'],
            'conditions' => [$searchString,'editorial_id'=>$id,'article_stage_id' =>8]
        ]);
		}
		else if($role_id ==4){
			$postQuery = $this->ArticalDetails->find('all', [
            'contain' => ['Users','ArticleCategories','ApplicationStatus','Languages'],
            'order' => ['ArticalDetails.id' => 'desc'],
            'conditions' => [$searchString,'approval_id'=>$id,'article_stage_id' =>8]
        ]);
		}
		else{
			$postQuery = $this->ArticalDetails->find('all', [
            'contain' => ['Users','ArticleCategories','ApplicationStatus','Languages'],
            'order' => ['ArticalDetails.id' => 'desc'],
            'conditions' => [$searchString,'user_id'=>$id,'article_stage_id' =>8]
        ]);
		}
        
        $this->paginate = ['limit' => 10];
        $articles = $this->paginate($postQuery);
		//echo "<pre>"; print_r($articles); exit;
        $this->set(compact('articles','role_id'));

    }
    /**
     * View method
     *
     * @param string|null $id Article id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {   
        $this->loadModel('ArticalDetails');
        $this->loadModel('ArticalMovementHistory');
        $article = $this->ArticalDetails->find()->contain(['ArticleTags','Languages','ArticleCategories','Users'])->where(['ArticalDetails.id' => $id])->first();
		$articleHistory = $this->ArticalMovementHistory->find('all')->where(['ArticalMovementHistory.artical_id '=>$id])->toArray();
		$this->set(compact('article', 'articleHistory'));
    }
	
	public function preview($id = null)
    {   
        $this->loadModel('ArticalDetails');
        $article = $this->ArticalDetails->find()->contain(['ArticleTags','Languages','ArticleCategories','Users'])->where(['ArticalDetails.id' => $id])->first();
		if ($this->request->is(['post','put'])) {
			$data                 = $this->request->getData();
			$article_id = $data['article_id'];
			$user_id = $this->Auth->user('id');
			$language_id = $this->Auth->user('language_id');
			$article = $this->ArticalDetails->get($this->Sanitize->clean($article_id));
			$noti_type = "Article";
			$message = $article['title'];
			$editorial_id = $this->getEditorialId($language_id);
			
			$editor = isset($editorial_id[0]['id'])?$editorial_id[0]['id']:0;
			$this->notification($article->id,$editor,$user_id,$noti_type,$message);
			$query = $this->ArticalDetails->query();
			$query->update()
				->set(['editorial_id' => $editor,'final_submit'=>1,'is_draft'=>1,'article_stage_id'=>1,'artical_status'=>1])
				->where(['id' => $article_id])
				->execute(); 
			$tableName  				= 'ArticalMovementHistory';
			$application_id_columnName = 'artical_id';
			$Article    				= $article_id;
			$comment                   = '';
			$current_with              = 'Editorial Desk';
			$initiated_date            = $article->created_date;
			$panding_from              = date('Y-m-d');

			$this->fileMovement($tableName, $application_id_columnName, $Article, $current_with, $comment, $initiated_date, $panding_from, $data);
			$this->Flash->success(__('Article Forward to Editorial Desk'));
			return $this->redirect(['controller'=>'articles','action' => 'index']);			
		}
		/* else{
			
			return $this->redirect(['controller'=>'articles','action' => 'preview',$id]);	
		}
		 */
        $this->set('article', $article);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add($id =NULL)
    {
		
		$user_id = $this->Auth->user('id');
		if($id > 0){
			$article = $this->ArticalDetails->get($this->Sanitize->clean($id), [
            'contain' => ['ArticleTags','Languages','ArticleCategories','Users'],
        ]);
			//$article = $this->ArticalDetails->get($this->Sanitize->clean($id,));
		}
		else{
			$article = $this->ArticalDetails->newEntity();
		}
        
        if ($this->request->is(['post','put'])) {
            $data                 = $this->request->getData();
			$tag = explode(',',$data['tag_id']);
            $article             = $this->ArticalDetails->patchEntity($article, $data);
			$article->created_at = date('Y-m-d H:i:s');
			$article->user_id = $user_id;
            $error = $article->errors();
			if ($data['intro_image']['name'] != '') {
				$certificate  = $this->uploadFiles('article/artical_intro', $data['intro_image']);
				$article->intro_image = $certificate['filename'];
			} else {
				$article->intro_image = @$data['intro_image_old'];
			}
			if ($data['artical_image']['name'] != '') {
				$certificates  = $this->uploadFiles('article/artical_image', $data['artical_image']);
				$article->artical_image = $certificates['filename'];
			} else {
				$article->artical_image = @$data['artical_image_old'];
			}
            if(!empty($error['title']['_empty'])){

                $this->Flash->error(__("Please fill the Article Title"));
            }
            else if(!empty($error['introduction']['_empty'])){

                $this->Flash->error(__("Please fill the Introducation details"));
            }
            else if(!empty($error['body_desc']['_empty'])){

                $this->Flash->error(__("Please fill the Body details"));
            }
            else if(!empty($error['tag_id']['_empty'])){

                $this->Flash->error(__("Please fill the Article Type"));
            }
            else{
			if(isset($data['save_as_draft']) && $data['save_as_draft'] =='Save As Draft'){
				$article->is_draft = 0;
			}
			else{
				$article->is_draft = 0;
			}
			//echo "<pre>"; print_r($article); exit;
            if ($this->ArticalDetails->save($article)) {
                $article_id = $article->id;
				if($data['field_id'] !=''){
					$article_field = $this->ArticleOptionFiels->newEntity();
					$op = explode(',',$data['field_id']);
					for($k=0;$k<sizeof($op);$k++){
						$article_links[$k]['option_id'] = $op[$k];
						$article_links[$k]['article_id'] = $article_id;
					}
					$articleLinks  = $this->ArticleOptionFiels->newEntity();
					$articleLinks  = $this->ArticleOptionFiels->patchEntities($articleLinks, $article_links);
					$articleLinkss = $this->ArticleOptionFiels->saveMany($articleLinks);
				}
				$referenceData = array();
				$this->ArticleTags->deleteAll(['article_id' => $article_id]);
				for($i=0;$i<sizeof($tag);$i++){
					//$referenceData = $this->ArticleTags->find()->where(['name' => $tag[$i],'article_id'=>$article_id])->toArray();
						$tags[$i]['name'] = $tag[$i];
						$tags[$i]['article_id'] = $article_id;
				}
					$tags_en  = $this->ArticleTags->newEntity();
					$artic  = $this->ArticleTags->patchEntities($tags_en, $tags);
					$articleLinss = $this->ArticleTags->saveMany($artic);
				
				
				if(!empty($this->request->data['save_as_draft'])){
					$this->Flash->success(__('The article has been saved as draft.'));
					return $this->redirect(['controller'=>'articles','action' => 'add',$article_id]);
				}else{
					$this->Flash->success(__('The article has been saved.'));
					return $this->redirect(['controller'=>'articles','action' => 'preview',$article_id]);	
				}
                

                //return $this->redirect(['action' => 'index']);
            }
            else{
                $this->Flash->error(__('The article could not be saved. Please, try again.'));
            }
        }
            
        }
 
		$lang = $this->Languages->find('list', ['limit' => 200]);
		$article_categories = $this->ArticleCategories->find('list', ['limit' => 200]);
		$tag = $this->Tags->find('list', ['limit' => 200]);
		$option_fields = $this->OptionFields->find('all', ['limit' => 200]);
        $this->set(compact('article','lang','article_categories','tag','id','option_fields','user_id'));
    }
	
	public function createArticleStep2($id = null)
    {
		$this->loadModel('ArticalDetails');
		$user_id = $this->Auth->user('id');
        $article = $this->ArticalDetails->get($this->Sanitize->clean($id));
		//echo "<pre>"; print_r($app_detail); exit;
        if ($this->request->is(['post','put'])) {
            $data                 = $this->request->getData();
            $article             = $this->ArticalDetails->patchEntity($article, $data);
			//echo "<pre>"; print_r($data); exit;
            if($data['intro_image']['name']!=''){
                $headerImage = $this->uploadImage('article', $data['intro_image'],'artical_image');
                $article->intro_image = $headerImage['filename'];
            }
			if(isset($data['save_draft']) && $data['save_draft'] =='Save As Draft'){
				$article->is_draft = 0;
			}
			else{
				$article->is_draft = 1;
			}
            if ($this->ArticalDetails->save($article)) {
                $article_id = $article->id;
				if(!empty($this->request->data['save_draft'])){
					$this->Flash->success(__('The article has been saved.'));
					return $this->redirect(['controller'=>'articles','action' => 'index']);
				}else{
					$this->request->session()->write('application_id', $article_id);
					return $this->redirect(['action' => 'createArticleStep3',$article_id]);
				}
                

                //return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The article could not be saved. Please, try again.'));
        }
        $this->set(compact('article','id'));
    }
	
	public function createArticleStep3($id = null)
    {
		$this->loadModel('ArticalDetails');
		$user_id = $this->Auth->user('id');
        $article = $this->ArticalDetails->get($this->Sanitize->clean($id));
		//echo "<pre>"; print_r($app_detail); exit;
        if ($this->request->is(['post','put'])) {
            $data                 = $this->request->getData();
            $article             = $this->ArticalDetails->patchEntity($article, $data);
            if($data['artical_image']['name']!=''){
                $headerImage = $this->uploadImage('article', $data['artical_image'],'artical_image');
                $article->artical_image = $headerImage['filename'];
            }
			if(isset($data['save_draft']) && $data['save_draft'] =='Save As Draft'){
				$article->is_draft = 0;
			}
			else{
				$article->is_draft = 1;
			}
            if ($this->ArticalDetails->save($article)) {
                $article_id = $article->id;
				if(!empty($this->request->data['save_draft'])){
					$this->Flash->success(__('The article has been saved.'));
					return $this->redirect(['controller'=>'articles','action' => 'index']);
				}else{
					
					
					return $this->redirect(['action' => 'createArticleStep4',$article_id]);
				}
                

                //return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The article could not be saved. Please, try again.'));
        }
        $this->set(compact('article','id'));
    }
	
	public function createarticleStep4($id =NULL)
    {
		$this->loadModel('ArticalDetails');
		$this->loadModel('Languages');
		$this->loadModel('ArticleCategories');
		$this->loadModel('Tags');
		$user_id = $this->Auth->user('id');
		$language_id = $this->Auth->user('language_id');
        $article = $this->ArticalDetails->get($this->Sanitize->clean($id));
        if ($this->request->is(['post','put'])) {
            $data                 = $this->request->getData();
            $article             = $this->ArticalDetails->patchEntity($article, $data);
			if(isset($data['save_draft']) && $data['save_draft'] =='Save As Draft'){
				$article->is_draft = 0;
			}
			else{
				$article->is_draft = 1;
			}
			//echo "<pre>"; print_r($article); exit;
            if ($this->ArticalDetails->save($article)) {
                $article_id = $article->id;
				if(!empty($this->request->data['save_draft'])){
					$this->Flash->success(__('The article has been saved as draft.'));
					return $this->redirect(['controller'=>'articles','action' => 'index']);
				}else{
					$noti_type = "Article";
					$message = $article['title'];
					$editorial_id = $this->getEditorialId($language_id);
					$editor = isset($editorial_id[0]['id'])?$editorial_id[0]['id']:0;
					$this->notification($article->id,$editor,$user_id,$noti_type,$message);
					$query = $this->ArticalDetails->query();
                    $query->update()
                        ->set(['editorial_id' => $editor,'final_submit'=>1])
                        ->where(['id' => $article_id])
                        ->execute(); 
						$this->Flash->success(__('The article has been saved.'));
					return $this->redirect(['controller'=>'articles','action' => 'add',$article_id]);
				}
                

                //return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The article could not be saved. Please, try again.'));
        }
 
		$lang = $this->Languages->find('list', ['limit' => 200]);
		$article_categories = $this->ArticleCategories->find('list', ['limit' => 200]);
		$tag = $this->Tags->find('list', ['limit' => 200]);
        $this->set(compact('article','lang','article_categories','tag','id'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Article id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $article = $this->Articles->get($id);
        if ($this->Articles->delete($article)) {
            $this->loadModel('ArticleTranslations');
            $this->ArticleTranslations->deleteAll(['article_id' => $id]);
            $this->Flash->success(__('The article has been deleted.'));
        } else {
            $this->Flash->error(__('The article could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }


	public function update($id) {
        //$id = base64_decode($id);
        $this->loadModel('ArticalDetails');
        $application = $this->ArticalDetails->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'index']);
        }
		$role_id = $this->Auth->user('role_id');
        $applications = $this->ArticalDetails->get($id);
        if ($this->request->is(['POST', 'PUT'])) {
			$user_id = $this->Auth->user('id');
			
			$language_id = $this->Auth->user('language_id');
            $data = $this->request->getData();
            $applications = $this->ArticalDetails->patchEntity($applications, $data);
			$noti_type = "Article";
			$message = $applications['title'];
			$editorial_id = $this->getApprovalId($language_id);
			
			$editor = isset($editorial_id[0]['id'])?$editorial_id[0]['id']:0;
			if($role_id == 4){
				$applications->approval_date = date('Y-m-d');
				$applications->approved_comment = $data['admin_comment'];
				if ($data['action'] == 'Publish') {
					$applications->artical_status = 6;
					$applications->article_stage_id = 8;
					$applications->publish_date = date('Y-m-d H:i:s');
					//$applications->approval_id = $editor;
				} else if ($this->request->data['action'] == 'Back To Editorial') {
					$applications->artical_status = 3;
					$applications->article_stage_id = 4;
					$applications->is_draft = 1;
				}
			}	
			else{
				$applications->editorial_remark_date = date('Y-m-d');
				$applications->editorial_comment = $data['admin_comment'];
				if ($data['action'] == 'Send To Approve') {
					$applications->artical_status = 2;
					$applications->article_stage_id = 2;
					$applications->approval_id = $editor;
				} else if ($this->request->data['action'] == 'Back To Author') {
					$applications->artical_status = 3;
					$applications->article_stage_id = 3;
					$applications->is_draft = 0;
					$applications->final_submit = 0;
				}
            
			}	
            
			$this->notification($applications['id'],$editor,$user_id,$noti_type,$message);
           //echo "<pre>"; print_r($applications); exit;
            if ($this->ArticalDetails->save($applications)) {
					
                 if ($data['action'] == 'Send To Approve') {
					
                    $tableName  				= 'ArticalMovementHistory';
					$application_id_columnName = 'artical_id';
					$Article    				= $id;
					$comment                   = $data['admin_comment'];
					$current_with              = 'Approval Authority';
					$initiated_date            = $applications->created_date;
					$panding_from              = date('Y-m-d');
					$this->fileMovement($tableName, $application_id_columnName, $Article, $current_with, $comment, $initiated_date, $panding_from, $data);
				}
				else if($data['action'] == 'Publish'){
					$tableName  				= 'ArticalMovementHistory';
					$application_id_columnName = 'artical_id';
					$Article    				= $id;
					$comment                   = $data['admin_comment'];
					$current_with              = 'Publish';
					$initiated_date            = $applications->created_date;
					$panding_from              = date('Y-m-d');
					$this->fileMovement($tableName, $application_id_columnName, $Article, $current_with, $comment, $initiated_date, $panding_from, $data);
				}
				if ($data['action'] == 'Publish') {
					$this->Flash->success(__('Article has been approved'));
				}
				else if ($this->request->data['action'] == 'Back To Editorial') {
					$this->Flash->success(__('Article has been back to editorial desk.'));
				}
				else if ($this->request->data['action'] == 'Back To Author') {
					$this->Flash->success(__('Article has been back to author.'));
				}
				else if ($this->request->data['action'] == 'Send To Approve') {
					$this->Flash->success(__('Article has been sended for approval.'));
				}
               
                
                return $this->redirect(['action' => 'index']);
            }
        }
        $this->set(compact('applications','role_id'));
    }
	public function getFieldName()
    {
       
        $this->viewBuilder()->layout('ajax');
        $len = $_POST['len'];
        		
		$vals = explode(',',$len);
		$data['title'] =$data['snapsis']=$data['intro']=$data['body']=$data['concl']='';
		for($i=0;$i<sizeof($vals);$i++){
			if($vals[$i] == 1){
				$data['title'] = 'title_view';
			}
			elseif($vals[$i] == 2){
				$data['snapsis'] = 'snapsis_view';
			}
			elseif($vals[$i] == 3){
				$data['intro'] = 'intro_view';
			}
			elseif($vals[$i] == 4){
				$data['body'] = 'body_view';
			}
			elseif($vals[$i] == 5){
				$data['concl'] = 'conclusion_view';
			} 
			
		}
		//echo "<pre>"; print_r($data); exit;
		echo json_encode($data); exit;
    }
	public function forwordEditorialDesk(){
		$this->viewBuilder()->layout('ajax');
        $ids = $_POST['ids'];
		if($ids > 0){
			$user_id = $this->Auth->user('id');
			$language_id = $this->Auth->user('language_id');
			$article = $this->ArticalDetails->get($this->Sanitize->clean($ids));
			$noti_type = "Article";
			$message = $article['title'];
			$editorial_id = $this->getEditorialId($language_id);
			
			$editor = isset($editorial_id[0]['id'])?$editorial_id[0]['id']:0;
			$this->notification($article->id,$editor,$user_id,$noti_type,$message);
			$query = $this->ArticalDetails->query();
			$query->update()
				->set(['editorial_id' => $editor,'final_submit'=>1])
				->where(['id' => $ids])
				->execute(); 
			$tableName  				= 'ArticalMovementHistory';
			$application_id_columnName = 'artical_id';
			$Article    				= $ids;
			$comment                   = '';
			$current_with              = 'Editorial Desk';
			$initiated_date            = $article->created;
			$panding_from              = date('Y-m-d');

			$this->fileMovement($tableName, $application_id_columnName, $Article, $current_with, $comment, $initiated_date, $panding_from, $data);
			echo "Article Forward to Editorial Desk"; exit;			
		}
		else{
			echo "Articlenot forward to editorial desk"; exit;
		}
		
	}
	public function changeNotificationStatus(){
		$this->viewBuilder()->layout('ajax');
        $id = $_POST['id'];
		$this->loadModel('Notifications');
		$users = TableRegistry::get('Notifications');
            $query = $users->query();
            $update_agent = $query->update()
                    ->set(['view_status' => 1])
                    ->where(['id' => $id])
                    ->execute();
	}
	
	
	
}
