<?php
namespace App\Controller\Admin;

use App\Controller\Admin\AppController;

/**
 * IncubatorCenterExcellence Controller
 *
 * @property \App\Model\Table\IncubatorCenterExcellenceTable $IncubatorCenterExcellence
 *
 * @method \App\Model\Entity\IncubatorCenterExcellence[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class IncubatorCenterExcellenceController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {

        $search_condition = array();
        $data = $this->Sanitize->clean($this->request->getQuery());
        if (!empty($data['title'])) {
            $postTitle = trim($data['title']); 
            $this->set('title', $postTitle);
            $search_condition[] = "IncubatorCenterExcellence.title like '%" . $postTitle . "%'";
        }
        
        if (isset($data['status']) && $data['status'] !='') {
            $status = trim($data['status']);
            $this->set('status', $status);
            $search_condition[] = "IncubatorCenterExcellence.status = '" . $status . "'";
        }

        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        //pr($search_condition); die;
        $postQuery = $this->IncubatorCenterExcellence->find('all', [
            'order' => ['IncubatorCenterExcellence.id' => 'desc'],
            'conditions' => [$searchString]
        ]);

        $incubatorCenterExcellences = $this->paginate($postQuery);

        $this->set(compact('incubatorCenterExcellences'));
    }

    /**
     * View method
     *
     * @param string|null $id Incubator Center Excellence id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $incubatorCenterExcellence = $this->IncubatorCenterExcellence->get($id, [
            'contain' => ['IncubatorCenterExcellenceTranslation']
        ]);

        $this->set('incubatorCenterExcellence', $incubatorCenterExcellence);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $incubatorCenterExcellence = $this->IncubatorCenterExcellence->newEntity();
        if ($this->request->is('post')) {
            $data = $this->request->getData();
            $incubator_center_excellence_translation = [];
            if (isset($data['incubator_center_excellence_translation'])) {
                $incubator_center_excellence_translation = $data['incubator_center_excellence_translation'];
                unset($data['incubator_center_excellence_translation']);
            }
            $incubatorCenterExcellence = $this->IncubatorCenterExcellence->patchEntity($incubatorCenterExcellence, $this->request->getData());
            if($data['image']['name']!=''){
                $image = $this->uploadFiles('center_excellence', $data['image']);
                $incubatorCenterExcellence->image = $image['filename'];
            }
            if ($this->IncubatorCenterExcellence->save($incubatorCenterExcellence)) {
                $incubatorCenterExcellence_id = $incubatorCenterExcellence->id;
                if (!empty($incubator_center_excellence_translation)) {
                    $this->loadModel('IncubatorCenterExcellenceTranslation');
                    foreach ($incubator_center_excellence_translation as $key => $_translation) {
                        if (empty($_translation['id'])) {
                            unset($incubator_center_excellence_translation[$key]['id']);
                        }
                        $incubator_center_excellence_translation[$key]['incubator_center_excellence_id'] = $incubatorCenterExcellence_id;
                    }
                    $incubatorCenterExcellence  = $this->IncubatorCenterExcellenceTranslation->newEntity();
                    $incubatorCenterExcellence  = $this->IncubatorCenterExcellenceTranslation->patchEntities($incubatorCenterExcellence, $incubator_center_excellence_translation);
                    $incubatorCenterExcellences = $this->IncubatorCenterExcellenceTranslation->saveMany($incubatorCenterExcellence);
                }
                $this->Flash->success(__('The incubator center of excellence has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The incubator center excellence could not be saved. Please, try again.'));
        }
        $centerExcellenceLanguages  = $this->languages;
        $system_languge_id = SYSTEM_LANGUAGE_ID;
        $this->set(compact('incubatorCenterExcellence','centerExcellenceLanguages','system_languge_id'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Incubator Center Excellence id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $incubatorCenterExcellence = $this->IncubatorCenterExcellence->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $data = $this->request->getData();
            $incubator_center_excellence_translation = [];
            if (isset($data['incubator_center_excellence_translation'])) {
                $incubator_center_excellence_translation = $data['incubator_center_excellence_translation'];
                unset($data['incubator_center_excellence_translation']);
            }
            $incubatorCenterExcellence = $this->IncubatorCenterExcellence->patchEntity($incubatorCenterExcellence, $this->request->getData());
            if($data['image']['name']!=''){
                $image = $this->uploadFiles('center_excellence', $data['image']);
                $incubatorCenterExcellence->image = $image['filename'];
            }else{
                $incubatorCenterExcellence->image = $data['old_image'];
            }
            if ($this->IncubatorCenterExcellence->save($incubatorCenterExcellence)) {
                $incubatorCenterExcellence_id = $incubatorCenterExcellence->id;
                if (!empty($incubator_center_excellence_translation)) {
                    $this->loadModel('IncubatorCenterExcellenceTranslation');
                    foreach ($incubator_center_excellence_translation as $key => $_translation) {
                        if (empty($_translation['id'])) {
                            unset($incubator_center_excellence_translation[$key]['id']);
                        }
                        $incubator_center_excellence_translation[$key]['incubator_center_excellence_id'] = $incubatorCenterExcellence_id;
                    }
                    $incubatorCenterExcellence  = $this->IncubatorCenterExcellenceTranslation->newEntity();
                    $incubatorCenterExcellence  = $this->IncubatorCenterExcellenceTranslation->patchEntities($incubatorCenterExcellence, $incubator_center_excellence_translation);
                    $incubatorCenterExcellences = $this->IncubatorCenterExcellenceTranslation->saveMany($incubatorCenterExcellence);
                }
                $this->Flash->success(__('The incubator center excellence has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The incubator center excellence could not be saved. Please, try again.'));
        }
        $centerExcellenceLanguages  = $this->languages;
        $system_languge_id = SYSTEM_LANGUAGE_ID;
        $this->set(compact('incubatorCenterExcellence','centerExcellenceLanguages','system_languge_id'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Incubator Center Excellence id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $incubatorCenterExcellence = $this->IncubatorCenterExcellence->get($id);
        if ($this->IncubatorCenterExcellence->delete($incubatorCenterExcellence)) {
            $this->Flash->success(__('The incubator center excellence has been deleted.'));
        } else {
            $this->Flash->error(__('The incubator center excellence could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
