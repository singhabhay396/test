<?php
namespace App\Controller\Admin;

use App\Controller\Admin\AppController;
use Cake\Cache\Cache;
use Cake\Event\Event;
use Cake\Network\Exception\NotFoundException;
use Cake\Utility\Hash;
use Cake\View\Exception\MissingTemplateException;
use Cake\Core\Configure;

/**
 * Posts Controller
 *
 * @property \App\Model\Table\PostsTable $Posts
 *
 * @method \App\Model\Entity\Post[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class FaqsController extends AppController
{

    public function initialize()
    {
        parent::initialize();
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }

    private $faqCat = [
        1 => 'Startups',
        2 => 'Incubatee',
        3 => 'Incubation Nodal Officer'
    ];
    

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $search_condition = array();
        $page_length = !empty($this->request->getQuery('page_length')) ? $this->request->getQuery('page_length') : 10;
        $page = !empty($this->request->getQuery('page')) ? $this->request->getQuery('page') : 1;
        if (!empty($this->request->getQuery('title'))) {
            $title = trim($this->request->getQuery('title'));
            $this->set('title', $title);
            $search_condition[] = "Faqs.title like '%" . $title . "%'";
        }
        if (isset($this->request->query['status']) && $this->request->getQuery('status') !='') {
            $status = trim($this->request->getQuery('status'));
            $this->set('status', $status);
            $search_condition[] = "Faqs.status = '" . $status . "'";
        }
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        $postQuery = $this->Faqs->find('all', [
            'contain' => ['Users'],
            'order' => ['Faqs.id' => 'desc'],
            'conditions' => [$searchString]
        ]);

        $this->paginate = ['limit' => 10];
        $faqs = $this->paginate($postQuery);
        $this->set('selectedLen', $page_length);
        $faqCat = $this->faqCat;
        $this->set(compact('faqs','faqCat'));
    }

    /**
     * View method
     *
     * @param string|null $id Post id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $faq = $this->Faqs->get($id, [
            'contain' => ['Users']
        ]);  
        $faqCat = $this->faqCat;
        $this->set(compact('faq','faqCat'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $faqs = $this->Faqs->newEntity();
        if ($this->request->is('post')) {
            $data              = $this->request->getData();
            $faq_translations  = [];
            if (isset($data['faq_translations'])) {
                $faq_translations = $data['faq_translations'];
                unset($data['faq_translations']);
            }
            $faqs = $this->Faqs->patchEntity($faqs, $data);
            if($data['faq_image']['name'] != ''){
                $postImage = $this->uploadImage('Faqs', $data['faq_image']);
                $faqs->faqs_image = $postImage['filename'];
            }
            if ($this->Faqs->save($faqs)) {
                $faq_id = $faqs->id;
                if (!empty($faq_translations)) {
                    $this->loadModel('FaqTranslations');
                    foreach ($faq_translations as $key => $_translation) {
                        if (empty($_translation['id'])) {
                            unset($faq_translations[$key]['id']);
                        }
                        $faq_translations[$key]['faq_id'] = $faq_id;
                    }
                    $postTranslation  = $this->FaqTranslations->newEntity();
                    $postTranslation  = $this->FaqTranslations->patchEntities($postTranslation, $faq_translations);
                    $postTranslations = $this->FaqTranslations->saveMany($postTranslation);
                }
                $this->Flash->success(__('The post has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The post could not be saved. Please, try again.'));
        }

        $faqsLanguages  = $this->languages;
        $system_languge_id = SYSTEM_LANGUAGE_ID;
        $faqCat = $this->faqCat;
        $this->set(compact('faqs', 'faqsLanguages','system_languge_id','faqCat'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Post id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {    
        $faqs = $this->Faqs->get($id, [
            'contain' => ['faqTranslations']
        ]); 
        $faqs['faq_translations'] = Hash::combine($faqs['faq_translations'], '{n}.language_id', '{n}');
        if ($this->request->is(['patch', 'post', 'put'])) {
            $data              = $this->request->getData();
            $faq_translations = [];
            if (isset($data['faq_translations'])) {
                $faq_translations = $data['faq_translations'];
                unset($data['faq_translations']);
            }
            $faqs->updated = date('Y-m-d H:i:s');
            $faqs = $this->Faqs->patchEntity($faqs, $data);
            if($data['faqs_image']['name'] != ''){
                $postImage = $this->uploadImage('faqs', $data['faqs_image']);
                $faqs->faqs_image = $postImage['filename'];
            } else {
                $faqs->faqs_image = $data['old_faqs_image'];
            }
            if ($this->Faqs->save($faqs)) {
                $faq_id = $faqs->id;
                if (!empty($faq_translations)) {
                    $this->loadModel('FaqTranslations');
                    foreach ($faq_translations as $key => $_translation) {
                        if (empty($_translation['id'])) {
                            unset($faq_translations[$key]['id']);
                        }
                        $faq_translations[$key]['faq_id'] = $faq_id;
                    }
                    $postTranslation  = $this->FaqTranslations->newEntity();
                    $postTranslation  = $this->FaqTranslations->patchEntities($postTranslation, $faq_translations);
                    $postTranslations = $this->FaqTranslations->saveMany($postTranslation);
                }
                $this->Flash->success(__('The post has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The post could not be saved. Please, try again.'));
        }
        $faqsLanguages  = $this->languages;
        $system_languge_id = SYSTEM_LANGUAGE_ID;
        $faqCat = $this->faqCat;
        $this->set(compact('faqs', 'faqsLanguages','system_languge_id','faqCat'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Post id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $faq = $this->Faqs->get($id);
        if ($this->Faqs->delete($faq)) {
            $this->loadModel('FaqTranslations');
            $this->FaqTranslations->deleteAll(['faq_id' => $id]);
            $this->Flash->success(__('The FAQ has been deleted.'));
        } else {
            $this->Flash->error(__('The FAQ could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
