<?php
namespace App\Controller\Admin;

use App\Controller\Admin\AppController;
use Cake\Event\Event;

/**
 * Tehsils Controller
 *
 * @property \App\Model\Table\TehsilsTable $Tehsils
 *
 * @method \App\Model\Entity\Tehsil[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class TehsilsController extends AppController
{

    public function initialize()
    {
        parent::initialize();
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $search_condition = array();
        $data = $this->Sanitize->clean($this->request->getQuery());
        if (!empty($data['name'])) {
            $name = trim($data['name']);
            $this->set('name', $name); 
            $search_condition[] = "Tehsils.name like '%" . $name . "%'";
        }
        if (!empty($data['district_id'])) {
            $district_id = trim($data['district_id']);
            $this->set('district_id', $district_id); 
            $search_condition[] = "Districts.id like '%" . $district_id . "%'";
        }
        if (isset($data['status']) && $data['status'] !='') {
            $status = trim($data['status']);
            $this->set('status', $status); 
            $search_condition[] = "Tehsils.status like '%" . $status . "%'";
        }
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        $districts = $this->Tehsils->Districts->find('list');
            //->order(['id' => 'ASC'])
            //->toArray(); 
        $query = $this->Tehsils->find()->contain(['Districts'])->order(['Tehsils.id'=>'DESC'])->where([$searchString]);
         $tehsils = $this->paginate($query);
        $this->set(compact('tehsils','districts'));
    }

    /**
     * View method
     *
     * @param string|null $id Tehsil id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {

        $tehsil = $this->Tehsils->get($id, [
            'contain' => ['Districts']
        ]);

        $this->set('tehsil', $tehsil);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $tehsil = $this->Tehsils->newEntity();
        if ($this->request->is('post')) {
            $tehsil = $this->Tehsils->patchEntity($tehsil, $this->request->getData());
            if ($this->Tehsils->save($tehsil)) {
                $this->Flash->success(__('The tehsil has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The tehsil could not be saved. Please, try again.'));
        }
        $districts = $this->Tehsils->Districts->find('list')->order(['name']);
        $this->set(compact('tehsil', 'districts'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Tehsil id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $tehsil = $this->Tehsils->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $tehsil = $this->Tehsils->patchEntity($tehsil, $this->request->getData());
            if ($this->Tehsils->save($tehsil)) {
                $this->Flash->success(__('The tehsil has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The tehsil could not be saved. Please, try again.'));
        }
        $districts = $this->Tehsils->Districts->find('list')->order(['name']);
        $this->set(compact('tehsil', 'districts'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Tehsil id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $tehsil = $this->Tehsils->get($id);
        if ($this->Tehsils->delete($tehsil)) {
            $this->Flash->success(__('The tehsil has been deleted.'));
        } else {
            $this->Flash->error(__('The tehsil could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }

  
}
