<?php

namespace App\Controller;

use App\Controller\AppController;
use Cake\Core\Configure;
use Cake\Event\Event;
use Cake\I18n\Time;
use Cake\Network\Exception\NotFoundException;
use Cake\View\Exception\MissingTemplateException;
use Cake\Routing\Router;
use Cake\Http\Exception\NotFoundException as HttpNotFoundException;

/**
 * Galleries Controller
 *
 */
class GalleriesController extends AppController {

    public function initialize() {
        parent::initialize();
        $this->viewBuilder()->setLayout('frontend');
        $this->Auth->allow(['index','photoGalleryCategories','videoGalleryCategories','videos', 'photos']);
    }

    public function beforeFilter(Event $event) {
        parent::beforeFilter($event);
    }

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index() {
        return $this->redirect(['action' => 'photos']);
    }
	
    public function photoGalleryCategories()
    {
	$this->loadModel('GalleryCategories');
	if($this->isDevice) {
            $this->request->allowMethod(['get']);
            $_status = false;
            $_message = '';
	    
	    $totalCounts = 0;
	    
	    $galleryCategories = $this->GalleryCategories->find('all', ['conditions' => ['status'=>1]]);
	    if(!empty($galleryCategories)) {
		$totalCounts = $galleryCategories->count();
		
		$_status = true;
		$_message = 'Photo categories found';
		
		foreach($galleryCategories as $galleryCategory){
		    $galleryCategory->created = $galleryCategory->created->format('Y-m-d');
		}
		
	    }else{
		$_message = 'Photo categories not found';
	    }
	    
	    $this->set(compact('_status','_message','totalCounts','galleryCategories'));
	    $this->set('_serialize', ['_status','_message','totalCounts','galleryCategories']);
        }
    }
	
    public function videoGalleryCategories()
    {
	$this->loadModel('VideoCategories');
	if($this->isDevice) {
            $this->request->allowMethod(['get']);
            $_status = false;
            $_message = '';
	    
	    $totalCounts = 0;
	    
	    $videoCategories = $this->VideoCategories->find('all', ['conditions' => ['status'=>1]]);
	    if(!empty($videoCategories)) {
		$totalCounts = $videoCategories->count();
		
		$_status = true;
		$_message = 'Video categories found';
		
		foreach($videoCategories as $videoCategory){
		    $videoCategory->created = $videoCategory->created->format('Y-m-d');
		}
		
	    }else{
		$_message = 'Video categories not found';
	    }
	    
	    $this->set(compact('_status','_message','totalCounts','videoCategories'));
	    $this->set('_serialize', ['_status','_message','totalCounts','videoCategories']);
        }
    }

    public function videos()
    {
        $this->loadModel('VideoGalleries');
	if($this->isDevice) {
            $this->request->allowMethod(['get']);
            $_status = false;
            $_message = '';
	    
	    $totalCounts = 0;
	    $totalPages = 0;
	    $pageSize = 0;
	    $pageIndex = 0;
	    
	    $gal_photos = $this->VideoGalleries->find('all', ['conditions' => ['status'=>1]]);
	    $query = $this->request->query;
	    if(!empty($query)){
		if (!empty($query['title'])) {
		    $title = trim($query['title']);
		    $gal_photos = $gal_photos->where(['VideoGalleries.title LIKE "%'.$title.'%"']);
		}            
		if(!empty($query['gallery_category_id'])){
		    $gal_photos = $gal_photos->where(['VideoGalleries.gallery_category_id'=>$query['gallery_category_id']]);
		}
		if(!empty($query['fromdate'])){
		    $date_from = Time::parse($query['fromdate']);
		    $start_date = $date_from->i18nFormat('yyyy-MM-dd HH:mm:ss'); 
		    $gal_photos = $gal_photos->where(['DATE(VideoGalleries.created) >= "'.$start_date.'"']);
		}
		if(!empty($query['todate'])){
		    $date_to = Time::parse($query['todate']);
		    $end_date = $date_to->i18nFormat('yyyy-MM-dd HH:mm:ss'); 
		    $gal_photos = $gal_photos->where(['DATE(VideoGalleries.created) <= "'.$end_date.'"']);
		}
	    }
        }else{
	    $this->set('title', 'Video Gallery');
	    $search_condition = array();
	    if($this->request->is('post')) {
		if (!empty($this->request->data['title'])) {
		    $title1 = trim($this->request->data['title']);
		    $this->set('title1', $title1);
		    $search_condition[] = "VideoGalleries.title like '%" . $title1 . "%'";
		}            
		if (!empty($this->request->data['gallery_category_id'])) {
		    $gallery_category_id = trim($this->request->data['gallery_category_id']);
		    $this->set('gallery_category_id', $gallery_category_id);
		    $search_condition[] = "VideoGalleries.gallery_category_id like '%" . $gallery_category_id . "%'";
		}            
		if (!empty($this->request->data['fromdate'])) {
		    $date_from = Time::parse($this->request->data['fromdate']);                 
		    $start_date = $date_from->i18nFormat('yyyy-MM-dd HH:mm:ss'); 
		    $this->set('fromdate', $start_date);
		    $search_condition[] = "DATE(VideoGalleries.created) >= '" . $start_date . "'";
		}            
		if (!empty($this->request->data['todate'])) {                
		    $date_to = Time::parse($this->request->data['todate']);              
		    $date_to = $date_to->i18nFormat('yyyy-MM-dd HH:mm:ss');
		    $this->set('todate', $date_to);                
		    $search_condition[] = "DATE(VideoGalleries.created) <= '" . $date_to . "'";
		}            
	    }
	    $searchString = implode(' AND ', $search_condition);
	    $gal_photos = $this->VideoGalleries->find('all', ['conditions' => [$searchString,'status'=>1]]);
	}
        
        $galleryCategories = $this->VideoGalleries->VideoCategories->find('list', ['limit' => 200]);
	$this->paginate = ['limit' => 12];
	
	try{
	    $gal_photos = $this->paginate($gal_photos);
	}catch(HttpNotFoundException $e){
	    $gal_photos = array();
	}
	
	if($this->isDevice) {
	    $paging = $this->Paginator->getPaginator()->getPagingParams();
	    if (!empty($paging['VideoGalleries'])) {
                $totalCounts = $paging['VideoGalleries']['count'];
                $totalPages = $paging['VideoGalleries']['pageCount'];
                $pageSize  = $paging['VideoGalleries']['perPage'];
		$pageIndex = $paging['VideoGalleries']['current'];
            }
	    if($totalCounts != 0 && !empty($gal_photos)){
		$_status = true;
		$_message = 'Gallery videos Found';
		
		if(!empty($gal_photos)){
		    foreach($gal_photos as $gal_photo){
			$gal_photo->filename = Router::url('/',true) . 'files/galleries/' . $gal_photo->filename;
			$gal_photo->posting_date = $gal_photo->posting_date->format('Y-m-d');
			$gal_photo->created = $gal_photo->created->format('Y-m-d');
			$gal_photo->modified = $gal_photo->modified->format('Y-m-d');
		    }
		}
		
		$galleryCategories = $galleryCategories->toArray();
		$videoCategories = array();
		if(!empty($galleryCategories)){
		    $i=0;
		    foreach($galleryCategories as $key=>$value){
			$videoCategories[$i]['id'] = $key;
			$videoCategories[$i]['title'] = $value;
			
			$i++;
		    }
		}
	    }else{
		$_message = 'Gallery videos not found';
	    }
	    
	    $this->set(compact(
		'_status','_message','totalCounts','totalPages','pageSize','pageIndex','videoCategories','gal_photos'
	    ));
	    $this->set('_serialize', [
		'_status','_message','totalCounts','totalPages','pageSize','pageIndex','videoCategories','gal_photos'
	    ]);
	}else{
	    $this->set(compact('gal_photos','galleryCategories'));
	}
	
        /*$this->set('title', 'Video Gallery');
        $this->loadModel('VideoGalleries');
        $search_condition = array();
        if($this->request->is('post')) {
            if (!empty($this->request->data['title'])) {
                $title1 = trim($this->request->data['title']);
                $this->set('title1', $title1);
                $search_condition[] = "VideoGalleries.title like '%" . $title1 . "%'";
            }            
            if (!empty($this->request->data['gallery_category_id'])) {
                $gallery_category_id = trim($this->request->data['gallery_category_id']);
                $this->set('gallery_category_id', $gallery_category_id);
                $search_condition[] = "VideoGalleries.gallery_category_id like '%" . $gallery_category_id . "%'";
            }            
            if (!empty($this->request->data['fromdate'])) {
                $date_from = Time::parse($this->request->data['fromdate']);                 
                $start_date = $date_from->i18nFormat('yyyy-MM-dd HH:mm:ss'); 
                $this->set('fromdate', $start_date);
                $search_condition[] = "DATE(VideoGalleries.created) >= '" . $start_date . "'";
            }            
            if (!empty($this->request->data['todate'])) {                
                $date_to = Time::parse($this->request->data['todate']);              
                $date_to = $date_to->i18nFormat('yyyy-MM-dd HH:mm:ss');
                $this->set('todate', $date_to);                
                $search_condition[] = "DATE(VideoGalleries.created) <= '" . $date_to . "'";
            }            
        }
        $searchString = implode(' AND ', $search_condition);
        $gal_photos = $this->VideoGalleries->find('all', ['conditions' => [$searchString,'status'=>1]]);
        $galleryCategories = $this->VideoGalleries->VideoCategories->find('list', ['limit' => 200]);
		$this->paginate = ['limit' => 12];
        $gal_photos = $this->paginate($gal_photos);
        $this->set(compact('gal_photos','galleryCategories'));*/
    }

    public function photos()
    {
        $this->loadModel('Galleries');
	$search_condition = array();
	if($this->isDevice) {
            $this->request->allowMethod(['get']);
            
            $_status = false;
            $_message = '';
	    
	    $totalCounts = 0;
	    $totalPages = 0;
	    $pageSize = 0;
	    $pageIndex = 0;
	    
	    $gal_photos = $this->Galleries->find('all', ['conditions' => ['status'=>1]]);
	    $query = $this->request->query;
	    if(!empty($query)){
		if (!empty($query['title'])) {
		    $title = trim($query['title']);
		    $gal_photos = $gal_photos->where(['Galleries.title LIKE "%'.$title.'%"']);
		}
		if(!empty($query['gallery_category_id'])){
		    $gal_photos = $gal_photos->where(['Galleries.gallery_category_id'=>$query['gallery_category_id']]);
		}
		if(!empty($query['fromdate'])){
		    $date_from = Time::parse($query['fromdate']);
		    $start_date = $date_from->i18nFormat('yyyy-MM-dd HH:mm:ss'); 
		    $gal_photos = $gal_photos->where(['DATE(Galleries.created) >= "'.$start_date.'"']);
		}
		if(!empty($query['todate'])){
		    $date_to = Time::parse($query['todate']);
		    $end_date = $date_to->i18nFormat('yyyy-MM-dd HH:mm:ss'); 
		    $gal_photos = $gal_photos->where(['DATE(Galleries.created) <= "'.$end_date.'"']);
		}
	    }
        }else{
	    $this->set('title', 'Photo Gallery');
	    if($this->request->is('post')) {
		if (!empty($this->request->data['title'])) {
		    $title1 = trim($this->request->data['title']);
		    $this->set('title1', $title1);
		    $search_condition[] = "Galleries.title like '%" . $title1 . "%'";
		}
		if (!empty($this->request->data['gallery_category_id'])) {
		    $gallery_category_id = trim($this->request->data['gallery_category_id']);
		    $this->set('gallery_category_id', $gallery_category_id);
		    $search_condition[] = "Galleries.gallery_category_id like '%" . $gallery_category_id . "%'";
		}                        
		if (!empty($this->request->data['fromdate'])) {
		    $date_from = Time::parse($this->request->data['fromdate']);                 
		    $start_date = $date_from->i18nFormat('yyyy-MM-dd HH:mm:ss'); 
		    $this->set('fromdate', $start_date);
		    $search_condition[] = "DATE(Galleries.created) >= '" . $start_date . "'";
		}            
		if (!empty($this->request->data['todate'])) {                
		    $date_to = Time::parse($this->request->data['todate']);              
		    $date_to = $date_to->i18nFormat('yyyy-MM-dd HH:mm:ss');
		    $this->set('todate', $date_to);                
		    $search_condition[] = "DATE(Galleries.created) <= '" . $date_to . "'";
		}
	    }
	    $searchString = implode(' AND ', $search_condition);        
	    $gal_photos = $this->Galleries->find('all', ['conditions' => [$searchString,'status'=>1]]);
	}
	$galleryCategories = $this->Galleries->GalleryCategories->find('list', ['limit' => 200]);
        $this->paginate = ['limit' => 12];
	
	try{
	    $gal_photos = $this->paginate($gal_photos);
	}catch(HttpNotFoundException $e){
	    $gal_photos = array();
	}
	
	if($this->isDevice) {
	    $paging = $this->Paginator->getPaginator()->getPagingParams();
	    if (!empty($paging['Galleries'])) {
                $totalCounts = $paging['Galleries']['count'];
                $totalPages = $paging['Galleries']['pageCount'];
                $pageSize  = $paging['Galleries']['perPage'];
		$pageIndex = $paging['Galleries']['current'];
            }
	    if($totalCounts != 0 && !empty($gal_photos)){
		$_status = true;
		$_message = 'Gallery Photo Found';
		if(!empty($gal_photos)){
		    foreach($gal_photos as $gal_photo){
			$gal_photo->filename = Router::url('/',true) . 'files/galleries/' . $gal_photo->filename;
			$gal_photo->gallery_date = $gal_photo->gallery_date->format('Y-m-d');
			$gal_photo->created = $gal_photo->created->format('Y-m-d');
		    }
		}
		$galleryCategories = $galleryCategories->toArray();
		$photoCategories = array();
		if(!empty($galleryCategories)){
		    $i=0;
		    foreach($galleryCategories as $key=>$value){
			$photoCategories[$i]['id'] = $key;
			$photoCategories[$i]['title'] = $value;
			
			$i++;
		    }
		}
	    }else{
		$_message = 'Gallery photos not found';
	    }
	    
	    $this->set(compact(
		'_status','_message','totalCounts','totalPages','pageSize','pageIndex','photoCategories','gal_photos'
	    ));
	    $this->set('_serialize', [
		'_status','_message','totalCounts','totalPages','pageSize','pageIndex','photoCategories','gal_photos'
	    ]);
	}else{
	    $this->set('galleryCategories', $galleryCategories);
	    $this->set('gal_photos', $gal_photos);
	}
    }
}
