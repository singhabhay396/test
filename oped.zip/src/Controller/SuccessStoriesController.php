<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Event\Event;
use Cake\Routing\Router;

/**
 * SuccessStories Controller
 *
 * @property \App\Model\Table\SuccessStoriesTable $SuccessStories
 *
 * @method \App\Model\Entity\SuccessStory[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class SuccessStoriesController extends AppController
{

    public function initialize()
    {
        parent::initialize();
        $this->viewBuilder()->setLayout('frontend');
        $this->Auth->allow(['index']);
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        if($this->isDevice) {
            $this->request->allowMethod(['get']);
            
            $_status = false;
            $_message = '';
			
			$totalCounts = 0;
			$totalPages = 0;
			$pageSize = 0;
			$pageIndex = 0;
		}
        try{
			$successStories = $this->paginate($this->SuccessStories->find()->where(['status'=>1]));
		}catch(HttpNotFoundException $e){
			$successStories = array();
		}
        //echo "<pre>";print_r($successStories);exit;
        if($this->isDevice) {
			$paging = $this->Paginator->getPaginator()->getPagingParams();
            //echo "<pre>";print_r($paging);exit;
			if (!empty($paging['SuccessStories'])) {
				$totalCounts = $paging['SuccessStories']['count'];
				$totalPages = $paging['SuccessStories']['pageCount'];
				$pageSize  = $paging['SuccessStories']['perPage'];
				$pageIndex = $paging['SuccessStories']['current'];
			}
			if($totalCounts != 0 && !empty($successStories)){
				$_status = true;
				$_message = 'Success Stories Found';
				if(!empty($successStories)){
					foreach($successStories as $ss){
						$ss->image = Router::url('/',true) . 'files/success_stories/' . $ss->image;
						$ss->created = $ss->created->format('Y-m-d');
						$ss->modified = $ss->modified->format('Y-m-d');
					}
				}
			}else{
				$_message = 'Success Stories not found';
			}
			//echo "<pre>";print_r($event);exit;
			$this->set(compact(
				'_status','_message','totalCounts','totalPages','pageSize','pageIndex','successStories'
			));
			$this->set('_serialize', [
				'_status','_message','totalCounts','totalPages','pageSize','pageIndex','successStories'
			]);
		}else{
            $this->set(compact('successStories'));
        }
    }

}