<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Core\Configure;
use Cake\Event\Event;
use Cake\Network\Exception\NotFoundException;
use Cake\View\Exception\MissingTemplateException;
use Cake\View\View;

/**
 * Startups Controller
 *
 * @property \App\Model\Table\StartupsTable $Startups
 *
 * @method \App\Model\Entity\Startups[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class StartupsController extends AppController
{
    public function initialize()
    {
        parent::initialize();
        $this->viewBuilder()->setLayout('frontend');
        $this->Auth->allow(['index','recognition','TrackApplication','DownloadRecognitionCertificate','StartupPolicyNotifications','SelfCertification','ProductsServices','SuccessStories','downloadFile','addObservation']);
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }

    /**
     * Page method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
       
    }

    public function eligibilityCriteria()
    {
        # code...
    }

    public function registration($id = null)
    {
        $this->viewBuilder()->layout('frontend');
        $this->loadModel('StartupApplications');
        $check_status = $this->StartupApplications->findByUserId($this->Auth->user('id'))->toArray();
        if($this->Auth->user('role_id') != 7){
            $this->Flash->error(__('You are not authorized to submit Startup form.'));
            $this->redirect(['controller' => 'Dashboard']);
        }
        if(!empty($check_status)){
            $this->Flash->error(__('You have already registered for Startup.'));
            $this->redirect(['controller' => 'Dashboard']);
        }        
        if (empty($id)) {
            $application = $this->StartupApplications->newEntity();
        } else {
            $application = $this->StartupApplications->get($id);
        }
        $this->loadModel('Users');
        $users = $this->Users->get($this->Auth->user('id'),['contain'=>['Registration.Designations']]);

        if($this->request->is(['post','put'])){
            $data = $this->request->getData();
            if (trim($data['whether_registered_as_startup_with_dipp']) == '1' && empty(trim($data['dipp_registration_number']))) {
                $this->Flash->warning(__('Since you are not registered with Startup India Portal (DIPP) so you are not eligible to apply on Startup Haryana portal. To avail benefits from Statup Haryana, Please apply with DIPP then you can apply on this portal.'));
                return $this->redirect(['controller' => 'Dashboard']);
            }
            
            $startup_director = [];
            if (isset($data['startup_director'])) {
                $startup_director = $data['startup_director'];
                unset($data['startup_director']);
            }
            
            $application  = $this->StartupApplications->patchEntity($application, $data);

            if($data['is_corp_office_same_as_reg_office'] == 1){
                $application->corporate_state_id = $data['registered_state_id'];
                $application->corporate_district_id = $data['registered_district_id'];
            }

            if($data['is_regional_office_same_as_corp_office'] == 1){
                $application->regional_state_id = $application->corporate_state_id;
                $application->regional_district_id = $application->corporate_district_id;
            }

            if ($data['registered_state_id'] == 14 && $application->corporate_state_id == 14) {
                $application->eligibility_criteria = 'C1';
            } elseif ($data['are_you_an_incubatee'] == 1 && ($data['registered_state_id'] != 14 && $application->corporate_state_id != 14)) {
                $application->eligibility_criteria = 'C3';
            } else {
                $application->eligibility_criteria = 'C2';
            }              

            if($data['registration_certificate']['name']!=''){
                $certificate = $this->uploadFiles('registration', $data['registration_certificate']);
                $application->registration_certificate = $certificate['filename'];
            }
            if($data['pan_number_of_startup']['name']!=''){
                $certificate = $this->uploadFiles('registration', $data['pan_number_of_startup']);
                $application->pan_number_of_startup = $certificate['filename'];
            }
            if($data['balance_sheet_of_startup']['name']!=''){
                $certificate = $this->uploadFiles('registration', $data['balance_sheet_of_startup']);
                $application->balance_sheet_of_startup = $certificate['filename'];
            }
            if($data['dipp_startup_registration']['name']!=''){
                $certificate = $this->uploadFiles('registration', $data['dipp_startup_registration']);
                $application->dipp_startup_registration = $certificate['filename'];
            }
            if($data['letter_of_authorization']['name']!=''){
                $certificate = $this->uploadFiles('registration', $data['letter_of_authorization']);
                $application->letter_of_authorization = $certificate['filename'];
            }
            if($data['undertaking']['name']!=''){
                $certificate = $this->uploadFiles('registration', $data['undertaking']);
                $application->undertaking = $certificate['filename'];
            }
            if($data['self_declaration']['name']!=''){
                $certificate = $this->uploadFiles('registration', $data['self_declaration']);
                $application->self_declaration = $certificate['filename'];
            }
            if($data['certificate_from_incubator']['name']!=''){
                $certificate = $this->uploadFiles('registration', $data['certificate_from_incubator']);
                $application->certificate_from_incubator = $certificate['filename'];
            }            
            if($data['introduction']['name']!=''){
                $certificate = $this->uploadFiles('registration', $data['introduction']);
                $application->introduction = $certificate['filename'];
            }
            if($data['innovativeness']['name']!=''){
                $certificate = $this->uploadFiles('registration', $data['innovativeness']);
                $application->innovativeness = $certificate['filename'];
            }
            $application->user_id = $this->Auth->user('id');
            $application->start_date_of_incubation =  date('Y-m-d H:i:s',strtotime($data['start_date_of_incubation']));
            $application->end_date_of_incubation =  date('Y-m-d H:i:s',strtotime($data['end_date_of_incubation']));
            $application->category_id = implode(',', $data['category_id']);
            $application->date_of_registration = date('Y-m-d',strtotime($data['date_of_registration']));
            $application->date_of_incorporation = date('Y-m-d',strtotime($data['date_of_incorporation']));
            if($result = $this->StartupApplications->save($application)) {
                $application_id = $application->id;
                $reference_no = $this->generateReferenceNo($application_id);
                $query = $this->StartupApplications->query();
                $query->update()
                    ->set(['reference_no' => $reference_no])
                    ->where(['id' => $application_id])
                    ->execute();

                if (!empty($startup_director)) {
                    $this->loadModel('StartupDirectors');
                    foreach ($startup_director as $key => $_director) {
                        if (empty($_director['id'])) {
                            unset($startup_director[$key]['id']);
                        }
                        $startup_director[$key]['startup_application_id'] = $application_id;
                        $startup_director[$key]['nationality'] = 1;
                        if($_director['id_proof']['name']!=''){
                            $certificate1 = $this->uploadFiles('directors', $_director['id_proof']);
                            $startup_director[$key]['id_proof'] = $certificate1['filename'];
                        }
                        if($_director['residential_proof']['name']!=''){
                            $certificate1 = $this->uploadFiles('directors', $_director['residential_proof']);
                            $startup_director[$key]['residential_proof'] = $certificate1['filename'];
                        }
                    }
                    $startupDirector  = $this->StartupDirectors->newEntity();
                    $startupDirector  = $this->StartupDirectors->patchEntities($startupDirector, $startup_director);
                    $startupDirectors = $this->StartupDirectors->saveMany($startupDirector);
                }
                $successSms = "Thanks for your application, Please note Reference number $reference_no for further communication. You can also check your mail for reference number.";
                $this->Flash->success($successSms);
                $this->redirect(['controller' => 'Dashboard']);
            }else{
                $this->Flash->error(__('Something went wrong. Please, try again.'));
            }
        }
        $this->loadModel('NatureOfStartup');
        $nature_of_startup = $this->NatureOfStartup->find('list',['keyField'=>'id','valueField'=>'nature'])->where(['status'=>1]);
        $this->loadModel('Industries');
        $industries = $this->Industries->find('list')->where(['status'=>1]);
        $this->loadModel('Sectors');
        $sectors = $this->Sectors->find('list',['keyField'=>'id','valueField'=>'name'])->where(['status'=>1]);
        $this->loadModel('StartupCategories');
        $startup_categories = $this->StartupCategories->find('list',['keyField'=>'id','valueField'=>'name'])->where(['status'=>1]);
        $this->loadModel('States');
        $states = $this->States->find('list',['keyField'=>'id','valueField'=>'name'])->where(['flag'=>1]);
        $this->loadModel('StartupStages');
        $startup_stages = $this->StartupStages->find('list',['keyField'=>'id','valueField'=>'startup_stage'])->where(['status'=>1]);
        $this->loadModel('BankDetails');
        $bank = $this->BankDetails->find('list',['keyField'=>'bank_name','valueField'=>'bank_name']);
        $this->set(compact('application','nature_of_startup','industries','sectors','startup_categories','states','startup_stages','name','email','users','bank'));
    }

    public function generateReferenceNo($id)
    {
        $this->loadModel('StartupApplications');
        $application = $this->StartupApplications->get($id,['contain'=>['NatureOfStartup']]);
        //$code =  $application['nature_of_startup']['code'];
        $code = 'STU';
        $string = '';
        $string.= $code.date('dmy');
        $string.= str_pad(($application->id), 6, 0, STR_PAD_LEFT);
        return $string;
    }

    public function viewStartupApplication($id='')
    {
        $id = base64_decode($id);
        $this->loadModel('StartupApplications');
        $application = $this->StartupApplications->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'index']);
        }
        $startupApplication = $this->StartupApplications->get($id,['contain'=>['Users','RegisteredStates','RegisteredDistricts','CorporateStates','CorporateDistricts','RegionalStates','RegionalDistricts','StartupStages','ApplicationStatus','NatureOfStartup','StartupCategories','Industries','Sectors','IncorporationAuthorities']]);
        $this->set(compact('startupApplication'));
    }

    public function downloadStartupApplication($id='')
    {
        $id = base64_decode($id);
        $this->loadModel('StartupApplications');
        $application = $this->StartupApplications->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'index']);
        }

        $startupApplication = $this->StartupApplications->get($id,['contain'=>['Users','RegisteredStates','RegisteredDistricts','CorporateStates','CorporateDistricts','RegionalStates','RegionalDistricts','StartupStages','ApplicationStatus','NatureOfStartup','StartupCategories','Industries','Sectors','IncorporationAuthorities', 'StartupDirectors.DirectorStates', 'StartupDirectors.DirectorDistricts']]);
        $categoryOfProduct = [1=>'Innovative',2=>'Proprietary'];
        $currentStartupStage = [1=>'Ideation',2=>'Early Traction',3=>'Scalable business'];


        $title = $startupApplication['name_of_startup'];
        $view = new View($this->request,$this->response,null);
        $view->viewPath = 'Startups';
        $view->set(compact('startupApplication','categoryOfProduct','currentStartupStage'));
        $view->layout = 'ajax';
        $html = $view->render('download_application');
        echo $this->downloadCertificate($html,$title);
    }

    public function downloadCertificate($content, $title)
    {
        $this->autoRender = false; 
        $pdf = new PDF();
        $pdf->AddPage('P');
        $pdf->SetFillColor(53,127,63);
        $pdf->SetFont('times', 'R', 11);
        $pdf->SetFont('courier', 'R', 11);
        $pdf->SetFont('Helvetica', 'R', 11);
        $pdf->SetTextColor(0,0,0);
        $pdf->SetCompression(true);
        $title = str_replace('/', '-', $title);
        $pdf->SetTitle($title);
        $pdf->writeHTML($content, false, false, false, false, 'L');
        $tempfile = $title.'_'.date("d-m-Y").'.pdf';        
        $pdf->Output($tempfile,'I');
        exit();
    }


    public function recognition()
    {
        
    }

    public function TrackApplication ()
    {
        $this->loadModel('StartupApplications');
        if ($this->request->is('post')) {
            $reference_no = trim($this->request->getData('reference_no'));
            $reference_no = $this->Sanitize->stripAll( $reference_no);
            $reference_no = $this->Sanitize->clean( $reference_no);
            $this->set('reference_no', $reference_no);

            $referenceData = $this->StartupApplications->find()->contain(['ApplicationStatus'])->where(['reference_no'=> $reference_no])->first();
        }
        $this->set(compact('referenceData'));
    }

    public function DownloadRecognitionCertificate()
    {
        $this->loadModel('StartupApplications');
        if ($this->request->is('post')) {
            $certificate_no = trim($this->request->getData('certificate_no'));
            $certificate_no = $this->Sanitize->stripAll( $certificate_no);
            $certificate_no = $this->Sanitize->clean( $certificate_no);
            $startup_name = trim($this->request->getData('startup_name'));
            $startup_name = $this->Sanitize->stripAll( $startup_name);
            $startup_name = $this->Sanitize->clean( $startup_name);
            $this->set('certificate_no', $certificate_no);
            $this->set('startup_name', $startup_name);
            
            if (empty($startup_name)) {
                $certificateData = $this->StartupApplications->find()->where(['recognition_certificate_no'=> $certificate_no])->first();
            } else {
                $certificateData = $this->StartupApplications->find()->where(['name_of_startup'=> $startup_name])->first();
            }            
        }
        $this->set(compact('certificateData'));
    }

    public function StartupPolicyNotifications()
    {
        # code...
    }

    public function SelfCertification()
    {
        # code...
    }

    public function ProductsServices()
    {
        # code...
    }

    public function SuccessStories()
    {
        # code...
    }

    public function observations()
    {
        $this->loadModel('StartupObservations');
        $this->loadModel('StartupApplications');
        $application = $this->StartupApplications->find()->where(['user_id'=>$this->Auth->user('id')])->first();
        if (empty($application)) {
            $this->Flash->error(__('You have not applied any Startup.'));
            return $this->redirect(['action' => 'index']);
        }
        $oldObservations = $this->StartupObservations->find()->where(['startup_application_id'=>$application->id])->enableHydration(false)->toArray();
        $this->set(compact('oldObservations','application'));
    }

    public function addObservation($id)
    {
        $id = base64_decode($id);
        $this->loadModel('StartupObservations');
        $application = $this->StartupObservations->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'index']);
        }        
        $startupObservations = $this->StartupObservations->get($id);
        if($this->request->is(['post','put'])){
            $data = $this->request->getData();
            $startupObservations = $this->StartupObservations->patchEntity($startupObservations,$data);
            $startupObservations->reply_date = date('Y-m-d H:i:s');
            if($this->StartupObservations->save($startupObservations)){
                $this->Flash->success(__('You have successfully replied.'));
                return $this->redirect(['action' => 'observations']);
            }
            $this->Flash->error(__('Some error occurred. Please, try again.'));
        }
        $this->set(compact('startupObservations'));
    }

    public function downloadFile($filePath) 
    {
        if($filePath){
            $filePath = base64_decode($filePath);
            ob_clean();
            if(file_exists($filePath)){
                $this->response->file($filePath,['download' => true]);
                return $this->response;
            }else{
                $this->Flash->error('File isn\'t available on server.');
                return $this->redirect($this->referer());
            }
        }else{
            $this->Flash->error('Not a valid file.');
            return $this->redirect($this->referer());
        }
    }

    public function leaseRentalEligibility($value='')
    {
        # code...
    }

    public function leaseRentals($id='')
    {
        $this->loadModel('StartupApplications');
        $application = $this->StartupApplications->find()->where(['user_id'=>$this->Auth->user('id')])->first();
        if(!empty($application)){
            if (empty($application['recognition_certificate_no'])) {
                $this->Flash->error(__('Your application is being considered but has not yet been approved.'));
                $this->redirect(['controller' => 'Dashboard']);
            }            
            $this->loadModel('StartupLeaseIncentives');
            $id = base64_decode($id);
            $incentiveData = $this->StartupLeaseIncentives->findById($id)->first();
            if (empty($incentiveData)) {
                $startupLeaseIncentive = $this->StartupLeaseIncentives->newEntity();
            } else {
                $startupLeaseIncentive = $this->StartupLeaseIncentives->get($id);
            }
            if($this->request->is(['post','put'])){
                $data = $this->request->getData();
                $startupLeaseIncentive = $this->StartupLeaseIncentives->patchEntity($startupLeaseIncentive,$data);
                if($data['registration_certificate']['name']!=''){
                    $certificate = $this->uploadFiles('lease-rental', $data['registration_certificate']);
                    $startupLeaseIncentive->registration_certificate = $certificate['filename'];
                } else {
                    $startupLeaseIncentive->registration_certificate = $data['old_registration_certificate'];
                }
                if($data['authorization_letter']['name']!=''){
                    $certificate = $this->uploadFiles('lease-rental', $data['authorization_letter']);
                    $startupLeaseIncentive->authorization_letter = $certificate['filename'];
                } else {
                    $startupLeaseIncentive->authorization_letter = $data['old_authorization_letter'];
                }
                if($data['undertaking_letter']['name']!=''){
                    $certificate = $this->uploadFiles('lease-rental', $data['undertaking_letter']);
                    $startupLeaseIncentive->undertaking_letter = $certificate['filename'];
                } else {
                    $startupLeaseIncentive->undertaking_letter = $data['old_undertaking_letter'];
                }
                if($data['proof_startup_operation']['name']!=''){
                    $certificate = $this->uploadFiles('lease-rental', $data['proof_startup_operation']);
                    $startupLeaseIncentive->proof_startup_operation = $certificate['filename'];
                } else {
                    $startupLeaseIncentive->proof_startup_operation = $data['old_proof_startup_operation'];
                }
                if($data['cancelled_cheque']['name']!=''){
                    $certificate = $this->uploadFiles('lease-rental', $data['cancelled_cheque']);
                    $startupLeaseIncentive->cancelled_cheque = $certificate['filename'];
                } else {
                    $startupLeaseIncentive->cancelled_cheque = $data['old_cancelled_cheque'];
                }
                if($data['space_proof']['name']!=''){
                    $certificate = $this->uploadFiles('lease-rental', $data['space_proof']);
                    $startupLeaseIncentive->space_proof = $certificate['filename'];
                } else {
                    $startupLeaseIncentive->space_proof = $data['old_space_proof'];
                }
                if($data['space_photographs']['name']!=''){
                    $certificate = $this->uploadFiles('lease-rental', $data['space_photographs']);
                    $startupLeaseIncentive->space_photographs = $certificate['filename'];
                } else {
                    $startupLeaseIncentive->space_photographs = $data['old_space_photographs'];
                }
                if($data['rent_receipts']['name']!=''){
                    $certificate = $this->uploadFiles('lease-rental', $data['rent_receipts']);
                    $startupLeaseIncentive->rent_receipts = $certificate['filename'];
                } else {
                    $startupLeaseIncentive->rent_receipts = $data['old_rent_receipts'];
                }
                if($data['payment_proof']['name']!=''){
                    $certificate = $this->uploadFiles('lease-rental', $data['payment_proof']);
                    $startupLeaseIncentive->payment_proof = $certificate['filename'];
                } else {
                    $startupLeaseIncentive->payment_proof = $data['old_payment_proof'];
                }
                $startupLeaseIncentive->startup_application_id = $application['id'];
                $startupLeaseIncentive->created = date('Y-m-d H:i:s');
                if($this->StartupLeaseIncentives->save($startupLeaseIncentive)){
                    $leaseIncentive_id = $startupLeaseIncentive->id;
                    $this->Flash->success(__('Successfully submitted.'));
                    return $this->redirect(['action' => 'leaseRentalPreview',base64_encode($leaseIncentive_id)]);
                }
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        } else {
            $this->Flash->error(__('You have not applied any Startup.'));
            $this->redirect(['controller' => 'Dashboard']);
        }
        $this->loadModel('Designations');
        $designations = $this->Designations->find('list')->where(['status'=>1])->order(['name ASC']);
        $this->set(compact('startupLeaseIncentive','application','designations'));
    }

    public function leaseRentalPreview($id)
    {
        $this->loadModel('StartupLeaseIncentives');
        $id = base64_decode($id);
        $incentiveData = $this->StartupLeaseIncentives->findById($id)->first();
        if (empty($incentiveData)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'leaseRentals']);
        }
        $startupLeaseIncentive = $this->StartupLeaseIncentives->get($id,['contain'=>['Designations']]);

        if($this->request->is(['post','put'])){
            $data = $this->request->getData();
            $startupLeaseIncentive->application_status_id = 1;
            $startupLeaseIncentive->application_stage_id = 1;
            $startupLeaseIncentive->created = date('Y-m-d H:i:s');
            if($this->StartupLeaseIncentives->save($startupLeaseIncentive)){
                $leaseIncentive_id = $startupLeaseIncentive->id;
                $reference_no = $this->leaseReferenceNo($leaseIncentive_id);
                $query = $this->StartupLeaseIncentives->query();
                $query->update()
                    ->set(['reference_number' => $reference_no])
                    ->where(['id' => $leaseIncentive_id])
                    ->execute();
                $this->Flash->success(__('You have successfully applied.'));
                return $this->redirect(['controller'=>'Dashboard','action' => 'index']);
            }
            $this->Flash->error(__('Some error occurred. Please, try again.'));
        }
        $this->loadModel('Designations');
        $designations = $this->Designations->find('list')->where(['status'=>1])->order(['name ASC']);
        $this->set(compact('startupLeaseIncentive','designations'));
    }

    public function leaseReferenceNo($id)
    {
        $this->loadModel('StartupApplications');
        $application = $this->StartupApplications->find()->where(['user_id'=>$this->Auth->user('id')])->first();
        $string = '';
        //$string.= 'L/'.date('dmY').'/';
        $string.= $application->recognition_certificate_no.'/LRS/';
        $string.= str_pad(($id), 5, 0, STR_PAD_LEFT);
        return $string;
    }

    public function developmentEligibility($value='')
    {
        # code...
    }

    public function developments($id='')
    {
        $this->loadModel('StartupApplications');
        $application = $this->StartupApplications->find()->where(['user_id'=>$this->Auth->user('id')])->first();
        if(!empty($application)){
            if (empty($application['recognition_certificate_no'])) {
                $this->Flash->error(__('Your application is being considered but has not yet been approved.'));
                $this->redirect(['controller' => 'Dashboard']);
            }            
            $this->loadModel('StartupAppIncentives');
            //$id = base64_decode($id);
            $incentiveData = $this->StartupAppIncentives->findById($id)->first();
            if (empty($incentiveData)) {
                $startupAppIncentive = $this->StartupAppIncentives->newEntity();
            } else {
                $startupAppIncentive = $this->StartupAppIncentives->get($id);
            }
            if($this->request->is(['post','put'])){
                $data = $this->request->getData();
                $startupAppIncentive = $this->StartupAppIncentives->patchEntity($startupAppIncentive,$data);
                $startupAppIncentive->empanelment_number = $data['empanelment_number'];
                $startupAppIncentive->total_expenditure = $data['total_expenditure'];
                if($data['registration_certificate']['name']!=''){
                    $certificate = $this->uploadFiles('development', $data['registration_certificate']);
                    $startupAppIncentive->registration_certificate = $certificate['filename'];
                }
                if($data['authorization_letter']['name']!=''){
                    $certificate = $this->uploadFiles('development', $data['authorization_letter']);
                    $startupAppIncentive->authorization_letter = $certificate['filename'];
                }
                if($data['undertaking_letter']['name']!=''){
                    $certificate = $this->uploadFiles('development', $data['undertaking_letter']);
                    $startupAppIncentive->undertaking_letter = $certificate['filename'];
                }
                if($data['original_invoices']['name']!=''){
                    $certificate = $this->uploadFiles('development', $data['original_invoices']);
                    $startupAppIncentive->original_invoices = $certificate['filename'];
                }
                if($data['cancelled_cheque']['name']!=''){
                    $certificate = $this->uploadFiles('development', $data['cancelled_cheque']);
                    $startupAppIncentive->cancelled_cheque = $certificate['filename'];
                }
                if($data['payment_proof']['name']!=''){
                    $certificate = $this->uploadFiles('development', $data['payment_proof']);
                    $startupAppIncentive->payment_proof = $certificate['filename'];
                } 
                $startupAppIncentive->application_status_id = 1;
                $startupAppIncentive->application_stage_id  = 1;
                $startupAppIncentive->startup_application_id = $application['id'];
                $startupAppIncentive->created = date('Y-m-d H:i:s');
                if($this->StartupAppIncentives->save($startupAppIncentive)){
                    $appIncentive_id = $startupAppIncentive->id;
                    $reference_no = $this->appReferenceNo($appIncentive_id);
                    $query = $this->StartupAppIncentives->query();
                    $query->update()
                        ->set(['reference_number' => $reference_no])
                        ->where(['id' => $appIncentive_id])
                        ->execute();
                    $this->Flash->success(__('You have successfully applied.'));
                    return $this->redirect(['controller'=>'Dashboard','action' => 'index']);
                }
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        } else {
            $this->Flash->error(__('You have not applied any Startup.'));
            $this->redirect(['controller' => 'Dashboard']);
        }
        $this->loadModel('Designations');
        $designations = $this->Designations->find('list')->where(['status'=>1])->order(['name ASC']);
        $this->set(compact('startupAppIncentive','application','designations'));
    }

    public function appReferenceNo($id)
    {
        $this->loadModel('StartupApplications');
        $application = $this->StartupApplications->find()->where(['user_id'=>$this->Auth->user('id')])->first();
        $string = '';
        $string.= $application->recognition_certificate_no.'/APD/';
        $string.= str_pad(($id), 5, 0, STR_PAD_LEFT);
        return $string;
    }

    public function PatentIncentives($id='')
    {
        $this->loadModel('StartupApplications');
        $application = $this->StartupApplications->find()->where(['user_id'=>$this->Auth->user('id')])->first();
        if(!empty($application)){
            if (empty($application['recognition_certificate_no'])) {
                $this->Flash->error(__('Your Startup Application is being considered but has not yet been approved.'));
                $this->redirect(['controller' => 'Dashboard']);
            }
            $this->loadModel('StartupPatentIncentives');
            //$id = base64_decode($id);
            $incentiveData = $this->StartupPatentIncentives->findById($id)->first();
            if (empty($incentiveData)) {
                $startupPatentIncentive = $this->StartupPatentIncentives->newEntity();
            } else {
                $startupPatentIncentive = $this->StartupPatentIncentives->get($id);
            }
            if($this->request->is(['post','put'])){
                $data = $this->request->getData();
                $startupPatentIncentive = $this->StartupPatentIncentives->patchEntity($startupPatentIncentive,$data);
                $startupPatentIncentive->mobile_number = $data['mobile'];
                $startupPatentIncentive->total_expenditure = $data['total_expenditure'];
                if($data['registration_certificate']['name']!=''){
                    $certificate = $this->uploadFiles('patents', $data['registration_certificate']);
                    $startupPatentIncentive->registration_certificate = $certificate['filename'];
                }
                if($data['authorization_letter']['name']!=''){
                    $certificate = $this->uploadFiles('patents', $data['authorization_letter']);
                    $startupPatentIncentive->authorization_letter = $certificate['filename'];
                }
                if($data['undertaking']['name']!=''){
                    $certificate = $this->uploadFiles('patents', $data['undertaking']);
                    $startupPatentIncentive->undertaking = $certificate['filename'];
                }
                if($data['application_form']['name']!=''){
                    $certificate = $this->uploadFiles('patents', $data['application_form']);
                    $startupPatentIncentive->application_form = $certificate['filename'];
                }
                if($data['petent_registraion']['name']!=''){
                    $certificate = $this->uploadFiles('patents', $data['petent_registraion']);
                    $startupPatentIncentive->petent_registraion = $certificate['filename'];
                }
                if($data['expenditure_statement']['name']!=''){
                    $certificate = $this->uploadFiles('patents', $data['expenditure_statement']);
                    $startupPatentIncentive->expenditure_statement = $certificate['filename'];
                } 
                if($data['original_invoice']['name']!=''){
                    $certificate = $this->uploadFiles('patents', $data['original_invoice']);
                    $startupPatentIncentive->original_invoice = $certificate['filename'];
                } 
                if($data['cancelled_cheque']['name']!=''){
                    $certificate = $this->uploadFiles('patents', $data['cancelled_cheque']);
                    $startupPatentIncentive->cancelled_cheque = $certificate['filename'];
                }
                if($data['payment_proof']['name']!=''){
                    $certificate = $this->uploadFiles('patents', $data['payment_proof']);
                    $startupPatentIncentive->payment_proof = $certificate['filename'];
                } 
                if($data['sanction_refusal_letter']['name']!=''){
                    $certificate = $this->uploadFiles('patents', $data['sanction_refusal_letter']);
                    $startupPatentIncentive->sanction_refusal_letter = $certificate['filename'];
                } 
                $startupPatentIncentive->application_status_id = 1;
                $startupPatentIncentive->application_stage_id  = 1;
                $startupPatentIncentive->startup_application_id = $application['id'];
                $startupPatentIncentive->created = date('Y-m-d H:i:s');
                if($this->StartupPatentIncentives->save($startupPatentIncentive)){
                    $appIncentive_id = $startupPatentIncentive->id;
                    $reference_no = $this->patentReferenceNo($appIncentive_id);
                    $query = $this->StartupPatentIncentives->query();
                    $query->update()
                        ->set(['reference_number' => $reference_no])
                        ->where(['id' => $appIncentive_id])
                        ->execute();
                    $this->Flash->success(__('You have successfully applied.'));
                    return $this->redirect(['controller'=>'Dashboard','action' => 'index']);
                }
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        } else {
            $this->Flash->error(__('You have not applied any Startup.'));
            $this->redirect(['controller' => 'Dashboard']);
        }
        $this->loadModel('Designations');
        $designations = $this->Designations->find('list')->where(['status'=>1])->order(['name ASC']);
        $this->set(compact('startupPatentIncentive','application','designations'));
    }

    public function patentReferenceNo($id)
    {
        $string = '';
        $string.= 'P/'.date('dmY').'/';
        $string.= str_pad(($id), 5, 0, STR_PAD_LEFT);
        return $string;
    }

    public function innovationPromotionEligibility(){
        
    }

    public function QualityCertifications($id='')
    {
        $this->loadModel('StartupApplications');
        $application = $this->StartupApplications->find()->where(['user_id'=>$this->Auth->user('id')])->first();
        if(!empty($application)){
            if (empty($application['recognition_certificate_no'])) {
                $this->Flash->error(__('Your Startup Application is being considered but has not yet been approved.'));
                $this->redirect(['controller' => 'Dashboard']);
            }
            $this->loadModel('StartupQualityCertifications');
            //$id = base64_decode($id);
            $incentiveData = $this->StartupQualityCertifications->findById($id)->first();
            if (empty($incentiveData)) {
                $startupQCIncentive = $this->StartupQualityCertifications->newEntity();
            } else {
                $startupQCIncentive = $this->StartupQualityCertifications->get($id);
            }
            if($this->request->is(['post','put'])){
                $data = $this->request->getData();
                $startupQCIncentive = $this->StartupQualityCertifications->patchEntity($startupQCIncentive,$data);
                $startupQCIncentive->total_expenditure = $data['total_expenditure'];
                if($data['registration_certificate']['name']!=''){
                    $certificate = $this->uploadFiles('quality', $data['registration_certificate']);
                    $startupQCIncentive->registration_certificate = $certificate['filename'];
                }
                if($data['authorization_letter']['name']!=''){
                    $certificate = $this->uploadFiles('quality', $data['authorization_letter']);
                    $startupQCIncentive->authorization_letter = $certificate['filename'];
                }
                if($data['undertaking']['name']!=''){
                    $certificate = $this->uploadFiles('quality', $data['undertaking']);
                    $startupQCIncentive->undertaking = $certificate['filename'];
                }
                if($data['application_form']['name']!=''){
                    $certificate = $this->uploadFiles('quality', $data['application_form']);
                    $startupQCIncentive->application_form = $certificate['filename'];
                }
                if($data['quality_certificate']['name']!=''){
                    $certificate = $this->uploadFiles('quality', $data['quality_certificate']);
                    $startupQCIncentive->quality_certificate = $certificate['filename'];
                }
                if($data['cancelled_cheque']['name']!=''){
                    $certificate = $this->uploadFiles('quality', $data['cancelled_cheque']);
                    $startupQCIncentive->cancelled_cheque = $certificate['filename'];
                } 
                if($data['original_invoice']['name']!=''){
                    $certificate = $this->uploadFiles('quality', $data['original_invoice']);
                    $startupQCIncentive->original_invoice = $certificate['filename'];
                } 
                if($data['payment_proof']['name']!=''){
                    $certificate = $this->uploadFiles('quality', $data['payment_proof']);
                    $startupQCIncentive->payment_proof = $certificate['filename'];
                }
                $startupQCIncentive->application_status_id = 1;
                $startupQCIncentive->application_stage_id  = 1;
                $startupQCIncentive->startup_application_id = $application['id'];
                $startupQCIncentive->created = date('Y-m-d H:i:s');
                if($this->StartupQualityCertifications->save($startupQCIncentive)){
                    $appIncentive_id = $startupQCIncentive->id;
                    $reference_no = $this->qualityReferenceNo($appIncentive_id);
                    $query = $this->StartupQualityCertifications->query();
                    $query->update()
                        ->set(['reference_number' => $reference_no])
                        ->where(['id' => $appIncentive_id])
                        ->execute();
                    $this->Flash->success(__('You have successfully applied.'));
                    return $this->redirect(['controller'=>'Dashboard','action' => 'index']);
                }
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        } else {
            $this->Flash->error(__('You have not applied any Startup.'));
            $this->redirect(['controller' => 'Dashboard']);
        }
        $this->loadModel('Designations');
        $designations = $this->Designations->find('list')->where(['status'=>1])->order(['name ASC']);
        $this->set(compact('startupQCIncentive','application','designations'));
    }

    public function qualityReferenceNo($id)
    {
        $string = '';
        $string.= 'Q/'.date('dmY').'/';
        $string.= str_pad(($id), 5, 0, STR_PAD_LEFT);
        return $string;
    }


}