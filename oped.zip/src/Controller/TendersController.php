<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Core\Configure;
use Cake\Event\Event;
use Cake\Network\Exception\NotFoundException;
use Cake\View\Exception\MissingTemplateException;

/**
 * Tenders Controller
 *
 * @property \App\Model\Table\TendersTable $Tenders
 *
 * @method \App\Model\Entity\Tender[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class TendersController extends AppController
{

    public function initialize()
    {
        parent::initialize();
        $this->viewBuilder()->setLayout('frontend');
        $this->Auth->allow(['index', 'page','archived']);
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }
    
    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $search_condition = array();
        $keyword = trim($this->request->getData('keyword'));
        $keyword = $this->Sanitize->stripAll( $keyword);
        $keyword = $this->Sanitize->clean( $keyword);
        $this->set('keyword', $keyword);
        if (!empty($keyword)) {
            $search_condition[] = "Tenders.title like '%" . $keyword . "%'";
        }
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        $tender = $this->Tenders->find('all')
            ->select([
                'id',
                'title'   => "IF(TenderTranslation.title != '',TenderTranslation.title,Tenders.title)",
                'slug'    => "IF(TenderTranslation.slug != '',TenderTranslation.slug,Tenders.slug)",
                'remarks' => "IF(TenderTranslation.remarks != '',TenderTranslation.remarks,Tenders.remarks)",
                'content' => "IF(TenderTranslation.content != '',TenderTranslation.content,Tenders.content)",
                'url'     => "IF(TenderTranslation.url != '',TenderTranslation.url,Tenders.url)",'last_date','tender_date','created','updated','meta_title','meta_keywords','meta_description',
            ])
            ->contain([
                'TenderTranslation' => function ($q) {
                    if (Configure::check('language')) {
                        $q->where(['TenderTranslation.culture' => Configure::read('language.culture')]);
                    } else {
                        $q->where(['TenderTranslation.language_id' => 0]);
                    }
                    return $q;
                },
                'TenderDocuments' => function ($q) {
                    if (Configure::check('language')) {
                        $q->where(['TenderDocuments.culture' => Configure::read('language.culture')]);
                    } else {
                        $q->where(['TenderDocuments.language_id' => 0]);
                    }
                    return $q;
                },
            ])
            ->where(['status' => 1,'last_date >=' => date('Y-m-d'),'tender_date <=' => date('Y-m-d'),$searchString])
            //->order(['Tenders.tender_date'=>'DESC','Tenders.last_date'=>'DESC',]);
            ->order(['Tenders.tender_date'=>'DESC','Tenders.id'=>'DESC','Tenders.last_date'=>'DESC']);
        $this->paginate = ['limit' => 15];
        $tender = $this->paginate($tender);
        $this->set('tender', $tender);
    }

    /**
     * Page method
     *
     * @return \Cake\Http\Response|void
     */
    public function page($tender_id)
    {
        $tender = $this->Tenders->findById($tender_id)
            ->select([
                'id',
                'title'   => "IF(TenderTranslation.title != '',TenderTranslation.title,Tenders.title)",
                'slug'    => "IF(TenderTranslation.slug != '',TenderTranslation.slug,Tenders.slug)",
                'remarks' => "IF(TenderTranslation.remarks != '',TenderTranslation.remarks,Tenders.remarks)",
                'content' => "IF(TenderTranslation.content != '',TenderTranslation.content,Tenders.content)",
                'url'     => "IF(TenderTranslation.url != '',TenderTranslation.url,Tenders.url)", 'last_date','tender_date','created','updated','meta_title','meta_keywords','meta_description',
            ])
            ->contain([
                'TenderTranslation' => function ($q) {
                    if (Configure::check('language')) {
                        $q->where(['TenderTranslation.culture' => Configure::read('language.culture')]);
                    } else {
                        $q->where(['TenderTranslation.language_id' => 0]);
                    }
                    return $q;
                },
                'TenderDocuments' => function ($q) {
                    if (Configure::check('language')) {
                        $q->where(['TenderDocuments.culture' => Configure::read('language.culture')]);
                    } else {
                        $q->where(['TenderDocuments.language_id' => 0]);
                    }
                    return $q;
                },
            ])
            ->where(['status' => 1])->first();
        if (empty($tender)) {
            throw new NotFoundException(__('Tender not found'));
        }

        $_template = 'page_' . $tender->id;

        $this->set('tender', $tender);

        try {
            $this->render($_template);
        } catch (MissingTemplateException $e) {
            $this->render('page');
        }
    }

    /**
     * Archived method
     *
     * @return \Cake\Http\Response|void
     */
    public function archived()
    {
        $search_condition = array();
        $keyword = trim($this->request->getData('keyword'));
        $keyword = $this->Sanitize->stripAll( $keyword);
        $keyword = $this->Sanitize->clean( $keyword);
        $this->set('keyword', $keyword);
        if (!empty($keyword)) {
            $search_condition[] = "Tenders.title like '%" . $keyword . "%'";
        }
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        $tender = $this->Tenders->find('all')
            ->select([
                'id',
                'title'   => "IF(TenderTranslation.title != '',TenderTranslation.title,Tenders.title)",
                'slug'    => "IF(TenderTranslation.slug != '',TenderTranslation.slug,Tenders.slug)",
                'remarks' => "IF(TenderTranslation.remarks != '',TenderTranslation.remarks,Tenders.remarks)",
                'content' => "IF(TenderTranslation.content != '',TenderTranslation.content,Tenders.content)",
                'url'     => "IF(TenderTranslation.url != '',TenderTranslation.url,Tenders.url)",'last_date','tender_date','created','updated','meta_title','meta_keywords','meta_description',
            ])
            ->contain([
                'TenderTranslation' => function ($q) {
                    if (Configure::check('language')) {
                        $q->where(['TenderTranslation.culture' => Configure::read('language.culture')]);
                    } else {
                        $q->where(['TenderTranslation.language_id' => 0]);
                    }
                    return $q;
                },
                'TenderDocuments' => function ($q) {
                    if (Configure::check('language')) {
                        $q->where(['TenderDocuments.culture' => Configure::read('language.culture')]);
                    } else {
                        $q->where(['TenderDocuments.language_id' => 0]);
                    }
                    return $q;
                },
            ])
            ->where(['status' => 1,'last_date <' => date('Y-m-d'),$searchString])->order(['Tenders.tender_date'=>'DESC','Tenders.last_date'=>'DESC']);
        if (empty($tender)) {
            throw new NotFoundException(__('Tender not found'));
        }
        $this->paginate = ['limit' => 15];
        $tender = $this->paginate($tender);
        $this->set('tender', $tender);
    }

}
