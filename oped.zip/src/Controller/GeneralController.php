<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Event\Event;

/**
 * General Controller
 *
 * @property \App\Model\Table\FormsTable $Forms
 *
 * @method \App\Model\Entity\Form[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class GeneralController extends AppController
{
    public function initialize()
    {
        parent::initialize();
        $this->Auth->allow();
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
        if ($this->isDevice == false) {
            return $this->redirect(['controller' => 'Dashboard', 'action' => 'index']);
        }
    }
    
    public function getUserTypes()
    {
        $this->request->allowMethod(['get']);
        $this->loadModel('Roles');
        
        $_status      = false;
        $_message     = '';
        
        $_userTypes = $where = [];
        $types = array(7,8,9,10,11,12,15);
        $where[]      = ['id IN' => $types];
        
        $userTypes = $this->Roles->find('all')->where($where)->order(['name' => 'ASC'])
            ->enableHydration(false)->toArray();
        
        if (!empty($userTypes)) {
            $_status = true;
            foreach ($userTypes as $userType) {
                $_userTypes[] = [
                    'id'    => $userType['id'],
                    'title' => $userType['name'],
                ];
            }
        } else {
            $_status = true;
            $_message = __('User Types not found!');
        }
        
        $this->set([
            '_status'      => $_status,
            '_userTypes' => $_userTypes,
            '_message'     => $_message,
            '_serialize'   => [
                '_status', '_userTypes', '_message',
            ],
        ]);
    }

    public function getDepartments()
    {
        $this->request->allowMethod(['get']);
        $this->loadModel('Departments');
        
        $_status      = false;
        $_message     = '';
        
        $_departments = $where = [];
        $where[]      = ['status' => 1];
        
        $departments  = $this->Departments->find('all')->where($where)->order(['name' => 'ASC'])
            ->enableHydration(false)->toArray();
        
        if (!empty($departments)) {
            $_status = true;
            foreach ($departments as $department) {
                $_departments[] = [
                    'id'    => $department['id'],
                    'title' => $department['name'],
                ];
            }
        } else {
            $_status = true;
            $_message = __('Departments not found!');
        }
        
        $this->set([
            '_status'      => $_status,
            '_departments' => $_departments,
            '_message'     => $_message,
            '_serialize'   => [
                '_status', '_departments', '_message',
            ],
        ]);
    }

    public function getDesignations()
    {
        $this->request->allowMethod(['get']);
        $this->loadModel('Designations');
        
        $_status       = false;
        $_message      = '';
        
        $_designations = $where = [];
        $department_id = $this->request->getQuery('department_id');
        if (!empty($department_id)) {
            $where[] = ['department_id' => $department_id];
        }
        $where[]      = ['status' => 1];
        
        $designations = $this->Designations->find('all')->where($where)->order(['name' => 'ASC'])
            ->enableHydration(false)->toArray();
        
        if (!empty($designations)) {
            $_status = true;
            foreach ($designations as $designation) {
                $_designations[] = [
                    'id'    => $designation['id'],
                    'title' => $designation['name'],
                ];
            }
        } else {
            $_status = true;
            $_message = __('Designations not found!');
        }
        
        $this->set([
            '_status'       => $_status,
            '_designations' => $_designations,
            '_message'      => $_message,
            '_serialize'    => [
                '_status', '_designations', '_message',
            ],
        ]);
    }
    
    public function getProfessions()
    {
        $this->request->allowMethod(['get']);
        $this->loadModel('Professions');
        
        $_status       = false;
        $_message      = '';
        
        $_professions = $where = [];
        $where[]      = ['status' => 1];
        
        $professions = $this->Professions->find('all')->where($where)->order(['name' => 'ASC'])
            ->enableHydration(false)->toArray();
        
        if (!empty($professions)) {
            $_status = true;
            foreach ($professions as $profession) {
                $_professions[] = [
                    'id'    => $profession['id'],
                    'title' => $profession['name'],
                ];
            }
        } else {
            $_status = true;
            $_message = __('Professions not found!');
        }
        
        $this->set([
            '_status'       => $_status,
            '_professions' => $_professions,
            '_message'      => $_message,
            '_serialize'    => [
                '_status', '_professions', '_message',
            ],
        ]);
    }

    public function getStates()
    {
        $this->request->allowMethod(['get']);
        $this->loadModel('States');
        
        $_status  = false;
        $_message = '';
        
        $_states  = $where  = [];
        $where[]  = ['flag' => 1];
        
        $states   = $this->States->find('all')->where($where)->order(['name' => 'ASC'])
            ->enableHydration(false)->toArray();
        
        if (!empty($states)) {
            $_status = true;
            foreach ($states as $state) {
                $_states[] = [
                    'id'    => $state['id'],
                    'title' => $state['name'],
                ];
            }
        } else {
            $_status = true;
            $_message = __('States not found!');
        }
        
        $this->set([
            '_status'    => $_status,
            '_states'    => $_states,
            '_message'   => $_message,
            '_serialize' => [
                '_status', '_states', '_message',
            ],
        ]);
    }

    public function getDistricts()
    {
        $this->request->allowMethod(['get']);
        $this->loadModel('Districts');
        
        $_status    = false;
        $_message   = '';
        
        $_districts = $where = [];
        $state_id   = $this->request->getQuery('state_id');
        if (!empty($state_id)) {
            $where[] = ['state_id' => $state_id];
        }
        $where[]   = ['flag' => 1];
        
        $districts = $this->Districts->find('all')->where($where)->order(['name' => 'ASC'])
            ->enableHydration(false)->toArray();
        
        if (!empty($districts)) {
            $_status = true;
            foreach ($districts as $district) {
                $_districts[] = [
                    'id'    => $district['id'],
                    'title' => $district['name'],
                ];
            }
        } else {
            $_status = true;
            $_message = __('Distrcts not found!');
        }
        
        $this->set([
            '_status'    => $_status,
            '_districts' => $_districts,
            '_message'   => $_message,
            '_serialize' => [
                '_status', '_districts', '_message',
            ],
        ]);
    }

    public function getTehsils()
    {
        $this->request->allowMethod(['get']);
        $this->loadModel('Tehsils');
        
        $_status     = false;
        $_message    = '';
        
        $_tehsils    = $where    = [];
        $district_id = $this->request->getQuery('district_id');
        if (!empty($district_id)) {
            $where[] = ['district_id' => $district_id];
        }
        $where[] = ['status' => 1];
        
        $tehsils = $this->Tehsils->find('all')->where($where)->order(['name' => 'ASC'])
            ->enableHydration(false)->toArray();
        
        if (!empty($tehsils)) {
            $_status = true;
            foreach ($tehsils as $tehsil) {
                $_tehsils[] = [
                    'id'    => $tehsil['id'],
                    'title' => $tehsil['name'],
                ];
            }
        } else {
            $_status = true;
            $_message = __('Tehsils not found!');
        }
        
        $this->set([
            '_status'    => $_status,
            '_tehsils'   => $_tehsils,
            '_message'   => $_message,
            '_serialize' => [
                '_status', '_tehsils', '_message',
            ],
        ]);
    }

    public function getIndustries()
    {
        $this->request->allowMethod(['get']);
        $this->loadModel('Industries');
        
        $_status     = false;
        $_message    = '';
        
        $_tndustries = $where = [];
        $where[]     = ['status' => 1];
        
        $industries  = $this->Industries->find('all')->where($where)->order(['name' => 'ASC'])
            ->enableHydration(false)->toArray();
        
        if (!empty($industries)) {
            $_status = true;
            foreach ($industries as $industry) {
                $_tndustries[] = [
                    'id'    => $industry['id'],
                    'title' => $industry['name'],
                ];
            }
        } else {
            $_status = true;
            $_message = __('Industries not found!');
        }
        
        $this->set([
            '_status'     => $_status,
            '_tndustries' => $_tndustries,
            '_message'    => $_message,
            '_serialize'  => [
                '_status', '_tndustries', '_message',
            ],
        ]);
    }

    public function getSectors()
    {
        $this->request->allowMethod(['get']);
        $this->loadModel('Sectors');
        
        $_status     = false;
        $_message    = '';
        
        $_sectors    = $where    = [];
        $industry_id = $this->request->getQuery('industry_id');
        if (!empty($industry_id)) {
            $where[] = ['industry_id' => $industry_id];
        }
        $where[] = ['status' => 1];
        
        $sectors = $this->Sectors->find('all')->where($where)->order(['name' => 'ASC'])
            ->enableHydration(false)->toArray();
        
        if (!empty($sectors)) {
            $_status = true;
            foreach ($sectors as $tehsil) {
                $_sectors[] = [
                    'id'    => $tehsil['id'],
                    'title' => $tehsil['name'],
                ];
            }
        } else {
            $_status = true;
            $_message = __('Sectors not found!');
        }
        
        $this->set([
            '_status'    => $_status,
            '_sectors'   => $_sectors,
            '_message'   => $_message,
            '_serialize' => [
                '_status', '_sectors', '_message',
            ],
        ]);
    }

    public function getSchemes()
    {
        $this->request->allowMethod(['get']);
        $this->loadModel('Schemes');
        
        $_status  = false;
        $_message = '';
        
        $_schemes = $where = [];
        $type     = $this->request->getQuery('type');
        if (!empty($type)) {
            $where[] = ['type' => $type];
        }
        $where[] = ['flag' => 1];
        
        $schemes = $this->Schemes->find('all')->where($where)->order(['name' => 'ASC'])
            ->enableHydration(false)->toArray();
        
        if (!empty($schemes)) {
            $_status = true;
            foreach ($schemes as $scheme) {
                $_schemes[] = [
                    'id'            => $scheme['id'],
                    'title'         => $scheme['name'],
                    'shortName'     => $scheme['short_name'],
                    'shortCode'     => $scheme['short_code'],
                    'agreementWith' => $scheme['agreement_with'],
                    'type'          => $scheme['type'],
                ];
            }
        } else {
            $_status = true;
            $_message = __('Schemes not found!');
        }
        
        $this->set([
            '_status'    => $_status,
            '_schemes'   => $_schemes,
            '_message'   => $_message,
            '_serialize' => [
                '_status', '_schemes', '_message',
            ],
        ]);
    }

    public function getBankDetails()
    {
        $this->request->allowMethod(['get']);
        $this->loadModel('BankDetails');
        
        $_status      = false;
        $_message     = '';
        
        $_bankDetails = $where = [];
        $bankDetails  = $this->BankDetails->find('all')->where($where)->order(['bank_name' => 'ASC'])
            ->enableHydration(false)->toArray();
        
        if (!empty($bankDetails)) {
            $_status = true;
            foreach ($bankDetails as $bankDetail) {
                $_bankDetails[] = [
                    'id'    => $bankDetail['id'],
                    'title' => $bankDetail['bank_name'],
                ];
            }
        } else {
            $_status = true;
            $_message = __('Bank Details not found!');
        }
        
        $this->set([
            '_status'      => $_status,
            '_bankDetails' => $_bankDetails,
            '_message'     => $_message,
            '_serialize'   => [
                '_status', '_bankDetails', '_message',
            ],
        ]);
    }
    
    public function getCategoryOfProduct()
    {
        $this->request->allowMethod(['get']);
        
        $_status      = false;
        $_message     = '';
        
        $_categories = $where = [];
        
        $_status = true;
        $_categories[] = [
            'id'    => 1,
            'title' => 'Innovative',
        ];
        $_categories[] = [
            'id'    => 2,
            'title' => 'Proprietary',
        ];
        
        $this->set([
            '_status'      => $_status,
            '_categories' => $_categories,
            '_message'     => $_message,
            '_serialize'   => [
                '_status', '_categories', '_message',
            ],
        ]);
    }
    
    public function getCurrentStartupStage()
    {
        $this->request->allowMethod(['get']);
        
        $_status      = false;
        $_message     = '';
        
        $_startupStage = $where = [];
        
        $_status = true;
        $_startupStage[] = [
            'id'    => 1,
            'title' => 'Ideation',
        ];
        $_startupStage[] = [
            'id'    => 2,
            'title' => 'Early Traction',
        ];
        $_startupStage[] = [
            'id'    => 2,
            'title' => 'Scalable business',
        ];
        
        $this->set([
            '_status'      => $_status,
            '_startupStage' => $_startupStage,
            '_message'     => $_message,
            '_serialize'   => [
                '_status', '_startupStage', '_message',
            ],
        ]);
    }
    
    public function getIncorporationAuthorities()
    {
        $this->request->allowMethod(['get']);
        $this->loadModel('IncorporationAuthorities');
        
        $_status      = false;
        $_message     = '';
        
        $_incorporationAuthorities = $where = [];
        $where[] = ['status' => 1];
        
        $incorporationAuthorities  = $this->IncorporationAuthorities->find('all')->where($where)
            ->order(['name' => 'ASC'])->enableHydration(false)->toArray();
        
        if (!empty($incorporationAuthorities)) {
            $_status = true;
            foreach ($incorporationAuthorities as $incorporationAuthority) {
                $_incorporationAuthorities[] = [
                    'id'    => $incorporationAuthority['id'],
                    'title' => $incorporationAuthority['name'],
                ];
            }
        } else {
            $_status = true;
            $_message = __('Incorporation Authority not found!');
        }
        
        $this->set([
            '_status'      => $_status,
            '_incorporationAuthorities' => $_incorporationAuthorities,
            '_message'     => $_message,
            '_serialize'   => [
                '_status', '_incorporationAuthorities', '_message',
            ],
        ]);
    }
    
    public function getTypeOfStartup()
    {
        $this->request->allowMethod(['get']);
        $this->loadModel('NatureOfStartup');
        
        $_status      = false;
        $_message     = '';
        
        $_typeOfStartup = $where = [];
        $where[] = ['status' => 1];
        
        $typeOfStartup  = $this->NatureOfStartup->find('all')->where($where)->order(['nature' => 'ASC'])
            ->enableHydration(false)->toArray();
        
        if (!empty($typeOfStartup)) {
            $_status = true;
            foreach ($typeOfStartup as $type) {
                $_typeOfStartup[] = [
                    'id'    => $type['id'],
                    'title' => $type['nature'],
                    'code' => $type['code'],
                ];
            }
        } else {
            $_status = true;
            $_message = __('Types of Startup not found!');
        }
        
        $this->set([
            '_status'      => $_status,
            '_typeOfStartup' => $_typeOfStartup,
            '_message'     => $_message,
            '_serialize'   => [
                '_status', '_typeOfStartup', '_message',
            ],
        ]);
    }
    
    public function getStartupCategories()
    {
        $this->request->allowMethod(['get']);
        $this->loadModel('StartupCategories');
        
        $_status      = false;
        $_message     = '';
        
        $_startupCategories = $where = [];
        $where[] = ['status' => 1];
        
        $startupCategories  = $this->StartupCategories->find('all')->where($where)->order(['name' => 'ASC'])
            ->enableHydration(false)->toArray();
        
        if (!empty($startupCategories)) {
            $_status = true;
            foreach ($startupCategories as $categories) {
                $_startupCategories[] = [
                    'id'    => $categories['id'],
                    'title' => $categories['name']
                ];
            }
        } else {
            $_status = true;
            $_message = __('Startup Categories not found!');
        }
        
        $this->set([
            '_status'      => $_status,
            '_startupCategories' => $_startupCategories,
            '_message'     => $_message,
            '_serialize'   => [
                '_status', '_startupCategories', '_message',
            ],
        ]);
    }
    
    public function getNationality()
    {
        $this->request->allowMethod(['get']);
        
        $_status      = false;
        $_message     = '';
        
        $_startupNationality = $where = [];
        
        $_status = true;
        $_startupNationality[] = [
            'id'    => 1,
            'title' => 'Indian',
        ];
        
        $this->set([
            '_status'      => $_status,
            '_startupNationality' => $_startupNationality,
            '_message'     => $_message,
            '_serialize'   => [
                '_status', '_startupNationality', '_message',
            ],
        ]);
    }
    
    public function getTypeOfEntity()
    {
        $this->request->allowMethod(['get']);
        
        $_status      = false;
        $_message     = '';
        
        $_typeOfEntity = $where = [];
        
        $_status = true;
        $_typeOfEntity[] = [
            'id'    => 1,
            'title' => 'Society (under The Societies Registration Act, 1860)',
        ];
        $_typeOfEntity[] = [
            'id'    => 2,
            'title' => 'Section 8 Company (under The Companies Act, 2013)',
        ];
        $_typeOfEntity[] = [
            'id'    => 3,
            'title' => 'Private Limited Company (under The Companies Act, 2013)',
        ];
        $_typeOfEntity[] = [
            'id'    => 4,
            'title' => 'Public Company (under The Companies Act, 2013)',
        ];
        $_typeOfEntity[] = [
            'id'    => 5,
            'title' => 'Limited Liability Partnership (under The Limited Liability',
        ];
        $_typeOfEntity[] = [
            'id'    => 6,
            'title' => 'Public Charitable Trust (under Indian Trusts Act, 1882)',
        ];
        
        $this->set([
            '_status'      => $_status,
            '_typeOfEntity' => $_typeOfEntity,
            '_message'     => $_message,
            '_serialize'   => [
                '_status', '_typeOfEntity', '_message',
            ],
        ]);
    }
    
    public function getStartupTypeOfOffice()
    {
        $this->request->allowMethod(['get']);
        
        $_status      = false;
        $_message     = '';
        
        $_typeOfOffice = $where = [];
        
        $_status = true;
        $_typeOfOffice[] = [
            'id'    => 1,
            'title' => 'Registered',
        ];
        $_typeOfOffice[] = [
            'id'    => 2,
            'title' => 'Corporate',
        ];
        $_typeOfOffice[] = [
            'id'    => 3,
            'title' => 'Operational',
        ];
        
        $this->set([
            '_status'      => $_status,
            '_typeOfOffice' => $_typeOfOffice,
            '_message'     => $_message,
            '_serialize'   => [
                '_status', '_typeOfOffice', '_message',
            ],
        ]);
    }
}
