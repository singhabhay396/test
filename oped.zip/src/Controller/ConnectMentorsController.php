<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Core\Configure;
use Cake\Event\Event;
use Cake\Mailer\Email;
use Cake\Routing\Router;
use Cake\Network\Exception\NotFoundException;
use Cake\View\Exception\MissingTemplateException;

/**
 * ConnectMentors Controller
 *
 * @property \App\Model\Table\ConnectMentorsTable $ConnectMentors
 *
 * @method \App\Model\Entity\Tender[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class ConnectMentorsController extends AppController
{

    public function initialize()
    {
        parent::initialize();
        $this->viewBuilder()->setLayout('frontend');
        $this->Auth->allow(['index','page']);
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */

    public function index()
    {
        $search_condition = array();
        $name = trim($this->request->getQuery('name'));
        $name = $this->Sanitize->stripAll( $name);
        $name = $this->Sanitize->clean( $name);
        $this->set('uName', $name);
        if (!empty($name)) {            
            $search_condition[] = "Users.name like '%" . $name . "%'";
        }
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        $this->loadModel('Users');
        $this->loadModel('MentorMentees');
        $ids = $this->Auth->user('id');
        $mentorData = $this->Users->find()
            ->where(['role_id'=>8,$searchString])
            ->contain(['Registration.States','Registration.Districts','Registration.Designations','Registration'])
            ->toArray();
        $menteesData = $this->MentorMentees->find()->where(['requested_id' => $ids])->toArray();;
        //echo "<pre>"; print_r($menteesData); exit;
        $this->set(compact('mentorData','menteesData'));
    }
    public function request($id = null){
        $this->loadModel('MentorMentees');
        $this->loadModel('Users');
        $requested_comment = trim($this->request->getQuery('requested_comment'));
        $requested_comment = $this->Sanitize->stripAll($requested_comment);
        $requested_comment = $this->Sanitize->clean($requested_comment);
        $this->set('requested_comment', $requested_comment);
        if (!empty($id)) {
            $mentorMentees = $this->MentorMentees->get($id);
        }
        else{
            $mentorMentees = $this->MentorMentees->newEntity();
        }
        $this->set(compact('mentorMentees'));
        if ($this->request->is(['post', 'put'])) {
            $data                = $this->request->getData();
            //echo "<pre>"; print_r($data); exit;
            $incubator_directors = array();
            $menteesPatch = $this->MentorMentees->patchEntity($mentorMentees, $data);
            /**/
            $menteesPatch->requested_id  = $this->Auth->user('id');
            $menteesPatch->requested_date  = date('Y-m-d');;
            
            if ($result = $this->MentorMentees->save($menteesPatch)) {
                $startupApplication = $this->MentorMentees->get($result->id, ['contain' => ['Users','MentorDetails']]);
                //echo "<pre>"; print_r($startupApplication['mentor_detail']['email']); exit;
                //echo $startupApplication['mentor_detail']['email']; exit;
                $nemail = new Email('default');
                $nemail->template('mentorrequest');
                $nemail->emailFormat('html');
                $nemail->viewVars(['emailData' => $startupApplication]);
                $nemail->viewVars(['email' => $startupApplication['mentor_detail']['email']]);
                $nemail->viewVars(['base_url' => Router::url('/', true)]);
                $nemail->cc('anayat.silvertouch@gmail.com');
                $status = $nemail->to($startupApplication['mentor_detail']['email'])
                    ->subject('Startup Haryana : Mentor Request')
                    ->send();
                if($status){
                    $successSms = "Request has been sent.";
                    $this->Flash->success($successSms);
                    $this->redirect(['controller' => 'connect-mentors']);
                }
                else{
                    $successSms = "Email not send to the requested mentor.";
                    $this->Flash->success($successSms);
                    $this->redirect(['controller' => 'connect-mentors']);
                }
                
            } else {
                $this->Flash->error(__('Something went wrong. Please, try again.'));
            }
        }
    }
    public function mentorAcceptList(){
        $this->loadModel('MentorMentees');
        $this->loadModel('Users');
        $ids = $this->Auth->user('id');
        $search_condition = array();
        $data = $this->Sanitize->clean($this->request->getQuery());
        if (!empty($data['reference_no'])) {
            $reference_no = trim($data['reference_no']);
            $this->set('reference_no', $reference_no); 
            $search_condition[] = "MentorMentees.reference_no like '%" . $reference_no . "%'";
        }
        if (!empty($data['mentor_name'])) {
            $mentor_name = trim($data['mentor_name']);
            $this->set('mentor_name', $mentor_name); 
            $search_condition[] = "MentorMentees.mentor_name like '%" . $mentor_name . "%'";
        }    

        if (!empty($data['certificate_no'])) {
            $certificate_no = trim($data['certificate_no']);
            $this->set('certificate_no', $certificate_no); 
            $search_condition[] = "MentorMentees.certificate_no like '%" . $certificate_no . "%'";
        }

        if (!empty($data['email_id'])) {
            $email_id = trim($data['email_id']);
            $this->set('email_id', $email_id); 
            $search_condition[] = "MentorMentees.email_id like '%" . $email_id . "%'";
        }
        
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        $user           = $this->Users->get($this->Auth->user('id'),['contain'=>['Roles']]);
        if($user['role_id']==8){
            $query = $this->MentorMentees->find()->contain(['Users','MentorDetails'])->order(['MentorMentees.id'=>'DESC'])->where([$searchString,'MentorMentees.mentor_id'=>$ids]);
        }
        else{
            $query = $this->MentorMentees->find()->contain(['Users','MentorDetails'])->order(['MentorMentees.id'=>'DESC'])->where([$searchString,'MentorMentees.requested_id'=>$ids]);
        }
        $role_id = $user['role_id'];
        $applications = $this->paginate($query);
       // echo "<pre>"; print_r($applications); exit;
        $this->set(compact('applications','role_id'));
    }
     public function update($id) {
        $id = base64_decode($id);
        $this->loadModel('MentorMentees');
        $application = $this->MentorMentees->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'index']);
        }
        $applications = $this->MentorMentees->get($id);
        if ($this->request->is(['POST', 'PUT'])) {
            $data = $this->request->getData();
            $applications = $this->MentorMentees->patchEntity($applications, $data);
            $applications->reasion_reject = $data['reasion_reject'];
            if ($data['action'] == 'Approve') {
                $applications->is_approved = 1;
            } else if ($this->request->data['action'] == 'Reject') {
                $applications->is_approved = 2;
            }
            $applications->accepted_date = date('Y-m-d');
            if ($result = $this->MentorMentees->save($applications)) {
                $startupApplication = $this->MentorMentees->get($result->id, ['contain' => ['Users','MentorDetails']]);
               //echo "<pre>"; print_r($startupApplication); exit;
                //echo $startupApplication['mentor_detail']['email']; exit;
                $nemail = new Email('default');
                $nemail->template('mentoraccepted');
                $nemail->emailFormat('html');
                $nemail->viewVars(['emailData' => $startupApplication]);
                $nemail->viewVars(['email' => $startupApplication['user']['email']]);
                $nemail->viewVars(['base_url' => Router::url('/', true)]);
                $nemail->cc('abhay_singh@silvertouch.com');
                $status = $nemail->to($startupApplication['user']['email'])
                    ->subject('Startup Haryana : Mentor Request Accepted')
                    ->send();
                if($status){
                    $this->Flash->success(__('You have successfully updated the status'));
                    return $this->redirect(['action' => 'index']);  
                }
                else{
                    $successSms = "Email not send to the requested mentor.";
                    $this->Flash->success($successSms);
                    $this->redirect(['controller' => 'index']);
                }
                
            }
        }
        $this->set(compact('applications'));
    }
    public function view($id)
    {
        $id = base64_decode($id);
        $this->loadModel('MentorMentees');
        $this->loadModel('Users');
        $application = $this->MentorMentees->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'index']);
        }
        $startupApplication = $this->MentorMentees->get($id, ['contain' => ['Users','MentorDetails']]);
        //echo "<pre>"; print_r($startupApplication); exit;
        $this->set(compact('startupApplication'));
    }
    public function meetingSchedule(){
    	$this->loadModel('MeetingSchedules');
    	$meeting_purpose = trim($this->request->getQuery('meeting_purpose'));
        $meeting_purpose = $this->Sanitize->stripAll($meeting_purpose);
        $meeting_purpose = $this->Sanitize->clean($meeting_purpose);
        $this->set('meeting_purpose', $meeting_purpose);
        if (!empty($id)) {
            $meetingschedule = $this->MeetingSchedules->get($id);
        }
        else{
            $meetingschedule = $this->MeetingSchedules->newEntity();
        }
        $this->set(compact('meetingschedule'));
        if ($this->request->is(['post', 'put'])) {
            $data                = $this->request->getData();
            //echo "<pre>"; print_r($data); exit;
            $incubator_directors = array();
/*             $meetingschedule->meeting_request_id  = $this->Auth->user('id');
            if($this->Auth->user('role_id') == '7'){	
            	$meetingschedule->available_mentor_id  = $data['meeting_request_id'];	
            }
            else{
            	$meetingschedule->available_mentor_id  = $data['available_mentor_id'];	
            }*/
            $meetingschedule->created  = date('Y-m-d');
            $menteesPatch = $this->MeetingSchedules->patchEntity($meetingschedule, $data);
            /**/
           
            if ($result = $this->MeetingSchedules->save($menteesPatch)) {
                $startupApplication = $this->MeetingSchedules->get($result->id, ['contain' => ['MenteesDetails']]);
                echo "<pre>"; print_r($startupApplication); exit;
                //echo $startupApplication['mentor_detail']['email']; exit;
                $nemail = new Email('default');
                $nemail->template('meetingschedule');
                $nemail->emailFormat('html');
                $nemail->viewVars(['emailData' => $startupApplication]);
                $nemail->viewVars(['email' => $startupApplication['mentor_detail']['email']]);
                $nemail->viewVars(['base_url' => Router::url('/', true)]);
                $nemail->cc('anayat.silvertouch@gmail.com');
                $status = $nemail->to($startupApplication['mentor_detail']['email'])
                    ->subject('Startup Haryana : Mentor Request')
                    ->send();
                if($status){
                    $successSms = "Request has been sent.";
                    $this->Flash->success($successSms);
                    $this->redirect(['controller' => 'connect-mentors']);
                }
                else{
                    $successSms = "Email not send to the requested mentor.";
                    $this->Flash->success($successSms);
                    $this->redirect(['controller' => 'connect-mentors']);
                }
                
            } else {
                $this->Flash->error(__('Something went wrong. Please, try again.'));
            }
        }

    }
}