<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Event\Event;
use Cake\Mailer\Email;
use Cake\ORM\TableRegistry;
use Cake\Error\Exceptions;
use Cake\I18n\Time;
use Cake\Routing\Router;
use Cake\Auth\DefaultPasswordHasher;
use Cake\Utility\Text;
use Cake\Validation\Validator;

/**
 * Users Controller
 *
 * @property \App\Model\Table\UsersTable $Users
 *
 * @method \App\Model\Entity\User[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class UsersController extends AppController
{
	public $dateFormat = 'Y-m-d';

    public $dateFormatFull = 'Y-m-d H:i:s';
	
    public function initialize()
    {
        parent::initialize();
        $this->Auth->allow(['userTypes','login', 'forgotPassword', 'resetPassword', 'captcha','registration','emailcheck','mobileexists','jcryption','checkMail','registrationVerification','resendOtp','restartRegistration','validateOtp','expireotp']);
        // load the Captcha component and set its parameter
        $this->loadComponent('CakephpCaptcha.Captcha');
        $this->loadModel('Otps');
        //$this->loadComponent('Csrf');
        $this->resQueryOtp = $this->Otps->findById($this->getRequest()->getSession()->read('otpId'))->enableHydration(false)->first();
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }
    
    /**
     * login method
     *
     * @return \Cake\Network\Response|null
     */

    public function checkMail()
    {
        $username = 'nileshkumar.kushvaha@silvertouch.com';
        $UserExist = $this->Users->findByEmail($username)->first();

        $emailData = [
            'setHelpers'     => ['Html'],
            'setTemplate'    => 'startup_mail',
            'setEmailFormat' => 'html',
            'setTo'          => trim($UserExist->email),
            'setSubject'     => __('Ridam'),
            'setViewVars'    => ['user' => $UserExist],
        ];
        $this->Email->sendMail($emailData);
        die('Test Mail Send');
    }

    public function login()
    {
        if($this->isDevice) {
            $this->request->allowMethod(['post']);
            
            $_status = false;
            $_message = '';
	    
	    $profileBaseUrl = Router::Url('/files/profile_pic',true);
            
            $userdata = $this->request->data;
            $validator = new Validator();
            $validator->email('email');
            $validError = $validator->errors(['email' => $this->request->data['username']]);
            if (empty($validError)) {
                $this->Auth->setConfig('authenticate', [
                    'Form' => ['fields' => ['username' => 'email']],
                ]);
                $this->request = $this->request->withData('email', $this->request->data['username']);
                $this->request = $this->request->withoutData('username');
            }
            $uname = $userdata['username'];
            $cUser = $this->Users->find('all')->where(['email' => $uname])->orWhere(['username'=>$uname])->first();
            if (!empty($cUser)) {
                $uId = $cUser['id'];
            } else {
                $uId = 0;
            }
            $user = $this->Auth->identify();
			$user_data = new \stdClass();
            if ($user) {
                if ($user['role_id'] != 1) {
                    if ($user['status']) {
                        $role = $this->Users->Roles->find('all')->where(['id' => $user['role_id']])->first();
                        $registration = $this->Users->Registration->find('all')->where(['user_id' => $user['id']])->first();
                        
                        //$user['role'] = $role;
                        //$user['registration'] = $registration;
                        
                        $this->Auth->setUser($user);
                        
                        $_status = true;
                        $_message = __('Login Successful.');
			
			if(!empty($user['fp_token_at'])){
			    $user['fp_token_at'] = $user['fp_token_at']->format('Y-m-d');
			}
			$user['created'] = $user['created']->format('Y-m-d');
			$user['modified'] = $user['modified']->format('Y-m-d');
			
			$user_data = $user;
			
			$user_data['role_id'] = $role->id;
                        $user_data['role_name'] = $role->name;
			//echo "<pre>";print_r($registration);exit;
			if(!empty($registration) && !empty($registration->date_of_birth)){
			    $user_data['date_of_birth'] = $registration->date_of_birth->format('Y-m-d');
			}
                        $user_data['organization'] = $registration->organization;
                        $user_data['shortname'] = $registration->shortname;
                        $user_data['first_name'] = $registration->first_name;
                        $user_data['last_name'] = $registration->last_name;
                        $user_data['gender'] = $registration->gender;
			//$user_data['email'] = $registration->email;
                        $user_data['mobile_number'] = $registration->mobile_number;
                        $user_data['phone'] = $registration->phone;
                        $user_data['fax'] = $registration->fax;
                        $user_data['state_id'] = $registration->state_id;
                        $user_data['district_id'] = $registration->district_id;
                        $user_data['city'] = $registration->city;
                        $user_data['address'] = $registration->address;
                        $user_data['pincode'] = $registration->pincode;
                        $user_data['profile_photo'] = $profileBaseUrl.'/'.$registration->profile_photo;
                        $user_data['website'] = $registration->website;
			$user_data['designation_id'] = $registration->designation_id;
                        $user_data['isApplicationRegistered'] = false;
                        
                        if ($user['role_id'] == 7) { // role_id = 7 
                            $this->loadModel('StartupApplications');
                            $checkStartup = $this->StartupApplications->findByUserId($user['id'])->first();
                            
                            if(!empty($checkStartup)){
                                $user_data['isApplicationRegistered'] = true;
				if($checkStartup->is_save_draft == 1){
				    $user_data['isApplicationRegistered'] = false;
				}
                            }
                        }
                        
                        if ($user['role_id'] == 10) { // role_id = 10 incubators
                            $this->loadModel('Incubators');
                            $checkIncubator = $this->Incubators->findByUserId($user['id'])->first();
                            
                            if(!empty($checkIncubator)){
                                $user_data['isApplicationRegistered'] = true;
				if($checkIncubator->is_save_draft == 1){
				    $user_data['isApplicationRegistered'] = false;
				}
                            }
                        }
                    } else {
                        $_message = __('Please activate your account by clicking activation link on your registered mail address.');
                    }
                } else {
                    $_message = __('Login with admin Url.');
                }
            } else {
                $_message = __('Invalid username or password.');
            }
            $this->set(compact('_status','_message','user_data'));
            $this->set('_serialize', ['_status','_message','user_data']);
        } else {
            $this->viewBuilder()->setLayout('login');
            if ($this->request->getSession()->check('Auth.User')) {
                return $this->redirect(['controller' => 'Dashboard', 'action' => 'index']);
            }
            //echo "<pre>";print_r($this->request);exit;
            if ($this->request->is('post')) {
                $token = $this->request->getParam('_csrfToken');
                $jcryption = new \JCryption;
                $jcryption->decrypt();
                $this->request->data = $_REQUEST;
                $userdata = $this->request->data;
                $errors = array();
                $captcha = $this->Captcha->check($userdata['captcha']);
                if (empty($captcha)) {
                    $errors['captcha']['_empty'] = 'Invalid captcha. Please try again.';
                }
                if (empty($errors)) {
                    $validator = new Validator();
                    $validator->email('email');
                    $validError = $validator->errors(['email'=>$this->request->data['username']]);
                    if (empty($validError)) {
                        $this->Auth->setConfig('authenticate', [
                            'Form' => ['fields' => ['username' => 'email']],
                        ]);
                        $this->request = $this->request->withData('email', $this->request->data['username']);
                        $this->request = $this->request->withoutData('username');
                    }
                    $uname = $userdata['username'];
                    $cUser = $this->Users->find('all')->where(['email' => $uname])->orWhere(['username'=>$uname])->first();
                    if (!empty($cUser)) {
                        $uId = $cUser['id'];
                    } else {
                        $uId = 0;
                    }
                    $user = $this->Auth->identify();
                    if ($user) {
                        if ($user['role_id'] != 1) {
                            if ($user['status']) {
                                $role = $this->Users->Roles->find('all')->where(['id' => $user['role_id']])->first();
                                $registration = $this->Users->Registration->find('all')->where(['user_id' => $user['id']])->first();
                                $user['role'] = $role;
                                $user['registration'] = $registration;
                                $this->Auth->setUser($user);
    
                                $this->adminLog($user['id'],'Login Successful.');
                                return $this->redirect($this->Auth->redirectUrl());
                            } else {
                                $this->adminLog($user['id'],'Please verify your account.');
                                $this->Flash->error(__('Please verify your account.'));
                                return $this->redirect($this->referer());
                            }
                        } else {
                            $this->adminLog($user['id'],'Login with admin Url.');
                            $this->Flash->error(__('Login with admin Url.'));
                            return $this->redirect($this->referer());
                        }
                    } else {
                        $this->adminLog($uId,'Login Failed.');
                        $this->Flash->error(__('Invalid credentials.'));
                    }
                } else {
                    if(!empty($errors['captcha']['_empty'])){
                        $this->Flash->error(__($errors['captcha']['_empty']));
                    } else {
                        $this->Flash->error(__('Your Captcha is expire. Please refresh the page'));
                    }
                }
            }
        }
    }

    public function adminLog($uid,$logSms='')
    {
        /* admin log code starts */
        $ipaddress = $_SERVER['REMOTE_ADDR'];
        if($ipaddress=='::1'){
            $ipadd = '127.0.0.1';
        } else {
            $ipadd = $ipaddress;
        }
        $ipaddress = $_SERVER['REMOTE_ADDR'];
        $date_today = date('Y-m-d H:i:s');
        $logtime = Time::createFromFormat('Y-m-d H:i:s', $date_today);
        $adminLogTable = TableRegistry::get('admin_logs');
        $adminLog = $adminLogTable->newEntity();
        $adminLog->uid = $uid;
        $adminLog->logsms = $logSms;
        $adminLog->logtime = $logtime;
        $adminLog->ipaddress = inet_pton($ipadd);//string inet_ntop ( string $in_addr )
        $adminLogTable->save($adminLog);
        /* admin log code ends */
    }

    /**
     * logout method
     *
     * @return \Cake\Network\Response|null
     */

    public function logout()
    {
        $this->Flash->success(__('You have logged out successfully.'));
        $user_id = $this->request->session()->read('Auth.User.id');
        $this->adminLog($user_id,'Logout.');
        return $this->redirect($this->Auth->logout());
    }

    /**
     * forgotPassword method
     *
     * @return \Cake\Network\Response|null
     */

    public function forgotPassword()
    {
        if ($this->request->getSession()->check('Auth.User')) {
            return $this->redirect(['controller' => 'Dashboard', 'action' => 'index']);
        }
        $this->viewBuilder()->setLayout('login');        
        if ($this->request->is('post')) {
            $errors = array();
            $captcha = $this->Captcha->check($this->request->getData('captcha'));
            if (empty($captcha)) {
                $errors['captcha']['_empty'] = 'Invalid captcha. Please try again.';
            }
            if (empty($errors)) {
                if (!empty(trim($this->request->getData('username')))) {
                    $username  = trim($this->request->getData('username'));
                    $validator = new Validator();
                    $validator->email('email');
                    $validError = $validator->errors(['email' => $username]);
                    if (empty($validError)) {
                        $UserExist = $this->Users->findByEmail($username)->first();
                    } else {
                        $UserExist = $this->Users->findByUsername($username)->first();
                    }
                    if ($UserExist) {
                        $UserExist->fp_token    = Text::uuid();
                        $UserExist->fp_token_at = date('Y-m-d H:i:s');
                        if ($this->Users->save($UserExist)) {
                            if (!empty($UserExist)) {
                                $emailData = [
                                    'setHelpers'     => ['Html'],
                                    'setTemplate'    => 'forgot_password',
                                    'setEmailFormat' => 'html',
                                    'setTo'          => trim($UserExist->email),
                                    'setSubject'     => __('Please reset your password'),
                                    'setViewVars'    => ['user' => $UserExist],
                                ];
                                $this->Email->send($emailData);
                            }
                            $this->Flash->success(__('Password reset instructions have been sent to your email address. You have 24 hours to complete the request.'));
                            return $this->redirect(['controller' => 'Users', 'action' => 'login']);
                        } else {
                            $this->Flash->error(__('Email not send successful, try again'));
                            return $this->redirect(['controller' => 'Users', 'action' => 'forgotPassword']);
                        }
                    } else {
                        $this->Flash->error(__('Invalid username, try again'));
                        return $this->redirect(['controller' => 'Users', 'action' => 'forgotPassword']);
                    }
                }
            } else {
                $this->Flash->error(__($errors['captcha']['_empty']));
                return $this->redirect(['controller' => 'Users', 'action' => 'forgotPassword']);
            }
        }
    }

    /**
     * Reset Password method
     *
     * @return \Cake\Http\Response|void
     */

    public function resetPassword($fp_token = null)
    {
        $this->viewBuilder()->setLayout('login');
        $user = $this->Users->newEntity();
        if (isset($fp_token)) {
            $TokenExist = $this->Users->findByFpToken($fp_token)->first();
            if ($TokenExist) {
                $tokenGeneratedDate = $TokenExist['fp_token_at'];
                $convertDate        = date("Y-m-d", strtotime($tokenGeneratedDate));
                if (strtotime($convertDate) <= strtotime('-1 day')) {
                    $TokenExist->fp_token    = "";
                    $TokenExist->fp_token_at = "";
                    $this->Users->save($TokenExist);
                    $this->Flash->error('Your link has been expired, try again.');
                    return $this->redirect(['controller' => 'Users', 'action' => 'forgotPassword']);
                } else {
                    if ($this->request->is('post')) {
                        $errors = [];
                        $captcha = $this->Captcha->check($this->request->getData('captcha'));
                        if (empty($captcha)) {
                            $errors['captcha']['_empty'] = 'Invalid captcha. Please try again.';
                        }
                        if (empty($errors)) {
                            $user = $this->Users->patchEntity($TokenExist, [
                                'new_password'     => $this->request->getData('password'),
                                'password'         => $this->request->getData('password'),
                                'confirm_password' => $this->request->getData('confirm_password'),
                            ], ['validate' => 'password']);
                            $user->fp_token    = "";
                            $user->fp_token_at = "";
                            if ($this->Users->save($user)) {
                                $this->__passwordLog($user);
                                if (!empty($user)) {
                                    /*$emailData = [
                                        'setHelpers'     => ['Html'],
                                        'setTemplate'    => 'resetpassword',
                                        'setEmailFormat' => 'html',
                                        'setTo'          => trim($user->email),
                                        'setSubject'     => __('You Password has changed'),
                                        'setViewVars'    => ['user' => $user],
                                    ];
                                    $this->Email->send($emailData);*/
                                }
                                $this->Flash->success(__('You Password has changed'));
                                return $this->redirect(['controller' => 'Users', 'action' => 'login']);
                            }
                        } else {
                            $this->Flash->error(__($errors['captcha']['_empty']));
                        }
                    }
                }
            } else {
                $this->Flash->error(__('Invalid Token.'));
                return $this->redirect(['controller' => 'Users', 'action' => 'login']);
            }
        } else {
            $this->Flash->error(__('Something missing in URL.'));
            return $this->redirect(['controller' => 'Users', 'action' => 'login']);
        }
        $this->set(compact('fp_token', 'user'));
        $this->set('_serialize', ['fp_token']);
    }

    protected function __passwordLog($user)
    {
        $changePasswordTable = TableRegistry::get('change_password_logs');
        $changePassword = $changePasswordTable->newEntity();
        $ipaddress = $_SERVER['REMOTE_ADDR'];
        if ($ipaddress == '::1') {
            $ipadd = '127.0.0.1';
        } else {
            $ipadd = $ipaddress;
        }
        $changePassword->user_id = $user->id;
        $changePassword->password = $user->password;
        $changePassword->change_time = date('Y-m-d H:i:s');
        $changePassword->ip_address = inet_pton($ipadd);
        $changePasswordTable->save($changePassword);
    }

    public function userLog()
    {
        $this->loadModel('AdminLogs');
        $rid = $this->Auth->user('role_id');
        $adminLog = $this->AdminLogs->find('all')
            ->contain(['Users'])
            ->order(['AdminLogs.id'=>'DESC']);
        if ($rid != 1) {
            $adminLog = $adminLog->where(['uid' => $this->Auth->user('id')]);
        }
        $this->paginate = ['limit' => 20];
        $adminLog = $this->paginate($adminLog);
        $this->set(compact('adminLog'));
    }

    public function changePasswordHistory()
    {
        $changePasswordTable = TableRegistry::get('change_password_logs');
        $changePassword = $changePasswordTable->find('all')->where(['user_id'=>$this->Auth->user('id')]);
        $this->paginate = ['limit' => 20];
        $changePassword = $this->paginate($changePassword);
        $this->set(compact('changePassword'));
    }
    
    /**
     * Change Password method
     *
     * @return \Cake\Http\Response|void
     */

    public function changePassword()
    {
        $user = $this->Users->get($this->Auth->user('id'));
        if(!empty($_REQUEST))
        {
            $jcryption = new \JCryption;
            $jcryption->decrypt();
            $userdata = $_REQUEST;
            $user = $this->Users->patchEntity($user, [
                    'old_password'      => $userdata['old_password'],
                    'password'          => $userdata['new_password'],
                    'new_password'      => $userdata['new_password'],
                    'confirm_password'  => $userdata['confirm_password']
                ],
                    ['validate' => 'password']
            );
            if($this->Users->save($user)) 
            {
                $this->__passwordLog($user);
                $this->Flash->success('Your password has been changed successfully.');
                //Email code
                //$this->redirect(['action'=>'view']);
            } else {
                if($user->errors()){
                    $error_msg = [];
                    foreach( $user->errors() as $errors){
                        if(is_array($errors)){
                            foreach($errors as $error){
                                $error_msg[]    =   $error;
                            }
                        }else{
                            $error_msg[]    =   $errors;
                        }
                    }
                    if(!empty($error_msg)){
                        $this->Flash->error(
                                    __("Please fix the following error(s):".implode("\r\n", $error_msg))
                        );
                    }
                }else{
                    $this->Flash->error('Error changing password. Please try again!');
                }
            }
        }
        $this->set('user',$user);
    }

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        return $this->redirect(['controller'=>'Users', 'action' => 'login']);
    }
    
    public function userTypes()
    {
        if($this->isDevice) {
            $this->request->allowMethod(['get']);
            
            $_status = false;
            $_message = '';
            $totalCounts = 0;
            
            $types = array(7,8,9,10,11,12,15);
            $this->loadModel('Roles');
            
            $roles = $this->Roles->find('list',['keyField'=>'id','valueField'=>'name'])->where(['id IN'=>$types])->toArray();
            $user_roles = array();
            if(empty($roles)){
		$_status = true;
                $_message = 'User types not found.';
            }else{
                $_status = true;
                $_message = 'User types found';
                
                $totalCounts = count($roles);
                
                $i=0;
                foreach($roles as $key=>$value){
                    $user_roles[$i]['id'] = $key;
                    $user_roles[$i]['name'] = $value;
                    
                    $i++;
                }
            }
            
            $this->set(compact('_status','_message','totalCounts','user_roles'));
            $this->set('_serialize', ['_status','_message','totalCounts','user_roles']);
        }
    }

    public function registration()
    {
        if($this->isDevice) {
            $this->request->allowMethod(['post']);
            $_status = false;
            $_message = '';
        }
        
        if(!$this->isDevice) {
            $this->viewBuilder()->setLayout('login');
        }
        
        $user = $this->Users->newEntity();
        $this->loadModel('Designations');
        $designation = $this->Designations->find('list',['keyField'=>'id','valueField'=>'name']);
        $this->loadModel('Countries');
        $countries = $this->Countries->find('list',['keyField'=>'id','valueField'=>'name'])->where(['status'=>1]);
        $this->loadModel('States');
        $states = $this->States->find('list',['keyField'=>'id','valueField'=>'name'])->where(['flag'=>1]);
        $this->loadModel('Professions');
        $profession = $this->Professions->find('list',['keyField'=>'id','valueField'=>'name'])->where(['status'=>1]);
        if ($this->request->is('post')) {
            $errors = array();
            
            if($this->isDevice){
                $userdata = $this->request->data;
            }else{
                $jcryption = new \JCryption;
                $jcryption->decrypt();
                $userdata = $_REQUEST;
                
                $captcha = $this->Captcha->check($userdata['captcha']);
                
                if (empty($captcha)) {
                    $errors['captcha']['_empty'] = 'Invalid captcha. Please try again.';
                    $role_id = $userdata['role_id'];
                    $email = $userdata['email'];
                    $name = $userdata['name'];
                    $mobile_number = $userdata['mobile_number'];
                    $organization = $userdata['organization'];
                    $this->set(compact('role_id','email','name','mobile_number','organization'));
                }
            }
            
            if (empty($errors)) {
                $userName = preg_replace('/([^@]*).*/', '$1', $userdata['email']);
                $password = trim($userdata['password']);
                $password = $this->Sanitize->stripAll( $password);
                $password = $this->Sanitize->clean( $password);
                $userRecord = [
                    'name'          => $userdata['name'],
                    'username'      => $userName,
                    'email'         => $userdata['email'],
                    'password'      => $password,
                    'role_id'       => $userdata['role_id'],
                    'status'        => 0,
                    //'password_hint' => $userdata['confirm_password'],
                    'fp_token'      => Text::uuid(),
                    'fp_token_at'   => date('Y-m-d H:i:s')
                ];
                
                $user = $this->Users->patchEntity($user, $userRecord);
                //pr($user); exit();
                if ($result = $this->Users->save($user)) {
                    $this->loadModel('Registration');
                    $registration = $this->Registration->newEntity();
                    $registration->user_id  = $result->id;
                    if(!empty($userdata['gender'])){
                        $registration->gender     = $userdata['gender'];
                    }
                    $registration->email          = $userdata['email'];
                    $registration->organization   = $userdata['name'];
                    $registration->first_name     = $userdata['first_name'];
                    if(!empty($userdata['middle_name'])){
                        $registration->middle_name= $userdata['middle_name'];
                    }
                    if(!empty($userdata['last_name'])){
                        $registration->last_name  = $userdata['last_name'];
                    }                    
                    $registration->date_of_birth  = date('Y-m-d',strtotime($userdata['date_of_birth']));
                    $registration->mobile_number  = $userdata['mobile_number'];
                    if(!empty($userdata['other_designation'])){
                        $registration->other_designation = $userdata['other_designation'];
                    }
                    if(!empty($userdata['profession_id'])){
                        $registration->profession_id = $userdata['profession_id'];
                    }
                    if(!empty($userdata['address'])){
                        $registration->address = $userdata['address'];
                    }
                    if(!empty($userdata['country_id'])){
                        $registration->country_id = $userdata['country_id'];
                    }
                    if(!empty($userdata['state_id'])){
                        $registration->state_id = $userdata['state_id'];
                    } else {
                        $registration->state_id = null;
                    }
                    if(!empty($userdata['district_id'])){
                        $registration->district_id = $userdata['district_id'];
                    } else {
                        $registration->district_id = null;
                    }
                    if(!empty($userdata['city'])){
                        $registration->city = $userdata['city'];
                    } else {
                        $registration->city = null;
                    }
                    if(!empty($userdata['pincode'])){
                        $registration->pincode = $userdata['pincode'];
                    } else {
                        $registration->pincode = null;
                    }
					
                    if ($this->Registration->save($registration)) {
                        $this->__passwordLog($result);
                        //$this->__sendActivationEmail($result->id,$result->fp_token);

                        $rndno = rand(1000, 9999);                        
                        $otpNew = $this->Otps->newEntity();
                        // delete the previous opt records
                        $queryOtp = $this->Otps->find('all')->where(['email'=>$userdata['email']])->first();
                        if(!empty($queryOtp['id'])){
                            $OtpEntity  = $this->Otps->get($queryOtp['id']);
                            $result     = $this->Otps->delete($OtpEntity);
                        }
                        $otpNew->email          = $userdata['email'];
                        $otpNew->mobile_number  = $userdata['mobile_number'];
                        $otpNew->otp            = $rndno;
                        $otpNew->created        = date('Y-m-d H:i:s');
                        $this->Otps->save($otpNew);
                        $cUser = $this->Users->find('all')->where(['email' => $userdata['email']])->first();
                        $this->getRequest()->getSession()->write('otpId', $otpNew->id);
                        $this->__sendOtpEmail($cUser,$rndno);                   
                        if($this->isDevice){
                            $_status = true;
                            $_message = 'An OTP has been sent to your Email. Please enter OTP';
                        }else{
                            $this->Flash->success(__('An OTP has been sent to your Email. Please enter OTP'));

                            return $this->redirect(['controller'=>'Users', 'action' => 'validateOtp']);
                        }
                    } else {
                        $inesrtedUser = $this->Users->get($result->id);
                        if($this->Users->delete($inesrtedUser)){
                            $this->loadModel('Registration');
                            $this->Registration->deleteAll(['user_id' => $result->id]);
                        }
                        if($this->isDevice){
                            $_message = 'Internal Server Error. Please, try again.';
                        }else{
                            $this->Flash->error(__('Internal Server Error. Please, try again.'));
                        }
                    }
                } else {
                    if($this->isDevice){
                        if(!empty($user->errors())){
                            foreach($user->errors() as $key=>$value){
                                if(is_array($value)){
                                    foreach($value as $k=>$v){
                                        $errs[] = $v;
                                    }
                                }else{
                                    $errs[] = $value;
                                }
                            }
                        }
                        $_message = implode(", ",$errs);
                        //$_message = 'Your online registration could not be completed. Please, try again.';
                    }else{
                        $this->Flash->error(__('Your online registration could not be completed. Please, try again.'));
                    }
                }
            } else {
                if(!empty($errors['captcha']['_empty'])){
                    $this->Flash->error(__($errors['captcha']['_empty']));
                } else {
                    $this->Flash->error(__('Your Captcha is expire. Please refresh the page'));
                }
            }
        }
        
        if($this->isDevice){
            $this->set(compact('_status','_message'));
            $this->set('_serialize', ['_status','_message']);
        }else{
            $this->set(compact('user','designation','states','profession','countries'));
        }
       
    }

    public function resendOtp(){
        if(!empty($this->getRequest()->getSession()->read('otpId')) && !empty($this->resQueryOtp['repeats']) >= 0){
            if($this->request->is('post')){
                $id = $this->getRequest()->getSession()->read('otpId');
                $email = $this->resQueryOtp['email'];
                $mobile = $this->resQueryOtp['mobile_number'];
                $rndno = rand(1000, 9999);
                $queryOtp = $this->Otps->find('all')->where(['id'=>$id])->first();
                $queryOtp->otp = $rndno;
                $queryOtp->repeats = $queryOtp['repeats']+1;
                $queryOtp->created = date('Y-m-d H:i:s');
                if($result  = $this->Otps->save($queryOtp)) {
                    $cUser = $this->Users->find('all')->where(['email' => $email])->first();
                    $this->__sendOtpEmail($cUser,$rndno);
                    $this->Flash->success(__('OTP has been Resent on your Email Id, please verify'));
                    return $this->redirect(['action' => 'validateOtp']);
                } else {
                    $this->Flash->error(__("There are some error in database. Please tray again"));
                }
            }else{
                return $this->redirect(['action' => 'validateOtp']);
            }
        }else{
            $this->Flash->error(__('Please provide below details.'));
            return $this->redirect(['action' => 'registration']);
        }
        exit();
    }

    public function restartRegistration() {
        if($this->request->is('post')){
            if($this->resQueryOtp['id']){
                $result = $this->Users->findByEmail($this->resQueryOtp['email'])->first();
                $inesrtedUser = $this->Users->get($result->id);
                if($this->Users->delete($inesrtedUser)){
                    $this->loadModel('Registration');
                    $this->Registration->deleteAll(['user_id' => $result->id]);
                }
                $id = $this->resQueryOtp['id'];
                $queryOtp = $this->Otps->findById($id)->first();
                $OtpEntity = $this->Otps->get($queryOtp['id']);
                $result = $this->Otps->delete($OtpEntity);
            }            
            $this->getRequest()->getSession()->destroy();
            $this->Flash->error(__('You are ready to Restart registration process.'));
            return $this->redirect(['action' => 'registration']);
        }else{
            return $this->redirect(['action' => 'registration']);
        }
    }

    public function validateOtp(){
        $this->viewBuilder()->setLayout('login');
        $this->set('repeats', $this->resQueryOtp['repeats']);
        if(!empty($this->resQueryOtp)){
            if(empty($this->getRequest()->getSession()->read('otp_time')) || $this->getRequest()->getSession()->read('update_time') != strtotime($this->resQueryOtp['created'])){
                $otptime = strtotime($this->resQueryOtp['created'])+4*60+(date('U')-strtotime($this->resQueryOtp['created']));
                $this->getRequest()->getSession()->write('otp_time', $otptime);
                $this->getRequest()->getSession()->write('update_time', strtotime($this->resQueryOtp['updated']));
            }
            if(!empty($this->resQueryOtp['verified'])){
                $this->Flash->success(__('OTP verification has been verified.'));
                return $this->redirect(['action' => 'login']);
            }
            if($this->request->is('post')){
                $this->loadModel('Otps');
                $id = $this->resQueryOtp['id'];
                $queryOtp = $this->Otps->find('all')->where(['id'=>$id,'otp'=>$this->request->getData('otp')])->first();

                if(empty($queryOtp)){
                    $wrong_att = $this->Otps->find('all')->where(['id'=>$id])->first();
                    $wrong_att->attempt = $wrong_att['attempt']+1;
                    $wrong = $this->Otps->save($wrong_att);
                    if($wrong->attempt >= 3){
                        $OtpEntity = $this->Otps->get($id);
                        $this->Otps->delete($OtpEntity);
                        $this->getRequest()->getSession()->destroy();
                        $this->Flash->error(__("You have reached maximum failed OTP verification. Try new registration."));
                        return $this->redirect(['action' => 'registration']);
                    }else{
                        $total = 3;
                        $left = $total - $wrong->attempt;
                        $this->Flash->error(__("Only ".$left." attempt left. Please provide correct OTP."));
                        return $this->redirect(['action' => 'validateOtp']);
                    }
                }
                $queryOtp->verified = 1;
                $result = $this->Otps->save($queryOtp);
                if(empty($result)){
                    $this->Flash->error(__("OTP could not be verified. Please try again"));
                    return $this->redirect(['action' => 'validateOtp']);
                }
                $this->getRequest()->getSession()->delete('otp_time');
                $this->getRequest()->getSession()->delete('update_time');
                
                // Activate User
                $userDa = $this->Users->find()->where(['email'=>$result->email])->first();
                if (empty($userDa['status'])) {
                    $query = $this->Users->query();
                    $query->update()
                    ->set(['status'=>1,'fp_token'=>null,'fp_token_at'=>null])
                    ->where(['id' => $userDa->id])
                    ->execute();

                    $this->Flash->success(__('Your account has been successfully activated.'));
                } elseif ($userDa['status'] == 1) {
                    $this->Flash->success(__('Your account has already been activated.'));
                }

                // Delete OTP entry
                $deletOtpEntity  = $this->Otps->get($this->resQueryOtp['id']);
                $this->Otps->delete($deletOtpEntity);

                return $this->redirect(['action' => 'login']);
            }
        }else{
            $this->Flash->error(__('Please provide below details.'));
            return $this->redirect(['action' => 'registration']);
        }
    }

    public function expireotp() {
        $this->set('title', 'Expire OTP');
        if(empty($this->resQueryOtp['id'])){
            $this->Flash->error(__('Please provide below details for OTP request.'));
            return $this->redirect(['action' => 'registration']);
        }
        $this->loadModel('Otps');
        $OtpEntity = $this->Otps->get($this->resQueryOtp['id']);
        $this->Otps->delete($OtpEntity);
        $this->getRequest()->getSession()->destroy();
        $this->Flash->error(__("Your OTP has been expired. Please Re-try registration."));
        return $this->redirect(['action' => 'registration']);
    }

    protected function __sendOtpEmail($userData,$rndno)
    {
        $emailData = [
            'setHelpers'     => ['Html'],
            'setTemplate'    => 'otp_mail',
            'setEmailFormat' => 'html',
            'setTo'          => trim($userData->email),
            'setCc'          => trim('nileshkumar.kushvaha@silvertouch.com'),
            'setSubject'     => __('Startup – OTP'),
            'setViewVars'    => ['otpno'=>$rndno,'name'=>$userData->name],
        ];
        $this->Email->sendMail($emailData);
    }


    protected function __sendActivationEmail($user_id, $token)
    {
        if (empty($token) && empty($user_id)) {
            $this->Flash->success(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'login']);
        }
        $user = $this->Users->find()->where(['id'=>$user_id])->first();
        $link = Router::url('/en/users/registration-verification/' . $token.'/'.$user->id, true);
        $to = $user->email;
        $emailData = [
            'setHelpers'     => ['Html'],
            'setTemplate'    => 'activation_email',
            'setEmailFormat' => 'html',
            'setTo'          => trim($to),
            //'setCc'          => trim('nileshkumar.kushvaha@silvertouch.com'),
            'setSubject'     => __('Startup – Registration Successful'),
            'setViewVars'    => ['link'=>$link,'name'=>$user->name],
        ];
        $this->Email->sendMail($emailData);
    }

    public function registrationVerification($token,$user_id)
    {
        if (empty($token) && empty($user_id)) {
            $this->Flash->success(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'login']);
        }
        $user = $this->Users->find()->where(['id'=>$user_id,'fp_token'=>$token])->first();
        if (empty($user['status'])) {
            $query = $this->Users->query();
            $query->update()
            ->set(['status'=>1,'fp_token'=>null,'fp_token_at'=>null])
            ->where(['id' => $user->id])
            ->execute();

            $this->Flash->success(__('Your account has been successfully activated.'));
        } elseif ($user['status'] == 1) {
            $this->Flash->success(__('Your account has already been activated.'));            
        }
        return $this->redirect(['action' => 'login']);
    }

    public function jcryption()
    {
        $this->autoRender = false;
        $jc = new \JCryption;
        $jc->go();
        header('Content-type: text/plain');
    }

    public function captcha()
    {
        $this->autoRender = false;
        echo $this->Captcha->image(5);
    }

    public function emailcheck() {
        $this->viewBuilder()->setLayout('ajax');
        $email = $_POST['email'];        
        $emailResult = $this->Users->find('all',['conditions'=>['email'=>$email],'fields'=>['email']])->enableHydration(false)->first();
        if (!empty($emailResult)) {
            echo 'false';
        } else {
            echo 'true';
        }
        exit();
    }

    public function mobileexists() {
        $this->loadModel('Registration');
        $this->viewBuilder()->setLayout('ajax');
        $mobileno = trim($_POST['mobile_number']);
        $newmobile = substr($mobileno, -10);
        $mobilenoResult = $this->Registration->find('all', ['conditions' => ['mobile_number' => $newmobile], 'fields' => ['mobile_number']])->enableHydration(false)->first();
        if (!empty($mobilenoResult)) {
            echo 'false';
        } else {
            echo 'true';
        }
        exit();
    }


    public function editProfile()
    {
        $this->viewBuilder()->layout('frontend');
        $this->loadModel('States');
        $state = $this->States->find('list',['keyField'=>'id','valueField'=>'name'])->where(['flag'=>1]);
        $user = $this->Users->get($this->Auth->user('id'),['contain'=>['Registration']]);
        $this->loadModel('Designations');
        $designation = $this->Designations->find('list',['keyField'=>'id','valueField'=>'name']);
        $this->loadModel('Countries');
        $countries = $this->Countries->find('list',['keyField'=>'id','valueField'=>'name'])->where(['status'=>1]);
        if(!empty($user->registration->district_id)){
            $this->loadModel('Districts');
            $district = $this->Districts->find('list',['keyField'=>'id','valueField'=>'name'])->where(['state_id'=>$user->registration->state_id]);
            $this->set('district',$district);
        }
        if($this->request->is(['post','put'])){
            $data = $this->request->getData();
            $data = $this->Sanitize->clean($data);
            $saveData = $this->Users->patchEntity($user, $data, ['associated' => ['Registration']]);
            
            if($data['registration']['profile_photo']['name']!=''){
                $photo = $this->uploadFiles('profile_pic', $data['registration']['profile_photo']);
                $saveData->registration->profile_photo = $photo['filename'];
            }else{
                $saveData->registration->profile_photo = @$data['registration']['profile_photo_old'];
            }
            $saveData->registration->date_of_birth = date('Y-m-d',strtotime($data['registration']['date_of_birth']));
            if ($userdata = $this->Users->save($saveData, ['associated'=>['Registration']])) {
                $this->Flash->success(__("Profile has been updated successfully"));
                return $this->redirect(['controller'=>'Dashboard']);
            }
        }
        $this->set(compact('user','state','designation','countries'));
    }
    
    public function apiEditProfile()
    {
		if ($this->isDevice == false) {
            return $this->redirect(['controller' => 'Dashboard', 'action' => 'index']);
        }
		
		$this->request->allowMethod(['post']);
        $_status  = false;
        $_message = '';
		
		$profileBaseUrl = Router::Url('/files/profile_pic',true);
		
        if ($this->request->is(['post'])) {
            $userId = $this->request->getData('userId');
        
		}
        $this->loadModel('Registration');
		
		$user_registration = new \stdClass();
		if (!empty($userId)) {
			$user_registration = $this->Registration->findByUserId($userId)->first();
        } else {
            $_message = __('UserID is required');
        }
		if(empty($user_registration)){
			$user_registration = $this->Registration->newEntity();
		}
		//echo "<pre>";print_r($user_registration);exit;
		if (empty($_message) && $this->request->is(['post'])) {
			$data = $this->request->getData();
			$data = $this->Sanitize->clean($data);
			
			$data['user_id'] = $data['userId'];
			if(!empty($data['date_of_birth'])){
				$data['date_of_birth'] = date('Y-m-d',strtotime($data['date_of_birth']));
			}
			if(!empty($data['profile_photo']) && $data['profile_photo']['name'] != ''){
				$photo = $this->uploadFiles('profile_pic', $data['profile_photo']);
				$data['profile_photo'] = $photo['filename'];
			}
			
			$saveData = $this->Registration->patchEntity($user_registration, $data);
			if($this->Users->Registration->save($saveData)) {
				$_status  = true;
				$_message = 'Profile has been updated successfully';
			}else{
				//pr($saveData->errors());exit;
				if(!empty($saveData->errors())){
					foreach($saveData->errors() as $key=>$value){
						if(is_array($value)){
							foreach($value as $k=>$v){
							$errs[] = $v;
							}
						}else{
							$errs[] = $value;
						}
					}
				}
				$_message = implode(", ",$errs);
			}
		}
		if(!empty((array)$user_registration)) {
            $dateFields = ['date_of_birth','created'];
            foreach ($dateFields as $field) {
                $date = $user_registration->get($field);
                if(!empty($date)) {
                    $user_registration->{$field} = $date->format($this->dateFormat);
                }
            }
        }
		$this->set([
            '_status'    => $_status,
            '_message' => $_message,
            'user_data'   => $user_registration,
			'profileBaseUrl'   => $profileBaseUrl,
			'_serialize' => [
                '_status', '_message', 'user_data','profileBaseUrl'
            ],
        ]);
        //$this->set(compact('_status','_message','user_registration'));
		//$this->set('_serialize', ['_status','_message','user_registration']);
    }

}
