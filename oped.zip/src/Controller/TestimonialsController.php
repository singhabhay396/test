<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Core\Configure;
use Cake\Event\Event;
use Cake\Network\Exception\NotFoundException;
use Cake\View\Exception\MissingTemplateException;

/**
 * Testimonials Controller
 *
 * @property \App\Model\Table\TestimonialsTable $Testimonials
 *
 * @method \App\Model\Entity\Tender[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class TestimonialsController extends AppController
{

    public function initialize()
    {
        parent::initialize();
        $this->viewBuilder()->setLayout('frontend');
        $this->Auth->allow(['index']);
        $this->loadModel('Testimonials');
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }

    /**
     * Page method
     *
     * @return \Cake\Http\Response|void
     */
    public function index($testimonial_id=null)
    {
        if (empty($testimonial_id)) {
            $testimonials = $this->Testimonials->find('all')->where(['status' => 1]);
            $_template = 'index';
            $this->paginate = ['limit' => 15];
            $testimonials = $this->paginate($testimonials);
        } else {
            $testimonials = $this->Testimonials->findById($testimonial_id)->where(['status' => 1])->first();
            $_template = 'page_' . $testimonials->id;
        }
        if (empty($testimonials)) {
            throw new NotFoundException(__('Testimonials not found'));
        }
        $this->set('testimonials', $testimonials);

        try {
            $this->render($_template);
        } catch (MissingTemplateException $e) {
            $this->render('page');
        }
    }
}