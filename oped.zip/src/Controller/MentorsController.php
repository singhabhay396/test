<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Controller\Controller;
use Cake\Event\Event;
use Cake\Routing\Router;
use Cake\View\View;

/**
 * Incubators Controller
 *
 * @property \App\Model\Table\IncubatorsTable $Incubators
 *
 * @method \App\Model\Entity\Incubators[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class MentorsController extends AppController
{
    public $dateFormat = 'Y-m-d';

    public $dateFormatFull = 'Y-m-d H:i:s';

    public function initialize()
    {
        parent::initialize();

        $this->viewBuilder()->setLayout('frontend');
        $this->Auth->allow(['index', 'TrackApplication', 'DownloadRecognitionCertificate']);
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }

    public function index()
    {
        return $this->redirect(['action' => 'eligibilityCriteria']);
    }

    public function eligibilityCriteria()
    {
    }

    public function apiCheckIncentive()
    {
        if ($this->isDevice == false) {
            return $this->redirect(['controller' => 'Dashboard', 'action' => 'index']);
        }
        $this->request->allowMethod(['get']);
        $_status  = false;
        $_message = '';

        $_BaseUrl         = Router::Url('/files/incubator', true);
        $_DirectorBaseUrl = Router::Url('/files/incubator_directors', true);

        $_incubator = new \stdClass();

        $userId = $this->request->getQuery('userId');
        if (!empty($userId)) {
            $where     = [];
            $where[]   = ['user_id' => $userId];
            $incubator = $this->Incubators->find('all', ['contain' => ['IncubatorDirectors']])->where($where)->first();
            if (!empty($incubator) && empty($incubator->incubator_certificate_no)) {
                $_message = __('Your application is being considered but has not yet been approved.');
            } else if (empty($incubator)) {
                $_message = __('You have not applied for any Incubator.');
            }
        } else {
            $_message = __('UserID is required');
        }
        if (empty($_message)) {
            $_status = true;
        }
        if (!empty($incubator)) {
            $_incubator = $incubator;
        }

        if(!empty($_incubator)) {
            $dateFields = ['date_of_incorporation', 'proposed_date', 'approval_date'];
            foreach ($dateFields as $field) {
                $date = $_incubator->get($field);
                if(!empty($date)) {
                    $_incubator->{$field} = $date->format($this->dateFormat);
                }
            }
        }
        $this->set([
            '_status'          => $_status,
            '_incubator'       => $_incubator,
            '_BaseUrl'         => $_BaseUrl,
            '_DirectorBaseUrl' => $_DirectorBaseUrl,
            '_message'         => $_message,
            '_serialize'       => [
                '_status', '_incubator', '_BaseUrl', '_DirectorBaseUrl', '_message',
            ],
        ]);
    }

    public function apiRegistration()
    {
        if ($this->isDevice == false) {
            return $this->redirect(['controller' => 'Dashboard', 'action' => 'index']);
        }
        $this->request->allowMethod(['get', 'post']);
        $_status  = false;
        $_message = '';

        $_BaseUrl         = Router::Url('/files/incubator', true);
        $_DirectorBaseUrl = Router::Url('/files/incubator_directors', true);
        
        $_format_links = [
    	  'entity_authorization' => Router::Url('/files/Annexure/Incubators-Annexure-III.docx',true),
    	  'entity_undertaking' => Router::Url('/files/Annexure/Incubators-Annexure-III.docx',true)
    	];

        $_incubator = new \stdClass();

        if ($this->request->is(['post'])) {
            $applicationId = $this->request->getData('applicationId');
            $userId        = $this->request->getData('userId');
        } else {
            $applicationId = $this->request->getQuery('applicationId');
            $userId        = $this->request->getQuery('userId');
        }

        if (!empty($userId)) {
            $where = [];
            if (!empty($applicationId)) {
                $where[] = ['id' => $applicationId];
            }
            if (!empty($userId)) {
                $where[] = ['user_id' => $userId];
            }
            $incubator = $this->Incubators->find('all', ['contain' => ['IncubatorDirectors']])->where($where)->first();
            if (!empty($incubator) && $incubator->is_save_draft != 1) {
                $_message = __('You have already registered for Incubator.');
            }
            $incubator = (!empty($incubator)) ? $incubator : $this->Incubators->newEntity();
        } else {
            $_message = __('UserID is required');
        }

        if (!empty($incubator) && !$incubator->isNew()) {
            $_incubator = $incubator;
        }

        if (empty($_message) && $this->request->is(['post'])) {
            $incubatorDirectorsFields = $this->request->getData('incubator_directors_fields');
            $this->request->withoutData('incubator_directors_fields');
            $incubatorDirectorsUpload = $this->request->getData('incubator_directors_upload');
            $this->request->withoutData('incubator_directors_upload');
            $postData                          = $this->request->getData();
            $postData['user_id']               = $userId;
            $postData['application_status_id'] = 1;
            $postData['incubator_stage_id']    = 1;
            $postData['is_save_draft']         = 0;
            if (!empty($postData['save_as_draft'])) {
                $postData['incubator_stage_id'] = 0;
                $postData['is_save_draft']      = 1;
            }
            /** Document **/
            $incubatorFiles = ['entity_incorp_reg_cert', 'entity_pan', 'entity_undertaking', 'entity_authorization', 'business_model', 'floor_plans', 'proof_of_ownership', 'detailed_project_report', 'photographs', 'employee_details_doc'];
            foreach ($incubatorFiles as $field) {
                if (isset($postData[$field]) && $postData[$field]['name'] != '') {
                    $uploaded = $this->uploadFiles('incubator', $postData[$field]);
                    if (isset($uploaded['filename'])) {
                        $postData[$field] = $uploaded['filename'];
                    } else {
                        unset($postData[$field]);
                    }
                } else if (isset($postData[$field])) {
                    unset($postData[$field]);
                }
            }
            //Save
            $incubatorSave = $this->Incubators->patchEntity($incubator, $postData);
            if ($this->Incubators->save($incubatorSave)) {
                $applicationId = $incubatorSave->id;
                $isSaveDraft   = (!empty($incubatorSave->is_save_draft)) ? true : false;
                $formOfEntity  = $incubatorSave->form_of_entity;
                $createdAt     = $incubatorSave->created;
                // Update Reference No
                $referenceNo = $incubatorSave->reference_no;
                if (empty($referenceNo)) {
                    $referenceNo = $this->generateReferenceNo($applicationId, $formOfEntity);
                    $this->Incubators->query()
                        ->update()
                        ->set(['reference_no' => $referenceNo])
                        ->where(['id' => $applicationId])
                        ->execute();
                    $incubatorSave->reference_no = $referenceNo;
                }
                // Save Incubator Directors
                $incubatorSave->{'incubator_directors'} = [];
                /** Document **/
                $incubatorDirectorFiles = ['id_proof', 'residential_proof'];
                if (!empty($incubatorDirectorsFields)) {
                    $incubatorDirectors       = [];
                    $incubatorDirectorsFields = json_decode($incubatorDirectorsFields, true);
                    foreach ($incubatorDirectorsFields as $key => $director) {
                        $director['incubator_application_id'] = $applicationId;
                        $director['nationality']              = 1;
                        foreach ($incubatorDirectorFiles as $field) {
                            if (isset($incubatorDirectorsUpload[$key][$field]) && $incubatorDirectorsUpload[$key][$field]['name'] != '') {
                                $uploaded = $this->uploadFiles('incubator_directors', $incubatorDirectorsUpload[$key][$field]);
                                if (isset($uploaded['filename'])) {
                                    $director[$field] = $uploaded['filename'];
                                } else {
                                    unset($director[$field]);
                                }
                            } else if (isset($director[$field])) {
                                unset($director[$field]);
                            }
                        }
                        $incubatorDirectors[] = $director;
                    }
                    $incubatorDirectors = $this->Incubators->IncubatorDirectors->newEntities($incubatorDirectors);
                    $incubatorDirectors = $this->Incubators->IncubatorDirectors->saveMany($incubatorDirectors);

                    $incubatorSave->{'incubator_directors'} = $incubatorDirectors;
                }
                if ($isSaveDraft) {
                    $_message = __("Your application has been saved as draft");
                } else {
                    /*startup_application_file_movements Table*/
                    $tableName               = 'IncubatorApplicationFileMovements';
                    $applicationIdColumnName = 'incubator_application_id';
                    $startupApplicationId    = $applicationId;
                    $comment                 = '';
                    $currentWith             = 'Dealing Officer';
                    $initiatedDate           = $createdAt;
                    $pandingFrom             = date('Y-m-d');
                    $this->fileMovement($tableName, $applicationIdColumnName, $startupApplicationId, $currentWith, $comment, $initiatedDate, $pandingFrom, $postData);
                    $_message = __("Thanks for your application, Please note Reference number {0} for further communication. You can also check your mail for reference number.", [$referenceNo]);
                }
                $_status    = true;
                $_incubator = $incubatorSave;
            } else {
                $_message = __("Your application could not be saved. Please, try again.");
            }
        } else if (empty($_message)) {
            $_status = true;
        }

        if(!empty($_incubator)) {
            $dateFields = ['date_of_incorporation', 'proposed_date', 'approval_date'];
            foreach ($dateFields as $field) {
                $date = $_incubator->get($field);
                if(!empty($date)) {
                    $_incubator->{$field} = $date->format($this->dateFormat);
                }
            }
        }
        
        $this->set([
            '_status'          => $_status,
            '_incubator'       => $_incubator,
            '_BaseUrl'         => $_BaseUrl,
            '_DirectorBaseUrl' => $_DirectorBaseUrl,
            '_format_links'    => $_format_links,
            '_message'         => $_message,
            '_serialize'       => [
                '_status', '_incubator', '_BaseUrl', '_DirectorBaseUrl', '_message','_format_links'
            ],
        ]);
    }

    public function registration($id = null)
    {
        $this->loadModel('Mentors');
        $this->loadModel('Users');
        $this->loadModel('BankDetails');
        $this->loadModel('Sectors');
		$datas = array();
        if (!empty($id)) {
            $mentors = $this->Mentors->get($id);
        }
        else {
            $check_status = $this->Mentors->findByUserId($this->Auth->user('id'))->first();
            if (!empty($check_status)) {
                if ($check_status->is_save_draft != 1) {
                    $this->Flash->error(__('You have already registered for Startup.'));
                    return $this->redirect(['controller' => 'Dashboard']);
                } else {
                    return $this->redirect(['action' => 'registration', $check_status->id]);
                }
            } else {
				$check_status2 = $this->Users->get($this->Auth->user('id'));
				if ($check_status2->id != '') {
                    $usersMentor 				= $this->Users->get($this->Auth->user('id'),['contain' => ['Registration']]);
					$datas['mentor_name'] 		= $usersMentor['name'];
					$datas['email_id'] 	 		= $usersMentor['email'];
					$datas['mobile_no'] 	 	= $usersMentor['registration']['mobile_number'];
					$datas['current_address'] 	= $usersMentor['registration']['address'];
					$mentors = $this->Mentors->newEntity();
                }
				else{
					$mentors = $this->Mentors->newEntity();
				}                
            }
        }
        $bank = $this->BankDetails->find('list', ['keyField' => 'bank_name', 'valueField' => 'bank_name']);
	$sectors = $this->Sectors->find('list', ['keyField' => 'id', 'valueField' => 'name']);
        $this->set(compact('datas','mentors', 'bank','sectors'));

        if ($this->request->is(['post', 'put'])) {
            $data                = $this->request->getData();
            $industry_experience    = $data['industry_experience'];
            $mentorship_experience  = $data['mentorship_experience'];
            $mentor_type            = $data['mentor_type'];
            $committed_hours        = $data['committed_hours'];
            $startups_mentored      = $data['startups_mentored'];
            $associated_mentors     = $data['associated_mentors'];
            $eligible_sum = $industry_experience + $mentorship_experience + $mentor_type + $committed_hours + $startups_mentored + $associated_mentors;
            $incubator_directors = array();
            if($eligible_sum > 49 || !empty($data['save_as_draft'])){
                $mentorPatch = $this->Mentors->patchEntity($mentors, $data);
                /*Entity Document */
                if ($data['cv_upload']['name'] != '') {
                    $certificate    = $this->uploadFiles('mentor', $data['cv_upload']);
                    $mentorPatch->cv_upload = $certificate['filename'];
                } else {
                    $mentorPatch->cv_upload = @$data['cv_upload_old'];
                }

                if ($data['photograph']['name'] != '') {
                    $certificate  = $this->uploadFiles('mentor', $data['photograph']);
                    $mentorPatch->photograph = $certificate['filename'];
                } else {
                    $mentorPatch->photograph = @$data['photograph_old'];
                }

                if ($data['copy_pan_card']['name'] != '') {
                    $certificate   = $this->uploadFiles('mentor', $data['copy_pan_card']);
                    $mentorPatch->copy_pan_card = $certificate['filename'];
                } else {
                    $mentorPatch->copy_pan_card = @$data['copy_pan_card_old'];
                }

                if ($data['copy_list_startups']['name'] != '') {
                    $certificate  = $this->uploadFiles('mentor', $data['copy_list_startups']);
                    $mentorPatch->copy_list_startups = $certificate['filename'];
                } else {
                    $mentorPatch->copy_list_startups = @$data['copy_list_startups_old'];
                }

                /**/
                $mentorPatch->user_id  = $this->Auth->user('id');
                if (!empty($data['save_as_draft'])) {
                    $mentorPatch->mentor_stage_id = 0;
                    $mentorPatch->is_save_draft      = 1;
                } else {
                    $mentorPatch->mentor_stage_id = 1;
                    $mentorPatch->is_save_draft      = 0;
                }
                            //echo "<pre>"; print_r($data); exit;
                if ($result = $this->Mentors->save($mentorPatch)) {
                    $application_id = $result->id;
                    $form_of_entity = $result->form_of_entity;
                    $reference_no   = $this->generateReferenceNo($application_id, $form_of_entity);
                    $query          = $this->Mentors->query();
                    $query->update()
                        ->set(['reference_no' => $reference_no])
                        ->where(['id' => $application_id])
                        ->execute();
                    if (!empty($data['save_as_draft'])) {
                        $this->Flash->success(__("Your application has been saved as draft"));
                        return $this->redirect(['action' => 'registration', $result->id]);
                    } else {
                        /*startup_application_file_movements Table*/
                        $tableName                 = 'MentorApplicationFileMovements';
                        $application_id_columnName = 'mentors_application_id';
                        $startup_application_id    = $result->id;
                        $comment                   = '';
                        $current_with              = 'Dealing Officer';
                        $initiated_date            = $mentorPatch->created;
                        $panding_from              = date('Y-m-d');

                        $this->fileMovement($tableName, $application_id_columnName, $startup_application_id, $current_with, $comment, $initiated_date, $panding_from, $data);

                        $successSms = "Thanks for your application, Please note Reference number $reference_no for further communication. You can also check your mail for reference number.";
                        $this->Flash->success($successSms);
                        $this->redirect(['controller' => 'Dashboard']);
                    }
                } else {
                    $this->Flash->error(__('Something went wrong. Please, try again.'));
                }
            }
            else{
                $this->Flash->error(__('Your marks is less then 50 So that you are not eligible to associate as Government recognised mentor.'));
            }
        }
    }

    public function viewMentorApplication($id = '')
    {
        $id = base64_decode($id);
        $this->loadModel('Mentors');
        $application = $this->Mentors->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'index']);
        }
        $startupApplication = $this->Mentors->get($id, ['contain' => ['Users','Sectors','StartupSectors','ApplicationStatus']]);

        $this->set(compact('startupApplication'));
    }

    public function downloadMentorApplication($id = '')
    {
        $id = base64_decode($id);
        $this->loadModel('Mentors');
        $application = $this->Mentors->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'index']);
        }
        $startupApplication = $this->Mentors->get($id, ['contain' => ['Users','Sectors','StartupSectors','ApplicationStatus']]);

        $title          = $startupApplication['mentor_name'];
        $view           = new View($this->request, $this->response, null);
        $view->viewPath = 'Mentors';
        $view->set(compact('startupApplication'));
        $view->layout = 'ajax';
        $html         = $view->render('download_application');
        echo $this->downloadCertificate($html, $title);
    }

    public function downloadCertificate($content, $title)
    {
        $this->autoRender = false;
        $pdf              = new PDF();
        $pdf->AddPage('P');
        $pdf->SetFillColor(53, 127, 63);
        $pdf->SetFont('times', 'R', 11);
        $pdf->SetFont('courier', 'R', 11);
        $pdf->SetFont('Helvetica', 'R', 11);
        $pdf->SetTextColor(0, 0, 0);
        $pdf->SetCompression(true);
        $title = str_replace('/', '-', $title);
        $pdf->SetTitle($title);
        $pdf->writeHTML($content, false, false, false, false, 'L');
        $tempfile = $title . '_' . date("d-m-Y") . '.pdf';
        $pdf->Output($tempfile, 'I');
        exit();
    }

    public function generateReferenceNo($id, $form_of_entity)
    {
        $this->loadModel('Mentors');
        $max_id = $this->Mentors->find();
        $max_id->select(['max_id' => $max_id->func()->max('id')]);
        $max_id->where(['year(created)' => date('Y')]);
        $max_id = $max_id->first();

        if (empty($max_id->max_id)) {
            $id = 1;
        } else {
            $id = ($max_id->max_id);
        }
        $string = '';

        if ($form_of_entity == 1) {
            $string .= "G";
        } else if ($form_of_entity == 2) {
            $string .= "P";
        }
        $string .= date('dmY');
        $string .= str_pad(($id), 5, 0, STR_PAD_LEFT);
        return $string;
    }

    public function TrackApplication()
    {
        $this->loadModel('Mentors');
        if($this->isDevice) {
            $this->request->allowMethod(['post']);
            $_status = false;
            $_message = '';
        }
        if ($this->request->is('post')) {
            $reference_no = trim($this->request->getData('reference_no'));
            $reference_no = $this->Sanitize->stripAll($reference_no);
            $reference_no = $this->Sanitize->clean($reference_no);
            if(!$this->isDevice) {
                $this->set('reference_no', $reference_no);
            }
            $referenceData = $this->Mentors->find()->contain(['ApplicationStatus'])->where(['reference_no' => $reference_no])->first();
            //echo "<pre>";print_r($referenceData);exit;
            if($this->isDevice) {
                $data = array();
                if(!empty($referenceData)){
                    $_status = true;
                    $message = 'Application data found';
                    
                    $data['reference_no'] = $referenceData->reference_no;
                    $data['mentor_name'] = $referenceData->mentor_name;
                    $data['application_date'] = date('Y-m-d',strtotime($referenceData->created));
                    $data['application_status'] = $referenceData->application_status->title;
                }else{
                    $message = 'Application data not found';
                }
                $this->set(compact('_status','_message','language','data'));
                $this->set('_serialize', ['_status','_message','language','data']);
            }
        }
        if(!$this->isDevice) {
            $this->set(compact('referenceData'));
        }
    }

    public function DownloadRecognitionCertificate()
    {
        $this->loadModel('Incubators');
        if ($this->request->is('post')) {
            $certificate_no = trim($this->request->getData('certificate_no'));
            $certificate_no = $this->Sanitize->stripAll($certificate_no);
            $certificate_no = $this->Sanitize->clean($certificate_no);
            $incubator_name = trim($this->request->getData('incubator_name'));
            $incubator_name = $this->Sanitize->stripAll($incubator_name);
            $incubator_name = $this->Sanitize->clean($incubator_name);
            $this->set('certificate_no', $certificate_no);
            $this->set('incubator_name', $incubator_name);

            if (empty($incubator_name)) {
                $certificateData = $this->Incubators->find()->where(['incubator_certificate_no' => $certificate_no])->first();
            } else {
                $certificateData = $this->Incubators->find()->where(['name_of_entity' => $incubator_name])->first();
            }
        }
        $this->set(compact('certificateData'));
    }

    public function observations()
    {
        $this->loadModel('MentorObservations');
        $application = $this->Mentors->find()->where(['user_id' => $this->Auth->user('id')])->first();
        if (empty($application)) {
            $this->Flash->error(__('You have not applied any Application.'));
            return $this->redirect(['controller' => 'Dashboard', 'action' => 'index']);
        }
        $oldObservations = $this->MentorObservations->find()->where(['mentor_application_id' => $application->id])->enableHydration(false)->toArray();
        $this->set(compact('oldObservations', 'application'));
    }

    public function addObservation($id)
    {
        $id = base64_decode($id);
        $this->loadModel('MentorObservations');
        $application = $this->MentorObservations->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'observations']);
        }
        $mentorObservations = $this->MentorObservations->get($id);
        if ($this->request->is(['post', 'put'])) {
            $data                              = $this->request->getData();
            $mentorObservations             = $this->MentorObservations->patchEntity($mentorObservations, $data);
            $mentorObservations->reply_date = date('Y-m-d H:i:s');
            if ($this->MentorObservations->save($mentorObservations)) {
                $this->Flash->success(__('You have successfully replied.'));
                return $this->redirect(['action' => 'observations']);
            }
            $this->Flash->error(__('Some error occurred. Please, try again.'));
        }
        $this->set(compact('mentorObservations'));
    }

    public function recurringExpensEligibility($value = '')
    {
        # code...
    }

    public function apiRecurringExpenses()
    {
        if ($this->isDevice == false) {
            return $this->redirect(['controller' => 'Dashboard', 'action' => 'index']);
        }
        $this->loadModel('IncubatorRecurringExpenses');
        $this->request->allowMethod(['get', 'post']);
        $_status  = false;
        $_message = '';

        $_IncubatorBaseUrl = Router::Url('/files/incubator', true);
        $_BaseUrl          = Router::Url('/files/recurring-expenses', true);

        $_incubator         = new \stdClass();
        $_recurringExpenses = new \stdClass();

        if ($this->request->is(['post'])) {
            $applicationId = $this->request->getData('applicationId');
            $userId        = $this->request->getData('userId');
        } else {
            $applicationId = $this->request->getQuery('applicationId');
            $userId        = $this->request->getQuery('userId');
        }
        if (!empty($userId)) {
            $where     = [];
            $where[]   = ['user_id' => $userId];
            $incubator = $this->Incubators->find('all', ['contain' => ['IncubatorDirectors']])->where($where)->first();
            if (!empty($incubator) && empty($incubator->incubator_certificate_no)) {
                $_message = __('Your application is being considered but has not yet been approved.');
            } else if (empty($incubator)) {
                $_message = __('You have not applied for any Incubator.');
            } else {
                $recurringExpenses = (!empty($applicationId)) ? $this->IncubatorRecurringExpenses->get($applicationId)->first() : $this->IncubatorRecurringExpenses->newEntity();
            }
        } else {
            $_message = __('UserID is required');
        }
        if (!empty($incubator)) {
            $_incubator = $incubator;
        }
        if (!empty($recurringExpenses) && !$recurringExpenses->isNew()) {
            $_recurringExpenses = $recurringExpenses;
        }
        if (empty($_message) && $this->request->is(['post'])) {
            $postData = $this->request->getData();

            $postData['incubator_application_id'] = $incubator->id;
            $postData['application_status_id']    = 1;
            $postData['application_stage_id']     = 1;
            if ($recurringExpenses->isNew()) {
                $postData['created'] = date('Y-m-d H:i:s');
            }
            /** Document **/
            $recurringExpensesFiles = ['registration_certificate', 'applicant_certificate', 'association_memorandum', 'authorization_letter', 'undertaking_letter', 'proof_incubator_operation', 'operational_centre_proof', 'cancelled_cheque', 'claimed_expenses_bill', 'payment_proof', 'ca_certificate', 'certificate_from_hod', 'performance_report'];
            foreach ($recurringExpensesFiles as $field) {
                if (isset($postData[$field]) && $postData[$field]['name'] != '') {
                    $uploaded = $this->uploadFiles('recurring-expenses', $postData[$field]);
                    if (isset($uploaded['filename'])) {
                        $postData[$field] = $uploaded['filename'];
                    } else {
                        unset($postData[$field]);
                    }
                } else if (isset($postData[$field])) {
                    unset($postData[$field]);
                }
            }
            //Save
            $recurringExpensesSave = $this->IncubatorRecurringExpenses->patchEntity($recurringExpenses, $postData);
            if ($this->IncubatorRecurringExpenses->save($recurringExpensesSave)) {
                $applicationId = $recurringExpensesSave->id;
                $referenceNo   = $recurringExpensesSave->reference_number;
                if (empty($referenceNo)) {
                    $referenceNo = $this->recurringExpensesReferenceNo($applicationId);
                    $this->IncubatorRecurringExpenses->query()
                        ->update()
                        ->set(['reference_number' => $referenceNo])
                        ->where(['id' => $applicationId])
                        ->execute();
                    $recurringExpensesSave->reference_number = $referenceNo;
                }
                $_message = __('You have successfully applied.');
                // $_message = __("Thanks for your application, Please note Reference number ( {0} ) for further communication. ", [$referenceNo]);
                $_status = true;

                $_recurringExpenses = $recurringExpensesSave;
            } else {
                $_message = __("Your application could not be saved. Please, try again.");
            }
        } else if (empty($_message)) {
            $_status = true;
        }

        $this->set([
            '_status'            => $_status,
            '_incubator'         => $_incubator,
            '_recurringExpenses' => $_recurringExpenses,
            '_IncubatorBaseUrl'  => $_IncubatorBaseUrl,
            '_BaseUrl'           => $_BaseUrl,
            '_message'           => $_message,
            '_serialize'         => [
                '_status', '_incubator', '_recurringExpenses', '_IncubatorBaseUrl', '_BaseUrl', '_message',
            ],
        ]);
    }

    public function recurringExpenses($id = '')
    {
        $this->loadModel('Incubators');
        $application = $this->Incubators->find()->where(['user_id' => $this->Auth->user('id')])->first();
        if (!empty($application)) {
            if (empty($application['incubator_certificate_no'])) {
                $this->Flash->error(__('Your application is being considered but has not yet been approved.'));
                $this->redirect(['controller' => 'Dashboard']);
            }
            $this->loadModel('IncubatorRecurringExpenses');
            $id            = base64_decode($id);
            $incentiveData = $this->IncubatorRecurringExpenses->findById($id)->first();
            if (empty($incentiveData)) {
                $recurringExpenses = $this->IncubatorRecurringExpenses->newEntity();
            } else {
                $recurringExpenses = $this->IncubatorRecurringExpenses->get($id);
            }
            if ($this->request->is(['post', 'put'])) {
                $data              = $this->request->getData();
                $data              = $this->Sanitize->clean($data);
                $recurringExpenses = $this->IncubatorRecurringExpenses->patchEntity($recurringExpenses, $data);
                if ($data['registration_certificate']['name'] != '') {
                    $certificate                                 = $this->uploadFiles('recurring-expenses', $data['registration_certificate']);
                    $recurringExpenses->registration_certificate = $certificate['filename'];
                } else {
                    $recurringExpenses->registration_certificate = $data['old_registration_certificate'];
                }
                if ($data['applicant_certificate']['name'] != '') {
                    $certificate                              = $this->uploadFiles('recurring-expenses', $data['applicant_certificate']);
                    $recurringExpenses->applicant_certificate = $certificate['filename'];
                } else {
                    $recurringExpenses->applicant_certificate = $data['old_applicant_certificate'];
                }
                if ($data['association_memorandum']['name'] != '') {
                    $certificate                               = $this->uploadFiles('recurring-expenses', $data['association_memorandum']);
                    $recurringExpenses->association_memorandum = $certificate['filename'];
                } else {
                    $recurringExpenses->association_memorandum = $data['old_association_memorandum'];
                }
                if ($data['authorization_letter']['name'] != '') {
                    $certificate                             = $this->uploadFiles('recurring-expenses', $data['authorization_letter']);
                    $recurringExpenses->authorization_letter = $certificate['filename'];
                } else {
                    $recurringExpenses->authorization_letter = $data['old_authorization_letter'];
                }
                if ($data['undertaking_letter']['name'] != '') {
                    $certificate                           = $this->uploadFiles('recurring-expenses', $data['undertaking_letter']);
                    $recurringExpenses->undertaking_letter = $certificate['filename'];
                } else {
                    $recurringExpenses->undertaking_letter = $data['old_undertaking_letter'];
                }
                if ($data['proof_incubator_operation']['name'] != '') {
                    $certificate                                  = $this->uploadFiles('recurring-expenses', $data['proof_incubator_operation']);
                    $recurringExpenses->proof_incubator_operation = $certificate['filename'];
                } else {
                    $recurringExpenses->proof_incubator_operation = $data['old_proof_incubator_operation'];
                }
                if ($data['operational_centre_proof']['name'] != '') {
                    $certificate                                 = $this->uploadFiles('recurring-expenses', $data['operational_centre_proof']);
                    $recurringExpenses->operational_centre_proof = $certificate['filename'];
                } else {
                    $recurringExpenses->operational_centre_proof = $data['old_operational_centre_proof'];
                }
                if ($data['cancelled_cheque']['name'] != '') {
                    $certificate                         = $this->uploadFiles('recurring-expenses', $data['cancelled_cheque']);
                    $recurringExpenses->cancelled_cheque = $certificate['filename'];
                } else {
                    $recurringExpenses->cancelled_cheque = $data['old_cancelled_cheque'];
                }
                if ($data['claimed_expenses_bill']['name'] != '') {
                    $certificate                              = $this->uploadFiles('recurring-expenses', $data['claimed_expenses_bill']);
                    $recurringExpenses->claimed_expenses_bill = $certificate['filename'];
                } else {
                    $recurringExpenses->claimed_expenses_bill = $data['old_claimed_expenses_bill'];
                }
                if ($data['payment_proof']['name'] != '') {
                    $certificate                      = $this->uploadFiles('recurring-expenses', $data['payment_proof']);
                    $recurringExpenses->payment_proof = $certificate['filename'];
                } else {
                    $recurringExpenses->payment_proof = $data['old_payment_proof'];
                }
                if ($data['ca_certificate']['name'] != '') {
                    $certificate                       = $this->uploadFiles('recurring-expenses', $data['ca_certificate']);
                    $recurringExpenses->ca_certificate = $certificate['filename'];
                } else {
                    $recurringExpenses->ca_certificate = $data['old_ca_certificate'];
                }
                if ($data['certificate_from_hod']['name'] != '') {
                    $certificate                             = $this->uploadFiles('recurring-expenses', $data['certificate_from_hod']);
                    $recurringExpenses->certificate_from_hod = $certificate['filename'];
                } else {
                    $recurringExpenses->certificate_from_hod = $data['old_certificate_from_hod'];
                }
                if ($data['performance_report']['name'] != '') {
                    $certificate                           = $this->uploadFiles('recurring-expenses', $data['performance_report']);
                    $recurringExpenses->performance_report = $certificate['filename'];
                } else {
                    $recurringExpenses->performance_report = $data['old_performance_report'];
                }
                $recurringExpenses->incubator_application_id = $application['id'];
                $recurringExpenses->created                  = date('Y-m-d H:i:s');
                if ($this->IncubatorRecurringExpenses->save($recurringExpenses)) {
                    $recurringExpenses_id = $recurringExpenses->id;
                    $this->Flash->success(__('Successfully submitted.'));
                    return $this->redirect(['action' => 'recurringExpensesPreview', base64_encode($recurringExpenses_id)]);
                }
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        } else {
            $this->Flash->error(__('You have not applied for any Incubator.'));
            $this->redirect(['controller' => 'Dashboard']);
        }
        $this->loadModel('Designations');
        $designations = $this->Designations->find('list')->where(['status' => 1])->order(['name ASC']);
        $this->set(compact('recurringExpenses', 'application', 'designations'));
    }

    public function recurringExpensesPreview($id = '')
    {
        $this->loadModel('IncubatorRecurringExpenses');
        $id            = base64_decode($id);
        $incentiveData = $this->IncubatorRecurringExpenses->findById($id)->first();
        if (empty($incentiveData)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'recurringExpenses']);
        }
        $recurringExpenses = $this->IncubatorRecurringExpenses->get($id, ['contain' => ['Designations']]);

        if ($this->request->is(['post', 'put'])) {
            $data                                     = $this->request->getData();
            $recurringExpenses->application_status_id = 1;
            $recurringExpenses->application_stage_id  = 1;
            $recurringExpenses->created               = date('Y-m-d H:i:s');
            if ($this->IncubatorRecurringExpenses->save($recurringExpenses)) {
                $recurringExpenses_id = $recurringExpenses->id;
                $reference_no         = $this->recurringExpensesReferenceNo($recurringExpenses_id);
                $query                = $this->IncubatorRecurringExpenses->query();
                $query->update()
                    ->set(['reference_number' => $reference_no])
                    ->where(['id' => $recurringExpenses_id])
                    ->execute();
                $this->Flash->success(__('You have successfully applied.'));
                return $this->redirect(['controller' => 'Dashboard', 'action' => 'index']);
            }
            $this->Flash->error(__('Some error occurred. Please, try again.'));
        }
        $this->set(compact('recurringExpenses'));
    }

    public function recurringExpensesReferenceNo($id)
    {
        $string = '';
        $string .= 'RE/' . date('dmY') . '/';
        $string .= str_pad(($id), 5, 0, STR_PAD_LEFT);
        return $string;
    }

    public function compititionAssistanceEligibility($value = '')
    {
        # code...
    }

    public function apiCompititionAssistance()
    {
        if ($this->isDevice == false) {
            return $this->redirect(['controller' => 'Dashboard', 'action' => 'index']);
        }
        $this->loadModel('IncubatorCompititionAssistances');
        $this->request->allowMethod(['get', 'post']);
        $_status  = false;
        $_message = '';

        $_IncubatorBaseUrl = Router::Url('/files/incubator', true);
        $_BaseUrl          = Router::Url('/files/compitition-assistance', true);

        $_incubator             = new \stdClass();
        $_compititionAssistance = new \stdClass();

        if ($this->request->is(['post'])) {
            $applicationId = $this->request->getData('applicationId');
            $userId        = $this->request->getData('userId');
        } else {
            $applicationId = $this->request->getQuery('applicationId');
            $userId        = $this->request->getQuery('userId');
        }
        if (!empty($userId)) {
            $where     = [];
            $where[]   = ['user_id' => $userId];
            $incubator = $this->Incubators->find('all', ['contain' => ['IncubatorDirectors']])->where($where)->first();
            if (!empty($incubator) && empty($incubator->incubator_certificate_no)) {
                $_message = __('Your application is being considered but has not yet been approved.');
            } else if (empty($incubator)) {
                $_message = __('You have not applied for any Incubator.');
            } else {
                $compititionAssistance = (!empty($applicationId)) ? $this->IncubatorCompititionAssistances->get($applicationId)->first() : $this->IncubatorCompititionAssistances->newEntity();
            }
        } else {
            $_message = __('UserID is required');
        }
        if (!empty($incubator)) {
            $_incubator = $incubator;
        }
        if (!empty($compititionAssistance) && !$compititionAssistance->isNew()) {
            $_compititionAssistance = $compititionAssistance;
        }
        if (empty($_message) && $this->request->is(['post'])) {
            $postData = $this->request->getData();

            $postData['incubator_application_id'] = $incubator->id;
            $postData['application_status_id']    = 1;
            $postData['application_stage_id']     = 1;
            if ($compititionAssistance->isNew()) {
                $postData['created'] = date('Y-m-d H:i:s');
            }
            /** Document **/
            $compititionAssistanceFiles = ['registration_certificate', 'applicant_certificate', 'association_memorandum', 'authorization_letter', 'undertaking_letter', 'ca_certificate', 'certificate_from_hod', 'proof_incubator_operation', 'cancelled_cheque'];
            foreach ($compititionAssistanceFiles as $field) {
                if (isset($postData[$field]) && $postData[$field]['name'] != '') {
                    $uploaded = $this->uploadFiles('compitition-assistance', $postData[$field]);
                    if (isset($uploaded['filename'])) {
                        $postData[$field] = $uploaded['filename'];
                    } else {
                        unset($postData[$field]);
                    }
                } else if (isset($postData[$field])) {
                    unset($postData[$field]);
                }
            }
            //Save
            $compititionAssistanceSave = $this->IncubatorCompititionAssistances->patchEntity($compititionAssistance, $postData);
            if ($this->IncubatorCompititionAssistances->save($compititionAssistanceSave)) {
                $applicationId = $compititionAssistanceSave->id;
                $referenceNo   = $compititionAssistanceSave->reference_number;
                if (empty($referenceNo)) {
                    $referenceNo = $this->compititionAssistanceReferenceNo($applicationId);
                    $this->IncubatorCompititionAssistances->query()
                        ->update()
                        ->set(['reference_number' => $referenceNo])
                        ->where(['id' => $applicationId])
                        ->execute();
                    $compititionAssistanceSave->reference_number = $referenceNo;
                }
                $_message = __('You have successfully applied.');
                // $_message = __("Thanks for your application, Please note Reference number ( {0} ) for further communication. ", [$referenceNo]);
                $_status = true;

                $_compititionAssistance = $compititionAssistanceSave;
            } else {
                $_message = __("Your application could not be saved. Please, try again.");
            }
        } else if (empty($_message)) {
            $_status = true;
        }
        $this->set([
            '_status'                => $_status,
            '_incubator'             => $_incubator,
            '_compititionAssistance' => $_compititionAssistance,
            '_IncubatorBaseUrl'  => $_IncubatorBaseUrl,
            '_BaseUrl'           => $_BaseUrl,
            '_message'               => $_message,
            '_serialize'             => [
                '_status', '_incubator', '_compititionAssistance', '_IncubatorBaseUrl', '_BaseUrl', '_message',
            ],
        ]);
    }

    public function compititionAssistance($id = '')
    {
        $this->loadModel('Incubators');
        $application = $this->Incubators->find()->where(['user_id' => $this->Auth->user('id')])->first();
        if (!empty($application)) {
            if (empty($application['incubator_certificate_no'])) {
                $this->Flash->error(__('Your application is being considered but has not yet been approved.'));
                $this->redirect(['controller' => 'Dashboard']);
            }
            $this->loadModel('IncubatorCompititionAssistances');
            $id            = base64_decode($id);
            $incentiveData = $this->IncubatorCompititionAssistances->findById($id)->first();
            if (empty($incentiveData)) {
                $compititionAssistance = $this->IncubatorCompititionAssistances->newEntity();
            } else {
                $compititionAssistance = $this->IncubatorCompititionAssistances->get($id);
            }
            if ($this->request->is(['post', 'put'])) {
                $data                  = $this->request->getData();
                $data                  = $this->Sanitize->clean($data);
                $compititionAssistance = $this->IncubatorCompititionAssistances->patchEntity($compititionAssistance, $data);
                if ($data['registration_certificate']['name'] != '') {
                    $certificate                                     = $this->uploadFiles('compitition-assistance', $data['registration_certificate']);
                    $compititionAssistance->registration_certificate = $certificate['filename'];
                } else {
                    $compititionAssistance->registration_certificate = $data['old_registration_certificate'];
                }
                if ($data['applicant_certificate']['name'] != '') {
                    $certificate                                  = $this->uploadFiles('compitition-assistance', $data['applicant_certificate']);
                    $compititionAssistance->applicant_certificate = $certificate['filename'];
                } else {
                    $compititionAssistance->applicant_certificate = $data['old_applicant_certificate'];
                }
                if ($data['association_memorandum']['name'] != '') {
                    $certificate                                   = $this->uploadFiles('compitition-assistance', $data['association_memorandum']);
                    $compititionAssistance->association_memorandum = $certificate['filename'];
                } else {
                    $compititionAssistance->association_memorandum = $data['old_association_memorandum'];
                }
                if ($data['authorization_letter']['name'] != '') {
                    $certificate                                 = $this->uploadFiles('compitition-assistance', $data['authorization_letter']);
                    $compititionAssistance->authorization_letter = $certificate['filename'];
                } else {
                    $compititionAssistance->authorization_letter = $data['old_authorization_letter'];
                }
                if ($data['undertaking_letter']['name'] != '') {
                    $certificate                               = $this->uploadFiles('compitition-assistance', $data['undertaking_letter']);
                    $compititionAssistance->undertaking_letter = $certificate['filename'];
                } else {
                    $compititionAssistance->undertaking_letter = $data['old_undertaking_letter'];
                }
                if ($data['ca_certificate']['name'] != '') {
                    $certificate                           = $this->uploadFiles('compitition-assistance', $data['ca_certificate']);
                    $compititionAssistance->ca_certificate = $certificate['filename'];
                } else {
                    $compititionAssistance->ca_certificate = $data['old_ca_certificate'];
                }
                if ($data['certificate_from_hod']['name'] != '') {
                    $certificate                                 = $this->uploadFiles('compitition-assistance', $data['certificate_from_hod']);
                    $compititionAssistance->certificate_from_hod = $certificate['filename'];
                } else {
                    $compititionAssistance->certificate_from_hod = $data['old_certificate_from_hod'];
                }
                if ($data['proof_incubator_operation']['name'] != '') {
                    $certificate                                      = $this->uploadFiles('compitition-assistance', $data['proof_incubator_operation']);
                    $compititionAssistance->proof_incubator_operation = $certificate['filename'];
                } else {
                    $compititionAssistance->proof_incubator_operation = $data['old_proof_incubator_operation'];
                }
                if ($data['cancelled_cheque']['name'] != '') {
                    $certificate                             = $this->uploadFiles('compitition-assistance', $data['cancelled_cheque']);
                    $compititionAssistance->cancelled_cheque = $certificate['filename'];
                } else {
                    $compititionAssistance->cancelled_cheque = $data['old_cancelled_cheque'];
                }

                $compititionAssistance->incubator_application_id = $application['id'];
                $compititionAssistance->created                  = date('Y-m-d H:i:s');
                if ($this->IncubatorCompititionAssistances->save($compititionAssistance)) {
                    $compititionAssistance_id = $compititionAssistance->id;
                    $this->Flash->success(__('Successfully submitted.'));
                    return $this->redirect(['action' => 'compititionAssistancePreview', base64_encode($compititionAssistance_id)]);
                }
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        } else {
            $this->Flash->error(__('You have not applied for any Incubator.'));
            $this->redirect(['controller' => 'Dashboard']);
        }
        $this->loadModel('Designations');
        $designations = $this->Designations->find('list')->where(['status' => 1])->order(['name ASC']);
        $this->set(compact('compititionAssistance', 'application', 'designations'));
    }

    public function compititionAssistancePreview($id = '')
    {
        $this->loadModel('IncubatorCompititionAssistances');
        $id            = base64_decode($id);
        $incentiveData = $this->IncubatorCompititionAssistances->findById($id)->first();
        if (empty($incentiveData)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'compititionAssistance']);
        }
        $compititionAssistance = $this->IncubatorCompititionAssistances->get($id, ['contain' => ['Designations']]);

        if ($this->request->is(['post', 'put'])) {
            $data                                         = $this->request->getData();
            $compititionAssistance->application_status_id = 1;
            $compititionAssistance->application_stage_id  = 1;
            $compititionAssistance->created               = date('Y-m-d H:i:s');
            if ($this->IncubatorCompititionAssistances->save($compititionAssistance)) {
                $compititionAssistance_id = $compititionAssistance->id;
                $reference_no             = $this->compititionAssistanceReferenceNo($compititionAssistance_id);
                $query                    = $this->IncubatorCompititionAssistances->query();
                $query->update()
                    ->set(['reference_number' => $reference_no])
                    ->where(['id' => $compititionAssistance_id])
                    ->execute();
                $this->Flash->success(__('You have successfully applied.'));
                return $this->redirect(['controller' => 'Dashboard', 'action' => 'index']);
            }
            $this->Flash->error(__('Some error occurred. Please, try again.'));
        }
        $this->set(compact('compititionAssistance'));
    }

    public function compititionAssistanceReferenceNo($id)
    {
        $string = '';
        $string .= 'CA/' . date('dmY') . '/';
        $string .= str_pad(($id), 5, 0, STR_PAD_LEFT);
        return $string;
    }

    public function apiFairExhibition()
    {
        if ($this->isDevice == false) {
            return $this->redirect(['controller' => 'Dashboard', 'action' => 'index']);
        }
        $this->loadModel('IncubatorFairExhibitions');
        $this->request->allowMethod(['get', 'post']);
        $_status  = false;
        $_message = '';

        $_IncubatorBaseUrl = Router::Url('/files/incubator', true);
        $_BaseUrl          = Router::Url('/files/fair-exhibition', true);
 
        $_incubator      = new \stdClass();
        $_fairExhibition = new \stdClass();

        if ($this->request->is(['post'])) {
            $applicationId = $this->request->getData('applicationId');
            $userId        = $this->request->getData('userId');
        } else {
            $applicationId = $this->request->getQuery('applicationId');
            $userId        = $this->request->getQuery('userId');
        }
        if (!empty($userId)) {
            $where     = [];
            $where[]   = ['user_id' => $userId];
            $incubator = $this->Incubators->find('all', ['contain' => ['IncubatorDirectors']])->where($where)->first();
            if (!empty($incubator) && empty($incubator->incubator_certificate_no)) {
                $_message = __('Your application is being considered but has not yet been approved.');
            } else if (empty($incubator)) {
                $_message = __('You have not applied for any Incubator.');
            } else {
                $fairExhibition = (!empty($applicationId)) ? $this->IncubatorFairExhibitions->get($applicationId)->first() : $this->IncubatorFairExhibitions->newEntity();
            }
        } else {
            $_message = __('UserID is required');
        }
        if (!empty($incubator)) {
            $_incubator = $incubator;
        }
        if (!empty($fairExhibition) && !$fairExhibition->isNew()) {
            $_fairExhibition = $fairExhibition;
        }
        if (empty($_message) && $this->request->is(['post'])) {
            $postData = $this->request->getData();

            $postData['incubator_application_id'] = $incubator->id;
            $postData['application_status_id']    = 1;
            $postData['application_stage_id']     = 1;
            if ($fairExhibition->isNew()) {
                $postData['created'] = date('Y-m-d H:i:s');
            }
            /** Document **/
            $fairExhibitionFiles = ['approval_letter', 'applicant_certificate', 'association_memorandum', 'authorization_letter', 'undertaking_letter', 'ca_certificate', 'certificate_from_hod', 'original_bills', 'cancelled_cheque', 'payment_proof'];
            foreach ($fairExhibitionFiles as $field) {
                if (isset($postData[$field]) && $postData[$field]['name'] != '') {
                    $uploaded = $this->uploadFiles('fair-exhibition', $postData[$field]);
                    if (isset($uploaded['filename'])) {
                        $postData[$field] = $uploaded['filename'];
                    } else {
                        unset($postData[$field]);
                    }
                } else if (isset($postData[$field])) {
                    unset($postData[$field]);
                }
            }
            //Save
            $fairExhibitionSave = $this->IncubatorFairExhibitions->patchEntity($fairExhibition, $postData);
            if ($this->IncubatorFairExhibitions->save($fairExhibitionSave)) {
                $applicationId = $fairExhibitionSave->id;
                $referenceNo   = $fairExhibitionSave->reference_number;
                if (empty($referenceNo)) {
                    $referenceNo = $this->fairExhibitionReferenceNo($applicationId);
                    $this->IncubatorFairExhibitions->query()
                        ->update()
                        ->set(['reference_number' => $referenceNo])
                        ->where(['id' => $applicationId])
                        ->execute();
                    $fairExhibitionSave->reference_number = $referenceNo;
                }
                $_message = __('You have successfully applied.');
                // $_message = __("Thanks for your application, Please note Reference number ( {0} ) for further communication. ", [$referenceNo]);
                $_status = true;

                $_fairExhibition = $fairExhibitionSave;
            } else {
                $_message = __("Your application could not be saved. Please, try again.");
            }
        } else if (empty($_message)) {
            $_status = true;
        }
        $this->set([
            '_status'         => $_status,
            '_incubator'      => $_incubator,
            '_fairExhibition' => $_fairExhibition,
            '_IncubatorBaseUrl' => $_IncubatorBaseUrl,
            '_BaseUrl'          => $_BaseUrl,
            '_message'        => $_message,
            '_serialize'      => [
                '_status', '_incubator', '_fairExhibition', '_IncubatorBaseUrl', '_BaseUrl', '_message',
            ],
        ]);
    }

    public function fairExhibition($id = '')
    {
        $this->loadModel('Incubators');
        $application = $this->Incubators->find()->where(['user_id' => $this->Auth->user('id')])->first();
        if (!empty($application)) {
            if (empty($application['incubator_certificate_no'])) {
                $this->Flash->error(__('Your application is being considered but has not yet been approved.'));
                $this->redirect(['controller' => 'Dashboard']);
            }
            $this->loadModel('IncubatorFairExhibitions');
            $id            = base64_decode($id);
            $incentiveData = $this->IncubatorFairExhibitions->findById($id)->first();
            if (empty($incentiveData)) {
                $fairExhibition = $this->IncubatorFairExhibitions->newEntity();
            } else {
                $fairExhibition = $this->IncubatorFairExhibitions->get($id);
            }
            if ($this->request->is(['post', 'put'])) {
                $data           = $this->request->getData();
                $data           = $this->Sanitize->clean($data);
                $fairExhibition = $this->IncubatorFairExhibitions->patchEntity($fairExhibition, $data);
                if ($data['approval_letter']['name'] != '') {
                    $certificate                     = $this->uploadFiles('fair-exhibition', $data['approval_letter']);
                    $fairExhibition->approval_letter = $certificate['filename'];
                } else {
                    $fairExhibition->approval_letter = $data['old_approval_letter'];
                }
                if ($data['applicant_certificate']['name'] != '') {
                    $certificate                           = $this->uploadFiles('fair-exhibition', $data['applicant_certificate']);
                    $fairExhibition->applicant_certificate = $certificate['filename'];
                } else {
                    $fairExhibition->applicant_certificate = $data['old_applicant_certificate'];
                }
                if ($data['association_memorandum']['name'] != '') {
                    $certificate                            = $this->uploadFiles('fair-exhibition', $data['association_memorandum']);
                    $fairExhibition->association_memorandum = $certificate['filename'];
                } else {
                    $fairExhibition->association_memorandum = $data['old_association_memorandum'];
                }
                if ($data['authorization_letter']['name'] != '') {
                    $certificate                          = $this->uploadFiles('fair-exhibition', $data['authorization_letter']);
                    $fairExhibition->authorization_letter = $certificate['filename'];
                } else {
                    $fairExhibition->authorization_letter = $data['old_authorization_letter'];
                }
                if ($data['undertaking_letter']['name'] != '') {
                    $certificate                        = $this->uploadFiles('fair-exhibition', $data['undertaking_letter']);
                    $fairExhibition->undertaking_letter = $certificate['filename'];
                } else {
                    $fairExhibition->undertaking_letter = $data['old_undertaking_letter'];
                }
                if ($data['ca_certificate']['name'] != '') {
                    $certificate                    = $this->uploadFiles('fair-exhibition', $data['ca_certificate']);
                    $fairExhibition->ca_certificate = $certificate['filename'];
                } else {
                    $fairExhibition->ca_certificate = $data['old_ca_certificate'];
                }
                if ($data['certificate_from_hod']['name'] != '') {
                    $certificate                          = $this->uploadFiles('fair-exhibition', $data['certificate_from_hod']);
                    $fairExhibition->certificate_from_hod = $certificate['filename'];
                } else {
                    $fairExhibition->certificate_from_hod = $data['old_certificate_from_hod'];
                }
                if ($data['original_bills']['name'] != '') {
                    $certificate                    = $this->uploadFiles('fair-exhibition', $data['original_bills']);
                    $fairExhibition->original_bills = $certificate['filename'];
                } else {
                    $fairExhibition->original_bills = $data['old_original_bills'];
                }
                if ($data['cancelled_cheque']['name'] != '') {
                    $certificate                      = $this->uploadFiles('fair-exhibition', $data['cancelled_cheque']);
                    $fairExhibition->cancelled_cheque = $certificate['filename'];
                } else {
                    $fairExhibition->cancelled_cheque = $data['old_cancelled_cheque'];
                }
                if ($data['payment_proof']['name'] != '') {
                    $certificate                   = $this->uploadFiles('fair-exhibition', $data['payment_proof']);
                    $fairExhibition->payment_proof = $certificate['filename'];
                } else {
                    $fairExhibition->payment_proof = $data['old_payment_proof'];
                }

                $fairExhibition->incubator_application_id = $application['id'];
                $fairExhibition->created                  = date('Y-m-d H:i:s');
                if ($this->IncubatorFairExhibitions->save($fairExhibition)) {
                    $fairExhibition_id = $fairExhibition->id;
                    $this->Flash->success(__('Successfully Saved.'));
                    return $this->redirect(['action' => 'fairExhibitionPreview', base64_encode($fairExhibition_id)]);
                }
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        } else {
            $this->Flash->error(__('You have not applied for any Incubator.'));
            $this->redirect(['controller' => 'Dashboard']);
        }
        $this->loadModel('Designations');
        $designations = $this->Designations->find('list')->where(['status' => 1])->order(['name ASC']);
        $this->set(compact('fairExhibition', 'application', 'designations'));
    }

    public function fairExhibitionPreview($id = '')
    {
        $this->loadModel('IncubatorFairExhibitions');
        $id            = base64_decode($id);
        $incentiveData = $this->IncubatorFairExhibitions->findById($id)->first();
        if (empty($incentiveData)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'fairExhibition']);
        }
        $fairExhibition = $this->IncubatorFairExhibitions->get($id);

        if ($this->request->is(['post', 'put'])) {
            $data                                  = $this->request->getData();
            $data                                  = $this->Sanitize->clean($data);
            $fairExhibition->application_status_id = 1;
            $fairExhibition->application_stage_id  = 1;
            $fairExhibition->created               = date('Y-m-d H:i:s');
            if ($this->IncubatorFairExhibitions->save($fairExhibition)) {
                $fairExhibition_id = $fairExhibition->id;
                $reference_no      = $this->fairExhibitionReferenceNo($fairExhibition_id);
                $query             = $this->IncubatorFairExhibitions->query();
                $query->update()
                    ->set(['reference_number' => $reference_no])
                    ->where(['id' => $fairExhibition_id])
                    ->execute();
                $this->Flash->success(__('You have successfully applied.'));
                return $this->redirect(['controller' => 'Dashboard', 'action' => 'index']);
            }
            $this->Flash->error(__('Some error occurred. Please, try again.'));
        }
        $this->set(compact('fairExhibition'));
    }

    public function fairExhibitionReferenceNo($id)
    {
        $string = '';
        $string .= 'FE/' . date('dmY') . '/';
        $string .= str_pad(($id), 5, 0, STR_PAD_LEFT);
        return $string;
    }

    public function mentorTrainingEligibility()
    {
        # code...
    }

    public function apiMentorTrainings()
    {
        if ($this->isDevice == false) {
            return $this->redirect(['controller' => 'Dashboard', 'action' => 'index']);
        }
        $this->loadModel('IncubatorMentorTrainings');
        $this->request->allowMethod(['get', 'post']);
        $_status  = false;
        $_message = '';

        $_IncubatorBaseUrl = Router::Url('/files/incubator', true);
        $_BaseUrl          = Router::Url('/files/mentor-training', true);

        $_incubator      = new \stdClass();
        $_mentorTraining = new \stdClass();

        if ($this->request->is(['post'])) {
            $applicationId = $this->request->getData('applicationId');
            $userId        = $this->request->getData('userId');
        } else {
            $applicationId = $this->request->getQuery('applicationId');
            $userId        = $this->request->getQuery('userId');
        }
        if (!empty($userId)) {
            $where     = [];
            $where[]   = ['user_id' => $userId];
            $incubator = $this->Incubators->find('all', ['contain' => ['IncubatorDirectors']])->where($where)->first();
            if (!empty($incubator) && empty($incubator->incubator_certificate_no)) {
                $_message = __('Your application is being considered but has not yet been approved.');
            } else if (empty($incubator)) {
                $_message = __('You have not applied for any Incubator.');
            } else {
                $mentorTraining = (!empty($applicationId)) ? $this->IncubatorMentorTrainings->get($applicationId)->first() : $this->IncubatorMentorTrainings->newEntity();
            }
        } else {
            $_message = __('UserID is required');
        }
        if (!empty($incubator)) {
            $_incubator = $incubator;
        }
        if (!empty($mentorTraining) && !$mentorTraining->isNew()) {
            $_mentorTraining = $mentorTraining;
        }
        if (empty($_message) && $this->request->is(['post'])) {
            $postData = $this->request->getData();

            $postData['incubator_application_id'] = $incubator->id;
            $postData['application_status_id']    = 1;
            $postData['application_stage_id']     = 1;
            if ($mentorTraining->isNew()) {
                $postData['created'] = date('Y-m-d H:i:s');
            }
            /** Document **/
            $mentorTrainingFiles = ['registration_certificate', 'applicant_certificate', 'association_memorandum', 'authorization_letter', 'undertaking_letter', 'proof_incubator_operation', 'ca_certificate', 'certificate_from_hod', 'mentor_details', 'key_mentors_list', 'participants_attendance', 'photographs_videos', 'cancelled_cheque', 'claimed_expenses_bill', 'payment_proof', 'performance_report'];
            foreach ($mentorTrainingFiles as $field) {
                if (isset($postData[$field]) && $postData[$field]['name'] != '') {
                    $uploaded = $this->uploadFiles('mentor-training', $postData[$field]);
                    if (isset($uploaded['filename'])) {
                        $postData[$field] = $uploaded['filename'];
                    } else {
                        unset($postData[$field]);
                    }
                } else if (isset($postData[$field])) {
                    unset($postData[$field]);
                }
            }
            //Save
            $mentorTrainingSave = $this->IncubatorMentorTrainings->patchEntity($mentorTraining, $postData);
            if ($this->IncubatorMentorTrainings->save($mentorTrainingSave)) {
                $applicationId = $mentorTrainingSave->id;
                $referenceNo   = $mentorTrainingSave->reference_number;
                if (empty($referenceNo)) {
                    $referenceNo = $this->mentorTrainingReferenceNo($applicationId);
                    $this->IncubatorMentorTrainings->query()
                        ->update()
                        ->set(['reference_number' => $referenceNo])
                        ->where(['id' => $applicationId])
                        ->execute();
                    $mentorTrainingSave->reference_number = $referenceNo;
                }
                $_message = __("Thanks for your application, Please note Reference number ( {0} ) for further communication. ", [$referenceNo]);
                $_status  = true;

                $_mentorTraining = $mentorTrainingSave;
            } else {
                $_message = __("Your application could not be saved. Please, try again.");
            }
        } else if (empty($_message)) {
            $_status = true;
        }
        $this->set([
            '_status'         => $_status,
            '_incubator'      => $_incubator,
            '_mentorTraining' => $_mentorTraining,
            '_IncubatorBaseUrl' => $_IncubatorBaseUrl,
            '_BaseUrl' => $_BaseUrl,
            '_message'        => $_message,
            '_serialize'      => [
                '_status', '_incubator', '_mentorTraining', '_IncubatorBaseUrl', '_BaseUrl', '_message',
            ],
        ]);
    }

    public function mentorTrainings($id = '')
    {
        $this->loadModel('Incubators');
        $application = $this->Incubators->find()->where(['user_id' => $this->Auth->user('id')])->first();
        if (!empty($application)) {
            if (empty($application['incubator_certificate_no'])) {
                $this->Flash->error(__('Your application is being considered but has not yet been approved.'));
                $this->redirect(['controller' => 'Dashboard']);
            }
            $this->loadModel('IncubatorMentorTrainings');
            $id            = base64_decode($id);
            $incentiveData = $this->IncubatorMentorTrainings->findById($id)->first();
            if (empty($incentiveData)) {
                $mentorTraining = $this->IncubatorMentorTrainings->newEntity();
            } else {
                $mentorTraining = $this->IncubatorMentorTrainings->get($id);
            }
            if ($this->request->is(['post', 'put'])) {
                $data           = $this->request->getData();
                $data           = $this->Sanitize->clean($data);
                $mentorTraining = $this->IncubatorMentorTrainings->patchEntity($mentorTraining, $data);
                if ($data['registration_certificate']['name'] != '') {
                    $certificate                              = $this->uploadFiles('mentor-training', $data['registration_certificate']);
                    $mentorTraining->registration_certificate = $certificate['filename'];
                } else {
                    $mentorTraining->registration_certificate = $data['old_registration_certificate'];
                }
                if ($data['applicant_certificate']['name'] != '') {
                    $certificate                           = $this->uploadFiles('mentor-training', $data['applicant_certificate']);
                    $mentorTraining->applicant_certificate = $certificate['filename'];
                } else {
                    $mentorTraining->applicant_certificate = $data['old_applicant_certificate'];
                }
                if ($data['association_memorandum']['name'] != '') {
                    $certificate                            = $this->uploadFiles('mentor-training', $data['association_memorandum']);
                    $mentorTraining->association_memorandum = $certificate['filename'];
                } else {
                    $mentorTraining->association_memorandum = $data['old_association_memorandum'];
                }
                if ($data['authorization_letter']['name'] != '') {
                    $certificate                          = $this->uploadFiles('mentor-training', $data['authorization_letter']);
                    $mentorTraining->authorization_letter = $certificate['filename'];
                } else {
                    $mentorTraining->authorization_letter = $data['old_authorization_letter'];
                }
                if ($data['undertaking_letter']['name'] != '') {
                    $certificate                        = $this->uploadFiles('mentor-training', $data['undertaking_letter']);
                    $mentorTraining->undertaking_letter = $certificate['filename'];
                } else {
                    $mentorTraining->undertaking_letter = $data['old_undertaking_letter'];
                }
                if ($data['proof_incubator_operation']['name'] != '') {
                    $certificate                               = $this->uploadFiles('mentor-training', $data['proof_incubator_operation']);
                    $mentorTraining->proof_incubator_operation = $certificate['filename'];
                } else {
                    $mentorTraining->proof_incubator_operation = $data['old_proof_incubator_operation'];
                }
                if ($data['ca_certificate']['name'] != '') {
                    $certificate                    = $this->uploadFiles('mentor-training', $data['ca_certificate']);
                    $mentorTraining->ca_certificate = $certificate['filename'];
                } else {
                    $mentorTraining->ca_certificate = $data['old_ca_certificate'];
                }
                if ($data['certificate_from_hod']['name'] != '') {
                    $certificate                          = $this->uploadFiles('mentor-training', $data['certificate_from_hod']);
                    $mentorTraining->certificate_from_hod = $certificate['filename'];
                } else {
                    $mentorTraining->certificate_from_hod = $data['old_certificate_from_hod'];
                }
                if ($data['mentor_details']['name'] != '') {
                    $certificate                    = $this->uploadFiles('mentor-training', $data['mentor_details']);
                    $mentorTraining->mentor_details = $certificate['filename'];
                } else {
                    $mentorTraining->mentor_details = $data['old_mentor_details'];
                }
                if ($data['key_mentors_list']['name'] != '') {
                    $certificate                      = $this->uploadFiles('mentor-training', $data['key_mentors_list']);
                    $mentorTraining->key_mentors_list = $certificate['filename'];
                } else {
                    $mentorTraining->key_mentors_list = $data['old_key_mentors_list'];
                }
                if ($data['participants_attendance']['name'] != '') {
                    $certificate                             = $this->uploadFiles('mentor-training', $data['participants_attendance']);
                    $mentorTraining->participants_attendance = $certificate['filename'];
                } else {
                    $mentorTraining->participants_attendance = $data['old_participants_attendance'];
                }
                if ($data['photographs_videos']['name'] != '') {
                    $certificate                        = $this->uploadFiles('mentor-training', $data['photographs_videos']);
                    $mentorTraining->photographs_videos = $certificate['filename'];
                } else {
                    $mentorTraining->photographs_videos = $data['old_photographs_videos'];
                }
                if ($data['cancelled_cheque']['name'] != '') {
                    $certificate                      = $this->uploadFiles('mentor-training', $data['cancelled_cheque']);
                    $mentorTraining->cancelled_cheque = $certificate['filename'];
                } else {
                    $mentorTraining->cancelled_cheque = $data['old_cancelled_cheque'];
                }
                if ($data['claimed_expenses_bill']['name'] != '') {
                    $certificate                           = $this->uploadFiles('mentor-training', $data['claimed_expenses_bill']);
                    $mentorTraining->claimed_expenses_bill = $certificate['filename'];
                } else {
                    $mentorTraining->claimed_expenses_bill = $data['old_claimed_expenses_bill'];
                }
                if ($data['payment_proof']['name'] != '') {
                    $certificate                   = $this->uploadFiles('mentor-training', $data['payment_proof']);
                    $mentorTraining->payment_proof = $certificate['filename'];
                } else {
                    $mentorTraining->payment_proof = $data['old_payment_proof'];
                }
                if ($data['performance_report']['name'] != '') {
                    $certificate                        = $this->uploadFiles('mentor-training', $data['performance_report']);
                    $mentorTraining->performance_report = $certificate['filename'];
                } else {
                    $mentorTraining->performance_report = $data['old_performance_report'];
                }
                $mentorTraining->application_status_id    = 1;
                $mentorTraining->application_stage_id     = 1;
                $mentorTraining->incubator_application_id = $application['id'];
                $mentorTraining->created                  = date('Y-m-d H:i:s');
                if ($this->IncubatorMentorTrainings->save($mentorTraining)) {
                    $mentorTraining_id = $mentorTraining->id;
                    $this->Flash->success(__('Successfully Saved.'));
                    return $this->redirect(['action' => 'mentorTrainingPreview', base64_encode($mentorTraining_id)]);
                }
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        } else {
            $this->Flash->error(__('You have not applied for any Incubator.'));
            $this->redirect(['controller' => 'Dashboard']);
        }
        $this->loadModel('Designations');
        $designations = $this->Designations->find('list')->where(['status' => 1])->order(['name ASC']);
        $this->set(compact('mentorTraining', 'application', 'designations'));
    }

    public function mentorTrainingPreview($id = '')
    {
        $this->loadModel('IncubatorMentorTrainings');
        $id            = base64_decode($id);
        $incentiveData = $this->IncubatorMentorTrainings->findById($id)->first();
        if (empty($incentiveData)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'mentorTrainings']);
        }
        $mentorTraining = $this->IncubatorMentorTrainings->get($id);

        if ($this->request->is(['post', 'put'])) {
            $data                                  = $this->request->getData();
            $mentorTraining->application_status_id = 1;
            $mentorTraining->application_stage_id  = 1;
            $mentorTraining->created               = date('Y-m-d H:i:s');
            if ($this->IncubatorMentorTrainings->save($mentorTraining)) {
                $mentorTraining_id = $mentorTraining->id;
                $reference_no      = $this->mentorTrainingReferenceNo($mentorTraining_id);
                $query             = $this->IncubatorMentorTrainings->query();
                $query->update()
                    ->set(['reference_number' => $reference_no])
                    ->where(['id' => $mentorTraining_id])
                    ->execute();
                $this->Flash->success(__("Thanks for your application, Please note Reference number ( $reference_no ) for further communication. "));
                return $this->redirect(['controller' => 'Dashboard', 'action' => 'index']);
            }
            $this->Flash->error(__('Some error occurred. Please, try again.'));
        }
        $this->set(compact('mentorTraining'));
    }

    public function mentorTrainingReferenceNo($id)
    {
        $string = '';
        $string .= 'MT/' . date('dmY') . '/';
        $string .= str_pad(($id), 5, 0, STR_PAD_LEFT);
        return $string;
    }

    public function rentalChargeExemptionEligibility()
    {
        # code...
    }

    public function apiRentalChargeExemptions()
    {
        if ($this->isDevice == false) {
            return $this->redirect(['controller' => 'Dashboard', 'action' => 'index']);
        }
        $this->loadModel('IncubatorRentalCharges');
        $this->request->allowMethod(['get', 'post']);
        $_status  = false;
        $_message = '';

        $_IncubatorBaseUrl = Router::Url('/files/incubator', true);
        $_BaseUrl          = Router::Url('/files/rental-charge', true);

        $_incubator    = new \stdClass();
        $_rentalCharge = new \stdClass();

        if ($this->request->is(['post'])) {
            $applicationId = $this->request->getData('applicationId');
            $userId        = $this->request->getData('userId');
        } else {
            $applicationId = $this->request->getQuery('applicationId');
            $userId        = $this->request->getQuery('userId');
        }
        if (!empty($userId)) {
            $where     = [];
            $where[]   = ['user_id' => $userId];
            $incubator = $this->Incubators->find('all', ['contain' => ['IncubatorDirectors']])->where($where)->first();
            if (!empty($incubator) && empty($incubator->incubator_certificate_no)) {
                $_message = __('Your application is being considered but has not yet been approved.');
            } else if (empty($incubator)) {
                $_message = __('You have not applied for any Incubator.');
            } else {
                $rentalCharge = (!empty($applicationId)) ? $this->IncubatorRentalCharges->get($applicationId)->first() : $this->IncubatorRentalCharges->newEntity();
            }
        } else {
            $_message = __('UserID is required');
        }
        if (!empty($incubator)) {
            $_incubator = $incubator;
        }
        if (!empty($rentalCharge) && !$rentalCharge->isNew()) {
            $_rentalCharge = $rentalCharge;
        }
        if (empty($_message) && $this->request->is(['post'])) {
            $postData = $this->request->getData();

            $postData['incubator_application_id'] = $incubator->id;
            $postData['application_status_id']    = 1;
            $postData['application_stage_id']     = 1;
            if ($rentalCharge->isNew()) {
                $postData['created'] = date('Y-m-d H:i:s');
            }
            /** Document **/
            $rentalChargeFiles = ['registration_certificate', 'applicant_certificate', 'association_memorandum', 'authorization_letter', 'undertaking_letter', 'proof_incubator_operation', 'ca_certificate', 'certificate_from_hod', 'space_availability_proof', 'cancelled_cheque', 'photographs', 'rent_receipts', 'claimed_expenses_bill', 'payment_proof', 'performance_report'];
            foreach ($rentalChargeFiles as $field) {
                if (isset($postData[$field]) && $postData[$field]['name'] != '') {
                    $uploaded = $this->uploadFiles('rental-charge', $postData[$field]);
                    if (isset($uploaded['filename'])) {
                        $postData[$field] = $uploaded['filename'];
                    } else {
                        unset($postData[$field]);
                    }
                } else if (isset($postData[$field])) {
                    unset($postData[$field]);
                }
            }
            //Save
            $rentalChargeSave = $this->IncubatorRentalCharges->patchEntity($rentalCharge, $postData);
            if ($this->IncubatorRentalCharges->save($rentalChargeSave)) {
                $applicationId = $rentalChargeSave->id;
                $referenceNo   = $rentalChargeSave->reference_number;
                if (empty($referenceNo)) {
                    $referenceNo = $this->rentalChargeReferenceNo($applicationId);
                    $this->IncubatorRentalCharges->query()
                        ->update()
                        ->set(['reference_number' => $referenceNo])
                        ->where(['id' => $applicationId])
                        ->execute();
                    $rentalChargeSave->reference_number = $referenceNo;
                }
                $_message = __("Thanks for your application, Please note Reference number ( {0} ) for further communication. ", [$referenceNo]);
                $_status  = true;

                $_rentalCharge = $rentalChargeSave;
            } else {
                $_message = __("Your application could not be saved. Please, try again.");
            }
        } else if (empty($_message)) {
            $_status = true;
        }
        $this->set([
            '_status'       => $_status,
            '_incubator'    => $_incubator,
            '_rentalCharge' => $_rentalCharge,
            '_IncubatorBaseUrl' => $_IncubatorBaseUrl,
            '_BaseUrl' => $_BaseUrl,
            '_message'      => $_message,
            '_serialize'    => [
                '_status', '_incubator', '_rentalCharge', '_IncubatorBaseUrl', '_BaseUrl', '_message',
            ],
        ]);
    }

    public function rentalChargeExemptions($id = '')
    {
        $this->loadModel('Incubators');
        $application = $this->Incubators->find()->where(['user_id' => $this->Auth->user('id')])->first();
        if (!empty($application)) {
            if (empty($application['incubator_certificate_no'])) {
                $this->Flash->error(__('Your application is being considered but has not yet been approved.'));
                $this->redirect(['controller' => 'Dashboard']);
            }
            $this->loadModel('IncubatorRentalCharges');
            $id            = base64_decode($id);
            $incentiveData = $this->IncubatorRentalCharges->findById($id)->first();
            if (empty($incentiveData)) {
                $rentalCharge = $this->IncubatorRentalCharges->newEntity();
            } else {
                $rentalCharge = $this->IncubatorRentalCharges->get($id);
            }
            if ($this->request->is(['post', 'put'])) {
                $data         = $this->request->getData();
                $data         = $this->Sanitize->clean($data);
                $rentalCharge = $this->IncubatorRentalCharges->patchEntity($rentalCharge, $data);
                if ($data['registration_certificate']['name'] != '') {
                    $certificate                            = $this->uploadFiles('rental-charge', $data['registration_certificate']);
                    $rentalCharge->registration_certificate = $certificate['filename'];
                } else {
                    $rentalCharge->registration_certificate = $data['old_registration_certificate'];
                }
                if ($data['applicant_certificate']['name'] != '') {
                    $certificate                         = $this->uploadFiles('rental-charge', $data['applicant_certificate']);
                    $rentalCharge->applicant_certificate = $certificate['filename'];
                } else {
                    $rentalCharge->applicant_certificate = $data['old_applicant_certificate'];
                }
                if ($data['association_memorandum']['name'] != '') {
                    $certificate                          = $this->uploadFiles('rental-charge', $data['association_memorandum']);
                    $rentalCharge->association_memorandum = $certificate['filename'];
                } else {
                    $rentalCharge->association_memorandum = $data['old_association_memorandum'];
                }
                if ($data['authorization_letter']['name'] != '') {
                    $certificate                        = $this->uploadFiles('rental-charge', $data['authorization_letter']);
                    $rentalCharge->authorization_letter = $certificate['filename'];
                } else {
                    $rentalCharge->authorization_letter = $data['old_authorization_letter'];
                }
                if ($data['undertaking_letter']['name'] != '') {
                    $certificate                      = $this->uploadFiles('rental-charge', $data['undertaking_letter']);
                    $rentalCharge->undertaking_letter = $certificate['filename'];
                } else {
                    $rentalCharge->undertaking_letter = $data['old_undertaking_letter'];
                }
                if ($data['proof_incubator_operation']['name'] != '') {
                    $certificate                             = $this->uploadFiles('rental-charge', $data['proof_incubator_operation']);
                    $rentalCharge->proof_incubator_operation = $certificate['filename'];
                } else {
                    $rentalCharge->proof_incubator_operation = $data['old_proof_incubator_operation'];
                }
                if ($data['ca_certificate']['name'] != '') {
                    $certificate                  = $this->uploadFiles('rental-charge', $data['ca_certificate']);
                    $rentalCharge->ca_certificate = $certificate['filename'];
                } else {
                    $rentalCharge->ca_certificate = $data['old_ca_certificate'];
                }
                if ($data['certificate_from_hod']['name'] != '') {
                    $certificate                        = $this->uploadFiles('rental-charge', $data['certificate_from_hod']);
                    $rentalCharge->certificate_from_hod = $certificate['filename'];
                } else {
                    $rentalCharge->certificate_from_hod = $data['old_certificate_from_hod'];
                }
                if ($data['space_availability_proof']['name'] != '') {
                    $certificate                            = $this->uploadFiles('rental-charge', $data['space_availability_proof']);
                    $rentalCharge->space_availability_proof = $certificate['filename'];
                } else {
                    $rentalCharge->space_availability_proof = $data['old_space_availability_proof'];
                }
                if ($data['cancelled_cheque']['name'] != '') {
                    $certificate                    = $this->uploadFiles('rental-charge', $data['cancelled_cheque']);
                    $rentalCharge->cancelled_cheque = $certificate['filename'];
                } else {
                    $rentalCharge->cancelled_cheque = $data['old_cancelled_cheque'];
                }
                if ($data['photographs']['name'] != '') {
                    $certificate               = $this->uploadFiles('rental-charge', $data['photographs']);
                    $rentalCharge->photographs = $certificate['filename'];
                } else {
                    $rentalCharge->photographs = $data['old_photographs'];
                }
                if ($data['rent_receipts']['name'] != '') {
                    $certificate                 = $this->uploadFiles('rental-charge', $data['rent_receipts']);
                    $rentalCharge->rent_receipts = $certificate['filename'];
                } else {
                    $rentalCharge->rent_receipts = $data['old_rent_receipts'];
                }
                if ($data['claimed_expenses_bill']['name'] != '') {
                    $certificate                         = $this->uploadFiles('rental-charge', $data['claimed_expenses_bill']);
                    $rentalCharge->claimed_expenses_bill = $certificate['filename'];
                } else {
                    $rentalCharge->claimed_expenses_bill = $data['old_claimed_expenses_bill'];
                }
                if ($data['payment_proof']['name'] != '') {
                    $certificate                 = $this->uploadFiles('rental-charge', $data['payment_proof']);
                    $rentalCharge->payment_proof = $certificate['filename'];
                } else {
                    $rentalCharge->payment_proof = $data['old_payment_proof'];
                }
                if ($data['performance_report']['name'] != '') {
                    $certificate                      = $this->uploadFiles('rental-charge', $data['performance_report']);
                    $rentalCharge->performance_report = $certificate['filename'];
                } else {
                    $rentalCharge->performance_report = $data['old_performance_report'];
                }
                $rentalCharge->application_status_id    = 1;
                $rentalCharge->application_stage_id     = 1;
                $rentalCharge->incubator_application_id = $application['id'];
                $rentalCharge->created                  = date('Y-m-d H:i:s');
                if ($this->IncubatorRentalCharges->save($rentalCharge)) {
                    $rentalCharge_id = $rentalCharge->id;
                    $this->Flash->success(__('Successfully Saved.'));
                    return $this->redirect(['action' => 'rentalChargePreview', base64_encode($rentalCharge_id)]);
                }
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        } else {
            $this->Flash->error(__('You have not applied for any Incubator.'));
            $this->redirect(['controller' => 'Dashboard']);
        }
        $this->loadModel('Designations');
        $designations = $this->Designations->find('list')->where(['status' => 1])->order(['name ASC']);
        $this->set(compact('rentalCharge', 'application', 'designations'));
    }

    public function rentalChargePreview($id)
    {
        $this->loadModel('IncubatorRentalCharges');
        $id            = base64_decode($id);
        $incentiveData = $this->IncubatorRentalCharges->findById($id)->first();
        if (empty($incentiveData)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'rentalChargeExemptions']);
        }
        $rentalCharge = $this->IncubatorRentalCharges->get($id, ['contain' => ['Designations']]);

        if ($this->request->is(['post', 'put'])) {
            $data                                = $this->request->getData();
            $rentalCharge->application_status_id = 1;
            $rentalCharge->application_stage_id  = 1;
            $rentalCharge->created               = date('Y-m-d H:i:s');
            if ($this->IncubatorRentalCharges->save($rentalCharge)) {
                $rentalCharge_id = $rentalCharge->id;
                $reference_no    = $this->rentalChargeReferenceNo($rentalCharge_id);
                $query           = $this->IncubatorRentalCharges->query();
                $query->update()
                    ->set(['reference_number' => $reference_no])
                    ->where(['id' => $rentalCharge_id])
                    ->execute();
                $this->Flash->success(__("Thanks for your application, Please note Reference number ( $reference_no ) for further communication. "));
                return $this->redirect(['controller' => 'Dashboard', 'action' => 'index']);
            }
            $this->Flash->error(__('Some error occurred. Please, try again.'));
        }
        $this->set(compact('rentalCharge'));
    }

    public function rentalChargeReferenceNo($id)
    {
        $string = '';
        $string .= 'RC/' . date('dmY') . '/';
        $string .= str_pad(($id), 5, 0, STR_PAD_LEFT);
        return $string;
    }

    public function StampDutyRegistrationExpensesEligibility()
    {
        # code...
    }

    public function apiStampDutyRegistrationExpenses()
    {
        if ($this->isDevice == false) {
            return $this->redirect(['controller' => 'Dashboard', 'action' => 'index']);
        }
        $this->loadModel('IncubatorStampDuties');
        $this->request->allowMethod(['get', 'post']);
        $_status  = false;
        $_message = '';

        $_IncubatorBaseUrl = Router::Url('/files/incubator', true);
        $_BaseUrl          = Router::Url('/files/stamp-duty', true);

        $_incubator          = new \stdClass();
        $_incubatorStampDuty = new \stdClass();

        if ($this->request->is(['post'])) {
            $applicationId = $this->request->getData('applicationId');
            $userId        = $this->request->getData('userId');
        } else {
            $applicationId = $this->request->getQuery('applicationId');
            $userId        = $this->request->getQuery('userId');
        }
        if (!empty($userId)) {
            $where     = [];
            $where[]   = ['user_id' => $userId];
            $incubator = $this->Incubators->find('all', ['contain' => ['IncubatorDirectors']])->where($where)->first();
            if (!empty($incubator) && empty($incubator->incubator_certificate_no)) {
                $_message = __('Your application is being considered but has not yet been approved.');
            } else if (empty($incubator)) {
                $_message = __('You have not applied for any Incubator.');
            } else {
                $incubatorStampDuty = (!empty($applicationId)) ? $this->IncubatorStampDuties->get($applicationId)->first() : $this->IncubatorStampDuties->newEntity();
            }
        } else {
            $_message = __('UserID is required');
        }
        if (!empty($incubator)) {
            $_incubator = $incubator;
        }
        if (!empty($incubatorStampDuty) && !$incubatorStampDuty->isNew()) {
            $_incubatorStampDuty = $incubatorStampDuty;
        }
        if (empty($_message) && $this->request->is(['post'])) {
            $postData = $this->request->getData();

            $postData['incubator_application_id'] = $incubator->id;
            $postData['application_status_id']    = 1;
            $postData['application_stage_id']     = 1;
            if ($incubatorStampDuty->isNew()) {
                $postData['created'] = date('Y-m-d H:i:s');
            }
            /** Document **/
            $incubatorStampDutyFiles = ['registration_certificate', 'applicant_certificate', 'association_memorandum', 'authorization_letter', 'undertaking_letter', 'proof_incubator_operation', 'cancelled_cheque', 'space_availability_proof', 'sale_deed_registered', 'lease_agreement_registered', 'sale_deed_mutation', 'nakal_aks_shajra', 'verification_report', 'payment_proof', 'photographs', 'performance_report'];
            foreach ($incubatorStampDutyFiles as $field) {
                if (isset($postData[$field]) && $postData[$field]['name'] != '') {
                    $uploaded = $this->uploadFiles('stamp-duty', $postData[$field]);
                    if (isset($uploaded['filename'])) {
                        $postData[$field] = $uploaded['filename'];
                    } else {
                        unset($postData[$field]);
                    }
                } else if (isset($postData[$field])) {
                    unset($postData[$field]);
                }
            }
            //Save
            $incubatorStampDutySave = $this->IncubatorStampDuties->patchEntity($incubatorStampDuty, $postData);
            if ($this->IncubatorStampDuties->save($incubatorStampDutySave)) {
                $applicationId = $incubatorStampDutySave->id;
                $referenceNo   = $incubatorStampDutySave->reference_number;
                if (empty($referenceNo)) {
                    $referenceNo = $this->stampDutyReferenceNo($applicationId);
                    $this->IncubatorStampDuties->query()
                        ->update()
                        ->set(['reference_number' => $referenceNo])
                        ->where(['id' => $applicationId])
                        ->execute();
                    $incubatorStampDutySave->reference_number = $referenceNo;
                }
                $_message = __("Thanks for your application, Please note Reference number ( {0} ) for further communication. ", [$referenceNo]);
                $_status  = true;

                $_incubatorStampDuty = $incubatorStampDutySave;
            } else {
                $_message = __("Your application could not be saved. Please, try again.");
            }
        } else if (empty($_message)) {
            $_status = true;
        }
        $this->set([
            '_status'             => $_status,
            '_incubator'          => $_incubator,
            '_incubatorStampDuty' => $_incubatorStampDuty,
            '_IncubatorBaseUrl'   => $_IncubatorBaseUrl,
            '_BaseUrl'            => $_BaseUrl,
            '_message'            => $_message,
            '_serialize'          => [
                '_status', '_incubator', '_incubatorStampDuty', '_IncubatorBaseUrl', '_BaseUrl', '_message',
            ],
        ]);
    }

    public function StampDutyRegistrationExpenses($id = '')
    {
        $this->loadModel('Incubators');
        $application = $this->Incubators->find()->where(['user_id' => $this->Auth->user('id')])->first();
        if (!empty($application)) {
            if (empty($application['incubator_certificate_no'])) {
                $this->Flash->error(__('Your application is being considered but has not yet been approved.'));
                $this->redirect(['controller' => 'Dashboard']);
            }
            $this->loadModel('IncubatorStampDuties');
            $id            = base64_decode($id);
            $incentiveData = $this->IncubatorStampDuties->findById($id)->first();
            if (empty($incentiveData)) {
                $stampDuty = $this->IncubatorStampDuties->newEntity();
            } else {
                $stampDuty = $this->IncubatorStampDuties->get($id);
            }
            if ($this->request->is(['post', 'put'])) {
                $data      = $this->request->getData();
                $data      = $this->Sanitize->clean($data);
                $stampDuty = $this->IncubatorStampDuties->patchEntity($stampDuty, $data);
                if ($data['registration_certificate']['name'] != '') {
                    $certificate                         = $this->uploadFiles('stamp-duty', $data['registration_certificate']);
                    $stampDuty->registration_certificate = $certificate['filename'];
                } else {
                    $stampDuty->registration_certificate = $data['old_registration_certificate'];
                }
                if ($data['applicant_certificate']['name'] != '') {
                    $certificate                      = $this->uploadFiles('stamp-duty', $data['applicant_certificate']);
                    $stampDuty->applicant_certificate = $certificate['filename'];
                } else {
                    $stampDuty->applicant_certificate = isset($data['old_applicant_certificate']) ? $data['old_applicant_certificate'] : null;
                }
                if ($data['association_memorandum']['name'] != '') {
                    $certificate                       = $this->uploadFiles('stamp-duty', $data['association_memorandum']);
                    $stampDuty->association_memorandum = $certificate['filename'];
                } else {
                    $stampDuty->association_memorandum = isset($data['old_association_memorandum']) ? $data['old_association_memorandum'] : null;
                }
                if ($data['authorization_letter']['name'] != '') {
                    $certificate                     = $this->uploadFiles('stamp-duty', $data['authorization_letter']);
                    $stampDuty->authorization_letter = $certificate['filename'];
                } else {
                    $stampDuty->authorization_letter = $data['old_authorization_letter'];
                }
                if ($data['undertaking_letter']['name'] != '') {
                    $certificate                   = $this->uploadFiles('stamp-duty', $data['undertaking_letter']);
                    $stampDuty->undertaking_letter = $certificate['filename'];
                } else {
                    $stampDuty->undertaking_letter = $data['old_undertaking_letter'];
                }
                if ($data['proof_incubator_operation']['name'] != '') {
                    $certificate                          = $this->uploadFiles('stamp-duty', $data['proof_incubator_operation']);
                    $stampDuty->proof_incubator_operation = $certificate['filename'];
                } else {
                    $stampDuty->proof_incubator_operation = $data['old_proof_incubator_operation'];
                }
                if ($data['cancelled_cheque']['name'] != '') {
                    $certificate                 = $this->uploadFiles('stamp-duty', $data['cancelled_cheque']);
                    $stampDuty->cancelled_cheque = $certificate['filename'];
                } else {
                    $stampDuty->cancelled_cheque = $data['old_cancelled_cheque'];
                }
                if ($data['space_availability_proof']['name'] != '') {
                    $certificate                         = $this->uploadFiles('stamp-duty', $data['space_availability_proof']);
                    $stampDuty->space_availability_proof = $certificate['filename'];
                } else {
                    $stampDuty->space_availability_proof = $data['old_space_availability_proof'];
                }
                if ($data['sale_deed_registered']['name'] != '') {
                    $certificate                     = $this->uploadFiles('stamp-duty', $data['sale_deed_registered']);
                    $stampDuty->sale_deed_registered = $certificate['filename'];
                } else {
                    $stampDuty->sale_deed_registered = $data['old_sale_deed_registered'];
                }
                if ($data['lease_agreement_registered']['name'] != '') {
                    $certificate                           = $this->uploadFiles('stamp-duty', $data['lease_agreement_registered']);
                    $stampDuty->lease_agreement_registered = $certificate['filename'];
                } else {
                    $stampDuty->lease_agreement_registered = $data['old_lease_agreement_registered'];
                }
                if ($data['sale_deed_mutation']['name'] != '') {
                    $certificate                   = $this->uploadFiles('stamp-duty', $data['sale_deed_mutation']);
                    $stampDuty->sale_deed_mutation = $certificate['filename'];
                } else {
                    $stampDuty->sale_deed_mutation = $data['old_sale_deed_mutation'];
                }
                if ($data['nakal_aks_shajra']['name'] != '') {
                    $certificate                 = $this->uploadFiles('stamp-duty', $data['nakal_aks_shajra']);
                    $stampDuty->nakal_aks_shajra = $certificate['filename'];
                } else {
                    $stampDuty->nakal_aks_shajra = $data['old_nakal_aks_shajra'];
                }
                if ($data['verification_report']['name'] != '') {
                    $certificate                    = $this->uploadFiles('stamp-duty', $data['verification_report']);
                    $stampDuty->verification_report = $certificate['filename'];
                } else {
                    $stampDuty->verification_report = $data['old_verification_report'];
                }
                if ($data['payment_proof']['name'] != '') {
                    $certificate              = $this->uploadFiles('stamp-duty', $data['payment_proof']);
                    $stampDuty->payment_proof = $certificate['filename'];
                } else {
                    $stampDuty->payment_proof = $data['old_payment_proof'];
                }
                if ($data['photographs']['name'] != '') {
                    $certificate            = $this->uploadFiles('stamp-duty', $data['photographs']);
                    $stampDuty->photographs = $certificate['filename'];
                } else {
                    $stampDuty->photographs = $data['old_photographs'];
                }
                if ($data['performance_report']['name'] != '') {
                    $certificate                   = $this->uploadFiles('stamp-duty', $data['performance_report']);
                    $stampDuty->performance_report = $certificate['filename'];
                } else {
                    $stampDuty->performance_report = $data['old_performance_report'];
                }

                $stampDuty->application_status_id    = 1;
                $stampDuty->application_stage_id     = 1;
                $stampDuty->incubator_application_id = $application['id'];
                $stampDuty->created                  = date('Y-m-d H:i:s');
                if ($this->IncubatorStampDuties->save($stampDuty)) {
                    $stampDuty_id = $stampDuty->id;
                    $this->Flash->success(__('Successfully Saved.'));
                    return $this->redirect(['action' => 'StampDutyRegistrationExpensesPreview', base64_encode($stampDuty_id)]);
                }
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        } else {
            $this->Flash->error(__('You have not applied for any Incubator.'));
            $this->redirect(['controller' => 'Dashboard']);
        }
        $this->loadModel('Designations');
        $designations = $this->Designations->find('list')->where(['status' => 1])->order(['name ASC']);
        $this->set(compact('stampDuty', 'application', 'designations'));
    }

    public function StampDutyRegistrationExpensesPreview($id = '')
    {
        $this->loadModel('IncubatorStampDuties');
        $id            = base64_decode($id);
        $incentiveData = $this->IncubatorStampDuties->findById($id)->first();
        if (empty($incentiveData)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'StampDutyRegistrationExpenses']);
        }
        $stampDuty = $this->IncubatorStampDuties->get($id, ['contain' => ['Designations']]);

        if ($this->request->is(['post', 'put'])) {
            $data                             = $this->request->getData();
            $stampDuty->application_status_id = 1;
            $stampDuty->application_stage_id  = 1;
            $stampDuty->created               = date('Y-m-d H:i:s');
            if ($this->IncubatorStampDuties->save($stampDuty)) {
                $stampDuty_id = $stampDuty->id;
                $reference_no = $this->stampDutyReferenceNo($stampDuty_id);
                $query        = $this->IncubatorStampDuties->query();
                $query->update()
                    ->set(['reference_number' => $reference_no])
                    ->where(['id' => $stampDuty_id])
                    ->execute();
                $this->Flash->success(__("Thanks for your application, Please note Reference number ( $reference_no ) for further communication. "));
                return $this->redirect(['controller' => 'Dashboard', 'action' => 'index']);
            }
            $this->Flash->error(__('Some error occurred. Please, try again.'));
        }
        $this->set(compact('stampDuty'));
    }

    public function stampDutyReferenceNo($id)
    {
        $string = '';
        $string .= 'SD/' . date('dmY') . '/';
        $string .= str_pad(($id), 5, 0, STR_PAD_LEFT);
        return $string;
    }

    public function fairExhibitionsEligibility($value = '')
    {
        # code...
    }

    public function preApprovalInFairExhibitions($id = '')
    {
        $this->loadModel('Incubators');
        $application = $this->Incubators->find()->where(['user_id' => $this->Auth->user('id')])->first();
        if (!empty($application)) {
            if (empty($application['incubator_certificate_no'])) {
                $this->Flash->error(__('Your application is being considered but has not yet been approved.'));
                $this->redirect(['controller' => 'Dashboard']);
            }
            $this->loadModel('IncubatorPreApprovalFairExhibitions');
            $id            = base64_decode($id);
            $incentiveData = $this->IncubatorPreApprovalFairExhibitions->findById($id)->first();
            if (empty($incentiveData)) {
                $preApprovalFairExhibition = $this->IncubatorPreApprovalFairExhibitions->newEntity();
            } else {
                $preApprovalFairExhibition = $this->IncubatorPreApprovalFairExhibitions->get($id);
            }
            if ($this->request->is(['post', 'put'])) {
                $data                      = $this->request->getData();
                $data                      = $this->Sanitize->clean($data);
                $preApprovalFairExhibition = $this->IncubatorPreApprovalFairExhibitions->patchEntity($preApprovalFairExhibition, $data);
                if ($data['registration_certificate']['name'] != '') {
                    $certificate                                         = $this->uploadFiles('pre-fair-exhibition', $data['registration_certificate']);
                    $preApprovalFairExhibition->registration_certificate = $certificate['filename'];
                } else {
                    $preApprovalFairExhibition->registration_certificate = $data['old_registration_certificate'];
                }
                if ($data['applicant_certificate']['name'] != '') {
                    $certificate                                      = $this->uploadFiles('pre-fair-exhibition', $data['applicant_certificate']);
                    $preApprovalFairExhibition->applicant_certificate = $certificate['filename'];
                } else {
                    $preApprovalFairExhibition->applicant_certificate = isset($data['old_applicant_certificate']) ? $data['old_applicant_certificate'] : null;
                }
                if ($data['association_memorandum']['name'] != '') {
                    $certificate                                       = $this->uploadFiles('pre-fair-exhibition', $data['association_memorandum']);
                    $preApprovalFairExhibition->association_memorandum = $certificate['filename'];
                } else {
                    $preApprovalFairExhibition->association_memorandum = isset($data['old_association_memorandum']) ? $data['old_association_memorandum'] : null;
                }
                if ($data['authorization_letter']['name'] != '') {
                    $certificate                                     = $this->uploadFiles('pre-fair-exhibition', $data['authorization_letter']);
                    $preApprovalFairExhibition->authorization_letter = $certificate['filename'];
                } else {
                    $preApprovalFairExhibition->authorization_letter = $data['old_authorization_letter'];
                }
                if ($data['undertaking_letter']['name'] != '') {
                    $certificate                                   = $this->uploadFiles('pre-fair-exhibition', $data['undertaking_letter']);
                    $preApprovalFairExhibition->undertaking_letter = $certificate['filename'];
                } else {
                    $preApprovalFairExhibition->undertaking_letter = $data['old_undertaking_letter'];
                }
                if ($data['event_brochure']['name'] != '') {
                    $certificate                               = $this->uploadFiles('pre-fair-exhibition', $data['event_brochure']);
                    $preApprovalFairExhibition->event_brochure = $certificate['filename'];
                } else {
                    $preApprovalFairExhibition->event_brochure = $data['old_event_brochure'];
                }
                if ($data['event_proposal']['name'] != '') {
                    $certificate                               = $this->uploadFiles('pre-fair-exhibition', $data['event_proposal']);
                    $preApprovalFairExhibition->event_proposal = $certificate['filename'];
                } else {
                    $preApprovalFairExhibition->event_proposal = $data['old_event_proposal'];
                }
                if ($data['proof_incubator_operation']['name'] != '') {
                    $certificate                                          = $this->uploadFiles('pre-fair-exhibition', $data['proof_incubator_operation']);
                    $preApprovalFairExhibition->proof_incubator_operation = $certificate['filename'];
                } else {
                    $preApprovalFairExhibition->proof_incubator_operation = $data['old_proof_incubator_operation'];
                }
                if ($data['cancelled_cheque']['name'] != '') {
                    $certificate                                 = $this->uploadFiles('pre-fair-exhibition', $data['cancelled_cheque']);
                    $preApprovalFairExhibition->cancelled_cheque = $certificate['filename'];
                } else {
                    $preApprovalFairExhibition->cancelled_cheque = $data['old_cancelled_cheque'];
                }
                if ($data['invitation_letter']['name'] != '') {
                    $certificate                                  = $this->uploadFiles('pre-fair-exhibition', $data['invitation_letter']);
                    $preApprovalFairExhibition->invitation_letter = $certificate['filename'];
                } else {
                    $preApprovalFairExhibition->invitation_letter = $data['old_invitation_letter'];
                }
                $preApprovalFairExhibition->application_status_id    = 1;
                $preApprovalFairExhibition->application_stage_id     = 1;
                $preApprovalFairExhibition->incubator_application_id = $application['id'];
                $preApprovalFairExhibition->created                  = date('Y-m-d H:i:s');
                if ($this->IncubatorPreApprovalFairExhibitions->save($preApprovalFairExhibition)) {
                    $preApprovalFairExhibition_id = $preApprovalFairExhibition->id;
                    $this->Flash->success(__('Successfully Saved.'));
                    return $this->redirect(['action' => 'preApprovalInFairExhibitionPreview', base64_encode($preApprovalFairExhibition_id)]);
                }
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        } else {
            $this->Flash->error(__('You have not applied for any Incubator.'));
            $this->redirect(['controller' => 'Dashboard']);
        }
        $this->loadModel('Designations');
        $designations = $this->Designations->find('list')->where(['status' => 1])->order(['name ASC']);
        $this->set(compact('preApprovalFairExhibition', 'application', 'designations'));
    }

    public function preApprovalInFairExhibitionPreview($id = '')
    {
        $this->loadModel('IncubatorPreApprovalFairExhibitions');
        $id            = base64_decode($id);
        $incentiveData = $this->IncubatorPreApprovalFairExhibitions->findById($id)->first();
        if (empty($incentiveData)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'preApprovalInFairExhibitions']);
        }
        $preApprovalFairExhibition = $this->IncubatorPreApprovalFairExhibitions->get($id, ['contain' => ['Designations']]);

        if ($this->request->is(['post', 'put'])) {
            $data                                             = $this->request->getData();
            $preApprovalFairExhibition->application_status_id = 1;
            $preApprovalFairExhibition->application_stage_id  = 1;
            $preApprovalFairExhibition->created               = date('Y-m-d H:i:s');
            if ($this->IncubatorPreApprovalFairExhibitions->save($preApprovalFairExhibition)) {
                $preApprovalFairExhibition_id = $preApprovalFairExhibition->id;
                $reference_no                 = $this->preApprovalReferenceNo($preApprovalFairExhibition_id);
                $query                        = $this->IncubatorPreApprovalFairExhibitions->query();
                $query->update()
                    ->set(['reference_number' => $reference_no])
                    ->where(['id' => $preApprovalFairExhibition_id])
                    ->execute();
                $this->Flash->success(__("Thanks for your application, Please note Reference number ( $reference_no ) for further communication. "));
                return $this->redirect(['controller' => 'Dashboard', 'action' => 'index']);
            }
            $this->Flash->error(__('Some error occurred. Please, try again.'));
        }
        $this->set(compact('preApprovalFairExhibition'));
    }

    public function preApprovalReferenceNo($id)
    {
        $string = '';
        $string .= 'FE/' . date('dmY') . '/';
        $string .= str_pad(($id), 5, 0, STR_PAD_LEFT);
        return $string;
    }

    public function claimingAssistanceInFairExhibition($id = '')
    {
        $this->loadModel('Incubators');
        $application = $this->Incubators->find()->where(['user_id' => $this->Auth->user('id')])->first();
        if (!empty($application)) {
            if (empty($application['incubator_certificate_no'])) {
                $this->Flash->error(__('Your application is being considered but has not yet been approved.'));
                $this->redirect(['controller' => 'Dashboard']);
            }
            $this->loadModel('IncubatorClaimingAssistanceFairExhibitions');
            $id            = base64_decode($id);
            $incentiveData = $this->IncubatorClaimingAssistanceFairExhibitions->findById($id)->first();
            if (empty($incentiveData)) {
                $claimingFairExhibition = $this->IncubatorClaimingAssistanceFairExhibitions->newEntity();
            } else {
                $claimingFairExhibition = $this->IncubatorClaimingAssistanceFairExhibitions->get($id);
            }
            if ($this->request->is(['post', 'put'])) {
                $data                   = $this->request->getData();
                $data                   = $this->Sanitize->clean($data);
                $claimingFairExhibition = $this->IncubatorClaimingAssistanceFairExhibitions->patchEntity($claimingFairExhibition, $data);
                if ($data['approval_letter']['name'] != '') {
                    $certificate                             = $this->uploadFiles('claiming-fair-exhibition', $data['approval_letter']);
                    $claimingFairExhibition->approval_letter = $certificate['filename'];
                } else {
                    $claimingFairExhibition->approval_letter = $data['old_approval_letter'];
                }
                if ($data['registration_certificate']['name'] != '') {
                    $certificate                                      = $this->uploadFiles('claiming-fair-exhibition', $data['registration_certificate']);
                    $claimingFairExhibition->registration_certificate = $certificate['filename'];
                } else {
                    $claimingFairExhibition->registration_certificate = isset($data['old_registration_certificate']) ? $data['old_registration_certificate'] : null;
                }
                if ($data['association_memorandum']['name'] != '') {
                    $certificate                                    = $this->uploadFiles('claiming-fair-exhibition', $data['association_memorandum']);
                    $claimingFairExhibition->association_memorandum = $certificate['filename'];
                } else {
                    $claimingFairExhibition->association_memorandum = isset($data['old_association_memorandum']) ? $data['old_association_memorandum'] : null;
                }
                if ($data['authorization_letter']['name'] != '') {
                    $certificate                                  = $this->uploadFiles('claiming-fair-exhibition', $data['authorization_letter']);
                    $claimingFairExhibition->authorization_letter = $certificate['filename'];
                } else {
                    $claimingFairExhibition->authorization_letter = $data['old_authorization_letter'];
                }
                if ($data['undertaking_letter']['name'] != '') {
                    $certificate                                = $this->uploadFiles('claiming-fair-exhibition', $data['undertaking_letter']);
                    $claimingFairExhibition->undertaking_letter = $certificate['filename'];
                } else {
                    $claimingFairExhibition->undertaking_letter = $data['old_undertaking_letter'];
                }
                if ($data['person_passport']['name'] != '') {
                    $certificate                             = $this->uploadFiles('claiming-fair-exhibition', $data['person_passport']);
                    $claimingFairExhibition->person_passport = $certificate['filename'];
                } else {
                    $claimingFairExhibition->person_passport = $data['old_person_passport'];
                }
                if ($data['boarding_pass']['name'] != '') {
                    $certificate                           = $this->uploadFiles('claiming-fair-exhibition', $data['boarding_pass']);
                    $claimingFairExhibition->boarding_pass = $certificate['filename'];
                } else {
                    $claimingFairExhibition->boarding_pass = $data['old_boarding_pass'];
                }
                if ($data['cancelled_cheque']['name'] != '') {
                    $certificate                              = $this->uploadFiles('claiming-fair-exhibition', $data['cancelled_cheque']);
                    $claimingFairExhibition->cancelled_cheque = $certificate['filename'];
                } else {
                    $claimingFairExhibition->cancelled_cheque = $data['old_cancelled_cheque'];
                }
                if ($data['original_bills']['name'] != '') {
                    $certificate                            = $this->uploadFiles('claiming-fair-exhibition', $data['original_bills']);
                    $claimingFairExhibition->original_bills = $certificate['filename'];
                } else {
                    $claimingFairExhibition->original_bills = $data['old_original_bills'];
                }
                if ($data['payment_proof']['name'] != '') {
                    $certificate                           = $this->uploadFiles('claiming-fair-exhibition', $data['payment_proof']);
                    $claimingFairExhibition->payment_proof = $certificate['filename'];
                } else {
                    $claimingFairExhibition->payment_proof = $data['old_payment_proof'];
                }
                if ($data['ca_certificate']['name'] != '') {
                    $certificate                            = $this->uploadFiles('claiming-fair-exhibition', $data['ca_certificate']);
                    $claimingFairExhibition->ca_certificate = $certificate['filename'];
                } else {
                    $claimingFairExhibition->ca_certificate = $data['old_ca_certificate'];
                }
                $claimingFairExhibition->application_status_id    = 1;
                $claimingFairExhibition->application_stage_id     = 1;
                $claimingFairExhibition->incubator_application_id = $application['id'];
                $claimingFairExhibition->created                  = date('Y-m-d H:i:s');
                if ($this->IncubatorClaimingAssistanceFairExhibitions->save($claimingFairExhibition)) {
                    $claimingFairExhibition_id = $claimingFairExhibition->id;
                    $this->Flash->success(__('Successfully Saved.'));
                    return $this->redirect(['action' => 'claimingAssistanceInFairExhibitionPreview', base64_encode($claimingFairExhibition_id)]);
                }
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        } else {
            $this->Flash->error(__('You have not applied for any Incubator.'));
            $this->redirect(['controller' => 'Dashboard']);
        }
        $this->loadModel('Designations');
        $designations = $this->Designations->find('list')->where(['status' => 1])->order(['name ASC']);
        $this->set(compact('claimingFairExhibition', 'application', 'designations'));
    }

    public function claimingAssistanceInFairExhibitionPreview($id = '')
    {
        $this->loadModel('IncubatorClaimingAssistanceFairExhibitions');
        $id            = base64_decode($id);
        $incentiveData = $this->IncubatorClaimingAssistanceFairExhibitions->findById($id)->first();
        if (empty($incentiveData)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'claimingAssistanceInFairExhibition']);
        }
        $claimingFairExhibition = $this->IncubatorClaimingAssistanceFairExhibitions->get($id, ['contain' => ['Designations']]);

        if ($this->request->is(['post', 'put'])) {
            $data                                          = $this->request->getData();
            $claimingFairExhibition->application_status_id = 1;
            $claimingFairExhibition->application_stage_id  = 1;
            $claimingFairExhibition->created               = date('Y-m-d H:i:s');
            if ($this->IncubatorClaimingAssistanceFairExhibitions->save($claimingFairExhibition)) {
                $claimingFairExhibition_id = $claimingFairExhibition->id;
                $reference_no              = $this->claimingAssistanceReferenceNo($claimingFairExhibition_id);
                $query                     = $this->IncubatorClaimingAssistanceFairExhibitions->query();
                $query->update()
                    ->set(['reference_number' => $reference_no])
                    ->where(['id' => $claimingFairExhibition_id])
                    ->execute();
                $this->Flash->success(__("Thanks for your application, Please note Reference number ( $reference_no ) for further communication. "));
                return $this->redirect(['controller' => 'Dashboard', 'action' => 'index']);
            }
            $this->Flash->error(__('Some error occurred. Please, try again.'));
        }
        $this->set(compact('claimingFairExhibition'));
    }

    public function claimingAssistanceReferenceNo($id)
    {
        $string = '';
        $string .= 'CA/' . date('dmY') . '/';
        $string .= str_pad(($id), 5, 0, STR_PAD_LEFT);
        return $string;
    }

    public function CapitalSubsidyEligibility($id = '')
    {
        # code...
    }

    public function apiCapitalSubsidyPhaseOne()
    {
        if ($this->isDevice == false) {
            return $this->redirect(['controller' => 'Dashboard', 'action' => 'index']);
        }
        $this->loadModel('IncubatorCapitalSubsidyPhaseOne');
        $this->request->allowMethod(['get', 'post']);
        $_status  = false;
        $_message = '';

        $_IncubatorBaseUrl = Router::Url('/files/incubator', true);
        $_BaseUrl          = Router::Url('/files/capital-subsidy', true);

        $_incubator              = new \stdClass();
        $_capitalSubsidyPhaseOne = new \stdClass();

        if ($this->request->is(['post'])) {
            $applicationId = $this->request->getData('applicationId');
            $userId        = $this->request->getData('userId');
        } else {
            $applicationId = $this->request->getQuery('applicationId');
            $userId        = $this->request->getQuery('userId');
        }
        if (!empty($userId)) {
            $where     = [];
            $where[]   = ['user_id' => $userId];
            $incubator = $this->Incubators->find('all', ['contain' => ['IncubatorDirectors']])->where($where)->first();
            if (!empty($incubator) && empty($incubator->incubator_certificate_no)) {
                $_message = __('Your application is being considered but has not yet been approved.');
            } else if (empty($incubator)) {
                $_message = __('You have not applied for any Incubator.');
            } else {
                $capitalSubsidyPhaseOne = (!empty($applicationId)) ? $this->IncubatorCapitalSubsidyPhaseOne->get($applicationId)->first() : $this->IncubatorCapitalSubsidyPhaseOne->newEntity();
            }
        } else {
            $_message = __('UserID is required');
        }
        if (!empty($incubator)) {
            $_incubator = $incubator;
        }
        if (!empty($capitalSubsidyPhaseOne) && !$capitalSubsidyPhaseOne->isNew()) {
            $_capitalSubsidyPhaseOne = $capitalSubsidyPhaseOne;
        }
        if (empty($_message) && $this->request->is(['post'])) {
            $postData = $this->request->getData();
            $postData['incubator_application_id'] = $incubator->id;
            $postData['application_status_id']    = 1;
            $postData['application_stage_id']     = 1;
            if ($capitalSubsidyPhaseOne->isNew()) {
                $postData['created'] = date('Y-m-d H:i:s');
            }
            /** Document **/
            $capitalSubsidyPhaseOneFiles = ['registration_certificate', 'applicant_certificate', 'association_memorandum', 'authorization_letter', 'undertaking_letter', 'ca_certificate', 'certificate_from_hod', 'space_availability_proof', 'proof_incubator_operation', 'cancelled_cheque', 'claimed_expenses_bill', 'payment_proof', 'detailed_project_report'];
            foreach ($capitalSubsidyPhaseOneFiles as $field) {
                if (isset($postData[$field]) && $postData[$field]['name'] != '') {
                    $uploaded = $this->uploadFiles('capital-subsidy', $postData[$field]);
                    if (isset($uploaded['filename'])) {
                        $postData[$field] = $uploaded['filename'];
                    } else {
                        unset($postData[$field]);
                    }
                } else if (isset($postData[$field])) {
                    unset($postData[$field]);
                }
            }
            //Save
            $capitalSubsidyPhaseOneSave = $this->IncubatorCapitalSubsidyPhaseOne->patchEntity($capitalSubsidyPhaseOne, $postData);
            if ($this->IncubatorCapitalSubsidyPhaseOne->save($capitalSubsidyPhaseOneSave)) {
                $applicationId = $capitalSubsidyPhaseOneSave->id;
                $referenceNo   = $capitalSubsidyPhaseOneSave->reference_number;
                if (empty($referenceNo)) {
                    $referenceNo = $this->capitalSubsidyOneReferenceNo($applicationId);
                    $this->IncubatorCapitalSubsidyPhaseOne->query()
                        ->update()
                        ->set(['reference_number' => $referenceNo])
                        ->where(['id' => $applicationId])
                        ->execute();
                    $capitalSubsidyPhaseOneSave->reference_number = $referenceNo;
                }
                $_message = __("Thanks for your application, Please note Reference number ( {0} ) for further communication. ", [$referenceNo]);
                $_status  = true;

                $_capitalSubsidyPhaseOne = $capitalSubsidyPhaseOneSave;
            } else {
                $_message = __("Your application could not be saved. Please, try again.");
            }
        } else if (empty($_message)) {
            $_status = true;
        }
        $this->set([
            '_status'                 => $_status,
            '_incubator'              => $_incubator,
            '_capitalSubsidyPhaseOne' => $_capitalSubsidyPhaseOne,
            '_IncubatorBaseUrl'       => $_IncubatorBaseUrl,
            '_BaseUrl'                => $_BaseUrl,
            '_message'                => $_message,
            '_serialize'              => [
                '_status', '_incubator', '_capitalSubsidyPhaseOne', '_IncubatorBaseUrl', '_BaseUrl', '_message',
            ],
        ]);
    }

    public function CapitalSubsidyPhaseOne($id = '')
    {
        $this->loadModel('Incubators');
        $application = $this->Incubators->find()->where(['user_id' => $this->Auth->user('id')])->first();
        if (!empty($application)) {
            if (empty($application['incubator_certificate_no'])) {
                $this->Flash->error(__('Your application is being considered but has not yet been approved.'));
                $this->redirect(['controller' => 'Dashboard']);
            }
            $this->loadModel('IncubatorCapitalSubsidyPhaseOne');
            $id            = base64_decode($id);
            $incentiveData = $this->IncubatorCapitalSubsidyPhaseOne->findById($id)->first();
            if (empty($incentiveData)) {
                $capitalSubsidyOne = $this->IncubatorCapitalSubsidyPhaseOne->newEntity();
            } else {
                $capitalSubsidyOne = $this->IncubatorCapitalSubsidyPhaseOne->get($id);
            }
            if ($this->request->is(['post', 'put'])) {
                $data              = $this->request->getData();
                $data              = $this->Sanitize->clean($data);
                $capitalSubsidyOne = $this->IncubatorCapitalSubsidyPhaseOne->patchEntity($capitalSubsidyOne, $data);
                if ($data['registration_certificate']['name'] != '') {
                    $certificate                                 = $this->uploadFiles('capital-subsidy', $data['registration_certificate']);
                    $capitalSubsidyOne->registration_certificate = $certificate['filename'];
                } else {
                    $capitalSubsidyOne->registration_certificate = $data['old_registration_certificate'];
                }
                if ($data['applicant_certificate']['name'] != '') {
                    $certificate                              = $this->uploadFiles('capital-subsidy', $data['applicant_certificate']);
                    $capitalSubsidyOne->applicant_certificate = $certificate['filename'];
                } else {
                    $capitalSubsidyOne->applicant_certificate = isset($data['old_applicant_certificate']) ? $data['old_applicant_certificate'] : null;
                }
                if ($data['association_memorandum']['name'] != '') {
                    $certificate                               = $this->uploadFiles('capital-subsidy', $data['association_memorandum']);
                    $capitalSubsidyOne->association_memorandum = $certificate['filename'];
                } else {
                    $capitalSubsidyOne->association_memorandum = isset($data['old_association_memorandum']) ? $data['old_association_memorandum'] : null;
                }
                if ($data['authorization_letter']['name'] != '') {
                    $certificate                             = $this->uploadFiles('capital-subsidy', $data['authorization_letter']);
                    $capitalSubsidyOne->authorization_letter = $certificate['filename'];
                } else {
                    $capitalSubsidyOne->authorization_letter = $data['old_authorization_letter'];
                }
                if ($data['undertaking_letter']['name'] != '') {
                    $certificate                           = $this->uploadFiles('capital-subsidy', $data['undertaking_letter']);
                    $capitalSubsidyOne->undertaking_letter = $certificate['filename'];
                } else {
                    $capitalSubsidyOne->undertaking_letter = $data['old_undertaking_letter'];
                }
                if ($data['ca_certificate']['name'] != '') {
                    $certificate                       = $this->uploadFiles('capital-subsidy', $data['ca_certificate']);
                    $capitalSubsidyOne->ca_certificate = $certificate['filename'];
                } else {
                    $capitalSubsidyOne->ca_certificate = $data['old_ca_certificate'];
                }
                if ($data['certificate_from_hod']['name'] != '') {
                    $certificate                             = $this->uploadFiles('capital-subsidy', $data['certificate_from_hod']);
                    $capitalSubsidyOne->certificate_from_hod = $certificate['filename'];
                } else {
                    $capitalSubsidyOne->certificate_from_hod = $data['old_certificate_from_hod'];
                }
                if ($data['space_availability_proof']['name'] != '') {
                    $certificate                                 = $this->uploadFiles('capital-subsidy', $data['space_availability_proof']);
                    $capitalSubsidyOne->space_availability_proof = $certificate['filename'];
                } else {
                    $capitalSubsidyOne->space_availability_proof = $data['old_space_availability_proof'];
                }
                if ($data['proof_incubator_operation']['name'] != '') {
                    $certificate                                  = $this->uploadFiles('capital-subsidy', $data['proof_incubator_operation']);
                    $capitalSubsidyOne->proof_incubator_operation = $certificate['filename'];
                } else {
                    $capitalSubsidyOne->proof_incubator_operation = $data['old_proof_incubator_operation'];
                }
                if ($data['cancelled_cheque']['name'] != '') {
                    $certificate                         = $this->uploadFiles('capital-subsidy', $data['cancelled_cheque']);
                    $capitalSubsidyOne->cancelled_cheque = $certificate['filename'];
                } else {
                    $capitalSubsidyOne->cancelled_cheque = $data['old_cancelled_cheque'];
                }
                if ($data['claimed_expenses_bill']['name'] != '') {
                    $certificate                              = $this->uploadFiles('capital-subsidy', $data['claimed_expenses_bill']);
                    $capitalSubsidyOne->claimed_expenses_bill = $certificate['filename'];
                } else {
                    $capitalSubsidyOne->claimed_expenses_bill = $data['old_claimed_expenses_bill'];
                }
                if ($data['payment_proof']['name'] != '') {
                    $certificate                      = $this->uploadFiles('capital-subsidy', $data['payment_proof']);
                    $capitalSubsidyOne->payment_proof = $certificate['filename'];
                } else {
                    $capitalSubsidyOne->payment_proof = $data['old_payment_proof'];
                }
                if ($data['detailed_project_report']['name'] != '') {
                    $certificate                                = $this->uploadFiles('capital-subsidy', $data['detailed_project_report']);
                    $capitalSubsidyOne->detailed_project_report = $certificate['filename'];
                } else {
                    $capitalSubsidyOne->detailed_project_report = $data['old_detailed_project_report'];
                }
                $capitalSubsidyOne->application_status_id    = 1;
                $capitalSubsidyOne->application_stage_id     = 1;
                $capitalSubsidyOne->incubator_application_id = $application['id'];
                $capitalSubsidyOne->created                  = date('Y-m-d H:i:s');
                if ($this->IncubatorCapitalSubsidyPhaseOne->save($capitalSubsidyOne)) {
                    $capitalSubsidyOne_id = $capitalSubsidyOne->id;
                    $this->Flash->success(__('Successfully Saved.'));
                    return $this->redirect(['action' => 'CapitalSubsidyPhaseOnePreview', base64_encode($capitalSubsidyOne_id)]);
                }
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        } else {
            $this->Flash->error(__('You have not applied for any Incubator.'));
            $this->redirect(['controller' => 'Dashboard']);
        }
        $this->loadModel('Designations');
        $designations = $this->Designations->find('list')->where(['status' => 1])->order(['name ASC']);
        $this->set(compact('capitalSubsidyOne', 'application', 'designations'));
    }

    public function capitalSubsidyPhaseOnePreview($id = '')
    {
        $this->loadModel('IncubatorCapitalSubsidyPhaseOne');
        $id            = base64_decode($id);
        $incentiveData = $this->IncubatorCapitalSubsidyPhaseOne->findById($id)->first();
        if (empty($incentiveData)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'CapitalSubsidyPhaseOne']);
        }
        $capitalSubsidyOne = $this->IncubatorCapitalSubsidyPhaseOne->get($id, ['contain' => ['Designations']]);

        if ($this->request->is(['post', 'put'])) {
            $data                                     = $this->request->getData();
            $capitalSubsidyOne->application_status_id = 1;
            $capitalSubsidyOne->application_stage_id  = 1;
            $capitalSubsidyOne->created               = date('Y-m-d H:i:s');
            if ($this->IncubatorCapitalSubsidyPhaseOne->save($capitalSubsidyOne)) {
                $capitalSubsidyOne_id = $capitalSubsidyOne->id;
                $reference_no         = $this->capitalSubsidyOneReferenceNo($capitalSubsidyOne_id);
                $query                = $this->IncubatorCapitalSubsidyPhaseOne->query();
                $query->update()
                    ->set(['reference_number' => $reference_no])
                    ->where(['id' => $capitalSubsidyOne_id])
                    ->execute();
                $this->Flash->success(__("Thanks for your application, Please note Reference number ( $reference_no ) for further communication. "));
                return $this->redirect(['controller' => 'Dashboard', 'action' => 'index']);
            }
            $this->Flash->error(__('Some error occurred. Please, try again.'));
        }
        $this->set(compact('capitalSubsidyOne'));
    }

    public function capitalSubsidyOneReferenceNo($id)
    {
        $string = '';
        $string .= 'CS1/' . date('dmY') . '/';
        $string .= str_pad(($id), 5, 0, STR_PAD_LEFT);
        return $string;
    }

    public function apiCapitalSubsidyPhaseTwo()
    {
        if ($this->isDevice == false) {
            return $this->redirect(['controller' => 'Dashboard', 'action' => 'index']);
        }
        $this->loadModel('IncubatorCapitalSubsidyPhaseTwo');
        $this->request->allowMethod(['get', 'post']);
        $_status  = false;
        $_message = '';

        $_IncubatorBaseUrl = Router::Url('/files/incubator', true);
        $_BaseUrl          = Router::Url('/files/capital-subsidy', true);

        $_incubator              = new \stdClass();
        $_capitalSubsidyPhaseTwo = new \stdClass();

        if ($this->request->is(['post'])) {
            $applicationId = $this->request->getData('applicationId');
            $userId        = $this->request->getData('userId');
        } else {
            $applicationId = $this->request->getQuery('applicationId');
            $userId        = $this->request->getQuery('userId');
        }
        if (!empty($userId)) {
            $where     = [];
            $where[]   = ['user_id' => $userId];
            $incubator = $this->Incubators->find('all', ['contain' => ['IncubatorDirectors']])->where($where)->first();
            if (!empty($incubator) && empty($incubator->incubator_certificate_no)) {
                $_message = __('Your application is being considered but has not yet been approved.');
            } else if (empty($incubator)) {
                $_message = __('You have not applied for any Incubator.');
            } else {
                $capitalSubsidyPhaseTwo = (!empty($applicationId)) ? $this->IncubatorCapitalSubsidyPhaseTwo->get($applicationId)->first() : $this->IncubatorCapitalSubsidyPhaseTwo->newEntity();
            }
        } else {
            $_message = __('UserID is required');
        }
        if (!empty($incubator)) {
            $_incubator = $incubator;
        }
        if (!empty($capitalSubsidyPhaseTwo) && !$capitalSubsidyPhaseTwo->isNew()) {
            $_capitalSubsidyPhaseTwo = $capitalSubsidyPhaseTwo;
        }
        if (empty($_message) && $this->request->is(['post'])) {
            $postData = $this->request->getData();

            $postData['incubator_application_id'] = $incubator->id;
            $postData['application_status_id']    = 1;
            $postData['application_stage_id']     = 1;
            if ($capitalSubsidyPhaseTwo->isNew()) {
                $postData['created'] = date('Y-m-d H:i:s');
            }
            /** Document **/
            $capitalSubsidyPhaseTwoFiles = ['registration_certificate', 'applicant_certificate', 'association_memorandum', 'authorization_letter', 'undertaking_letter', 'ca_certificate', 'certificate_from_hod', 'space_availability_proof', 'proof_incubator_operation', 'cancelled_cheque', 'claimed_expenses_bill', 'payment_proof', 'detailed_project_report'];
            foreach ($capitalSubsidyPhaseTwoFiles as $field) {
                if (isset($postData[$field]) && $postData[$field]['name'] != '') {
                    $uploaded = $this->uploadFiles('capital-subsidy', $postData[$field]);
                    if (isset($uploaded['filename'])) {
                        $postData[$field] = $uploaded['filename'];
                    } else {
                        unset($postData[$field]);
                    }
                } else if (isset($postData[$field])) {
                    unset($postData[$field]);
                }
            }
            //Save
            $capitalSubsidyPhaseTwoSave = $this->IncubatorCapitalSubsidyPhaseTwo->patchEntity($capitalSubsidyPhaseTwo, $postData);
            if ($this->IncubatorCapitalSubsidyPhaseTwo->save($capitalSubsidyPhaseTwoSave)) {
                $applicationId = $capitalSubsidyPhaseTwoSave->id;
                $referenceNo   = $capitalSubsidyPhaseTwoSave->reference_number;
                if (empty($referenceNo)) {
                    $referenceNo = $this->capitalSubsidyTwoReferenceNo($applicationId);
                    $this->IncubatorCapitalSubsidyPhaseTwo->query()
                        ->update()
                        ->set(['reference_number' => $referenceNo])
                        ->where(['id' => $applicationId])
                        ->execute();
                    $capitalSubsidyPhaseTwoSave->reference_number = $referenceNo;
                }
                $_message = __("Thanks for your application, Please note Reference number ( {0} ) for further communication. ", [$referenceNo]);
                $_status  = true;

                $_capitalSubsidyPhaseTwo = $capitalSubsidyPhaseTwoSave;
            } else {
                $_message = __("Your application could not be saved. Please, try again.");
            }
        } else if (empty($_message)) {
            $_status = true;
        }
        $this->set([
            '_status'                 => $_status,
            '_incubator'              => $_incubator,
            '_capitalSubsidyPhaseTwo' => $_capitalSubsidyPhaseTwo,
            '_IncubatorBaseUrl'       => $_IncubatorBaseUrl,
            '_BaseUrl'                => $_BaseUrl,
            '_message'                => $_message,
            '_serialize'              => [
                '_status', '_incubator', '_capitalSubsidyPhaseTwo', '_IncubatorBaseUrl', '_BaseUrl', '_message',
            ],
        ]);
    }

    public function CapitalSubsidyPhaseTwo($id = '')
    {
        $this->loadModel('Incubators');
        $application = $this->Incubators->find()->where(['user_id' => $this->Auth->user('id')])->first();
        if (!empty($application)) {
            if (empty($application['incubator_certificate_no'])) {
                $this->Flash->error(__('Your application is being considered but has not yet been approved.'));
                $this->redirect(['controller' => 'Dashboard']);
            }
            $this->loadModel('IncubatorCapitalSubsidyPhaseTwo');
            $id            = base64_decode($id);
            $incentiveData = $this->IncubatorCapitalSubsidyPhaseTwo->findById($id)->first();
            if (empty($incentiveData)) {
                $capitalSubsidyTwo = $this->IncubatorCapitalSubsidyPhaseTwo->newEntity();
            } else {
                $capitalSubsidyTwo = $this->IncubatorCapitalSubsidyPhaseTwo->get($id);
            }
            if ($this->request->is(['post', 'put'])) {
                $data              = $this->request->getData();
                $data              = $this->Sanitize->clean($data);
                $capitalSubsidyTwo = $this->IncubatorCapitalSubsidyPhaseTwo->patchEntity($capitalSubsidyTwo, $data);
                if ($data['registration_certificate']['name'] != '') {
                    $certificate                                 = $this->uploadFiles('capital-subsidy', $data['registration_certificate']);
                    $capitalSubsidyTwo->registration_certificate = $certificate['filename'];
                } else {
                    $capitalSubsidyTwo->registration_certificate = $data['old_registration_certificate'];
                }
                if ($data['applicant_certificate']['name'] != '') {
                    $certificate                              = $this->uploadFiles('capital-subsidy', $data['applicant_certificate']);
                    $capitalSubsidyTwo->applicant_certificate = $certificate['filename'];
                } else {
                    $capitalSubsidyTwo->applicant_certificate = isset($data['old_applicant_certificate']) ? $data['old_applicant_certificate'] : null;
                }
                if ($data['association_memorandum']['name'] != '') {
                    $certificate                               = $this->uploadFiles('capital-subsidy', $data['association_memorandum']);
                    $capitalSubsidyTwo->association_memorandum = $certificate['filename'];
                } else {
                    $capitalSubsidyTwo->association_memorandum = isset($data['old_association_memorandum']) ? $data['old_association_memorandum'] : null;
                }
                if ($data['authorization_letter']['name'] != '') {
                    $certificate                             = $this->uploadFiles('capital-subsidy', $data['authorization_letter']);
                    $capitalSubsidyTwo->authorization_letter = $certificate['filename'];
                } else {
                    $capitalSubsidyTwo->authorization_letter = $data['old_authorization_letter'];
                }
                if ($data['undertaking_letter']['name'] != '') {
                    $certificate                           = $this->uploadFiles('capital-subsidy', $data['undertaking_letter']);
                    $capitalSubsidyTwo->undertaking_letter = $certificate['filename'];
                } else {
                    $capitalSubsidyTwo->undertaking_letter = $data['old_undertaking_letter'];
                }
                if ($data['ca_certificate']['name'] != '') {
                    $certificate                       = $this->uploadFiles('capital-subsidy', $data['ca_certificate']);
                    $capitalSubsidyTwo->ca_certificate = $certificate['filename'];
                } else {
                    $capitalSubsidyTwo->ca_certificate = $data['old_ca_certificate'];
                }
                if ($data['certificate_from_hod']['name'] != '') {
                    $certificate                             = $this->uploadFiles('capital-subsidy', $data['certificate_from_hod']);
                    $capitalSubsidyTwo->certificate_from_hod = $certificate['filename'];
                } else {
                    $capitalSubsidyTwo->certificate_from_hod = $data['old_certificate_from_hod'];
                }
                if ($data['space_availability_proof']['name'] != '') {
                    $certificate                                 = $this->uploadFiles('capital-subsidy', $data['space_availability_proof']);
                    $capitalSubsidyTwo->space_availability_proof = $certificate['filename'];
                } else {
                    $capitalSubsidyTwo->space_availability_proof = $data['old_space_availability_proof'];
                }
                if ($data['proof_incubator_operation']['name'] != '') {
                    $certificate                                  = $this->uploadFiles('capital-subsidy', $data['proof_incubator_operation']);
                    $capitalSubsidyTwo->proof_incubator_operation = $certificate['filename'];
                } else {
                    $capitalSubsidyTwo->proof_incubator_operation = $data['old_proof_incubator_operation'];
                }
                if ($data['cancelled_cheque']['name'] != '') {
                    $certificate                         = $this->uploadFiles('capital-subsidy', $data['cancelled_cheque']);
                    $capitalSubsidyTwo->cancelled_cheque = $certificate['filename'];
                } else {
                    $capitalSubsidyTwo->cancelled_cheque = $data['old_cancelled_cheque'];
                }
                if ($data['claimed_expenses_bill']['name'] != '') {
                    $certificate                              = $this->uploadFiles('capital-subsidy', $data['claimed_expenses_bill']);
                    $capitalSubsidyTwo->claimed_expenses_bill = $certificate['filename'];
                } else {
                    $capitalSubsidyTwo->claimed_expenses_bill = $data['old_claimed_expenses_bill'];
                }
                if ($data['payment_proof']['name'] != '') {
                    $certificate                      = $this->uploadFiles('capital-subsidy', $data['payment_proof']);
                    $capitalSubsidyTwo->payment_proof = $certificate['filename'];
                } else {
                    $capitalSubsidyTwo->payment_proof = $data['old_payment_proof'];
                }
                if ($data['detailed_project_report']['name'] != '') {
                    $certificate                                = $this->uploadFiles('capital-subsidy', $data['detailed_project_report']);
                    $capitalSubsidyTwo->detailed_project_report = $certificate['filename'];
                } else {
                    $capitalSubsidyTwo->detailed_project_report = $data['old_detailed_project_report'];
                }
                $capitalSubsidyTwo->application_status_id    = 1;
                $capitalSubsidyTwo->application_stage_id     = 1;
                $capitalSubsidyTwo->incubator_application_id = $application['id'];
                $capitalSubsidyTwo->created                  = date('Y-m-d H:i:s');
                if ($this->IncubatorCapitalSubsidyPhaseTwo->save($capitalSubsidyTwo)) {
                    $capitalSubsidyTwo_id = $capitalSubsidyTwo->id;
                    $this->Flash->success(__('Successfully Saved.'));
                    return $this->redirect(['action' => 'CapitalSubsidyPhaseTwoPreview', base64_encode($capitalSubsidyTwo_id)]);
                }
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        } else {
            $this->Flash->error(__('You have not applied for any Incubator.'));
            $this->redirect(['controller' => 'Dashboard']);
        }
        $this->loadModel('Designations');
        $designations = $this->Designations->find('list')->where(['status' => 1])->order(['name ASC']);
        $this->set(compact('capitalSubsidyTwo', 'application', 'designations'));
    }

    public function CapitalSubsidyPhaseTwoPreview($id = '')
    {
        $this->loadModel('IncubatorCapitalSubsidyPhaseTwo');
        $id            = base64_decode($id);
        $incentiveData = $this->IncubatorCapitalSubsidyPhaseTwo->findById($id)->first();
        if (empty($incentiveData)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'CapitalSubsidyPhaseTwo']);
        }
        $capitalSubsidyTwo = $this->IncubatorCapitalSubsidyPhaseTwo->get($id, ['contain' => ['Designations']]);

        if ($this->request->is(['post', 'put'])) {
            $data                                     = $this->request->getData();
            $capitalSubsidyTwo->application_status_id = 1;
            $capitalSubsidyTwo->application_stage_id  = 1;
            $capitalSubsidyTwo->created               = date('Y-m-d H:i:s');
            if ($this->IncubatorCapitalSubsidyPhaseTwo->save($capitalSubsidyTwo)) {
                $capitalSubsidyTwo_id = $capitalSubsidyTwo->id;
                $reference_no         = $this->capitalSubsidyTwoReferenceNo($capitalSubsidyTwo_id);
                $query                = $this->IncubatorCapitalSubsidyPhaseTwo->query();
                $query->update()
                    ->set(['reference_number' => $reference_no])
                    ->where(['id' => $capitalSubsidyTwo_id])
                    ->execute();
                $this->Flash->success(__("Thanks for your application, Please note Reference number ( $reference_no ) for further communication. "));
                return $this->redirect(['controller' => 'Dashboard', 'action' => 'index']);
            }
            $this->Flash->error(__('Some error occurred. Please, try again.'));
        }
        $this->set(compact('capitalSubsidyTwo'));
    }

    public function capitalSubsidyTwoReferenceNo($id)
    {
        $string = '';
        $string .= 'CS2/' . date('dmY') . '/';
        $string .= str_pad(($id), 5, 0, STR_PAD_LEFT);
        return $string;
    }

    public function apiCapitalSubsidyPhaseThree()
    {
        if ($this->isDevice == false) {
            return $this->redirect(['controller' => 'Dashboard', 'action' => 'index']);
        }
        $this->loadModel('IncubatorCapitalSubsidyPhaseThree');
        $this->request->allowMethod(['get', 'post']);
        $_status  = false;
        $_message = '';

        $_IncubatorBaseUrl = Router::Url('/files/incubator', true);
        $_BaseUrl          = Router::Url('/files/capital-subsidy', true);

        $_incubator                = new \stdClass();
        $_capitalSubsidyPhaseThree = new \stdClass();

        if ($this->request->is(['post'])) {
            $applicationId = $this->request->getData('applicationId');
            $userId        = $this->request->getData('userId');
        } else {
            $applicationId = $this->request->getQuery('applicationId');
            $userId        = $this->request->getQuery('userId');
        }
        if (!empty($userId)) {
            $where     = [];
            $where[]   = ['user_id' => $userId];
            $incubator = $this->Incubators->find('all', ['contain' => ['IncubatorDirectors']])->where($where)->first();
            if (!empty($incubator) && empty($incubator->incubator_certificate_no)) {
                $_message = __('Your application is being considered but has not yet been approved.');
            } else if (empty($incubator)) {
                $_message = __('You have not applied for any Incubator.');
            } else {
                $capitalSubsidyPhaseThree = (!empty($applicationId)) ? $this->IncubatorCapitalSubsidyPhaseThree->get($applicationId)->first() : $this->IncubatorCapitalSubsidyPhaseThree->newEntity();
            }
        } else {
            $_message = __('UserID is required');
        }
        if (!empty($incubator)) {
            $_incubator = $incubator;
        }
        if (!empty($capitalSubsidyPhaseThree) && !$capitalSubsidyPhaseThree->isNew()) {
            $_capitalSubsidyPhaseThree = $capitalSubsidyPhaseThree;
        }
        if (empty($_message) && $this->request->is(['post'])) {
            $postData = $this->request->getData();

            $postData['incubator_application_id'] = $incubator->id;
            $postData['application_status_id']    = 1;
            $postData['application_stage_id']     = 1;
            if ($capitalSubsidyPhaseThree->isNew()) {
                $postData['created'] = date('Y-m-d H:i:s');
            }
            /** Document **/
            $capitalSubsidyPhaseThreeFiles = ['registration_certificate', 'applicant_certificate', 'association_memorandum', 'authorization_letter', 'undertaking_letter', 'ca_certificate', 'certificate_from_hod', 'space_availability_proof', 'proof_incubator_operation', 'cancelled_cheque', 'claimed_expenses_bill', 'payment_proof', 'detailed_project_report'];
            foreach ($capitalSubsidyPhaseThreeFiles as $field) {
                if (isset($postData[$field]) && $postData[$field]['name'] != '') {
                    $uploaded = $this->uploadFiles('capital-subsidy', $postData[$field]);
                    if (isset($uploaded['filename'])) {
                        $postData[$field] = $uploaded['filename'];
                    } else {
                        unset($postData[$field]);
                    }
                } else if (isset($postData[$field])) {
                    unset($postData[$field]);
                }
            }
            //Save
            $capitalSubsidyPhaseThreeSave = $this->IncubatorCapitalSubsidyPhaseThree->patchEntity($capitalSubsidyPhaseThree, $postData);
            if ($this->IncubatorCapitalSubsidyPhaseThree->save($capitalSubsidyPhaseThreeSave)) {
                $applicationId = $capitalSubsidyPhaseThreeSave->id;
                $referenceNo   = $capitalSubsidyPhaseThreeSave->reference_number;
                if (empty($referenceNo)) {
                    $referenceNo = $this->capitalSubsidyThreeReferenceNo($applicationId);
                    $this->IncubatorCapitalSubsidyPhaseThree->query()
                        ->update()
                        ->set(['reference_number' => $referenceNo])
                        ->where(['id' => $applicationId])
                        ->execute();
                    $capitalSubsidyPhaseThreeSave->reference_number = $referenceNo;
                }
                $_message = __("Thanks for your application, Please note Reference number ( {0} ) for further communication. ", [$referenceNo]);
                $_status  = true;

                $_capitalSubsidyPhaseThree = $capitalSubsidyPhaseThreeSave;
            } else {
                $_message = __("Your application could not be saved. Please, try again.");
            }
        } else if (empty($_message)) {
            $_status = true;
        }
        $this->set([
            '_status'                   => $_status,
            '_incubator'                => $_incubator,
            '_capitalSubsidyPhaseThree' => $_capitalSubsidyPhaseThree,
            '_IncubatorBaseUrl'         => $_IncubatorBaseUrl,
            '_BaseUrl'                  => $_BaseUrl,
            '_message'                  => $_message,
            '_serialize'                => [
                '_status', '_incubator', '_capitalSubsidyPhaseThree', '_IncubatorBaseUrl', '_BaseUrl', '_message',
            ],
        ]);
    }

    public function CapitalSubsidyPhaseThree($id = '')
    {
        $this->loadModel('Incubators');
        $application = $this->Incubators->find()->where(['user_id' => $this->Auth->user('id')])->first();
        if (!empty($application)) {
            if (empty($application['incubator_certificate_no'])) {
                $this->Flash->error(__('Your application is being considered but has not yet been approved.'));
                $this->redirect(['controller' => 'Dashboard']);
            }
            $this->loadModel('IncubatorCapitalSubsidyPhaseThree');
            $id            = base64_decode($id);
            $incentiveData = $this->IncubatorCapitalSubsidyPhaseThree->findById($id)->first();
            if (empty($incentiveData)) {
                $capitalSubsidyThree = $this->IncubatorCapitalSubsidyPhaseThree->newEntity();
            } else {
                $capitalSubsidyThree = $this->IncubatorCapitalSubsidyPhaseThree->get($id);
            }
            if ($this->request->is(['post', 'put'])) {
                $data                = $this->request->getData();
                $data                = $this->Sanitize->clean($data);
                $capitalSubsidyThree = $this->IncubatorCapitalSubsidyPhaseThree->patchEntity($capitalSubsidyThree, $data);
                if ($data['registration_certificate']['name'] != '') {
                    $certificate                                   = $this->uploadFiles('capital-subsidy', $data['registration_certificate']);
                    $capitalSubsidyThree->registration_certificate = $certificate['filename'];
                } else {
                    $capitalSubsidyThree->registration_certificate = $data['old_registration_certificate'];
                }
                if ($data['applicant_certificate']['name'] != '') {
                    $certificate                                = $this->uploadFiles('capital-subsidy', $data['applicant_certificate']);
                    $capitalSubsidyThree->applicant_certificate = $certificate['filename'];
                } else {
                    $capitalSubsidyThree->applicant_certificate = isset($data['old_applicant_certificate']) ? $data['old_applicant_certificate'] : null;
                }
                if ($data['association_memorandum']['name'] != '') {
                    $certificate                                 = $this->uploadFiles('capital-subsidy', $data['association_memorandum']);
                    $capitalSubsidyThree->association_memorandum = $certificate['filename'];
                } else {
                    $capitalSubsidyThree->association_memorandum = isset($data['old_association_memorandum']) ? $data['old_association_memorandum'] : null;
                }
                if ($data['authorization_letter']['name'] != '') {
                    $certificate                               = $this->uploadFiles('capital-subsidy', $data['authorization_letter']);
                    $capitalSubsidyThree->authorization_letter = $certificate['filename'];
                } else {
                    $capitalSubsidyThree->authorization_letter = $data['old_authorization_letter'];
                }
                if ($data['undertaking_letter']['name'] != '') {
                    $certificate                             = $this->uploadFiles('capital-subsidy', $data['undertaking_letter']);
                    $capitalSubsidyThree->undertaking_letter = $certificate['filename'];
                } else {
                    $capitalSubsidyThree->undertaking_letter = $data['old_undertaking_letter'];
                }
                if ($data['ca_certificate']['name'] != '') {
                    $certificate                         = $this->uploadFiles('capital-subsidy', $data['ca_certificate']);
                    $capitalSubsidyThree->ca_certificate = $certificate['filename'];
                } else {
                    $capitalSubsidyThree->ca_certificate = $data['old_ca_certificate'];
                }
                if ($data['certificate_from_hod']['name'] != '') {
                    $certificate                               = $this->uploadFiles('capital-subsidy', $data['certificate_from_hod']);
                    $capitalSubsidyThree->certificate_from_hod = $certificate['filename'];
                } else {
                    $capitalSubsidyThree->certificate_from_hod = $data['old_certificate_from_hod'];
                }
                if ($data['space_availability_proof']['name'] != '') {
                    $certificate                                   = $this->uploadFiles('capital-subsidy', $data['space_availability_proof']);
                    $capitalSubsidyThree->space_availability_proof = $certificate['filename'];
                } else {
                    $capitalSubsidyThree->space_availability_proof = $data['old_space_availability_proof'];
                }
                if ($data['proof_incubator_operation']['name'] != '') {
                    $certificate                                    = $this->uploadFiles('capital-subsidy', $data['proof_incubator_operation']);
                    $capitalSubsidyThree->proof_incubator_operation = $certificate['filename'];
                } else {
                    $capitalSubsidyThree->proof_incubator_operation = $data['old_proof_incubator_operation'];
                }
                if ($data['cancelled_cheque']['name'] != '') {
                    $certificate                           = $this->uploadFiles('capital-subsidy', $data['cancelled_cheque']);
                    $capitalSubsidyThree->cancelled_cheque = $certificate['filename'];
                } else {
                    $capitalSubsidyThree->cancelled_cheque = $data['old_cancelled_cheque'];
                }
                if ($data['claimed_expenses_bill']['name'] != '') {
                    $certificate                                = $this->uploadFiles('capital-subsidy', $data['claimed_expenses_bill']);
                    $capitalSubsidyThree->claimed_expenses_bill = $certificate['filename'];
                } else {
                    $capitalSubsidyThree->claimed_expenses_bill = $data['old_claimed_expenses_bill'];
                }
                if ($data['payment_proof']['name'] != '') {
                    $certificate                        = $this->uploadFiles('capital-subsidy', $data['payment_proof']);
                    $capitalSubsidyThree->payment_proof = $certificate['filename'];
                } else {
                    $capitalSubsidyThree->payment_proof = $data['old_payment_proof'];
                }
                if ($data['detailed_project_report']['name'] != '') {
                    $certificate                                  = $this->uploadFiles('capital-subsidy', $data['detailed_project_report']);
                    $capitalSubsidyThree->detailed_project_report = $certificate['filename'];
                } else {
                    $capitalSubsidyThree->detailed_project_report = $data['old_detailed_project_report'];
                }
                $capitalSubsidyThree->application_status_id    = 1;
                $capitalSubsidyThree->application_stage_id     = 1;
                $capitalSubsidyThree->incubator_application_id = $application['id'];
                $capitalSubsidyThree->created                  = date('Y-m-d H:i:s');
                if ($this->IncubatorCapitalSubsidyPhaseThree->save($capitalSubsidyThree)) {
                    $capitalSubsidyThree_id = $capitalSubsidyThree->id;
                    $this->Flash->success(__('Successfully Saved.'));
                    return $this->redirect(['action' => 'CapitalSubsidyPhaseThreePreview', base64_encode($capitalSubsidyThree_id)]);
                }
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        } else {
            $this->Flash->error(__('You have not applied for any Incubator.'));
            $this->redirect(['controller' => 'Dashboard']);
        }
        $this->loadModel('Designations');
        $designations = $this->Designations->find('list')->where(['status' => 1])->order(['name ASC']);
        $this->set(compact('capitalSubsidyThree', 'application', 'designations'));
    }

    public function capitalSubsidyPhaseThreePreview($id = '')
    {
        $this->loadModel('IncubatorCapitalSubsidyPhaseThree');
        $id            = base64_decode($id);
        $incentiveData = $this->IncubatorCapitalSubsidyPhaseThree->findById($id)->first();
        if (empty($incentiveData)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'CapitalSubsidyPhaseThree']);
        }
        $capitalSubsidyThree = $this->IncubatorCapitalSubsidyPhaseThree->get($id, ['contain' => ['Designations']]);

        if ($this->request->is(['post', 'put'])) {
            $data                                       = $this->request->getData();
            $capitalSubsidyThree->application_status_id = 1;
            $capitalSubsidyThree->application_stage_id  = 1;
            $capitalSubsidyThree->created               = date('Y-m-d H:i:s');
            if ($this->IncubatorCapitalSubsidyPhaseThree->save($capitalSubsidyThree)) {
                $capitalSubsidyThree_id = $capitalSubsidyThree->id;
                $reference_no           = $this->capitalSubsidyThreeReferenceNo($capitalSubsidyThree_id);
                $query                  = $this->IncubatorCapitalSubsidyPhaseThree->query();
                $query->update()
                    ->set(['reference_number' => $reference_no])
                    ->where(['id' => $capitalSubsidyThree_id])
                    ->execute();
                $this->Flash->success(__("Thanks for your application, Please note Reference number ( $reference_no ) for further communication. "));
                return $this->redirect(['controller' => 'Dashboard', 'action' => 'index']);
            }
            $this->Flash->error(__('Some error occurred. Please, try again.'));
        }
        $this->set(compact('capitalSubsidyThree'));
    }

    public function capitalSubsidyThreeReferenceNo($id)
    {
        $string = '';
        $string .= 'CS3/' . date('dmY') . '/';
        $string .= str_pad(($id), 5, 0, STR_PAD_LEFT);
        return $string;
    }

}
