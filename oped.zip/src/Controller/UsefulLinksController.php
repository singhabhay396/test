<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Core\Configure;
use Cake\Event\Event;
use Cake\Network\Exception\NotFoundException;
use Cake\View\Exception\MissingTemplateException;

/**
 * OnlineEnquiry Controller
 *
 * @property \App\Model\Table\OnlineEnquiryTable $OnlineEnquiry
 *
 * @method \App\Model\Entity\OnlineEnquiry[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class UsefulLinksController extends AppController
{
    public function initialize()
    {
        parent::initialize();
        $this->viewBuilder()->setLayout('frontend');
        $this->Auth->allow(['index']);
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }
	
	

    /**
     * Page method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $usefulLinks = $this->UsefulLinks->find('all');
        $this->set('usefulLinks',$usefulLinks);
    }
}