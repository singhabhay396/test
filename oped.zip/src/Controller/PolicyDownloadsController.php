<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Core\Configure;
use Cake\Event\Event;
use Cake\Network\Exception\NotFoundException;
use Cake\View\Exception\MissingTemplateException;
use Cake\Routing\Router;

/**
 * PolicyDownloads Controller
 *
 * @property \App\Model\Table\PolicyDownloadsTable $PolicyDownloads
 *
 * @method \App\Model\Entity\Tender[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class PolicyDownloadsController extends AppController
{
    public $policycategory = ['1'=>'Notifications issued','2'=>'Guidelines for Incubators and Startups','3'=>'Progress Report/ Minutes of meetings','4'=>'Amendments in Acts'];

	public function initialize()
    {
        parent::initialize();
        $this->viewBuilder()->setLayout('frontend');
        $this->Auth->allow(['index', 'page','incubatorStartups','notifications','AmendmentsActs']);
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }
    
    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        return $this->redirect(['action' => 'notifications']);
        $search_condition = array();
        $keyword = trim($this->request->getData('keyword'));
        $keyword = $this->Sanitize->stripAll( $keyword);
        $keyword = $this->Sanitize->clean( $keyword);
        $this->set('keyword', $keyword);
        if (!empty($keyword)) {            
            $search_condition[] = "PolicyDownloads.title like '%" . $keyword . "%'";
        }
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        $policy = $this->PolicyDownloads->find('all')
            ->select([
                'id',
                'title'   => "IF(PolicyDownloadTranslation.title != '',PolicyDownloadTranslation.title,PolicyDownloads.title)",
                'status','created','modified','policy_date','upload_document' 
            ])
            ->contain([
                'PolicyDownloadTranslation' => function ($q) {
                    if (Configure::check('language')) {
                        $q->where(['PolicyDownloadTranslation.culture' => Configure::read('language.culture')]);
                    } else {
                        $q->where(['PolicyDownloadTranslation.language_id' => 0]);
                    }
                    return $q;
                },
            ])
            ->where(['status' => 1])
            ->order(['PolicyDownloads.created'=>'DESC']);
        $this->paginate = ['limit' => 15];
        $policy = $this->paginate($policy);
        $policycategory = $this->policycategory;
        $this->set('policy', $policy,'policycategory');
    }

        /**
     * Notifications method
     *
     * @return \Cake\Http\Response|void
     */
    public function notifications()
    {
		$search_condition = array();
		if($this->isDevice) {
            $this->request->allowMethod(['get']);
            
            $_status = false;
            $_message = '';
			
			$totalCounts = 0;
			$totalPages = 0;
			$pageSize = 0;
			$pageIndex = 0;
		}
		
        $keyword = trim($this->request->getData('keyword'));
        $keyword = $this->Sanitize->stripAll( $keyword);
        $keyword = $this->Sanitize->clean( $keyword);
        $this->set('keyword', $keyword);
        if (!empty($keyword)) {            
            $search_condition[] = "PolicyDownloads.title like '%" . $keyword . "%'";
        }
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
		
        $policy = $this->PolicyDownloads->find('all')
            ->select([
                'id',
                'title'   => "IF(PolicyDownloadTranslation.title != '',PolicyDownloadTranslation.title,PolicyDownloads.title)",
                'status','created','modified','policy_date','upload_document' 
            ])
            ->contain([
                'PolicyDownloadTranslation' => function ($q) {
                    if (Configure::check('language')) {
                        $q->where(['PolicyDownloadTranslation.culture' => Configure::read('language.culture')]);
                    } else {
                        $q->where(['PolicyDownloadTranslation.language_id' => 0]);
                    }
                    return $q;
                },
            ])
            ->where(['status' => 1,'policy_category_id'=>1])
            ->order(['PolicyDownloads.created'=>'DESC']);
        $this->paginate = ['limit' => 15];
		
		try{
			$policy = $this->paginate($policy);
		}catch(HttpNotFoundException $e){
			$policy = array();
		}
		//echo "<pre>";print_r($policy);exit;
		if($this->isDevice) {
			$paging = $this->Paginator->getPaginator()->getPagingParams();
            //echo "<pre>";print_r($paging);exit;
			if (!empty($paging['PolicyDownloads'])) {
				$totalCounts = $paging['PolicyDownloads']['count'];
				$totalPages = $paging['PolicyDownloads']['pageCount'];
				$pageSize  = $paging['PolicyDownloads']['perPage'];
				$pageIndex = $paging['PolicyDownloads']['current'];
			}
			if($totalCounts != 0 && !empty($policy)){
				$_status = true;
				$_message = 'Notification Found';
				if(!empty($policy)){
					foreach($policy as $plc){
						$plc->upload_document = Router::url('/',true) . 'files/policy_downloads/' . $plc->upload_document;
						$plc->created = $plc->created->format('Y-m-d');
						$plc->modified = $plc->modified->format('Y-m-d');
						$plc->policy_date = $plc->policy_date->format('Y-m-d');
					}
				}
			}else{
				$_message = 'Notification not found';
			}
			//echo "<pre>";print_r($event);exit;
			$this->set(compact(
				'_status','_message','totalCounts','totalPages','pageSize','pageIndex','policy'
			));
			$this->set('_serialize', [
				'_status','_message','totalCounts','totalPages','pageSize','pageIndex','policy'
			]);
		}else{
            $policycategory = $this->policycategory;
			$this->set('policy', $policy,'policycategory');
        }
    }

    /**
     * AmendmentsInActs method
     *
     * @return \Cake\Http\Response|void
     */
    public function AmendmentsActs()
    {
        $search_condition = array();
		if($this->isDevice) {
			$this->request->allowMethod(['get']);
			
			$_status = false;
			$_message = '';
			
			$totalCounts = 0;
			$totalPages = 0;
			$pageSize = 0;
			$pageIndex = 0;
		}
		
        $keyword = trim($this->request->getData('keyword'));
        $keyword = $this->Sanitize->stripAll( $keyword);
        $keyword = $this->Sanitize->clean( $keyword);
        $this->set('keyword', $keyword);
        if (!empty($keyword)) {            
            $search_condition[] = "PolicyDownloads.title like '%" . $keyword . "%'";
        }
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        $policy = $this->PolicyDownloads->find('all')
            ->select([
                'id',
                'title'   => "IF(PolicyDownloadTranslation.title != '',PolicyDownloadTranslation.title,PolicyDownloads.title)",
                'status','created','modified','policy_date','upload_document' 
            ])
            ->contain([
                'PolicyDownloadTranslation' => function ($q) {
                    if (Configure::check('language')) {
                        $q->where(['PolicyDownloadTranslation.culture' => Configure::read('language.culture')]);
                    } else {
                        $q->where(['PolicyDownloadTranslation.language_id' => 0]);
                    }
                    return $q;
                },
            ])
            ->where(['status' => 1,'policy_category_id'=>4])
            ->order(['PolicyDownloads.created'=>'DESC']);
        $this->paginate = ['limit' => 15];
		
		try{
			$policy = $this->paginate($policy);
		}catch(HttpNotFoundException $e){
			$policy = array();
		}
		//echo "<pre>";print_r($policy);exit;
		if($this->isDevice) {
			$paging = $this->Paginator->getPaginator()->getPagingParams();
			//echo "<pre>";print_r($paging);exit;
			if (!empty($paging['PolicyDownloads'])) {
				$totalCounts = $paging['PolicyDownloads']['count'];
				$totalPages = $paging['PolicyDownloads']['pageCount'];
				$pageSize  = $paging['PolicyDownloads']['perPage'];
				$pageIndex = $paging['PolicyDownloads']['current'];
			}
			if($totalCounts != 0 && !empty($policy)){
				$_status = true;
				$_message = 'Notification Found';
				if(!empty($policy)){
					foreach($policy as $plc){
						$plc->upload_document = Router::url('/',true) . 'files/policy_downloads/' . $plc->upload_document;
						$plc->created = $plc->created->format('Y-m-d');
						$plc->modified = $plc->modified->format('Y-m-d');
						$plc->policy_date = $plc->policy_date->format('Y-m-d');
					}
				}
			}else{
				$_message = 'Notification not found';
			}
			//echo "<pre>";print_r($event);exit;
			$this->set(compact(
				'_status','_message','totalCounts','totalPages','pageSize','pageIndex','policy'
			));
			$this->set('_serialize', [
				'_status','_message','totalCounts','totalPages','pageSize','pageIndex','policy'
			]);
		}else{
			$policycategory = $this->policycategory;
			$this->set('policy', $policy,'policycategory');
		}
    }

    public function EventReports()
    {
        $search_condition = array();
		if($this->isDevice) {
			$this->request->allowMethod(['get']);
			
			$_status = false;
			$_message = '';
			
			$totalCounts = 0;
			$totalPages = 0;
			$pageSize = 0;
			$pageIndex = 0;
		}
		
        $keyword = trim($this->request->getData('keyword'));
        $keyword = $this->Sanitize->stripAll( $keyword);
        $keyword = $this->Sanitize->clean( $keyword);
        $this->set('keyword', $keyword);
        if (!empty($keyword)) {            
            $search_condition[] = "PolicyDownloads.title like '%" . $keyword . "%'";
        }
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        $policy = $this->PolicyDownloads->find('all')
            ->select([
                'id',
                'title'   => "IF(PolicyDownloadTranslation.title != '',PolicyDownloadTranslation.title,PolicyDownloads.title)",
                'status','created','modified','policy_date','upload_document' 
            ])
            ->contain([
                'PolicyDownloadTranslation' => function ($q) {
                    if (Configure::check('language')) {
                        $q->where(['PolicyDownloadTranslation.culture' => Configure::read('language.culture')]);
                    } else {
                        $q->where(['PolicyDownloadTranslation.language_id' => 0]);
                    }
                    return $q;
                },
            ])
            ->where(['status' => 1,'policy_category_id'=>5])
            ->order(['PolicyDownloads.created'=>'DESC']);
        $this->paginate = ['limit' => 15];
        
		try{
			$policy = $this->paginate($policy);
		}catch(HttpNotFoundException $e){
			$policy = array();
		}
		//echo "<pre>";print_r($policy);exit;
		if($this->isDevice) {
			$paging = $this->Paginator->getPaginator()->getPagingParams();
			//echo "<pre>";print_r($paging);exit;
			if (!empty($paging['PolicyDownloads'])) {
				$totalCounts = $paging['PolicyDownloads']['count'];
				$totalPages = $paging['PolicyDownloads']['pageCount'];
				$pageSize  = $paging['PolicyDownloads']['perPage'];
				$pageIndex = $paging['PolicyDownloads']['current'];
			}
			if($totalCounts != 0 && !empty($policy)){
				$_status = true;
				$_message = 'Event Reports Found';
				if(!empty($policy)){
					foreach($policy as $plc){
						$plc->upload_document = Router::url('/',true) . 'files/policy_downloads/' . $plc->upload_document;
						$plc->created = $plc->created->format('Y-m-d');
						$plc->modified = $plc->modified->format('Y-m-d');
						$plc->policy_date = $plc->policy_date->format('Y-m-d');
					}
				}
			}else{
				$_message = 'Event Reports not found';
			}
			//echo "<pre>";print_r($event);exit;
			$this->set(compact(
				'_status','_message','totalCounts','totalPages','pageSize','pageIndex','policy'
			));
			$this->set('_serialize', [
				'_status','_message','totalCounts','totalPages','pageSize','pageIndex','policy'
			]);
		}else{
			$policycategory = $this->policycategory;
			$this->set(compact('policy','policycategory'));
		}
    }
    /**
     * Page method
     *
     * @return \Cake\Http\Response|void
     */


    public function  incubatorStartups(){
        $search_condition = array();
        $keyword = trim($this->request->getData('keyword'));
        $keyword = $this->Sanitize->stripAll( $keyword);
        $keyword = $this->Sanitize->clean( $keyword);
        $this->set('keyword', $keyword);
        if (!empty($keyword)) {            
            $search_condition[] = "PolicyDownloads.title like '%" . $keyword . "%'";
        }
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        $policy = $this->PolicyDownloads->find('all')
            ->select([
                'id',
                'title'   => "IF(PolicyDownloadTranslation.title != '',PolicyDownloadTranslation.title,PolicyDownloads.title)",
                'status','created','modified','policy_date','upload_document' 
            ])
            ->contain([
                'PolicyDownloadTranslation' => function ($q) {
                    if (Configure::check('language')) {
                        $q->where(['PolicyDownloadTranslation.culture' => Configure::read('language.culture')]);
                    } else {
                        $q->where(['PolicyDownloadTranslation.language_id' => 0]);
                    }
                    return $q;
                },
            ])
            ->where(['status' => 1,'policy_category_id'=>2])
            ->order(['PolicyDownloads.created'=>'DESC']);
        $this->paginate = ['limit' => 15];
        $policy = $this->paginate($policy);
        $policycategory = $this->policycategory;
        $this->set('policy', $policy,'policycategory');
    }

    public function page($event_id)
    {
        $event = $this->PolicyDownloads->findById($event_id)
            ->select([
                'id',
                'title'   => "IF(PolicyDownloadTranslations.title != '',PolicyDownloadTranslations.title,PolicyDownloads.title)",
                'subtitle'   => "IF(PolicyDownloadTranslations.subtitle != '',PolicyDownloadTranslations.subtitle,PolicyDownloads.subtitle)",
                'excerpt' => "IF(PolicyDownloadTranslations.excerpt != '',PolicyDownloadTranslations.excerpt,PolicyDownloads.excerpt)",
                'content' => "IF(PolicyDownloadTranslations.content != '',PolicyDownloadTranslations.content,PolicyDownloads.content)",
                'url'     => "IF(PolicyDownloadTranslations.url != '',PolicyDownloadTranslations.url,PolicyDownloads.url)",
                'slug','status','created','updated','meta_title','meta_keywords','meta_description','header_image','date','venue','event_type'
            ])
            ->contain([
                'PolicyDownloadTranslations' => function ($q) {
                    if (Configure::check('language')) {
                        $q->where(['PolicyDownloadTranslations.culture' => Configure::read('language.culture')]);
                    } else {
                        $q->where(['PolicyDownloadTranslations.language_id' => 0]);
                    }
                    return $q;
                },'EventImages'
            ])
            ->where(['status' => 1])->first();
        if (empty($event)) {
            throw new NotFoundException(__('Policy Download not found'));
        }

        $_template = 'page_' . $event->id;

        $this->set('event', $event);

        try {
            $this->render($_template);
        } catch (MissingTemplateException $e) {
            $this->render('page');
        }
    }
}