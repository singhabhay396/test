<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Core\Configure;
use Cake\Event\Event;
use Cake\Network\Exception\NotFoundException;
use Cake\View\Exception\MissingTemplateException;
use Cake\Routing\Router;

/**
 * Events Controller
 *
 * @property \App\Model\Table\EventsTable $Events
 *
 * @method \App\Model\Entity\Tender[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class EventsController extends AppController
{
	public function initialize()
    {
        parent::initialize();
        $this->viewBuilder()->setLayout('frontend');
        $this->Auth->allow(['index', 'page']);
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }
    
    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
		$search_condition = array();
		if($this->isDevice) {
            $this->request->allowMethod(['get']);
            
            $_status = false;
            $_message = '';
			
			$totalCounts = 0;
			$totalPages = 0;
			$pageSize = 0;
			$pageIndex = 0;
		}
		
        $keyword = trim($this->request->getData('keyword'));
        $keyword = $this->Sanitize->stripAll( $keyword);
        $keyword = $this->Sanitize->clean( $keyword);
        $this->set('keyword', $keyword);
        if (!empty($keyword)) {            
            $search_condition[] = "Events.title like '%" . $keyword . "%'";
        }
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
		
        $event = $this->Events->find('all')
            ->select([
                'id',
                'title'   => "IF(EventTranslation.title != '',EventTranslation.title,Events.title)",
                'subtitle'   => "IF(EventTranslation.subtitle != '',EventTranslation.subtitle,Events.subtitle)",
                'excerpt' => "IF(EventTranslation.excerpt != '',EventTranslation.excerpt,Events.excerpt)",
                'content' => "IF(EventTranslation.content != '',EventTranslation.content,Events.content)",
                'url'     => "IF(EventTranslation.url != '',EventTranslation.url,Events.url)",
                'slug','status','created','updated','meta_title','meta_keywords','meta_description','header_image','date','venue'
            ])
            ->contain([
                'EventTranslation' => function ($q) {
                    if (Configure::check('language')) {
                        $q->where(['EventTranslation.culture' => Configure::read('language.culture')]);
                    } else {
                        $q->where(['EventTranslation.language_id' => 0]);
                    }
                    return $q;
                },
            ])
            ->where(['status' => 1])
            ->order(['Events.date'=>'DESC']);
        
		$this->paginate = ['limit' => 12];
		
		try{
			$event = $this->paginate($event);
		}catch(HttpNotFoundException $e){
			$event = array();
		}
		//echo "<pre>";print_r($event);exit;
		if($this->isDevice) {
			$paging = $this->Paginator->getPaginator()->getPagingParams();
			if (!empty($paging['Events'])) {
				$totalCounts = $paging['Events']['count'];
				$totalPages = $paging['Events']['pageCount'];
				$pageSize  = $paging['Events']['perPage'];
				$pageIndex = $paging['Events']['current'];
			}
			if($totalCounts != 0 && !empty($event)){
				$_status = true;
				$_message = 'Events Found';
				if(!empty($event)){
					foreach($event as $eve){
						$eve->header_image = Router::url('/',true) . 'files/events/' . $eve->header_image;
						$eve->date = $eve->date->format('Y-m-d');
						$eve->created = $eve->created->format('Y-m-d');
						if(!empty($eve->updated)){
							$eve->updated = $eve->updated->format('Y-m-d');
						}
					}
				}
			}else{
				$_message = 'Events not found';
			}
			//echo "<pre>";print_r($event);exit;
			$this->set(compact(
				'_status','_message','totalCounts','totalPages','pageSize','pageIndex','event'
			));
			$this->set('_serialize', [
				'_status','_message','totalCounts','totalPages','pageSize','pageIndex','event'
			]);
		}else{
			$this->set('event', $event);
		}
    }

    /**
     * Page method
     *
     * @return \Cake\Http\Response|void
     */
    public function page($event_id)
    {
		if($this->isDevice) {
            $this->request->allowMethod(['get']);
            
            $_status = false;
            $_message = '';
			
			$language = 'en';
			if(!empty($this->request->params) && !empty($this->request->params['language'])){
				$language = $this->request->params['language'];
			}
		}
        $event = $this->Events->findById($event_id)
            ->select([
                'id',
                'title'   => "IF(EventTranslation.title != '',EventTranslation.title,Events.title)",
                'subtitle'   => "IF(EventTranslation.subtitle != '',EventTranslation.subtitle,Events.subtitle)",
                'excerpt' => "IF(EventTranslation.excerpt != '',EventTranslation.excerpt,Events.excerpt)",
                'content' => "IF(EventTranslation.content != '',EventTranslation.content,Events.content)",
                'url'     => "IF(EventTranslation.url != '',EventTranslation.url,Events.url)",
                'slug','status','created','updated','meta_title','meta_keywords','meta_description','header_image','date','venue','event_type'
            ])
            ->contain([
                'EventTranslation' => function ($q) {
                    if (Configure::check('language')) {
                        $q->where(['EventTranslation.culture' => Configure::read('language.culture')]);
                    } else {
                        $q->where(['EventTranslation.language_id' => 0]);
                    }
                    return $q;
                },'EventImages'
            ])
            ->where(['status' => 1])->first();
        if (empty($event)) {
			if($this->isDevice) {
				$_message = 'Tender not found';
			}else{
				throw new NotFoundException(__('Tender not found'));
			}
        }
		
		if($this->isDevice) {
            $_status = true;
            $_message = 'Tender found';
			
			if(!empty($event)){
				$event->header_image = Router::url('/',true) . 'files/events/' . $event->header_image;
				$event->date = $event->date->format('Y-m-d');
				$event->created = $event->created->format('Y-m-d');
				$event->updated = $event->updated->format('Y-m-d');
				
				if(!empty($event['event_images'])){
					foreach($event['event_images'] as $eveImage){
						$eveImage->event_image = Router::url('/',true) . 'files/events/' . $eveImage->event_image;
					}
				}
			}
            //echo "<pre>";print_r($event);exit;
            //$content = $event->content;
            
            $this->set(compact('_status','_message','language','event'));
			$this->set('_serialize', ['_status','_message','language','event']);
        }
		
        $_template = 'page_' . $event->id;
		
        $this->set('event', $event);
		
        try {
            $this->render($_template);
        } catch (MissingTemplateException $e) {
            $this->render('page');
        }
    }
	
	public function getEvent()
    {
		if(!$this->isDevice) {
			return $this->redirect(['controller' => 'Events', 'action' => 'index']);
		}
        $this->request->allowMethod(['get']);
        $this->loadModel('Events');
        
        $_status       = false;
        $_message      = '';
		$title = $content = $imageURL = $description = $date = $venue = $event_type = '';
		$event_images = array();
        $event_id = $this->request->getQuery('event_id');
        if (!empty($event_id)) {
			$event = $this->Events->findById($event_id)
				->select([
					'id',
					'title'   => "IF(EventTranslation.title != '',EventTranslation.title,Events.title)",
					'subtitle'   => "IF(EventTranslation.subtitle != '',EventTranslation.subtitle,Events.subtitle)",
					'excerpt' => "IF(EventTranslation.excerpt != '',EventTranslation.excerpt,Events.excerpt)",
					'content' => "IF(EventTranslation.content != '',EventTranslation.content,Events.content)",
					'url'     => "IF(EventTranslation.url != '',EventTranslation.url,Events.url)",
					'slug','status','created','updated','meta_title','meta_keywords','meta_description','header_image','date','venue','event_type'
				])
				->contain([
					'EventTranslation' => function ($q) {
						if (Configure::check('language')) {
							$q->where(['EventTranslation.culture' => Configure::read('language.culture')]);
						} else {
							$q->where(['EventTranslation.language_id' => 0]);
						}
						return $q;
					},'EventImages'
				])
				->where(['status' => 1])->first();
		}
		
        if (empty($event)) {
			$_message = 'Tender not found';
        }else{
			$_status = true;
			$_message = 'Tender found';
			//echo "<pre>";print_r($event);exit;
			
			$title = $event->title;
			$content = $event->content;
			$date = $event->date->format('Y-m-d');
			$venue = $event->venue;
			$event_type = $event->event_type;
			$imageURL = Router::url('/',true) . 'files/events/' . $event->header_image;
			if(!empty($event->event_images)){
				foreach($event->event_images as $imgs){
					$event_images[] = Router::url('/',true) . 'files/events/' . $imgs->event_image;
				}
			}
		}
		
		$this->set(compact(
			'_status','_message','title','content','date','venue','event_type','imageURL','event_images'
		));
		$this->set('_serialize', [
			'_status','_message','title','content','date','venue','event_type','imageURL','event_images'
		]);
    }
}