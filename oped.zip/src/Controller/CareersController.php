<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Core\Configure;
use Cake\Event\Event;
use Cake\Network\Exception\NotFoundException;
use Cake\View\Exception\MissingTemplateException;

/**
 * Careers Controller
 *
 * @property \App\Model\Table\CareersTable $Careers
 *
 * @method \App\Model\Entity\Tender[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class CareersController extends AppController
{

    public function initialize()
    {
        parent::initialize();
        $this->viewBuilder()->setLayout('frontend');
        $this->Auth->allow(['index', 'page','archived']);
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }
    
    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $search_condition = array();
        $keyword = trim($this->request->getData('keyword'));
        $keyword = $this->Sanitize->stripAll( $keyword);
        $keyword = $this->Sanitize->clean( $keyword);
        $this->set('keyword', $keyword);
        if (!empty($keyword)) {            
            $search_condition[] = "Careers.title like '%" . $keyword . "%'";
        }
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        $career = $this->Careers->find('all')
            ->select([
                'id',
                'title'   => "IF(CareerTranslation.title != '',CareerTranslation.title,Careers.title)",
                'excerpt' => "IF(CareerTranslation.excerpt != '',CareerTranslation.excerpt,Careers.excerpt)",
                'content' => "IF(CareerTranslation.content != '',CareerTranslation.content,Careers.content)",
                'url'     => "IF(CareerTranslation.url != '',CareerTranslation.url,Careers.url)",
                'slug','start_date','expiry_date','status','is_archive','created','updated','meta_title','meta_keywords','meta_description'
            ])
            ->contain([
                'CareerTranslation' => function ($q) {
                    if (Configure::check('language')) {
                        $q->where(['CareerTranslation.culture' => Configure::read('language.culture')]);
                    } else {
                        $q->where(['CareerTranslation.language_id' => 0]);
                    }
                    return $q;
                },
                'CareerDocuments' => function ($q) {
                    if (Configure::check('language')) {
                        $q->where(['CareerDocuments.culture' => Configure::read('language.culture')]);
                    } else {
                        $q->where(['CareerDocuments.language_id' => 0]);
                    }
                    return $q;
                },
            ])
            ->where(['status' => 1,'is_archive' => 0,$searchString, 'expiry_date >=' => date('Y-m-d'),
            ])
            ->order(['Careers.created'=>'DESC']);
            //])->where(['status' => 1,'is_archive' => 0,$searchString])->order(['Careers.created'=>'DESC']);
        $this->paginate = ['limit' => 15];
        $career = $this->paginate($career);
        $this->set('career', $career);
    }

    /**
     * Page method
     *
     * @return \Cake\Http\Response|void
     */
    public function page($career_id)
    {
        $career = $this->Careers->findById($career_id)
            ->select([
                'id',
                'title'   => "IF(CareerTranslation.title != '',CareerTranslation.title,Careers.title)",
                'excerpt' => "IF(CareerTranslation.excerpt != '',CareerTranslation.excerpt,Careers.excerpt)",
                'content' => "IF(CareerTranslation.content != '',CareerTranslation.content,Careers.content)",
                'url'     => "IF(CareerTranslation.url != '',CareerTranslation.url,Careers.url)",
                'slug','start_date','expiry_date','status','is_archive','created','updated','meta_title','meta_keywords','meta_description'
            ])
            ->contain([
                'CareerTranslation' => function ($q) {
                    if (Configure::check('language')) {
                        $q->where(['CareerTranslation.culture' => Configure::read('language.culture')]);
                    } else {
                        $q->where(['CareerTranslation.language_id' => 0]);
                    }
                    return $q;
                },
                'CareerDocuments' => function ($q) {
                    if (Configure::check('language')) {
                        $q->where(['CareerDocuments.culture' => Configure::read('language.culture')]);
                    } else {
                        $q->where(['CareerDocuments.language_id' => 0]);
                    }
                    return $q;
                },
            ])
            ->where(['status' => 1])->first();
        if (empty($career)) {
            throw new NotFoundException(__('Tender not found'));
        }

        $_template = 'page_' . $career->id;

        $this->set('career', $career);

        try {
            $this->render($_template);
        } catch (MissingTemplateException $e) {
            $this->render('page');
        }
    }

     /**
     * Archived method
     *
     * @return \Cake\Http\Response|void
     */
    public function archived()
    {
        $search_condition = array();
        $keyword = trim($this->request->getData('keyword'));
        $keyword = $this->Sanitize->stripAll( $keyword);
        $keyword = $this->Sanitize->clean( $keyword);
        $this->set('keyword', $keyword);
        if (!empty($keyword)) {
            $search_condition[] = "Careers.title like '%" . $keyword . "%'";
        }
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        $career = $this->Careers->find('all')
            ->select([
                'id',
                'title'   => "IF(CareerTranslation.title != '',CareerTranslation.title,Careers.title)",
                'excerpt' => "IF(CareerTranslation.excerpt != '',CareerTranslation.excerpt,Careers.excerpt)",
                'content' => "IF(CareerTranslation.content != '',CareerTranslation.content,Careers.content)",
                'url'     => "IF(CareerTranslation.url != '',CareerTranslation.url,Careers.url)",
                'slug','start_date','expiry_date','status','is_archive','created','updated','meta_title','meta_keywords','meta_description'
            ])->contain([
                'CareerTranslation' => function ($q) {
                    if (Configure::check('language')) {
                        $q->where(['CareerTranslation.culture' => Configure::read('language.culture')]);
                    } else {
                        $q->where(['CareerTranslation.language_id' => 0]);
                    }
                    return $q;
                },
                'CareerDocuments' => function ($q) {
                    if (Configure::check('language')) {
                        $q->where(['CareerDocuments.culture' => Configure::read('language.culture')]);
                    } else {
                        $q->where(['CareerDocuments.language_id' => 0]);
                    }
                    return $q;
                },
            ])->where([
                'OR'=>[
                    'expiry_date <=' => date('Y-m-d'),
                    'is_archive' => 1,
                ],
                'status' => 1,$searchString,
            ])->order(['Careers.start_date'=>'DESC','Careers.expiry_date'=>'DESC']); 
            //])->where(['status' => 1,'is_archive' => 1,$searchString])->order(['Careers.start_date'=>'DESC','Careers.expiry_date'=>'DESC']);
        $this->paginate = ['limit' => 15];
        $career = $this->paginate($career);
        $this->set('career', $career);
    }
}
