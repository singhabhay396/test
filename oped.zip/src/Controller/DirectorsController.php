<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Core\Configure;
use Cake\Event\Event;
use Cake\Network\Exception\NotFoundException;
use Cake\View\Exception\MissingTemplateException;

/**
 * Directors Controller
 *
 * @property \App\Model\Table\DirectorsTable $Directors
 *
 * @method \App\Model\Entity\Tender[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class DirectorsController extends AppController
{

    public function initialize()
    {
        parent::initialize();
        $this->viewBuilder()->setLayout('frontend');
        $this->Auth->allow(['index','page']);
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */

    public function index()
    {
        $director = $this->Directors->find('all')
            ->select([
                'id',
                'title'   => "IF(DirectorTranslation.title != '',DirectorTranslation.title,Directors.title)",
                'excerpt'    => "IF(DirectorTranslation.excerpt != '',DirectorTranslation.excerpt,Directors.excerpt)",
                'content' => "IF(DirectorTranslation.content != '',DirectorTranslation.content,Directors.content)",
                'url'     => "IF(DirectorTranslation.url != '',DirectorTranslation.url,Directors.url)",
                'images',
                'header_image',
                'is_main',
                'status',
                'created'
            ])
            ->contain([
                'DirectorTranslation' => function ($q) {
                    if (Configure::check('language')) {
                        $q->where(['DirectorTranslation.culture' => Configure::read('language.culture')]);
                    } else {
                        $q->where(['DirectorTranslation.language_id' => 0]);
                    }
                    return $q;
                }
            ])
            ->where(['status' => 1])
            ->order(['sort_order'=>'ASC']);
        if (empty($director)) {
            throw new NotFoundException(__('Director not found'));
        }
        $this->paginate = ['limit' => 15];
        $director = $this->paginate($director);
        $this->set(compact('director'));
    }

    /**
     * Page method
     *
     * @return \Cake\Http\Response|void
     */
    public function page($director_id)
    {
        $select = [
                'id',
                'title'   => "IF(DirectorTranslation.title != '',DirectorTranslation.title,Directors.title)",
                'excerpt'    => "IF(DirectorTranslation.excerpt != '',DirectorTranslation.excerpt,Directors.excerpt)",
                'content' => "IF(DirectorTranslation.content != '',DirectorTranslation.content,Directors.content)",
                'url'     => "IF(DirectorTranslation.url != '',DirectorTranslation.url,Directors.url)",
                'images',
                'header_image',
                'is_main',
                'status',
                'created',
            ];
        $director = $this->Directors->findById($director_id)
            ->select($select)
            ->contain([
                'DirectorTranslation' => function ($q) {
                    if (Configure::check('language')) {
                        $q->where(['DirectorTranslation.culture' => Configure::read('language.culture')]);
                    } else {
                        $q->where(['DirectorTranslation.language_id' => 0]);
                    }
                    return $q;
                }
            ])
            ->where(['status' => 1])->first();

        if (empty($director)) {
            throw new NotFoundException(__('Director not found'));
        }
        $_template = 'page_' . $director->id;
        
        if (!empty($director->slug)) {
            $_template = 'page_' . $director->slug;
        }
        $this->set(compact('director'));
        try {
            $this->render($_template);
        } catch (MissingTemplateException $e) {
            $this->render('page');
        }
    }
}