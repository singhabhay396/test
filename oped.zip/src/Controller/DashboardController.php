<?php
namespace App\Controller;

use App\View\Helper\SilverFormHelper;
use Cake\Controller\Controller;
use Cake\Event\Event;
use Cake\Mailer\Email;
use Cake\ORM\TableRegistry;
use Cake\Utility\Text;
use Cake\View\View;
use Cake\Core\Configure;

/**
 * Users Controller
 *
 * @property \App\Model\Table\UsersTable $Users
 */
class DashboardController extends AppController
{
   public function initialize()
   {
      parent::initialize();
    
      $this->SilverForm = new SilverFormHelper(new View());
      //$this->Auth->allow(['index']);
      $this->viewBuilder()->setLayout('dashboard');
   }

   public function beforeFilter(Event $event)
   {
      parent::beforeFilter($event);
   }
	 
    public function index(){
      $this->viewBuilder()->layout('frontend');
      $this->loadModel('Users');
      $this->loadModel('StartupApplications');
      $this->loadModel('Incubators');
      $this->loadModel('Mentors');
      $this->loadModel('Partners');
      $this->loadModel('IndustryAssociations');
      $this->loadModel('Investors');
      $this->loadModel('Events');
      $user           = $this->Users->get($this->Auth->user('id'),['contain'=>['Registration.States','Registration.Districts','Registration.Designations','Roles']]);
      $checkStartup   = $this->StartupApplications->findByUserId($this->Auth->user('id'))->first();
      $checkIncubator = $this->Incubators->findByUserId($this->Auth->user('id'))->first();
      $checkMentor    = $this->Mentors->findByUserId($this->Auth->user('id'))->first();
      $checkPartner   = $this->Partners->findByUserId($this->Auth->user('id'))->first();
      $checkIndustry  = $this->IndustryAssociations->findByUserId($this->Auth->user('id'))->first();
      $checkInvestor  = $this->Investors->findByUserId($this->Auth->user('id'))->first();
      $events = $this->Events->find()->where(['status'=>1])->order(['created'=>'DESC'])->limit(10)->toArray();
      $this->set(compact('checkInvestor','checkIndustry','checkPartner','checkMentor','user','checkStartup','checkIncubator','events'));
    }

   public function t($string, array $args = array(), array $options = array()) {
      global $language;
      static $custom_strings;

      // Merge in default.
      if (empty($options['langcode'])) {
        $options['langcode'] = isset($language->language) ? $language->language : 'en';
      }
      if (empty($options['context'])) {
        $options['context'] = '';
      }

      // First, check for an array of customized strings. If present, use the array
      // *instead of* database lookups. This is a high performance way to provide a
      // handful of string replacements. See settings.php for examples.
      // Cache the $custom_strings variable to improve performance.
      if (!isset($custom_strings[$options['langcode']])) {
        $custom_strings[$options['langcode']] = variable_get('locale_custom_strings_' . $options['langcode'], array());
      }

      // Custom strings work for English too, even if locale module is disabled.
      if (isset($custom_strings[$options['langcode']][$options['context']][$string])) {
        $string = $custom_strings[$options['langcode']][$options['context']][$string];
      }
      elseif ($options['langcode'] != 'en' && function_exists('locale')) {
        $string = locale($string, $options['context'], $options['langcode']);
      }
      if (empty($args)) {
        return $string;
      }
      else {
        return format_string($string, $args);
      }
    }

    function format_string($string, array $args = array()) {
      // Transform arguments before inserting them.
      foreach ($args as $key => $value) {
        switch ($key[0]) {
          case '@':

            // Escaped only.
            $args[$key] = check_plain($value);
            break;
          case '%':
          default:

            // Escaped and placeholder.
            $args[$key] = drupal_placeholder($value);
            break;
          case '!':
        }
      }
      return strtr($string, $args);
    }

}
