<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Core\Configure;
use Cake\Event\Event;
use Cake\Mailer\Email;
use Cake\Routing\Router;
use Cake\Network\Exception\NotFoundException;
use Cake\View\Exception\MissingTemplateException;

/**
 * OnlineEnquiry Controller
 *
 * @property \App\Model\Table\OnlineEnquiryTable $OnlineEnquiry
 *
 * @method \App\Model\Entity\OnlineEnquiry[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class GrievancesController extends AppController
{   

    public $grievancetype = ['1'=>'Technical Query','2'=>'Public Procurement','3'=>'Regulatory issue'];

    public function initialize()
    {
        parent::initialize();
        $this->viewBuilder()->setLayout('frontend');
        $this->Auth->allow(['captcha']);        
        $this->loadComponent('CakephpCaptcha.Captcha');
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }

    /**
     * Page method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->loadModel('Grievances');
        $grievance = $this->Grievances->newEntity(); 
        if ($this->request->is('post')) {
            $data       = $this->request->getData(); 
            $grievance  = $this->Grievances->patchEntity($grievance,$data);
                if ($this->Grievances->save($grievance)) {
                    $this->Flash->success(__('The grievance has been submitted.'));

                    return $this->redirect(['action' => 'index']);
                }
                $this->Flash->error(__('The grievance could not be submitted. Please, try again.'));
        }    
        $grievancetype = $this->grievancetype;
        $this->set(compact('grievance','grievancetype'));      
    }
}