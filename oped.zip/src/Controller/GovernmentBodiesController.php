<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Event\Event;
use Cake\Routing\Router;

/**
 * GovernmentBodies Controller
 *
 * @property \App\Model\Table\GovernmentBodiesTable $GovernmentBodies
 *
 * @method \App\Model\Entity\GovernmentBody[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class GovernmentBodiesController extends AppController
{

    public function initialize()
    {
        parent::initialize();
        $this->viewBuilder()->setLayout('frontend');
        $this->Auth->allow(['index']);
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        if($this->isDevice) {
            $this->request->allowMethod(['get']);
            
            $_status = false;
            $_message = '';
			
			$totalCounts = 0;
			$totalPages = 0;
			$pageSize = 0;
			$pageIndex = 0;
		}
        try{
			$governmentBodies = $this->paginate($this->GovernmentBodies->find()->where(['status'=>1])->order(['created'=>'DESC']));
		}catch(HttpNotFoundException $e){
			$governmentBodies = array();
		}
        //echo "<pre>";print_r($governmentBodies);exit;
        if($this->isDevice) {
			$paging = $this->Paginator->getPaginator()->getPagingParams();
            //echo "<pre>";print_r($paging);exit;
			if (!empty($paging['GovernmentBodies'])) {
				$totalCounts = $paging['GovernmentBodies']['count'];
				$totalPages = $paging['GovernmentBodies']['pageCount'];
				$pageSize  = $paging['GovernmentBodies']['perPage'];
				$pageIndex = $paging['GovernmentBodies']['current'];
			}
			if($totalCounts != 0 && !empty($governmentBodies)){
				$_status = true;
				$_message = 'Government Bodies Found';
				if(!empty($governmentBodies)){
					foreach($governmentBodies as $gb){
						$gb->image = Router::url('/',true) . 'files/government_bodies/' . $gb->image;
						$gb->created = $gb->created->format('Y-m-d');
						$gb->modified = $gb->modified->format('Y-m-d');
					}
				}
			}else{
				$_message = 'Government Bodies not found';
			}
			//echo "<pre>";print_r($event);exit;
			$this->set(compact(
				'_status','_message','totalCounts','totalPages','pageSize','pageIndex','governmentBodies'
			));
			$this->set('_serialize', [
				'_status','_message','totalCounts','totalPages','pageSize','pageIndex','governmentBodies'
			]);
		}else{
            $this->set(compact('governmentBodies'));
        }
    }
}