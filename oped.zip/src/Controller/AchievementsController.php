<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Core\Configure;
use Cake\Event\Event;
use Cake\Network\Exception\NotFoundException;
use Cake\View\Exception\MissingTemplateException;

/**
 * Achievements Controller
 *
 * @property \App\Model\Table\AchievementsTable $Achievements
 *
 * @method \App\Model\Entity\Tender[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class AchievementsController extends AppController
{
	public function initialize()
    {
        parent::initialize();
        $this->viewBuilder()->setLayout('frontend');
        $this->Auth->allow(['index', 'page']);
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }
    
    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $search_condition = array();
        $keyword = trim($this->request->getData('keyword'));
        $keyword = $this->Sanitize->stripAll( $keyword);
        $keyword = $this->Sanitize->clean( $keyword);
        $this->set('keyword', $keyword);
        if (!empty($keyword)) {            
            $search_condition[] = "Achievements.title like '%" . $keyword . "%'";
        }
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        $achievement = $this->Achievements->find('all')
            ->select([
                'id',
                'title'   => "IF(AchievementTranslation.title != '',AchievementTranslation.title,Achievements.title)",
                'subtitle'   => "IF(AchievementTranslation.subtitle != '',AchievementTranslation.subtitle,Achievements.subtitle)",
                'excerpt' => "IF(AchievementTranslation.excerpt != '',AchievementTranslation.excerpt,Achievements.excerpt)",
                'content' => "IF(AchievementTranslation.content != '',AchievementTranslation.content,Achievements.content)",
                'url'     => "IF(AchievementTranslation.url != '',AchievementTranslation.url,Achievements.url)",
                'slug','status','created','modified','meta_title','meta_keywords','meta_description','header_image','achievement_date'
            ])
            ->contain([
                'AchievementTranslation' => function ($q) {
                    if (Configure::check('language')) {
                        $q->where(['AchievementTranslation.culture' => Configure::read('language.culture')]);
                    } else {
                        $q->where(['AchievementTranslation.language_id' => 0]);
                    }
                    return $q;
                },
            ])
            ->where(['status' => 1])
            ->order(['Achievements.created'=>'DESC']);
        $this->paginate = ['limit' => 15];
        $achievement = $this->paginate($achievement);
        $this->set('achievement', $achievement);
    }

    /**
     * Page method
     *
     * @return \Cake\Http\Response|void
     */
    public function page($achievement_id)
    {
        $achievement = $this->Achievements->findById($achievement_id)
            ->select([
                'id',
                'title'   => "IF(AchievementTranslation.title != '',AchievementTranslation.title,Achievements.title)",
                'subtitle'   => "IF(AchievementTranslation.subtitle != '',AchievementTranslation.subtitle,Achievements.subtitle)",
                'excerpt' => "IF(AchievementTranslation.excerpt != '',AchievementTranslation.excerpt,Achievements.excerpt)",
                'content' => "IF(AchievementTranslation.content != '',AchievementTranslation.content,Achievements.content)",
                'url'     => "IF(AchievementTranslation.url != '',AchievementTranslation.url,Achievements.url)",
                'slug','status','created','modified','meta_title','meta_keywords','meta_description'
            ])
            ->contain([
                'AchievementTranslation' => function ($q) {
                    if (Configure::check('language')) {
                        $q->where(['AchievementTranslation.culture' => Configure::read('language.culture')]);
                    } else {
                        $q->where(['AchievementTranslation.language_id' => 0]);
                    }
                    return $q;
                },
            ])
            ->where(['status' => 1])->first();
        if (empty($achievement)) {
            throw new NotFoundException(__('Tender not found'));
        }

        $_template = 'page_' . $achievement->id;

        $this->set('achievement', $achievement);

        try {
            $this->render($_template);
        } catch (MissingTemplateException $e) {
            $this->render('page');
        }
    }
}