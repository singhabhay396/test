<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Core\Configure;
use Cake\Event\Event;
use Cake\Network\Exception\NotFoundException;
use Cake\View\Exception\MissingTemplateException;

/**
 * OnlineEnquiry Controller
 *
 * @property \App\Model\Table\OnlineEnquiryTable $OnlineEnquiry
 *
 * @method \App\Model\Entity\OnlineEnquiry[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class FaqsController extends AppController
{
    public function initialize()
    {
        parent::initialize();
        $this->viewBuilder()->setLayout('frontend');
        $this->Auth->allow(['faqCategories','index']);
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }
	
	private $faqCat = [
        1 => 'Startups',
        2 => 'Incubatee',
        3 => 'Incubation Nodal Officer'
    ];

    public function faqCategories()
    {
	if($this->isDevice) {
            $this->request->allowMethod(['get']);
            
            $_status = false;
            $_message = '';
	    
	    $language = 'en';
	    if(!empty($this->request->params) && !empty($this->request->params['language'])){
		    $language = $this->request->params['language'];
	    }
	    
	    $categories = $this->faqCat;
	    if(!empty($categories)){
		$_status = true;
		$_message = 'Faq categories found';
		
		$i=0;
		foreach($categories as $key=>$value){
		    $faq_categories[$i]['id'] = $key;
		    $faq_categories[$i]['name'] = $value;
		    $i++;
		}
		
		$this->set(compact('_status','_message','language','faq_categories'));
		$this->set('_serialize', ['_status','_message','language','faq_categories']);
	    }
        }
    }

    /**
     * Page method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
	if($this->isDevice) {
            $this->request->allowMethod(['get']);
            
            $_status = false;
            $_message = '';
	    
	    $language = 'en';
	    if(!empty($this->request->params) && !empty($this->request->params['language'])){
		$language = $this->request->params['language'];
	    }
        }
        $select = [
            'id',
            'title'   => "IF(FaqTranslation.title != '',FaqTranslation.title,Faqs.title)",
            'subtitle'   => "IF(FaqTranslation.subtitle != '',FaqTranslation.subtitle,Faqs.subtitle)",
            'content' => "IF(FaqTranslation.content != '',FaqTranslation.content,Faqs.content)",
            'status',
            'faqs_image','faq_cat',
            'created'
            ];
        if (empty($faq_id)) {
            $faqs = $this->Faqs->find('all')->select($select)->contain([
                'FaqTranslation' => function ($q) {
                    if (Configure::check('language')) {
                        $q->where(['FaqTranslation.culture' => Configure::read('language.culture')]);
                    } else {
                        $q->where(['FaqTranslation.language_id' => 0]);
                    }
                    return $q;
                }
            ])->where(['status' => 1]);
	    if($this->isDevice) {
		if(!empty($this->request->query('faq_cat'))){
		    $faqs = $faqs->andwhere(['faq_cat'=>$this->request->query('faq_cat')]);
		}
	    }
	    $faqs = $faqs->enableHydration(false)->toArray();            
        }
	if (empty($faqs)) {
	    if($this->isDevice) {
                $_message = 'Faqs not found';
            }else{
		throw new NotFoundException(__('Faqs not found'));
	    }
        }else{
	    $_status = true;
            $_message = 'Faqs found';
            
	    $i=0;
            foreach($faqs as $faq){
		$faq_data[$i] = $faq;
		$faq_data[$i]['created'] = $faq['created']->format('Y-m-d');
		$i++;
	    }
            
            $this->set(compact('_status','_message','language','faq_data'));
	    $this->set('_serialize', ['_status','_message','language','faq_data']);
	}
        // $this->paginate = ['limit' => 15];
        // $faqs = $this->paginate($faqs);
        //$this->set('faqs', $faqs);
	if(!$this->isDevice) {
		$faqCat = $this->faqCat;
		$this->set(compact('faqs','faqCat'));
	}
    }
}