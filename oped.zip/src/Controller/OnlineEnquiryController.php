<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Core\Configure;
use Cake\Event\Event;
use Cake\Mailer\Email;
use Cake\Routing\Router;
use Cake\Network\Exception\NotFoundException;
use Cake\View\Exception\MissingTemplateException;

/**
 * OnlineEnquiry Controller
 *
 * @property \App\Model\Table\OnlineEnquiryTable $OnlineEnquiry
 *
 * @method \App\Model\Entity\OnlineEnquiry[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class OnlineEnquiryController extends AppController
{
    public function initialize()
    {
        parent::initialize();
        $this->viewBuilder()->setLayout('frontend');
        $this->Auth->allow(['index','captcha','complaints','loanEnquiry']);        
        $this->loadComponent('Captcha', ['captchaConfig' => 'ContactCaptcha']);
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }

    /**
     * Page method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $onlineEnquiry = $this->OnlineEnquiry->newEntity();
        if ($this->request->is('post')) {
            if ($this->Captcha->getCode('securitycode') == $this->request->getData('securitycode')){
                $data                   = $this->request->getData();
                $onlineEnquiry->created_at = date('Y-m-d H:i:s');
                $onlineEnquiry          = $this->OnlineEnquiry->patchEntity($onlineEnquiry, $data);
                if ($this->OnlineEnquiry->save($onlineEnquiry)) {
                    $referenceNumber = "SIDBI/E/".date('Y')."/".date('m')."/".date('d')."/".str_pad($onlineEnquiry['id'],6, '00000', STR_PAD_LEFT);
                    $queryUpdate = $this->OnlineEnquiry->query();
                    $queryUpdate->update()
                        ->set(['reference_number' => $referenceNumber])
                        ->where(['id' => $onlineEnquiry['id']])
                        ->execute();

                    $sidbiMailOpt = $this->mailList($onlineEnquiry['need']);
                    $userEmail = new Email('default');
                    $userEmail->template('enquiry');
                    $userEmail->emailFormat('html');
                    $userEmail->viewVars(['referenceNumber' => $referenceNumber]);
                    $userEmail->viewVars(['emailData' => $onlineEnquiry]);
                    $userEmail->viewVars(['email' => $onlineEnquiry['emailid']]);
                    $userEmail->viewVars(['base_url' => Router::url('/', true)]);
                    $status = $userEmail->to($onlineEnquiry['emailid'])
                        //->addTo(WEBSUPPORT)
                        ->returnPath('noreply@sidbi.in')
                        ->subject('SIDBI : Your enquiry has been submitted successfully.')
                        ->returnPath('noreply@sidbi.in')
                        ->send();
                    $adminEmail = new Email('default');
                    $adminEmail->template('enquiry');
                    $adminEmail->emailFormat('html');
                    $adminEmail->viewVars(['referenceNumber' => $referenceNumber]);
                    $adminEmail->viewVars(['emailData' => $onlineEnquiry]);
                    $adminEmail->viewVars(['email' => WEBSUPPORT]);
                    $adminEmail->viewVars(['base_url' => Router::url('/', true)]);
                    $status = $adminEmail->to($sidbiMailOpt)
                        //->addTo(WEBSUPPORT)
                        ->subject('SIDBI : New Online Enquiry')
                        ->send();
                    $this->Flash->success(__('The online enquiry has been submitted.'));

                    return $this->redirect(['action' => 'index']);
                }
                $this->Flash->error(__('The online enquiry could not be submitted. Please, try again.'));
            } else {
                $this->Flash->error(__('Invalid captcha. Please, try again.'));
            }
        }
        $this->set(compact('onlineEnquiry'));
    }

    protected function mailList($sidbiMail)
    {
        $needOptions = [1=>'vcfoperations@sidbi.in',2=>'ifvrefinance@sidbi.in',3=>'ifv_nbfc@sidbi.in',4=>'ccg@sidbi.in',5=>'sfmcvert@sidbi.in',6=>'abhijitdas@sidbi.in',7=>'ifvsfb@sidbi.in',8=>'rmd_mho@sidbi.in',9=>'websupport@sidbi.in'];
        if (!empty($sidbiMail)) {
            return $needOptions[$sidbiMail];
        }

    }

    public function complaints()
    {
        $this->loadModel('Complaints');
        $complaint = $this->Complaints->newEntity();
        if ($this->request->is('post')) {
            if ($this->Captcha->getCode('securitycode') == $this->request->getData('securitycode')){
                $data               = $this->request->getData();
                $complaint->created = date('Y-m-d H:i:s');
                $complaint          = $this->Complaints->patchEntity($complaint, $data);
                if ($this->Complaints->save($complaint)) {
                    $referenceNumber = "STARTUP/G/".date('Y')."/".date('m')."/".date('d')."/".str_pad($complaint['id'],8, '00000', STR_PAD_LEFT);
                    $queryUpdate = $this->Complaints->query();
                    $queryUpdate->update()
                        ->set(['reference_number' => $referenceNumber])
                        ->where(['id' => $complaint['id']])
                        ->execute();

                    $nemail = new Email('default');
                    $nemail->template('complaint');
                    $nemail->emailFormat('html');
                    $nemail->viewVars(['referenceNumber' => $referenceNumber]);
                    $nemail->viewVars(['emailData' => $complaint]);
                    $nemail->viewVars(['email' => $complaint['email_id']]);
                    $nemail->viewVars(['base_url' => Router::url('/', true)]);
                    $status = $nemail->to($complaint['email_id'])
                        //->addTo(WEBSUPPORT)
                        ->subject('SIDBI : Online Complaints')
                        ->send();
                    $adminEmail = new Email('default');
                    $adminEmail->template('complaint');
                    $adminEmail->emailFormat('html');
                    $adminEmail->viewVars(['referenceNumber' => $referenceNumber]);
                    $adminEmail->viewVars(['emailData' => $complaint]);
                    $adminEmail->viewVars(['email' => 'complaints@sidbi.in']);
                    $adminEmail->viewVars(['base_url' => Router::url('/', true)]);
                    $status = $adminEmail->to('complaints@sidbi.in')
                        ->subject('New Complaints : SIDBI')
                        ->send();
                    $this->Flash->success(__('The online enquiry has been submitted.'));

                    return $this->redirect(['action' => 'complaints']);
                }
                $this->Flash->error(__('The online enquiry could not be submitted. Please, try again.'));
            } else {
                $this->Flash->error(__('Invalid captcha. Please, try again.'));
            }
        }
        $this->set(compact('complaint'));
    }

    public function captcha()
    {
        if (!empty($this->request->getQuery())) {
            $this->autoRender = false;
            $this->viewBuilder()->setLayout('ajax');
            $this->Captcha->create();
        } else {
            die('Access Denied..');
        }
    }
}