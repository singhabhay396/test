<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Core\Configure;
use Cake\Event\Event;
use Cake\Network\Exception\NotFoundException;
use Cake\View\Exception\MissingTemplateException;

/**
 * PressRelease Controller
 *
 * @property \App\Model\Table\PressReleaseTable $PressRelease
 *
 * @method \App\Model\Entity\Tender[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class PressReleaseController extends AppController
{

    public function initialize()
    {
        parent::initialize();
        $this->viewBuilder()->setLayout('frontend');
        $this->Auth->allow(['index','page','archived']);
        $this->loadModel('PressReleases');
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }

    /**
     * Page method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $search_condition = array();
        $keyword = trim($this->request->getData('keyword'));
        $keyword = $this->Sanitize->stripAll( $keyword);
        $keyword = $this->Sanitize->clean( $keyword);
        $this->set('keyword', $keyword);
        if (!empty($keyword)) {
            $search_condition[] = "PressReleases.title like '%" . $keyword . "%'";
        }
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        $pressRelease = $this->PressReleases->find('all')
            ->select([
                'id',
                'title'   => "IF(PressReleaseTranslation.title != '',PressReleaseTranslation.title,PressReleases.title)",
                'excerpt' => "IF(PressReleaseTranslation.excerpt != '',PressReleaseTranslation.excerpt,PressReleases.excerpt)",
                'content' => "IF(PressReleaseTranslation.content != '',PressReleaseTranslation.content,PressReleases.content)",
                'url'     => "IF(PressReleaseTranslation.url != '',PressReleaseTranslation.url,PressReleases.url)",
                'sort_order','upload_document_1','upload_document_2','custom_link','status','created','release_date','meta_title','meta_keywords','meta_description',
            ])->contain([
                'PressReleaseTranslation' => function ($q) {
                    if (Configure::check('language')) {
                        $q->where(['PressReleaseTranslation.culture' => Configure::read('language.culture')]);
                    } else {
                        $q->where(['PressReleaseTranslation.language_id' => 0]);
                    }
                    return $q;
                }
            ])
            ->where(['status' => 1,'is_archive'=>0,$searchString])->order(['PressReleases.release_date'=>'DESC']);
        $this->paginate = ['limit' => 15];
        $pressRelease = $this->paginate($pressRelease);
        $this->set('pressRelease', $pressRelease);
    }

    /**
     * Page method
     *
     * @return \Cake\Http\Response|void
     */
    public function page($press_release_id)
    {
        $pressRelease = $this->PressReleases->findById($press_release_id)
            ->select([
                'id',
                'title'   => "IF(PressReleaseTranslation.title != '',PressReleaseTranslation.title,PressReleases.title)",
                'excerpt' => "IF(PressReleaseTranslation.excerpt != '',PressReleaseTranslation.excerpt,PressReleases.excerpt)",
                'content' => "IF(PressReleaseTranslation.content != '',PressReleaseTranslation.content,PressReleases.content)",
                'url'     => "IF(PressReleaseTranslation.url != '',PressReleaseTranslation.url,PressReleases.url)",
                'sort_order','upload_document_1','upload_document_2','custom_link','status','created','release_date','meta_title','meta_keywords','meta_description',
            ])->contain([
                'PressReleaseTranslation' => function ($q) {
                    if (Configure::check('language')) {
                        $q->where(['PressReleaseTranslation.culture' => Configure::read('language.culture')]);
                    } else {
                        $q->where(['PressReleaseTranslation.language_id' => 0]);
                    }
                    return $q;
                }
            ])
            ->where(['status' => 1])->first();
        if (empty($pressRelease)) {
            throw new NotFoundException(__('Press Releases not found'));
        }
        $_template = 'page_' . $pressRelease->id;
        $this->set('pressRelease', $pressRelease);
        try {
            $this->render($_template);
        } catch (MissingTemplateException $e) {
            $this->render('page');
        }
    }

    /**
     * Archived method
     *
     * @return \Cake\Http\Response|void
     */
    public function archived()
    {
        $search_condition = array();
        $keyword = trim($this->request->getData('keyword'));
        $keyword = $this->Sanitize->stripAll( $keyword);
        $keyword = $this->Sanitize->clean( $keyword);
        $this->set('keyword', $keyword);
        if (!empty($keyword)) {
            $search_condition[] = "PressReleases.title like '%" . $keyword . "%'";
        }
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        $pressRelease = $this->PressReleases->find('all')
            ->select([
                'id',
                'title'   => "IF(PressReleaseTranslation.title != '',PressReleaseTranslation.title,PressReleases.title)",
                'excerpt' => "IF(PressReleaseTranslation.excerpt != '',PressReleaseTranslation.excerpt,PressReleases.excerpt)",
                'content' => "IF(PressReleaseTranslation.content != '',PressReleaseTranslation.content,PressReleases.content)",
                'url'     => "IF(PressReleaseTranslation.url != '',PressReleaseTranslation.url,PressReleases.url)",
                'sort_order','upload_document_1','upload_document_2','custom_link','status','created','release_date','meta_title','meta_keywords','meta_description',
            ])->contain([
                'PressReleaseTranslation' => function ($q) {
                    if (Configure::check('language')) {
                        $q->where(['PressReleaseTranslation.culture' => Configure::read('language.culture')]);
                    } else {
                        $q->where(['PressReleaseTranslation.language_id' => 0]);
                    }
                    return $q;
                }
            ])
            ->where(['status' => 1,'is_archive'=>1,$searchString])->order(['PressReleases.created'=>'DESC']);
        $this->paginate = ['limit' => 15];
        $pressRelease = $this->paginate($pressRelease);
        $this->set('pressRelease', $pressRelease);
    }

}
