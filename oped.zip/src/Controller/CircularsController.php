<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Core\Configure;
use Cake\Event\Event;
use Cake\Network\Exception\NotFoundException;
use Cake\View\Exception\MissingTemplateException;

/**
 * Circulars Controller
 *
 * @property \App\Model\Table\CircularsTable $Circulars
 *
 * @method \App\Model\Entity\Circular[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class CircularsController extends AppController
{

    public function initialize()
    {
        parent::initialize();
        $this->viewBuilder()->setLayout('frontend');
        $this->Auth->allow(['index', 'page','archived']);
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }
    
    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $search_condition = array();
        $keyword = trim($this->request->getData('keyword'));
        $keyword = $this->Sanitize->stripAll( $keyword);
        $keyword = $this->Sanitize->clean( $keyword);
        $this->set('keyword', $keyword);
        if (!empty($keyword)) {
            $search_condition[] = "Circulars.title like '%" . $keyword . "%'";
        }
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        $tender = $this->Circulars->find('all')
        ->select([
            'id',
            'title'   => "IF(CircularTranslation.title != '',CircularTranslation.title,Circulars.title)",
            'slug'    => "IF(CircularTranslation.slug != '',CircularTranslation.slug,Circulars.slug)",
            'remarks' => "IF(CircularTranslation.remarks != '',CircularTranslation.remarks,Circulars.remarks)",
            'content' => "IF(CircularTranslation.content != '',CircularTranslation.content,Circulars.content)",
            'url'     => "IF(CircularTranslation.url != '',CircularTranslation.url,Circulars.url)",
			'circulation_date',
            'last_date',
            'created',
            'created',
            'updated',
        ])
        ->contain([
            'CircularTranslation' => function ($q) {
                if (Configure::check('language')) {
                    $q->where(['CircularTranslation.culture' => Configure::read('language.culture')]);
                } else {
                    $q->where(['CircularTranslation.language_id' => 0]);
                }
                return $q;
            },
            'CircularDocuments' => function ($q) {
                if (Configure::check('language')) {
                    $q->where(['CircularDocuments.culture' => Configure::read('language.culture')]);
                } else {
                    $q->where(['CircularDocuments.language_id' => 0]);
                }
                return $q;
            },
        ])
        ->where(['status' => 1,$searchString])->order(['Circulars.circulation_date'=>'DESC','Circulars.created'=>'DESC']); //pr($tender); die;
        $this->paginate = ['limit' => 15];
        //debug($tender->toArray());
        //exit;
        $tender = $this->paginate($tender);
        $this->set('tender', $tender);
    }

    /**
     * Page method
     *
     * @return \Cake\Http\Response|void
     */
    public function page($tender_id)
    {
        $tender = $this->Circulars->findById($tender_id)
            ->select([
                'id',
                'title'   => "IF(CircularTranslation.title != '',CircularTranslation.title,Circulars.title)",
                'slug'    => "IF(CircularTranslation.slug != '',CircularTranslation.slug,Circulars.slug)",
                'remarks' => "IF(CircularTranslation.remarks != '',CircularTranslation.remarks,Circulars.remarks)",
                'content' => "IF(CircularTranslation.content != '',CircularTranslation.content,Circulars.content)",
                'url'     => "IF(CircularTranslation.url != '',CircularTranslation.url,Circulars.url)",
                'last_date',
                'circulation_date',
                'created',
                'updated',
            ])
            ->contain([
                'CircularTranslation' => function ($q) {
                    if (Configure::check('language')) {
                        $q->where(['CircularTranslation.culture' => Configure::read('language.culture')]);
                    } else {
                        $q->where(['CircularTranslation.language_id' => 0]);
                    }
                    return $q;
                },
                'CircularDocuments' => function ($q) {
                    if (Configure::check('language')) {
                        $q->where(['CircularDocuments.culture' => Configure::read('language.culture')]);
                    } else {
                        $q->where(['CircularDocuments.language_id' => 0]);
                    }
                    return $q;
                },
            ])
            ->where(['status' => 1])->first();
        if (empty($tender)) {
            throw new NotFoundException(__('Circular not found'));
        }

        $_template = 'page_' . $tender->id;

        $this->set('tender', $tender);

        try {
            $this->render($_template);
        } catch (MissingTemplateException $e) {
            $this->render('page');
        }
    }

    /**
     * Archived method
     *
     * @return \Cake\Http\Response|void
     */
    public function archived()
    {
        $search_condition = array();
        $keyword = trim($this->request->getData('keyword'));
        $keyword = $this->Sanitize->stripAll( $keyword);
        $keyword = $this->Sanitize->clean( $keyword);
        $this->set('keyword', $keyword);
        if (!empty($keyword)) {
            $search_condition[] = "Circulars.title like '%" . $keyword . "%'";
        }
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }
        $tender = $this->Circulars->find('all')
            ->select([
                'id',
                'title'   => "IF(CircularTranslation.title != '',CircularTranslation.title,Circulars.title)",
                'slug'    => "IF(CircularTranslation.slug != '',CircularTranslation.slug,Circulars.slug)",
                'remarks' => "IF(CircularTranslation.remarks != '',CircularTranslation.remarks,Circulars.remarks)",
                'content' => "IF(CircularTranslation.content != '',CircularTranslation.content,Circulars.content)",
                'url'     => "IF(CircularTranslation.url != '',CircularTranslation.url,Circulars.url)",
                'last_date',
                'circulation_date',
                'created',
                'updated',
            ])
            ->contain([
                'CircularTranslation' => function ($q) {
                    if (Configure::check('language')) {
                        $q->where(['CircularTranslation.culture' => Configure::read('language.culture')]);
                    } else {
                        $q->where(['CircularTranslation.language_id' => 0]);
                    }
                    return $q;
                },
                'CircularDocuments' => function ($q) {
                    if (Configure::check('language')) {
                        $q->where(['CircularDocuments.culture' => Configure::read('language.culture')]);
                    } else {
                        $q->where(['CircularDocuments.language_id' => 0]);
                    }
                    return $q;
                },
            ])
            ->where(['status' => 1,$searchString])->order(['Circulars.circulation_date'=>'DESC','Circulars.last_date'=>'DESC']);
        if (empty($tender)) {
            throw new NotFoundException(__('Circular not found'));
        }
        $this->paginate = ['limit' => 15];
        $tender = $this->paginate($tender);
        $this->set('tender', $tender);
    }

}
