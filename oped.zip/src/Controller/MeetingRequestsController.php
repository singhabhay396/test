<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Event\Event;
use Cake\Mailer\Email;
use Cake\ORM\TableRegistry;
use Cake\Error\Exceptions;
use Cake\I18n\Time;
use Cake\Routing\Router;
use Cake\Auth\DefaultPasswordHasher;
use Cake\Utility\Text;
use Cake\Validation\Validator;

/**
 * Users Controller
 *
 * @property \App\Model\Table\UsersTable $Users
 *
 * @method \App\Model\Entity\User[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class MeetingRequestsController extends AppController
{

    public function initialize()
    {
        parent::initialize();
        $this->Auth->allow([]);
        // load the Captcha component and set its parameter
        $this->loadComponent('CakephpCaptcha.Captcha');
        $this->viewBuilder()->layout('frontend');
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }
    
    public function index(){
        $this->loadModel('MeetingRequests');
        $this->loadModel('StartupApplications');
        $this->loadModel('Roles');
        $meetingPersons = $this->Roles->find('list',['keyField'=>'id','valueField'=>'name', 'conditions'=>[ 'Roles.id in'=> [8,9,10,11,12]]]);
        
        $application = $this->StartupApplications->find()->where(['user_id'=>$this->Auth->user('id')])->first();
        //debug($application).die;
        $search_condition = array();
        if ($this->request->is('post') || $this->request->is('get')) {
            //debug($this->request->data).die;
            if (!empty($this->request->data['MeetingRequests']['meeting_persion_type_id'])) {
                $personRole = trim($this->request->data['MeetingRequests']['meeting_persion_type_id']);
                $this->set('personRole', $personRole);
                $search_condition[] = "MeetingRequests.meeting_persion_type_id like '%" . $personRole . "%'";
            }
            if (!empty($this->request->data['MeetingRequests']['meeting_persion_id'])) {
                $personName = trim($this->request->data['MeetingRequests']['meeting_persion_id']);
                $this->set('personName', $personName);
                $search_condition[] = "MeetingRequests.meeting_persion_id like '%" . $personName . "%'";
            }
        }
        $searchString = implode(' AND ', $search_condition); //die;
        $meetingRequests = $this->MeetingRequests->find('all',['conditions'=>[$searchString,'MeetingRequests.startup_application_id'=>$application->id],'contain'=>['MeetingPerson']])->enableHydration(false)->toArray();
        //debug($meetingRequests).die;
        $this->set(compact('meetingRequests','application','meetingPersons'));
    }
    
    public function meetingRequestList(){
        $this->loadModel('MeetingRequests');
        $this->loadModel('StartupApplications');
        $this->loadModel('Roles');
        $meetingPersons = $this->Roles->find('list',['keyField'=>'id','valueField'=>'name', 'conditions'=>[ 'Roles.id in'=> [8,9,10,11,12]]]);
        
        $application = $this->StartupApplications->find()->where(['user_id'=>$this->Auth->user('id')])->first();
        //debug($application).die;
        $search_condition = array();
        if ($this->request->is('post') || $this->request->is('get')) {
            //debug($this->request->data).die;
            if (!empty($this->request->data['MeetingRequests']['meeting_persion_type_id'])) {
                $personRole = trim($this->request->data['MeetingRequests']['meeting_persion_type_id']);
                $this->set('personRole', $personRole);
                $search_condition[] = "MeetingRequests.meeting_persion_type_id like '%" . $personRole . "%'";
            }
            if (!empty($this->request->data['MeetingRequests']['meeting_persion_id'])) {
                $personName = trim($this->request->data['MeetingRequests']['meeting_persion_id']);
                $this->set('personName', $personName);
                $search_condition[] = "MeetingRequests.meeting_persion_id like '%" . $personName . "%'";
            }
        }
        $searchString = implode(' AND ', $search_condition); //die;
        $meetingRequests = $this->MeetingRequests->find('all',['conditions'=>[$searchString,'MeetingRequests.meeting_persion_id'=>$this->Auth->user('id')],'contain'=>['MeetingPerson']])->enableHydration(false)->toArray();
        //debug($meetingRequests).die;
        $this->set(compact('meetingRequests','application','meetingPersons'));
    }
    
    public function add(){
        $this->loadModel('StartupApplications');
        $meetingRequests = $this->StartupApplications->find('all',['contain'=>['Users'=>['Registration']]])->where(['StartupApplications.user_id'=>$this->Auth->user('id')])->first();
        $this->loadModel('StartupApplications');
        $startupApplication = $this->StartupApplications->find('list',['keyField'=>'id','valueField'=>'name_of_startup']);
        
        $this->loadModel('Roles');
        $meetingPersons = $this->Roles->find('list',['keyField'=>'id','valueField'=>'name', 'conditions'=>[ 'Roles.id in'=> [8,9,10,11,12]]]);
        $this->set(compact('meetingRequests','startupApplication','meetingPersons'));
        //debug($meetingRequests).die;
        if($this->request->is(['post','put'])){
            $application = $this->MeetingRequests->newEntity();
            $application  = $this->MeetingRequests->patchEntity($application, $this->request->getData());
         //debug($application).die;
            if($result = $this->MeetingRequests->save($application)) {
       
                $this->Flash->success('You have registered Meeting Request Successfully.');
                $this->redirect(['controller'=>'meeting-requests','action' => 'index']);
            }else{
                $this->Flash->error(__('Something went wrong. Please, try again.'));
            }
        }
    }
    
    public function view($id=null){
         $id = base64_decode($id);    
         $data = $this->MeetingRequests->find('all',['conditions'=>['id'=>$id]])->first();                
         $this->set('data',$data);
    }

    public function editProfile()
    {
        $this->viewBuilder()->layout('frontend');
        $this->loadModel('States');
        $state = $this->States->find('list',['keyField'=>'id','valueField'=>'name'])->where(['flag'=>1]);
        $user = $this->Users->get($this->Auth->user('id'),['contain'=>['Registration']]);
        $this->loadModel('Designations');
        $designation = $this->Designations->find('list',['keyField'=>'id','valueField'=>'name']);
        if(!empty($user->registration->district_id)){
            $this->loadModel('Districts');
            $district = $this->Districts->find('list',['keyField'=>'id','valueField'=>'name'])->where(['state_id'=>$user->registration->state_id]);
            $this->set('district',$district);
        }
        //pr($user); die();
        if($this->request->is(['post','put'])){
            $saveData = $this->Users->patchEntity($user, $this->request->getData(), ['associated' => ['Registration']]);

            if($this->request->data['registration']['profile_photo']['name']!=''){
                $photo = $this->uploadFiles('files/profile_pic/', $this->request->data['registration']['profile_photo']);
                $saveData->registration->profile_photo = $photo['filename'];
            }else{
                $saveData->registration->profile_photo = @$this->request->data['registration']['profile_photo_old'];
            }
            $saveData->registration->date_of_birth = date('Y-m-d',strtotime($this->request->data['registration']['date_of_birth']));
            if ($userdata = $this->Users->save($saveData, ['associated'=>['Registration']])) {
                $this->Flash->success(__("Profile has been updated successfully"));
                return $this->redirect(['controller'=>'Dashboard']);
            }
        }
        $this->set(compact('user','state','designation'));
    }
    
    public function getPersonList(){
        $this->viewBuilder()->layout('ajax');
        $state_id = $_POST['state_id'];
        $this->loadModel('Users');
        $districtResult = $this->Users->find('list',['keyField'=>'id','valueField'=>'name','conditions'=>['role_id'=>$state_id]])->enableHydration(false)->toArray();
//        $this->loadModel('Districts');
//        $districtResult = $this->Users->find('list',['keyField'=>'id','valueField'=>'name','conditions'=>['role_id'=>$state_id]])->enableHydration(false)->toArray();
        $select = array('' =>'--Select--');
        $final  = array();
        foreach( $select as $key=>$each ){
            $final[$key]    = $each;
        }
        foreach( $districtResult as $key=>$each ){
            $final[$key]    = $each;
        }
        $this->set('persons',$final);
    }

}
