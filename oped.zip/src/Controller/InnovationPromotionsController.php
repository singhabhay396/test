<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Validation\Validator;
use Cake\Controller\Controller;
use Cake\Mailer\Email;
use Cake\Error\Exceptions;
use Cake\I18n\Time;
use Cake\Routing\Router;
use Cake\Event\Event;
use Cake\Auth\DefaultPasswordHasher;

/**
 * InnovationPromotions Controller
 *
 * @property \App\Model\Table\InnovationPromotionsTable $InnovationPromotions
 *
 * @method \App\Model\Entity\InnovationPromotions[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class InnovationPromotionsController extends AppController
{
    public function initialize() {
        parent::initialize(); 

        $this->viewBuilder()->setLayout('frontend');
        $this->Auth->allow(['index']);
    }

    public function beforeFilter(Event $event){
        parent::beforeFilter($event);
    }

    public function index()
    {
        return $this->redirect(['action'=>'Patents']);
    }

    public function Patents()
    {
        # code...
    }

}