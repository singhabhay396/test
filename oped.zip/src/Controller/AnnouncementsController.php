<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Core\Configure;
use Cake\Event\Event;
use Cake\Network\Exception\NotFoundException;
use Cake\View\Exception\MissingTemplateException;

/**
 * Tenders Controller
 *
 * @property \App\Model\Table\TendersTable $Tenders
 *
 * @method \App\Model\Entity\Tender[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class AnnouncementsController extends AppController
{

    public function initialize()
    {
        parent::initialize();
        $this->viewBuilder()->setLayout('frontend');
        $this->Auth->allow(['index']);
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }
    
    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $search_condition = array();
        $keyword = trim($this->request->getData('keyword'));
        $keyword = $this->Sanitize->stripAll( $keyword);
        $keyword = $this->Sanitize->clean( $keyword);
        $this->set('keyword', $keyword);
        if (!empty($keyword)) {
            $search_condition[] = "Announcements.title like '%" . $keyword . "%'";
        }
        if(!empty($search_condition)){
            $searchString = implode(" AND ",$search_condition);
        } else {
            $searchString = '';
        }

        $select = [
            'id',
            'title'   => "IF(AnnouncementTranslation.title != '',AnnouncementTranslation.title,Announcements.title)",
            'description'   => "IF(AnnouncementTranslation.description != '',AnnouncementTranslation.description,Announcements.description)",
            'filename' => "IF(AnnouncementTranslation.filename != '',AnnouncementTranslation.filename,Announcements.filename)",
            'is_active',
            'created'
            ];
        if (empty($announcement_id)) {
            $announcements = $this->Announcements->find('all')->select($select)->contain([
                'AnnouncementTranslation' => function ($q) {
                    if (Configure::check('language')) {
                        $q->where(['AnnouncementTranslation.culture' => Configure::read('language.culture')]);
                    } else {
                        $q->where(['AnnouncementTranslation.language_id' => 0]);
                    }
                    return $q;
                }
            ])->where(['is_active' => 1])->order(['publish_date'=>'DESC']);            
        }

        if (empty($announcements)) {
            throw new NotFoundException(__('Announcements not found'));
        }
        $this->paginate = ['limit' => 15];
        $announcements = $this->paginate($announcements);
        $this->set('announcements', $announcements);
    }

    

}
