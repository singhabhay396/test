<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Core\Configure;
use Cake\Event\Event;
use Cake\Network\Exception\NotFoundException;
use Cake\View\Exception\MissingTemplateException;

/**
 * Products Controller
 *
 * @property \App\Model\Table\ProductsTable $Products
 *
 * @method \App\Model\Entity\Article[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class ProductsController extends AppController
{
    public function initialize()
    {
        parent::initialize();
        $this->viewBuilder()->setLayout('frontend');
        $this->Auth->allow(['page','index']);
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }

    public function index($value='')
    {
        $product = $this->Products->find('all')
            ->select([
                'id',
                'sub_title'   => "IF(ProductTranslation.sub_title != '',ProductTranslation.sub_title,Products.sub_title)",
                'title'   => "IF(ProductTranslation.title != '',ProductTranslation.title,Products.title)",
                'excerpt'    => "IF(ProductTranslation.excerpt != '',ProductTranslation.excerpt,Products.excerpt)",
                'content' => "IF(ProductTranslation.content != '',ProductTranslation.content,Products.content)",
                'features' => "IF(ProductTranslation.features != '',ProductTranslation.features,Products.features)",
				'feature_title' => "IF(ProductTranslation.feature_title != '',ProductTranslation.feature_title,Products.feature_title)",
                'url'     => "IF(ProductTranslation.url != '',ProductTranslation.url,Products.url)",
                'icon',
                'status',
                'sort_order',
                'created',
            ])
            ->contain([
                'ProductTranslation' => function ($q) {
                    if (Configure::check('language')) {
                        $q->where(['ProductTranslation.culture' => Configure::read('language.culture')]);
                    } else {
                        $q->where(['ProductTranslation.language_id' => 0]);
                    }
                    return $q;
                },
                'ProductBlocks' => function ($q) {
                    if (Configure::check('language')) {
                        $q->where(['ProductBlocks.culture' => Configure::read('language.culture')]);
                    } else {
                        $q->where(['ProductBlocks.language_id' => 0]);
                    }
                    return $q;
                },
            ])
            ->where(['status' => 1,'category_id'=>1,'Products.id NOT IN'=>[7]]);
        if (empty($product)) {
            throw new NotFoundException(__('Product not found'));
        }
        $this->paginate = ['limit' => 15];
        $product = $this->paginate($product);
        $this->set(compact('product'));
    }

    /**
     * Page method
     *
     * @return \Cake\Http\Response|void
     */
    public function page($product_id)
    {
        $select = [
                'id',
                'title'   => "IF(ProductTranslation.title != '',ProductTranslation.title,Products.title)",
                'excerpt'    => "IF(ProductTranslation.excerpt != '',ProductTranslation.excerpt,Products.excerpt)",
                'content' => "IF(ProductTranslation.content != '',ProductTranslation.content,Products.content)",
                'url'     => "IF(ProductTranslation.url != '',ProductTranslation.url,Products.url)",
				'features' => "IF(ProductTranslation.features != '',ProductTranslation.features,Products.features)",
				'feature_title' => "IF(ProductTranslation.feature_title != '',ProductTranslation.feature_title,Products.feature_title)",
                'icon',
                'status',
                'sort_order',
                'created',
            ];
        $product = $this->Products->findById($product_id)
            ->select($select)
            ->contain([
                'ProductTranslation' => function ($q) {
                    if (Configure::check('language')) {
                        $q->where(['ProductTranslation.culture' => Configure::read('language.culture')]);
                    } else {
                        $q->where(['ProductTranslation.language_id' => 0]);
                    }
                    return $q;
                }
            ])
            ->where(['status' => 1])->first();

        $productlist = $this->Products->find('all')
            ->select($select)
            ->contain([
                'ProductTranslation' => function ($q) {
                    if (Configure::check('language')) {
                        $q->where(['ProductTranslation.culture' => Configure::read('language.culture')]);
                    } else {
                        $q->where(['ProductTranslation.language_id' => 0]);
                    }
                    return $q;
                }
            ])
            ->where(['status' => 1,'category_id'=>1]);

        if (empty($product)) {
            throw new NotFoundException(__('Product not found'));
        }
        $_template = 'page_' . $product->id;
        
        if (!empty($product->slug)) {
            $_template = 'page_' . $product->slug;
        }
        $this->set(compact('product','productlist'));
        try {
            $this->render($_template);
        } catch (MissingTemplateException $e) {
            $this->render('page');
        }
    }
}
