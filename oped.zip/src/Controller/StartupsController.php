<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Core\Configure;
use Cake\Event\Event;
use Cake\Network\Exception\NotFoundException;
use Cake\View\Exception\MissingTemplateException;
use Cake\View\View;
use Cake\Routing\Router;

/**
 * Startups Controller
 *
 * @property \App\Model\Table\StartupsTable $Startups
 *
 * @method \App\Model\Entity\Startups[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class StartupsController extends AppController
{
    public $dateFormat = 'Y-m-d';

    public $dateFormatFull = 'Y-m-d H:i:s';
    
    public function initialize()
    {
        parent::initialize();
        $this->viewBuilder()->setLayout('frontend');
        $this->Auth->allow(['index','recognition','TrackApplication','DownloadRecognitionCertificate','StartupPolicyNotifications','SelfCertification','ProductsServices','SuccessStories','downloadFile','addObservation']);
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
        if($this->isDevice) {
            $this->Auth->allow(['registration','industries','startupCategories','typesOfStartup','states','banks']);
        }
    }

    /**
     * Page method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
       
    }

    public function eligibilityCriteria()
    {
        # code...
    }

    public function registration($id = NULL)
    {
        /*if($this->isDevice) {
            $this->request->allowMethod(['post']);
            
            $_status = false;
            $_message = '';
	    $language = 'en';
	    if(!empty($this->request->params) && !empty($this->request->params['language'])){
		    $language = $this->request->params['language'];
	    }
        }*/
        $id = base64_decode($id);
        //if(!$this->isDevice) {
            $this->viewBuilder()->layout('frontend');
        //}
        $this->loadModel('StartupApplications');
        if($this->Auth->user('role_id') != 7){
            /*if($this->isDevice) {
                $_message = 'You are not authorized to submit Startup form.';
            }else{*/
                $this->Flash->error(__('You are not authorized to submit Startup form.'));
                $this->redirect(['controller' => 'Dashboard']);
            //}
        }
        
        if(!empty($id)){
            $application = $this->StartupApplications->get($id,['contain'=>['StartupDirectors']]);
            if(!empty($application->sector_id)){
                $this->loadModel('Sectors');
                $sector = $this->Sectors->find('list',['keyField'=>'id','valueField'=>'name'])->where(['id'=>$application->sector_id]);
            }
            if(!empty($application->sector_of_product)){
                $this->loadModel('Sectors');
                $sector_of_product = $this->Sectors->find('list',['keyField'=>'id','valueField'=>'name'])->where(['id'=>$application->sector_of_product]);
            }
            
            $this->loadModel('Tehsils');
            $tehsil = $this->Tehsils->find('list')->order(['name'])->where(['status'=>1]);
            
            $this->loadModel('Districts');
            $district = $this->Districts->find('list',['keyField'=>'id','valueField'=>'name']);
            
            $this->set(compact('sector','sector_of_product','registered_district','corporate_district','regional_district','district','tehsil'));
        }else{
            $check_status = $this->StartupApplications->findByUserId($this->Auth->user('id'))->first();
            if(!empty($check_status)){
                if($check_status->is_save_draft != 1){
                    /*if($this->isDevice) {
                        $_message = 'You have already registered for Startup.';
                    }else{*/
                        $this->Flash->error(__('You have already registered for Startup.'));
                        return $this->redirect(['controller' => 'Dashboard']);
                    //}
                }else{
                    return $this->redirect(['action' => 'registration',base64_encode($check_status->id)]);
                }
            }else{
                $application = $this->StartupApplications->newEntity();
            }
        }
        
        $this->loadModel('Users');
        //if(!$this->isDevice) {
            $users = $this->Users->get($this->Auth->user('id'),['contain'=>['Registration.Designations']]);
        //}
        
        if($this->request->is(['post','put'])){
            $data = $this->Sanitize->clean($this->request->getData());
	    /*if($this->isDevice) {
                $users = $this->Users->get($data['user_id'],['contain'=>['Registration.Designations']]);
            }*/
            if (trim($data['whether_registered_as_startup_with_dipp']) == '1' && empty(trim($data['dipp_registration_number']))) {
                /*if($this->isDevice) {
                    $_message = 'Since you are not registered with Startup India Portal (DIPP) so you are not eligible to apply on Startup Haryana portal. To avail benefits from Statup Haryana, Please apply with DIPP then you can apply on this portal.';
                }else{*/
                    $this->Flash->warning(__('Since you are not registered with Startup India Portal (DIPP) so you are not eligible to apply on Startup Haryana portal. To avail benefits from Statup Haryana, Please apply with DIPP then you can apply on this portal.'));
                    return $this->redirect(['controller' => 'Dashboard']);
                //}
            }
            
            $startup_director = [];
            if (isset($data['startup_director'])) {
                $startup_director = $data['startup_director'];
                unset($data['startup_director']);
            }
            
            $application  = $this->StartupApplications->patchEntity($application, $data);
            
            if($data['is_corp_office_same_as_reg_office'] == 1){
                $application->corporate_state_id = $data['registered_state_id'];
                $application->corporate_district_id = $data['registered_district_id'];
            }
            
            if($data['is_regional_office_same_as_corp_office'] == 1){
                $application->regional_state_id = $application->corporate_state_id;
                $application->regional_district_id = $application->corporate_district_id;
            }
            
            if ($data['registered_state_id'] == 14 && $application->corporate_state_id == 14) {
                $application->eligibility_criteria = 'C1';
            } elseif ($data['are_you_an_incubatee'] == 1 && ($data['registered_state_id'] != 14 && $application->corporate_state_id != 14)) {
                $application->eligibility_criteria = 'C3';
            } else {
                $application->eligibility_criteria = 'C2';
            }
            
            if(!empty($data['registration_certificate']) && $data['registration_certificate']['name']!=''){
                $certificate = $this->uploadFiles('registration', $data['registration_certificate']);
                $application->registration_certificate = $certificate['filename'];
            }else{
                $application->registration_certificate = @$data['registration_certificate_old'];
            }
            
            if(!empty($data['pan_number_of_startup']) && $data['pan_number_of_startup']['name']!=''){
                $certificate = $this->uploadFiles('registration', $data['pan_number_of_startup']);
                $application->pan_number_of_startup = $certificate['filename'];
            }else{
                $application->pan_number_of_startup = @$data['pan_number_of_startup_old'];
            }
            
            if(!empty($data['balance_sheet_of_startup']) && $data['balance_sheet_of_startup']['name']!=''){
                $certificate = $this->uploadFiles('registration', $data['balance_sheet_of_startup']);
                $application->balance_sheet_of_startup = $certificate['filename'];
            }else{
                $application->balance_sheet_of_startup = @$data['balance_sheet_of_startup_old'];
            }
            
            if(!empty($data['dipp_startup_registration']) && $data['dipp_startup_registration']['name']!=''){
                $certificate = $this->uploadFiles('registration', $data['dipp_startup_registration']);
                $application->dipp_startup_registration = $certificate['filename'];
            }else{
                $application->dipp_startup_registration = @$data['dipp_startup_registration_old'];
            }
            
            if(!empty($data['letter_of_authorization']) && $data['letter_of_authorization']['name']!=''){
                $certificate = $this->uploadFiles('registration', $data['letter_of_authorization']);
                $application->letter_of_authorization = $certificate['filename'];
            }else{
                $application->letter_of_authorization = @$data['letter_of_authorization_old'];
            }
            
            if(!empty($data['undertaking']) && $data['undertaking']['name']!=''){
                $certificate = $this->uploadFiles('registration', $data['undertaking']);
                $application->undertaking = $certificate['filename'];
            }else{
                $application->undertaking = @$data['undertaking_old'];
            }
            
            if(!empty($data['self_declaration']) && $data['self_declaration']['name']!=''){
                $certificate = $this->uploadFiles('registration', $data['self_declaration']);
                $application->self_declaration = $certificate['filename'];
            }else{
                $application->self_declaration = @$data['self_declaration_old'];
            }
            
            if(!empty($data['certificate_from_incubator']) && $data['certificate_from_incubator']['name']!=''){
                $certificate = $this->uploadFiles('registration', $data['certificate_from_incubator']);
                $application->certificate_from_incubator = $certificate['filename'];
            }else{
                $application->certificate_from_incubator = @$data['certificate_from_incubator_old'];
            }
            
            if(!empty($data['introduction']) && $data['introduction']['name']!=''){
                $certificate = $this->uploadFiles('registration', $data['introduction']);
                $application->introduction = $certificate['filename'];
            }else{
                $application->introduction = @$data['introduction_old'];
            }
            
            if(!empty($data['innovativeness']) && $data['innovativeness']['name']!=''){
                $certificate = $this->uploadFiles('registration', $data['innovativeness']);
                $application->innovativeness = $certificate['filename'];
            }else{
                $application->innovativeness = @$data['innovativeness_old'];
            }
            
            /*if($this->isDevice){
                $application->user_id = $data['user_id'];
            }else{*/
                $application->user_id = $this->Auth->user('id');
            //}
            
            if($data['are_you_an_incubatee'] == 1){
                $application->start_date_of_incubation =  date('Y-m-d H:i:s',strtotime($data['start_date_of_incubation']));
                $application->end_date_of_incubation =  date('Y-m-d H:i:s',strtotime($data['end_date_of_incubation']));
            }
            /*if($this->isDevice){
                $application->category_id = $data['category_id'];
            }else{*/
                $application->category_id = implode(',', $data['category_id']);
            //}
            $application->date_of_registration = date('Y-m-d',strtotime($data['date_of_registration']));
            $application->date_of_incorporation = date('Y-m-d',strtotime($data['date_of_incorporation']));
            
            if(!empty($data['save_as_draft'])){
                $application->startup_stage_id = 0;
                $application->is_save_draft = 1;
            }else{
		$application->startup_stage_id = 1;
                $application->is_save_draft = 0;
	    }
            
            //pr($application); //die();
            if($result = $this->StartupApplications->save($application)) {
                //pr($result); die();
		//$this->convertHtml($application);
		
                $application_id = $application->id;
                $reference_no = $this->generateReferenceNo($application_id);
                $query = $this->StartupApplications->query();
                $query->update()
                    ->set(['reference_no' => $reference_no])
                    ->where(['id' => $application_id])
                    ->execute();
				
                //pr($startup_director); die();
                if (!empty($startup_director)) {
                    $this->loadModel('StartupDirectors');
                    foreach ($startup_director as $key => $_director) {
                        if (empty($_director['id'])) {
                            unset($startup_director[$key]['id']);
                        }
                        
                        $startup_director[$key]['startup_application_id'] = $application_id;
                        $startup_director[$key]['nationality'] = 1;
                        
                        if(!empty($_director['id_proof']) && $_director['id_proof']['name']!=''){
                            $certificate1 = $this->uploadFiles('directors', $_director['id_proof']);
                            $startup_director[$key]['id_proof'] = $certificate1['filename'];
                        }else{
                            $startup_director[$key]['id_proof'] = @$_director['id_proof_old'];
                        }
                        
                        if(!empty($_director['residential_proof']) && $_director['residential_proof']['name']!=''){
                            $certificate1 = $this->uploadFiles('directors', $_director['residential_proof']);
                            $startup_director[$key]['residential_proof'] = $certificate1['filename'];
                        }else{
                            $startup_director[$key]['residential_proof'] = @$_director['residential_proof_old'];
                        }
                    }
                    $startupDirector  = $this->StartupDirectors->newEntity();
                    $startupDirector  = $this->StartupDirectors->patchEntities($startupDirector, $startup_director);
                    $startupDirectors = $this->StartupDirectors->saveMany($startupDirector);
		    
		    //$application->startup_directors = $startupDirectors;
                }
                if(!empty($data['save_as_draft'])){
                    /*if($this->isDevice) {
                        $_status = true;
                        $_message = 'Your application has been saved as draft';
                    }else{*/
                        $this->Flash->success(__("Your application has been saved as draft"));
                        return $this->redirect(['action' => 'registration',base64_encode($result->id)]);
                    //}
                }else{
                    /*startup_application_file_movements Table*/
                    $tableName                  = 'StartupApplicationFileMovements';
                    $application_id_columnName  = 'startup_application_id';
                    $startup_application_id     = $application->id;
                    $comment                    = '';
                    $current_with               = 'Dealing Officer';
                    $initiated_date             = $application->created;
                    $panding_from               = date('Y-m-d');    
                    
                    $this->fileMovement($tableName, $application_id_columnName, $startup_application_id, $current_with, $comment, $initiated_date, $panding_from, $data);
                    /**/
                    $successSms = "Thanks for your application, Please note Reference number $reference_no for further communication. You can also check your mail for reference number.";
                    /*if($this->isDevice) {
			$_status = true;
                        $_message = $successSms;
                    }else{*/
                        $this->Flash->success($successSms);
                        $this->redirect(['controller' => 'Dashboard']);
                    //}
                }
            }else{
                //pr($application->errors());exit;
                /*if($this->isDevice) {
                    $_message = 'Something went wrong. Please, try again.';
                }else{*/
                    $this->Flash->error(__('Something went wrong. Please, try again.'));
                //}
            }
        }
        
        //if(!$this->isDevice) {
            $this->loadModel('NatureOfStartup');
            $nature_of_startup = $this->NatureOfStartup->find('list',['keyField'=>'id','valueField'=>'nature'])->where(['status'=>1]);
            $this->loadModel('Industries');
            $industries = $this->Industries->find('list')->where(['status'=>1]);
            $this->loadModel('Sectors');
            $sectors = $this->Sectors->find('list',['keyField'=>'id','valueField'=>'name'])->where(['status'=>1]);
            $this->loadModel('StartupCategories');
            $startup_categories = $this->StartupCategories->find('list',['keyField'=>'id','valueField'=>'name'])->where(['status'=>1])->toArray();
            $this->loadModel('States');
            $states = $this->States->find('list',['keyField'=>'id','valueField'=>'name'])->where(['flag'=>1]);
            $this->loadModel('StartupStages');
            $startup_stages = $this->StartupStages->find('list',['keyField'=>'id','valueField'=>'startup_stage'])->where(['status'=>1]);
            $this->loadModel('BankDetails');
            $bank = $this->BankDetails->find('list',['keyField'=>'bank_name','valueField'=>'bank_name']);
        //}
        
	/*if($this->isDevice) {
	    $this->set(compact(
                '_status','_message','language','application','name','email'
            ));
	    $this->set('_serialize', [
                '_status','_message','language','application','name','email'
            ]);
        }else{*/
            $this->set(compact('application','nature_of_startup','industries','sectors','startup_categories','states','startup_stages','name','email','users','bank'));
        //}
    }
    
    public function apiRegistration()
    {
        if ($this->isDevice == false) {
            return $this->redirect(['controller' => 'Dashboard', 'action' => 'index']);
        }
        $this->request->allowMethod(['get', 'post']);
	$this->loadModel('StartupApplications');
        $_status    = false;
        $_message   = '';
        $_startup = new \stdClass();
	
	$registerBaseUrl = Router::Url('/files/registration',true);
	$directorBaseUrl = Router::Url('/files/directors',true);
	
	$_format_links = [
	  'letter_of_authorization' => Router::Url('/files/Annexure/Annexure_II_Letter_of_Authorization.doc',true),
	  'undertaking' => Router::Url('/files/Annexure/Annexure_III-Undertaking.doc',true),
	  'self_declaration' => Router::Url('/files/Annexure/Annexure_IV-Self_Declaration.doc',true),
	  'certificate_from_incubator' => Router::Url('/files/Annexure/Annexure-V-Certificate_from_Incubator.doc',true)
	];

        if ($this->request->is(['post'])) {
            $applicationId = $this->request->getData('applicationId');
            $userId        = $this->request->getData('userId');
        } else {
            $applicationId = $this->request->getQuery('applicationId');
            $userId        = $this->request->getQuery('userId');
        }

        if (!empty($userId)) {
            $where = [];
            if (!empty($applicationId)) {
                $where[] = ['id' => $applicationId];
            }
            if (!empty($userId)) {
                $where[] = ['user_id' => $userId];
            }
            $startup = $this->StartupApplications->find('all', ['contain' => ['StartupDirectors']])->where($where)->first();
            if (!empty($startup) && $startup->is_save_draft != 1) {
                $_message = __('You have already registered for Startup.');
            }
            $startup = (!empty($startup)) ? $startup : $this->StartupApplications->newEntity();
        } else {
            $_message = __('UserID is required');
        }

        if (!empty($startup) && !$startup->isNew()) {
            $_startup = $startup;
        }
        
        if (empty($_message) && $this->request->is(['post'])) {
	    $startupDirectorsFields = $this->request->getData('startup_director_fields');
            $this->request->withoutData('startup_director_fields');
	    $startupDirectorsUpload = $this->request->getData('startup_director_upload');
            $this->request->withoutData('startup_director_upload');
            $postData                          = $this->request->getData();
            $postData['user_id']               = $userId;
	    $postData['date_of_registration']  = date('Y-m-d',strtotime($postData['date_of_registration']));
	    $postData['date_of_incorporation']  = date('Y-m-d',strtotime($postData['date_of_incorporation']));
	    if(!empty($postData['start_date_of_incubation'])){
		$postData['start_date_of_incubation']  = date('Y-m-d',strtotime($postData['start_date_of_incubation']));
	    }
	    if(!empty($postData['end_date_of_incubation'])){
		$postData['end_date_of_incubation']  = date('Y-m-d',strtotime($postData['end_date_of_incubation']));
	    }
	    $postData['application_status_id'] = 1;
            $postData['startup_stage_id']    = 1;
            $postData['is_save_draft']         = 0;
            if (!empty($postData['save_as_draft'])) {
                $postData['startup_stage_id'] = 0;
                $postData['is_save_draft']      = 1;
            }
            /** Document **/
            $startupFiles = ['registration_certificate', 'pan_number_of_startup', 'balance_sheet_of_startup', 'dipp_startup_registration', 'letter_of_authorization', 'undertaking', 'self_declaration', 'certificate_from_incubator', 'introduction', 'innovativeness'];
            foreach ($startupFiles as $field) {
                if (isset($postData[$field]) && $postData[$field]['name'] != '') {
                    $uploaded         = $this->uploadFiles('registration', $postData[$field]);
                    if(!empty($uploaded) && !empty($uploaded['filename'])){
			$postData[$field] = $uploaded['filename'];
		    }
                } else if (isset($postData[$field])) {
                    unset($postData[$field]);
                }
            }
            //Save
	    $startupSave = $this->StartupApplications->patchEntity($startup, $postData);
            if ($this->StartupApplications->save($startupSave)) {
		$applicationId = $startupSave->id;
                $isSaveDraft   = (!empty($startupSave->is_save_draft)) ? true : false;
                $createdAt     = $startupSave->created;
                // Update Reference No
                $referenceNo   = $startupSave->reference_no;
		//if ($startup->isNew()) {
		if (empty($referenceNo)) {
                    $referenceNo = $this->generateReferenceNo($applicationId);
		    $this->StartupApplications->query()
                        ->update()
                        ->set(['reference_no' => $referenceNo])
                        ->where(['id' => $applicationId])
                        ->execute();
                }
                // Save Startup Directors
                $startupSave->{'startup_directors'} = [];
                /** Document **/
                $startupDirectorFiles = ['id_proof', 'residential_proof'];
                if (!empty($startupDirectorsFields)) {
		    $startupDirectors = [];
		    $startupDirectorsFields = json_decode($startupDirectorsFields,true);
                    foreach ($startupDirectorsFields as $key => $director) {
                        $director['startup_application_id'] = $applicationId;
                        $director['nationality']              = 1;
                        foreach ($startupDirectorFiles as $field) {
                            if (isset($startupDirectorsUpload[$key][$field]) && $startupDirectorsUpload[$key][$field]['name'] != '') {
                                $uploaded         = $this->uploadFiles('directors', $startupDirectorsUpload[$key][$field]);
                                if(!empty($uploaded) && !empty($uploaded['filename'])){
				    $director[$field] = $uploaded['filename'];
				}
                            } else if (isset($director[$field])) {
                                unset($director[$field]);
                            }
                        }
                        $startupDirectors[] = $director;
                    }
                    $startupDirectors = $this->StartupApplications->StartupDirectors->newEntities($startupDirectors);
                    $startupDirectors = $this->StartupApplications->StartupDirectors->saveMany($startupDirectors);
		    
                    $startupSave->{'startup_directors'} = $startupDirectors;
                }
                if ($isSaveDraft) {
                    $_message = __("Your application has been saved as draft");
                } else {
                    /*startup_application_file_movements Table*/
                    $tableName               = 'StartupApplicationFileMovements';
                    $applicationIdColumnName = 'startup_application_id';
                    $startupApplicationId    = $applicationId;
                    $comment                 = '';
                    $currentWith             = 'Dealing Officer';
                    $initiatedDate           = $createdAt;
                    $pandingFrom             = date('Y-m-d');
                    $this->fileMovement($tableName, $applicationIdColumnName, $startupApplicationId, $currentWith, $comment, $initiatedDate, $pandingFrom, $postData);
                    $_message = __("Thanks for your application, Please note Reference number {0} for further communication. You can also check your mail for reference number.", [$referenceNo]);
                }
                $_status    = true;
                $_startup = $startupSave;
            } else {
                $_message = __("Your application could not be saved. Please, try again.");
            }
        } else if (empty($_message)) {
            $_status = true;
        }
	
	if(!empty((array) $_startup)) {
            $dateFields = [
		'date_of_registration','date_of_incorporation','start_date_of_incubation','end_date_of_incubation',
		'created'
	    ];
	    foreach ($dateFields as $field) {
                $date = $_startup->get($field);
		if(!empty($date)) {
                    $_startup->{$field} = $date->format($this->dateFormat);
                }
            }
        }
	
        $this->set([
            '_status'    => $_status,
            '_startup' => $_startup,
            '_message'   => $_message,
	    'registerBaseUrl'   => $registerBaseUrl,
	    'directorBaseUrl'   => $directorBaseUrl,
	    '_format_links' => $_format_links,
            '_serialize' => [
                '_status', '_startup', '_message','registerBaseUrl','directorBaseUrl','_format_links'
            ],
        ]);
    }
    
    public function apiPatentIncentives()
    {
        if ($this->isDevice == false) {
            return $this->redirect(['controller' => 'Dashboard', 'action' => 'index']);
        }
        $this->loadModel('StartupApplications');
	$this->loadModel('StartupPatentIncentives');
	
        $this->request->allowMethod(['get', 'post']);
        $_status  = false;
        $_message = '';

        $_startup          = new \stdClass();
        $_patentIncentives = new \stdClass();
	
	$patentsBaseUrl = Router::Url('/files/patents',true);
	
	$_format_links = [
	  'authorization_letter' => Router::Url('/files/Annexure/AnnexureII.docx',true),
	  'undertaking' => Router::Url('/files/Annexure/AnnexurIII.docx',true),
	  'expenditure_statement' => Router::Url('/files/Annexure/Annexure-IV_FormA.docx',true),
	  'sanction_refusal_letter' => Router::Url('/files/Annexure/AnnexureV.docx',true)
	];
	
        if ($this->request->is(['post'])) {
            $applicationId = $this->request->getData('applicationId');
            $userId        = $this->request->getData('userId');
        } else {
            $applicationId = $this->request->getQuery('applicationId');
            $userId        = $this->request->getQuery('userId');
        }
        if (!empty($userId)) {
            $where     = [];
            $where[]   = ['user_id' => $userId];
            $startup = $this->StartupApplications->find('all')->where($where)->first();
            if (!empty($startup) && empty($startup->recognition_certificate_no)) {
                $_message = __('Your application is being considered but has not yet been approved.');
            } else if (empty($startup)) {
                $_message = __('You have not applied for any Startup.');
            } else {
                $patentIncentives = (!empty($applicationId)) ? $this->StartupPatentIncentives->get($applicationId)->first() : $this->StartupPatentIncentives->newEntity();
            }
        } else {
            $_message = __('UserID is required');
        }
        if (!empty($startup)) {
            $_startup = $startup;
        }
        if (!empty($patentIncentives) && !$patentIncentives->isNew()) {
            $_patentIncentives = $patentIncentives;
        }
        if (empty($_message) && $this->request->is(['post'])) {
            $postData = $this->request->getData();
            $postData['startup_application_id'] = $startup->id;
	    if(!empty($postData['date_of_registration'])){
		$postData['date_of_registration']  = date('Y-m-d',strtotime($postData['date_of_registration']));
	    }
	    if(!empty($postData['date_of_filling_application'])){
		$postData['date_of_filling_application']  = date('Y-m-d',strtotime($postData['date_of_filling_application']));
	    }
	    $postData['application_status_id']    = 1;
            $postData['application_stage_id']     = 1;
            if ($patentIncentives->isNew()) {
                $postData['created'] = date('Y-m-d H:i:s');
            }
            /** Document **/
            $patentIncentivesFiles = ['registration_certificate','authorization_letter','undertaking','application_form','petent_registraion','expenditure_statement','original_invoice','cancelled_cheque','payment_proof','sanction_refusal_letter'];
            foreach ($patentIncentivesFiles as $field) {
                if (isset($postData[$field]) && $postData[$field]['name'] != '') {
                    $uploaded         = $this->uploadFiles('patents', $postData[$field]);
                    if(!empty($uploaded) && !empty($uploaded['filename'])){
			$postData[$field] = $uploaded['filename'];
		    }
		    
                } else if (isset($postData[$field])) {
                    unset($postData[$field]);
                }
            }
            //Save
            $patentIncentivesSave = $this->StartupPatentIncentives->patchEntity($patentIncentives, $postData);
            if ($this->StartupPatentIncentives->save($patentIncentivesSave)) {
                $applicationId = $patentIncentivesSave->id;
                $referenceNo   = $patentIncentivesSave->reference_number;
                //if ($patentIncentives->isNew()) {
		if(empty($referenceNo)){
                    $referenceNo = $this->patentReferenceNo($applicationId);
                    $this->StartupPatentIncentives->query()
                        ->update()
                        ->set(['reference_number' => $referenceNo])
                        ->where(['id' => $applicationId])
                        ->execute();
                    $patentIncentivesSave->reference_number = $referenceNo;
                }
                $_message = __("Thanks for your application, Please note Reference number ( {0} ) for further communication. ", [$referenceNo]);
                $_status  = true;

                $_patentIncentives = $patentIncentivesSave;
            } else {
                $_message = __("Your application could not be saved. Please, try again.");
            }
        } else if (empty($_message)) {
            $_status = true;
        }
	
	if(!empty($_startup)) {
            $dateFields = ['date_of_registration','date_of_filling_application'];
            foreach ($dateFields as $field) {
                $date = $_startup->get($field);
                if(!empty($date)) {
                    $_startup->{$field} = $date->format($this->dateFormat);
                }
            }
        }
	
        $this->set([
            '_status'             => $_status,
            '_startup'          => $_startup,
            '_patentIncentives' => $_patentIncentives,
            '_message'            => $_message,
	    'patentsBaseUrl'   => $patentsBaseUrl,
	    '_format_links' => $_format_links,
	    '_serialize'          => [
                '_status', '_startup', '_patentIncentives', '_message','patentsBaseUrl','_format_links'
            ],
        ]);
    }
    
    public function apiQualityCertifications()
    {
        if ($this->isDevice == false) {
            return $this->redirect(['controller' => 'Dashboard', 'action' => 'index']);
        }
        $this->loadModel('StartupApplications');
	$this->loadModel('StartupQualityCertifications');
	
        $this->request->allowMethod(['get', 'post']);
        $_status  = false;
        $_message = '';
	
        $_startup          = new \stdClass();
        $_qualityCertifications = new \stdClass();
	
	$qualityBaseUrl = Router::Url('/files/quality',true);
	
	$_format_links = [
	  'authorization_letter' => Router::Url('/files/Annexure/Letter_of_Authorization_quality.docx',true),
	  'undertaking' => Router::Url('/files/Annexure/Undertaking_quality.docx',true),
	  'application_form' => Router::Url('/files/Annexure/Undertaking_quality.docx',true),
	  'detailed_statement' => Router::Url('/files/Annexure/Annexure-IV_FormB.docx',true)
	];
	
	if ($this->request->is(['post'])) {
            $applicationId = $this->request->getData('applicationId');
            $userId        = $this->request->getData('userId');
        } else {
            $applicationId = $this->request->getQuery('applicationId');
            $userId        = $this->request->getQuery('userId');
        }
        if (!empty($userId)) {
            $where     = [];
            $where[]   = ['user_id' => $userId];
            $startup = $this->StartupApplications->find('all')->where($where)->first();
            if (!empty($startup) && empty($startup->recognition_certificate_no)) {
                $_message = __('Your application is being considered but has not yet been approved.');
            } else if (empty($startup)) {
                $_message = __('You have not applied for any Startup.');
            } else {
                $qualityCertifications = (!empty($applicationId)) ? $this->StartupQualityCertifications->get($applicationId)->first() : $this->StartupQualityCertifications->newEntity();
            }
        } else {
            $_message = __('UserID is required');
        }
        if (!empty($startup)) {
            $_startup = $startup;
        }
        if (!empty($qualityCertifications) && !$qualityCertifications->isNew()) {
            $_qualityCertifications = $qualityCertifications;
        }
        if (empty($_message) && $this->request->is(['post'])) {
	    //echo "<pre>";print_r($this->request->getData());exit;
	    $postData = $this->request->getData();
	    //$postData['startup_application_id'] = $startup->id;
	    $qualityCertifications->startup_application_id = $startup->id;
	    if(!empty($postData['date_of_registration'])){
		$postData['date_of_registration']  = date('Y-m-d',strtotime($postData['date_of_registration']));
	    }
	    $postData['application_status_id']    = 1;
            $postData['application_stage_id']     = 1;
            if ($qualityCertifications->isNew()) {
		$postData['created'] = date('Y-m-d H:i:s');
            }
	    /** Document **/
            $qualityCertificationsFiles = ['registration_certificate','authorization_letter','undertaking','application_form','quality_certificate','cancelled_cheque','detailed_statement','original_invoice','payment_proof'];
            foreach ($qualityCertificationsFiles as $field) {
                if (isset($postData[$field]) && $postData[$field]['name'] != '') {
                    $uploaded         = $this->uploadFiles('patents', $postData[$field]);
		    if(!empty($uploaded) && !empty($uploaded['filename'])){
			$postData[$field] = $uploaded['filename'];
		    }
                } else if (isset($postData[$field])) {
                    unset($postData[$field]);
                }
            }
	    //Save
            $qualityCertificationsSave = $this->StartupQualityCertifications->patchEntity($qualityCertifications, $postData);
            if ($this->StartupQualityCertifications->save($qualityCertificationsSave)) {
                $applicationId = $qualityCertificationsSave->id;
                $referenceNo   = $qualityCertificationsSave->reference_number;
                //if ($patentIncentives->isNew()) {
		if(empty($referenceNo)){
                    $referenceNo = $this->patentReferenceNo($applicationId);
                    $this->StartupQualityCertifications->query()
                        ->update()
                        ->set(['reference_number' => $referenceNo])
                        ->where(['id' => $applicationId])
                        ->execute();
                    $qualityCertificationsSave->reference_number = $referenceNo;
                }
                $_message = __("Thanks for your application, Please note Reference number ( {0} ) for further communication. ", [$referenceNo]);
                $_status  = true;

                $_qualityCertifications = $qualityCertificationsSave;
            } else {
		//echo "<pre>";print_r($qualityCertificationsSave->errors());exit;
                $_message = __("Your application could not be saved. Please, try again.");
            }
        } else if (empty($_message)) {
            $_status = true;
        }
	
	if(!empty($_startup)) {
            $dateFields = ['date_of_registration'];
            foreach ($dateFields as $field) {
                $date = $_startup->get($field);
                if(!empty($date)) {
                    $_startup->{$field} = $date->format($this->dateFormat);
                }
            }
        }
	
        $this->set([
            '_status'             => $_status,
            '_startup'          => $_startup,
            '_qualityCertifications' => $_qualityCertifications,
            '_message'            => $_message,
	    'qualityBaseUrl'   => $qualityBaseUrl,
	    '_format_links' => $_format_links,
	    '_serialize'          => [
                '_status', '_startup', '_qualityCertifications', '_message','qualityBaseUrl','_format_links'
            ],
        ]);
    }
    
    public function apiDevelopments()
    {
        if ($this->isDevice == false) {
            return $this->redirect(['controller' => 'Dashboard', 'action' => 'index']);
        }
        $this->loadModel('StartupApplications');
	$this->loadModel('StartupAppIncentives');
	
        $this->request->allowMethod(['get', 'post']);
        $_status  = false;
        $_message = '';
	
        $_startup          = new \stdClass();
        $_developments = new \stdClass();
	
	$developmentBaseUrl = Router::Url('/files/development',true);
	
        if ($this->request->is(['post'])) {
            $applicationId = $this->request->getData('applicationId');
            $userId        = $this->request->getData('userId');
        } else {
            $applicationId = $this->request->getQuery('applicationId');
            $userId        = $this->request->getQuery('userId');
        }
        if (!empty($userId)) {
            $where     = [];
            $where[]   = ['user_id' => $userId];
            $startup = $this->StartupApplications->find('all')->where($where)->first();
            if (!empty($startup) && empty($startup->recognition_certificate_no)) {
                $_message = __('Your application is being considered but has not yet been approved.');
            } else if (empty($startup)) {
                $_message = __('You have not applied for any Startup.');
            } else {
                $developments = (!empty($applicationId)) ? $this->StartupAppIncentives->get($applicationId)->first() : $this->StartupAppIncentives->newEntity();
            }
        } else {
            $_message = __('UserID is required');
        }
        if (!empty($startup)) {
            $_startup = $startup;
        }
        if (!empty($developments) && !$developments->isNew()) {
            $_developments = $developments;
        }
        if (empty($_message) && $this->request->is(['post'])) {
	    $postData = $this->request->getData();
            //$postData['startup_application_id'] = $startup->id;
	    $developments->startup_application_id = $startup->id;
	    if(!empty($postData['date_of_registration'])){
		$postData['date_of_registration']  = date('Y-m-d',strtotime($postData['date_of_registration']));
	    }
	    $postData['application_status_id']    = 1;
            $postData['application_stage_id']     = 1;
            if ($developments->isNew()) {
                $postData['created'] = date('Y-m-d H:i:s');
            }
            /** Document **/
            $developmentsFiles = ['registration_certificate','authorization_letter','undertaking_letter','original_invoices','cancelled_cheque','payment_proof'];
            foreach ($developmentsFiles as $field) {
                if (isset($postData[$field]) && $postData[$field]['name'] != '') {
                    $uploaded         = $this->uploadFiles('development', $postData[$field]);
                    if(!empty($uploaded) && !empty($uploaded['filename'])){
			$postData[$field] = $uploaded['filename'];
		    }
                } else if (isset($postData[$field])) {
                    unset($postData[$field]);
                }
            }
	    //Save
            $developmentsSave = $this->StartupAppIncentives->patchEntity($developments, $postData);
            if ($this->StartupAppIncentives->save($developmentsSave)) {
                $applicationId = $developmentsSave->id;
                $referenceNo   = $developmentsSave->reference_number;
                //if ($patentIncentives->isNew()) {
		if(empty($referenceNo)){
                    $referenceNo = $this->appReferenceNo($applicationId,$userId);
                    $this->StartupAppIncentives->query()
                        ->update()
                        ->set(['reference_number' => $referenceNo])
                        ->where(['id' => $applicationId])
                        ->execute();
                    $developmentsSave->reference_number = $referenceNo;
                }
                $_message = __("Thanks for your application, Please note Reference number ( {0} ) for further communication. ", [$referenceNo]);
                $_status  = true;

                $_developments = $developmentsSave;
            } else {
                $_message = __("Your application could not be saved. Please, try again.");
            }
        } else if (empty($_message)) {
            $_status = true;
        }
	
	if(!empty($_startup)) {
            $dateFields = ['date_of_registration'];
            foreach ($dateFields as $field) {
                $date = $_startup->get($field);
                if(!empty($date)) {
                    $_startup->{$field} = $date->format($this->dateFormat);
                }
            }
        }
	
        $this->set([
            '_status'             => $_status,
            '_startup'          => $_startup,
            '_developments' => $_developments,
            '_message'            => $_message,
	    'developmentBaseUrl'   => $developmentBaseUrl,
	    '_serialize'          => [
                '_status', '_startup', '_developments', '_message','developmentBaseUrl'
            ],
        ]);
    }
    
    public function apiLeaseRentals()
    {
        if ($this->isDevice == false) {
            return $this->redirect(['controller' => 'Dashboard', 'action' => 'index']);
        }
        $this->loadModel('StartupApplications');
	$this->loadModel('StartupLeaseIncentives');
	
        $this->request->allowMethod(['get', 'post']);
        $_status  = false;
        $_message = '';
	
        $_startup          = new \stdClass();
        $_leaseRentals = new \stdClass();
	
	$leaseRentalsBaseUrl = Router::Url('/files/lease-rental',true);
	
	$_format_links = [
	    'authorization_letter' => Router::Url('/files/Annexure/Letter_of_Authorization_Lease_Rentals.docx',true),
	    'undertaking_letter' => Router::Url('/files/Annexure/Undertaking_Lease_Rentals.docx',true)
	];
	
        if ($this->request->is(['post'])) {
            $applicationId = $this->request->getData('applicationId');
            $userId        = $this->request->getData('userId');
        } else {
            $applicationId = $this->request->getQuery('applicationId');
            $userId        = $this->request->getQuery('userId');
        }
        if (!empty($userId)) {
            $where     = [];
            $where[]   = ['user_id' => $userId];
            $startup = $this->StartupApplications->find('all')->where($where)->first();
            if (!empty($startup) && empty($startup->recognition_certificate_no)) {
                $_message = __('Your application is being considered but has not yet been approved.');
            } else if (empty($startup)) {
                $_message = __('You have not applied for any Startup.');
            } else {
                $leaseRentals = (!empty($applicationId)) ? $this->StartupLeaseIncentives->get($applicationId)->first() : $this->StartupLeaseIncentives->newEntity();
            }
        } else {
            $_message = __('UserID is required');
        }
        if (!empty($startup)) {
            $_startup = $startup;
        }
        if (!empty($leaseRentals) && !$leaseRentals->isNew()) {
            $_leaseRentals = $leaseRentals;
        }
        if (empty($_message) && $this->request->is(['post'])) {
	    $postData = $this->request->getData();
            //$postData['startup_application_id'] = $startup->id;
	    $leaseRentals->startup_application_id = $startup->id;
	    if(!empty($postData['date_of_registration'])){
		$postData['date_of_registration']  = date('Y-m-d',strtotime($postData['date_of_registration']));
	    }
	    if(!empty($postData['date_of_commencement'])){
		$postData['date_of_commencement']  = date('Y-m-d',strtotime($postData['date_of_commencement']));
	    }
	    if(!empty($postData['being_claimed_date'])){
		$postData['being_claimed_date']  = date('Y-m-d',strtotime($postData['being_claimed_date']));
	    }
	    if(!empty($postData['end_claimed_date'])){
		$postData['end_claimed_date']  = date('Y-m-d',strtotime($postData['end_claimed_date']));
	    }
	    $postData['application_status_id']    = 1;
            $postData['application_stage_id']     = 1;
            if ($leaseRentals->isNew()) {
                $postData['created'] = date('Y-m-d H:i:s');
            }
            /** Document **/
            $leaseRentalsFiles = ['registration_certificate','authorization_letter','undertaking_letter','proof_startup_operation','cancelled_cheque','space_proof','space_photographs','rent_receipts','payment_proof'];
            foreach ($leaseRentalsFiles as $field) {
                if (isset($postData[$field]) && $postData[$field]['name'] != '') {
                    $uploaded         = $this->uploadFiles('lease-rental', $postData[$field]);
                    if(!empty($uploaded) && !empty($uploaded['filename'])){
			$postData[$field] = $uploaded['filename'];
		    }
                } else if (isset($postData[$field])) {
                    unset($postData[$field]);
                }
            }
	    //Save
            $leaseRentalsSave = $this->StartupLeaseIncentives->patchEntity($leaseRentals, $postData);
            if ($this->StartupLeaseIncentives->save($leaseRentalsSave)) {
		$applicationId = $leaseRentalsSave->id;
		
		/*startup_application_file_movements Table*/
		$tableName                 = 'StartupLeaseIncentivesFileMovements';
		$application_id_columnName = 'startup_lease_incentive_id';
		$startup_application_id    = $applicationId;
		$comment                   = '';
		$current_with              = 'Dealing Officer';
		$initiated_date            = $leaseRentalsSave->created;
		$panding_from              = date('Y-m-d');	
		
		$this->fileMovement($tableName, $application_id_columnName, $startup_application_id, $current_with, $comment, $initiated_date, $panding_from, $postData);
                
		$referenceNo   = $leaseRentalsSave->reference_number;
                //if ($patentIncentives->isNew()) {
		if(empty($referenceNo)){
                    $referenceNo = $this->leaseReferenceNo($applicationId,$userId);
                    $this->StartupLeaseIncentives->query()
                        ->update()
                        ->set(['reference_number' => $referenceNo])
                        ->where(['id' => $applicationId])
                        ->execute();
                    $leaseRentalsSave->reference_number = $referenceNo;
                }
                $_message = __("Thanks for your application, Please note Reference number ( {0} ) for further communication. ", [$referenceNo]);
                $_status  = true;

                $_leaseRentals = $leaseRentalsSave;
            } else {
                $_message = __("Your application could not be saved. Please, try again.");
            }
        } else if (empty($_message)) {
            $_status = true;
        }
	
	if(!empty($_startup)) {
            $dateFields = ['date_of_registration','date_of_commencement','being_claimed_date','end_claimed_date'];
            foreach ($dateFields as $field) {
                $date = $_startup->get($field);
                if(!empty($date)) {
                    $_startup->{$field} = $date->format($this->dateFormat);
                }
            }
        }
	
        $this->set([
            '_status'             => $_status,
            '_startup'          => $_startup,
            '_leaseRentals' => $_leaseRentals,
            '_message'            => $_message,
	    'leaseRentalsBaseUrl'   => $leaseRentalsBaseUrl,
	    '_format_links' => $_format_links,
	    '_serialize'          => [
                '_status', '_startup', '_leaseRentals', '_message','leaseRentalsBaseUrl','_format_links'
            ],
        ]);
    }
    
    public function apiCheckIncentive()
    {
        if ($this->isDevice == false) {
            return $this->redirect(['controller' => 'Dashboard', 'action' => 'index']);
        }
		$this->loadModel('StartupApplications');
        $this->request->allowMethod(['get']);
        $_status  = false;
        $_message = '';

        $_BaseUrl         = Router::Url('/files/registration', true);
        $_DirectorBaseUrl = Router::Url('/files/directors', true);

        $_startup = new \stdClass();

        $userId = $this->request->getQuery('userId');
        if (!empty($userId)) {
            $where     = [];
            $where[]   = ['user_id' => $userId];
            $startup = $this->StartupApplications->find('all', ['contain' => ['StartupDirectors']])->where($where)->first();
            if (!empty($startup) && empty($startup->recognition_certificate_no)) {
                $_message = __('Your application is being considered but has not yet been approved.');
            } else if (empty($startup)) {
				$_message = __('You have not applied for any Startup.');
            }
        } else {
            $_message = __('UserID is required');
        }
        if (empty($_message)) {
            $_status = true;
        }
        if (!empty($startup)) {
            $_startup = $startup;
        }
		if(!empty((array)$_startup)) {
            $dateFields = [
				'date_of_registration','date_of_incorporation','start_date_of_incubation','end_date_of_incubation',
				'created','updated'
			];
            foreach ($dateFields as $field) {
                $date = $_startup->get($field);
                if(!empty($date)) {
                    $_startup->{$field} = $date->format($this->dateFormat);
                }
            }
        }
		
        $this->set([
            '_status'          => $_status,
            '_startup'         => $_startup,
            '_BaseUrl'         => $_BaseUrl,
            '_DirectorBaseUrl' => $_DirectorBaseUrl,
            '_message'         => $_message,
            '_serialize'       => [
                '_status', '_startup', '_BaseUrl', '_DirectorBaseUrl', '_message',
            ],
        ]);
    }
    
    /*public function convertHtml($application)
    {
	if(!empty($application)){
	    if($this->isDevice) {
		//if (is_object($application)) {
		//    $values = get_class_vars(get_class($application));
		//    foreach ( $values as $key => $value ) {
		//	$application->{htmlspecialchars($key)} = convertHtml($value);
		//    }
		//}else{
		//    $application = htmlspecialchars($application);
		//}
		if(!empty($application->name_of_startup)){
		    $application->name_of_startup = htmlspecialchars_decode($application->name_of_startup);
		}
		if(!empty($application->registered_address)){
		    $application->registered_address = htmlspecialchars_decode($application->registered_address);
		}
		if(!empty($application->registered_block)){
		    $application->registered_block = htmlspecialchars_decode($application->registered_block);
		}
		if(!empty($application->corporate_address)){
		    $application->corporate_address = htmlspecialchars_decode($application->corporate_address);
		}
		if(!empty($application->corporate_block)){
		    $application->corporate_block = htmlspecialchars_decode($application->corporate_block);
		}
		if(!empty($application->regional_address)){
		    $application->regional_address = htmlspecialchars_decode($application->regional_address);
		}
		if(!empty($application->regional_block)){
		    $application->regional_block = htmlspecialchars_decode($application->regional_block);
		}
		if(!empty($application->branch_address)){
		    $application->branch_address = htmlspecialchars_decode($application->branch_address);
		}
		if(!empty($application->name_of_incubator)){
		    $application->name_of_incubator = htmlspecialchars_decode($application->name_of_incubator);
		}
		if(!empty($application->address_of_incubator)){
		    $application->address_of_incubator = htmlspecialchars_decode($application->address_of_incubator);
		}
		if(!empty($application->name_of_im)){
		    $application->name_of_im = htmlspecialchars_decode($application->name_of_im);
		}
		if(!empty($application->contact_details_of_im)){
		    $application->contact_details_of_im = htmlspecialchars_decode($application->contact_details_of_im);
		}
		if(!empty($application->name_of_the_product)){
		    $application->name_of_the_product = htmlspecialchars_decode($application->name_of_the_product);
		}
		if(!empty($application->product_description)){
		    $application->product_description = htmlspecialchars_decode($application->product_description);
		}
		if(!empty($application->innovativeness_in_concept)){
		    $application->innovativeness_in_concept = htmlspecialchars_decode($application->innovativeness_in_concept);
		}
		if(!empty($application->target_market_and_users)){
		    $application->target_market_and_users = htmlspecialchars_decode($application->target_market_and_users);
		}
		if(!empty($application->usefulness_of_product)){
		    $application->usefulness_of_product = htmlspecialchars_decode($application->usefulness_of_product);
		}
		if(!empty($application->features_of_product)){
		    $application->features_of_product = htmlspecialchars_decode($application->features_of_product);
		}
		if(!empty($application->compliance_to_national)){
		    $application->compliance_to_national = htmlspecialchars_decode($application->compliance_to_national);
		}
		if(!empty($application->product_patent_details)){
		    $application->product_patent_details = htmlspecialchars_decode($application->product_patent_details);
		}
		if(!empty($application->name_of_product)){
		    $application->name_of_product = htmlspecialchars_decode($application->name_of_product);
		}
		return $application;
	    }
	}
    }*/
    
    public function industries()
    {
        if($this->isDevice) {
            $this->request->allowMethod(['get']);
            
            $_status = false;
            $_message = '';
			
			$language = 'en';
			if(!empty($this->request->params) && !empty($this->request->params['language'])){
				$language = $this->request->params['language'];
			}
            
            $this->loadModel('Industries');
            $industries = $this->Industries->find('list')->where(['status'=>1])->toArray();
            $industry_data = array();
            if(empty($industries)){
                $_message = 'Industry data not found';
            }else{
                $_status = true;
                $_message = 'Industry data found';
                
                $i=0;
                foreach($industries as $key=>$value){
                    $industry_data[$i]['id'] = $key;
                    $industry_data[$i]['name'] = $value;
                    $i++;
                }
            }
            $this->set(compact('_status','_message','language','industry_data'));
			$this->set('_serialize', ['_status','_message','language','industry_data']);
        }
    }
    
    public function startupCategories()
    {
        if($this->isDevice) {
            $this->request->allowMethod(['get']);
            
            $_status = false;
            $_message = '';
			
			$language = 'en';
			if(!empty($this->request->params) && !empty($this->request->params['language'])){
				$language = $this->request->params['language'];
			}
            
            $this->loadModel('StartupCategories');
            $startup_categories = $this->StartupCategories->find('list',['keyField'=>'id','valueField'=>'name'])->where(['status'=>1])->toArray();
            $startup_category_data = array();
            if(empty($startup_categories)){
                $_message = 'Startup Category data not found';
            }else{
                $_status = true;
                $_message = 'Startup Category data found';
                
                $i=0;
                foreach($startup_categories as $key=>$value){
                    $startup_category_data[$i]['id'] = $key;
                    $startup_category_data[$i]['name'] = $value;
                    $i++;
                }
            }
            $this->set(compact('_status','_message','language','startup_category_data'));
			$this->set('_serialize', ['_status','_message','language','startup_category_data']);
        }
    }
    
    public function typesOfStartup()
    {
        if($this->isDevice) {
            $this->request->allowMethod(['get']);
            
            $_status = false;
            $_message = '';
			
			$language = 'en';
			if(!empty($this->request->params) && !empty($this->request->params['language'])){
				$language = $this->request->params['language'];
			}
            
            $this->loadModel('NatureOfStartup');
            $nature_of_startup = $this->NatureOfStartup->find('list',['keyField'=>'id','valueField'=>'nature'])->where(['status'=>1])->toArray();
            $startup_types_data = array();
            if(empty($nature_of_startup)){
                $_message = 'Startup Types data not found';
            }else{
                $_status = true;
                $_message = 'Startup Types data found';
                
                $i=0;
                foreach($nature_of_startup as $key=>$value){
                    $startup_types_data[$i]['id'] = $key;
                    $startup_types_data[$i]['name'] = $value;
                    $i++;
                }
            }
            $this->set(compact('_status','_message','language','startup_types_data'));
			$this->set('_serialize', ['_status','_message','language','startup_types_data']);
        }
    }
    
    public function states()
    {
        if($this->isDevice) {
            $this->request->allowMethod(['get']);
            
            $_status = false;
            $_message = '';
			
			$language = 'en';
			if(!empty($this->request->params) && !empty($this->request->params['language'])){
				$language = $this->request->params['language'];
			}
            
            $this->loadModel('States');
            $states = $this->States->find('list',['keyField'=>'id','valueField'=>'name'])->where(['flag'=>1])->toArray();
            $states_data = array();
            if(empty($states)){
                $_message = 'States data not found';
            }else{
                $_status = true;
                $_message = 'States data found';
                
                $i=0;
                foreach($states as $key=>$value){
                    $states_data[$i]['id'] = $key;
                    $states_data[$i]['name'] = $value;
                    $i++;
                }
            }
            $this->set(compact('_status','_message','language','states_data'));
			$this->set('_serialize', ['_status','_message','language','states_data']);
        }
    }
    
    public function banks()
    {
        if($this->isDevice) {
            $this->request->allowMethod(['get']);
            
            $_status = false;
            $_message = '';
			
			$language = 'en';
			if(!empty($this->request->params) && !empty($this->request->params['language'])){
				$language = $this->request->params['language'];
			}
            
            $this->loadModel('BankDetails');
            $bank = $this->BankDetails->find('list',['keyField'=>'bank_name','valueField'=>'bank_name'])->toArray();
            $banks_data = array();
            if(empty($bank)){
                $_message = 'Bank data not found';
            }else{
                $_status = true;
                $_message = 'Bank data found';
                
                $i=0;
                foreach($bank as $key=>$value){
                    //$banks_data[$i]['id'] = $key;
                    $banks_data[$i]['name'] = $value;
                    $i++;
                }
            }
            $this->set(compact('_status','_message','language','banks_data'));
			$this->set('_serialize', ['_status','_message','language','banks_data']);
        }
    }

    public function generateReferenceNo($id)
    {
        $this->loadModel('StartupApplications');
        $application = $this->StartupApplications->get($id);
        //$code =  $application['nature_of_startup']['code'];
        $code = 'STU';
        $string = '';
        $string.= $code.date('dmy');
        $string.= str_pad(($application->id), 6, 0, STR_PAD_LEFT);
        return $string;
    }

    public function viewStartupApplication($id='')
    {
        $this->loadModel('StartupApplications');
        $check_status = $this->StartupApplications->findByUserId($this->Auth->user('id'))->toArray();
        if(empty($check_status)){
            $this->Flash->error(__('You have not applied any Startup.'));
            $this->redirect(['controller' => 'Dashboard']);
        }
        $id = base64_decode($id);
        
        $application = $this->StartupApplications->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'index']);
        }
        $startupApplication = $this->StartupApplications->get($id,['contain'=>['Users','RegisteredStates','RegisteredDistricts','CorporateStates','CorporateDistricts','RegionalStates','RegionalDistricts','StartupStages','ApplicationStatus','NatureOfStartup','StartupCategories','Industries','Sectors','IncorporationAuthorities']]);
        $this->set(compact('startupApplication'));
    }

    public function downloadStartupApplication($id='')
    {
        $id = base64_decode($id);
        $this->loadModel('StartupApplications');
        $application = $this->StartupApplications->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'index']);
        }

        $startupApplication = $this->StartupApplications->get($id,['contain'=>['Users','RegisteredStates','RegisteredDistricts','CorporateStates','CorporateDistricts','RegionalStates','RegionalDistricts','StartupStages','ApplicationStatus','NatureOfStartup','StartupCategories','Industries','Sectors','IncorporationAuthorities', 'StartupDirectors.DirectorStates', 'StartupDirectors.DirectorDistricts']]);
        $categoryOfProduct = [1=>'Innovative',2=>'Proprietary'];
        $currentStartupStage = [1=>'Ideation',2=>'Early Traction',3=>'Scalable business'];


        $title = $startupApplication['name_of_startup'];
        $view = new View($this->request,$this->response,null);
        $view->viewPath = 'Startups';
        $view->set(compact('startupApplication','categoryOfProduct','currentStartupStage'));
        $view->layout = 'ajax';
        $html = $view->render('download_application');
        echo $this->downloadCertificate($html,$title);
    }

    public function downloadCertificate($content, $title)
    {
        $this->autoRender = false; 
        $pdf = new PDF();
        $pdf->AddPage('P');
        $pdf->SetFillColor(53,127,63);
        $pdf->SetFont('times', 'R', 11);
        $pdf->SetFont('courier', 'R', 11);
        $pdf->SetFont('Helvetica', 'R', 11);
        $pdf->SetTextColor(0,0,0);
        $pdf->SetCompression(true);
        $title = str_replace('/', '-', $title);
        $pdf->SetTitle($title);
        $pdf->writeHTML($content, false, false, false, false, 'L');
        $tempfile = $title.'_'.date("d-m-Y").'.pdf';        
        $pdf->Output($tempfile,'I');
        exit();
    }


    public function recognition()
    {
        
    }

    public function TrackApplication ()
    {
        $this->loadModel('StartupApplications');
        if($this->isDevice) {
            $this->request->allowMethod(['post']);
            
            $_status = false;
            $_message = '';
        }
        if ($this->request->is('post')) {
            $reference_no = trim($this->request->getData('reference_no'));
            $reference_no = $this->Sanitize->stripAll( $reference_no);
            $reference_no = $this->Sanitize->clean( $reference_no);
            if(!$this->isDevice) {
                $this->set('reference_no', $reference_no);
            }
            $referenceData = $this->StartupApplications->find()->contain(['ApplicationStatus'])->where(['reference_no'=> $reference_no])->first();
            if($this->isDevice) {
                $data = array();
                if(!empty($referenceData)){
                    $_status = true;
                    $message = 'Application data found';
                    
                    $data['reference_no'] = $referenceData->reference_no;
                    $data['name_of_entity'] = $referenceData->name_of_startup;
                    $data['application_date'] = date('Y-m-d',strtotime($referenceData->created));
                    $data['application_status'] = $referenceData->application_status->title;
                }else{
                    $message = 'Application data not found';
                }
                $this->set(compact('_status','_message','language','data'));
                $this->set('_serialize', ['_status','_message','language','data']);
            }
        }
        
        if(!$this->isDevice) {
            $this->set(compact('referenceData'));
        }
    }

    public function DownloadRecognitionCertificate()
    {
        $this->loadModel('StartupApplications');
		if ($this->isDevice) {
			$_status  = false;
			$_message = '';
			$fileBaseUrl = Router::Url('/en/startups/download-file',true);
		}
        if ($this->request->is('post')) {
            $certificate_no = trim($this->request->getData('certificate_no'));
            $certificate_no = $this->Sanitize->stripAll( $certificate_no);
            $certificate_no = $this->Sanitize->clean( $certificate_no);
            
			$startup_name = trim($this->request->getData('startup_name'));
            $startup_name = $this->Sanitize->stripAll( $startup_name);
            $startup_name = $this->Sanitize->clean( $startup_name);
            $this->set('certificate_no', $certificate_no);
            $this->set('startup_name', $startup_name);
			
			if ($this->isDevice) {
				if(empty($certificate_no) && empty($startup_name)){
					$_message = 'Please enter certification number or startup name';
				}
			}
            
            if (empty($startup_name)) {
                $certificateData = $this->StartupApplications->find()->where(['recognition_certificate_no'=> $certificate_no])->first();
            } else {
                $certificateData = $this->StartupApplications->find()->where(['name_of_startup'=> $startup_name])->first();
            }
			//echo "<pre>";print_r($certificateData);exit;
			if ($this->isDevice) {
				$certificate_link = '';
				if(!empty((array)$certificateData)){
					$_status = true;
					$_message = 'Recognition certificate found';
					
					$application_number = str_replace('/', '-', $certificateData->recognition_certificate_no);
					$filePath = UPLOAD_FILE.'certificate/'.$application_number.'.pdf';
					$fileLink = $fileBaseUrl.'/'.base64_encode($filePath);
					$certificate_link = $fileLink;
				}
				
				$this->set([
					'_status' => $_status,
					'_message' => $_message,
					'certificate_link' => $certificate_link,
					'_serialize' => [
						'_status', '_message', 'certificate_link'
					],
				]);
			}
        }
        $this->set(compact('certificateData'));
    }

    public function StartupPolicyNotifications()
    {
        # code...
    }

    public function SelfCertification()
    {
        # code...
    }

    public function ProductsServices()
    {
        # code...
    }

    public function SuccessStories()
    {
        # code...
    }

    public function observations()
    {
        $this->loadModel('StartupObservations');
        $this->loadModel('StartupApplications');
        $application = $this->StartupApplications->find()->where(['user_id'=>$this->Auth->user('id')])->first();
        if (empty($application)) {
            $this->Flash->error(__('You have not applied any Startup.'));
            return $this->redirect(['action' => 'index']);
        }
        $oldObservations = $this->StartupObservations->find()->where(['startup_application_id'=>$application->id])->enableHydration(false)->toArray();
        $this->set(compact('oldObservations','application'));
    }

    public function addObservation($id)
    {
        $id = base64_decode($id);
        $this->loadModel('StartupObservations');
        $application = $this->StartupObservations->findById($id)->first();
        if (empty($application)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'index']);
        }        
        $startupObservations = $this->StartupObservations->get($id);
        if($this->request->is(['post','put'])){
            $data = $this->request->getData();
            $startupObservations = $this->StartupObservations->patchEntity($startupObservations,$data);
            $startupObservations->reply_date = date('Y-m-d H:i:s');
            if($this->StartupObservations->save($startupObservations)){
                $this->Flash->success(__('You have successfully replied.'));
                return $this->redirect(['action' => 'observations']);
            }
            $this->Flash->error(__('Some error occurred. Please, try again.'));
        }
        $this->set(compact('startupObservations'));
    }

    public function downloadFile($filePath) 
    {
        if($filePath){
            $filePath = base64_decode($filePath);
            ob_clean();
            if(file_exists($filePath)){
                $this->response->file($filePath,['download' => true]);
                return $this->response;
            }else{
                $this->Flash->error('File isn\'t available on server.');
                return $this->redirect($this->referer());
            }
        }else{
            $this->Flash->error('Not a valid file.');
            return $this->redirect($this->referer());
        }
    }

    public function leaseRentalEligibility($value='')
    {
        # code...
    }

    public function leaseRentals($id='')
    {
        $this->loadModel('StartupApplications');
        $application = $this->StartupApplications->find()->where(['user_id'=>$this->Auth->user('id')])->first();
        if(!empty($application)){
            if (empty($application['recognition_certificate_no'])) {
                $this->Flash->error(__('Your application is being considered but has not yet been approved.'));
                $this->redirect(['controller' => 'Dashboard']);
            }            
            $this->loadModel('StartupLeaseIncentives');
            $id = base64_decode($id);
            $incentiveData = $this->StartupLeaseIncentives->findById($id)->first();
            if (empty($incentiveData)) {
                $startupLeaseIncentive = $this->StartupLeaseIncentives->newEntity();
            } else {
                $startupLeaseIncentive = $this->StartupLeaseIncentives->get($id);
            }
            if($this->request->is(['post','put'])){
                $data = $this->request->getData();
                $startupLeaseIncentive = $this->StartupLeaseIncentives->patchEntity($startupLeaseIncentive,$data);
                if($data['registration_certificate']['name']!=''){
                    $certificate = $this->uploadFiles('lease-rental', $data['registration_certificate']);
                    $startupLeaseIncentive->registration_certificate = $certificate['filename'];
                } else {
                    $startupLeaseIncentive->registration_certificate = $data['old_registration_certificate'];
                }
                if($data['authorization_letter']['name']!=''){
                    $certificate = $this->uploadFiles('lease-rental', $data['authorization_letter']);
                    $startupLeaseIncentive->authorization_letter = $certificate['filename'];
                } else {
                    $startupLeaseIncentive->authorization_letter = $data['old_authorization_letter'];
                }
                if($data['undertaking_letter']['name']!=''){
                    $certificate = $this->uploadFiles('lease-rental', $data['undertaking_letter']);
                    $startupLeaseIncentive->undertaking_letter = $certificate['filename'];
                } else {
                    $startupLeaseIncentive->undertaking_letter = $data['old_undertaking_letter'];
                }
                if($data['proof_startup_operation']['name']!=''){
                    $certificate = $this->uploadFiles('lease-rental', $data['proof_startup_operation']);
                    $startupLeaseIncentive->proof_startup_operation = $certificate['filename'];
                } else {
                    $startupLeaseIncentive->proof_startup_operation = $data['old_proof_startup_operation'];
                }
                if($data['cancelled_cheque']['name']!=''){
                    $certificate = $this->uploadFiles('lease-rental', $data['cancelled_cheque']);
                    $startupLeaseIncentive->cancelled_cheque = $certificate['filename'];
                } else {
                    $startupLeaseIncentive->cancelled_cheque = $data['old_cancelled_cheque'];
                }
                if($data['space_proof']['name']!=''){
                    $certificate = $this->uploadFiles('lease-rental', $data['space_proof']);
                    $startupLeaseIncentive->space_proof = $certificate['filename'];
                } else {
                    $startupLeaseIncentive->space_proof = $data['old_space_proof'];
                }
                if($data['space_photographs']['name']!=''){
                    $certificate = $this->uploadFiles('lease-rental', $data['space_photographs']);
                    $startupLeaseIncentive->space_photographs = $certificate['filename'];
                } else {
                    $startupLeaseIncentive->space_photographs = $data['old_space_photographs'];
                }
                if($data['rent_receipts']['name']!=''){
                    $certificate = $this->uploadFiles('lease-rental', $data['rent_receipts']);
                    $startupLeaseIncentive->rent_receipts = $certificate['filename'];
                } else {
                    $startupLeaseIncentive->rent_receipts = $data['old_rent_receipts'];
                }
                if($data['payment_proof']['name']!=''){
                    $certificate = $this->uploadFiles('lease-rental', $data['payment_proof']);
                    $startupLeaseIncentive->payment_proof = $certificate['filename'];
                } else {
                    $startupLeaseIncentive->payment_proof = $data['old_payment_proof'];
                }
                $startupLeaseIncentive->startup_application_id = $application['id'];
                $startupLeaseIncentive->created = date('Y-m-d H:i:s');
                if($this->StartupLeaseIncentives->save($startupLeaseIncentive)){
                    
					/*startup_application_file_movements Table*/
					$tableName 					= 'StartupLeaseIncentivesFileMovements';
					$application_id_columnName 	= 'startup_lease_incentive_id';
					$startup_application_id 	= $startupLeaseIncentive->id;
					$comment					= '';
					$current_with				= 'Dealing Officer';
					$initiated_date				= $startupLeaseIncentive->created;
					$panding_from				= date('Y-m-d');	
					
					$this->fileMovement($tableName, $application_id_columnName, $startup_application_id, $current_with, $comment, $initiated_date, $panding_from, $data);
					
					
					$leaseIncentive_id = $startupLeaseIncentive->id;
					
					
                    $this->Flash->success(__('Successfully submitted.'));
                    return $this->redirect(['action' => 'leaseRentalPreview',base64_encode($leaseIncentive_id)]);
                }
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        } else {
            $this->Flash->error(__('You have not applied any Startup.'));
            $this->redirect(['controller' => 'Dashboard']);
        }
        $this->loadModel('Designations');
        $designations = $this->Designations->find('list')->where(['status'=>1])->order(['name ASC']);
        $this->set(compact('startupLeaseIncentive','application','designations'));
    }

    public function leaseRentalPreview($id)
    {
        $this->loadModel('StartupLeaseIncentives');
        $id = base64_decode($id);
        $incentiveData = $this->StartupLeaseIncentives->findById($id)->first();
        if (empty($incentiveData)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'leaseRentals']);
        }
        $startupLeaseIncentive = $this->StartupLeaseIncentives->get($id,['contain'=>['Designations']]);

        if($this->request->is(['post','put'])){
            $data = $this->request->getData();
            $startupLeaseIncentive->application_status_id = 1;
            $startupLeaseIncentive->application_stage_id = 1;
            $startupLeaseIncentive->created = date('Y-m-d H:i:s');
            if($this->StartupLeaseIncentives->save($startupLeaseIncentive)){
                $leaseIncentive_id = $startupLeaseIncentive->id;
                $reference_no = $this->leaseReferenceNo($leaseIncentive_id);
                $query = $this->StartupLeaseIncentives->query();
                $query->update()
                    ->set(['reference_number' => $reference_no])
                    ->where(['id' => $leaseIncentive_id])
                    ->execute();
                $this->Flash->success(__("Thanks for your application, Please note Reference number ( $reference_no ) for further communication. "));
                return $this->redirect(['controller'=>'Dashboard','action' => 'index']);
            }
            $this->Flash->error(__('Some error occurred. Please, try again.'));
        }
        $this->loadModel('Designations');
        $designations = $this->Designations->find('list')->where(['status'=>1])->order(['name ASC']);
        $this->set(compact('startupLeaseIncentive','designations'));
    }

    public function leaseReferenceNo($id,$user_id = NULL)
    {
        $this->loadModel('StartupApplications');
	if($this->isDevice){
	    $application = $this->StartupApplications->find()->where(['user_id'=>$user_id])->first();
	}else{
	    $application = $this->StartupApplications->find()->where(['user_id'=>$this->Auth->user('id')])->first();
	}
        $string = '';
        //$string.= 'L/'.date('dmY').'/';
        $string.= $application->recognition_certificate_no.'/LRS/';
        $string.= str_pad(($id), 5, 0, STR_PAD_LEFT);
        return $string;
    }

    public function developmentEligibility($value='')
    {
        # code...
    }

    public function developments($id='')
    {
        $this->loadModel('StartupApplications');
        $application = $this->StartupApplications->find()->where(['user_id'=>$this->Auth->user('id')])->first();
        if(!empty($application)){
            if (empty($application['recognition_certificate_no'])) {
                $this->Flash->error(__('Your application is being considered but has not yet been approved.'));
                $this->redirect(['controller' => 'Dashboard']);
            }            
            $this->loadModel('StartupAppIncentives');
            $id = base64_decode($id);
            $incentiveData = $this->StartupAppIncentives->findById($id)->first();
            if (empty($incentiveData)) {
                $startupAppIncentive = $this->StartupAppIncentives->newEntity();
            } else {
                $startupAppIncentive = $this->StartupAppIncentives->get($id);
            }
            if($this->request->is(['post','put'])){
                $data = $this->request->getData();
                $startupAppIncentive = $this->StartupAppIncentives->patchEntity($startupAppIncentive,$data);
                $startupAppIncentive->empanelment_number = $data['empanelment_number'];
                $startupAppIncentive->total_expenditure = $data['total_expenditure'];
                if($data['registration_certificate']['name']!=''){
                    $certificate = $this->uploadFiles('development', $data['registration_certificate']);
                    $startupAppIncentive->registration_certificate = $certificate['filename'];
                } else {
                    $startupAppIncentive->registration_certificate = $data['old_registration_certificate'];
                }
                if($data['authorization_letter']['name']!=''){
                    $certificate = $this->uploadFiles('development', $data['authorization_letter']);
                    $startupAppIncentive->authorization_letter = $certificate['filename'];
                } else {
                    $startupAppIncentive->authorization_letter = $data['old_authorization_letter'];
                }
                if($data['undertaking_letter']['name']!=''){
                    $certificate = $this->uploadFiles('development', $data['undertaking_letter']);
                    $startupAppIncentive->undertaking_letter = $certificate['filename'];
                } else {
                    $startupAppIncentive->undertaking_letter = $data['old_undertaking_letter'];
                }
                if($data['original_invoices']['name']!=''){
                    $certificate = $this->uploadFiles('development', $data['original_invoices']);
                    $startupAppIncentive->original_invoices = $certificate['filename'];
                } else {
                    $startupAppIncentive->original_invoices = $data['old_original_invoices'];
                }
                if($data['cancelled_cheque']['name']!=''){
                    $certificate = $this->uploadFiles('development', $data['cancelled_cheque']);
                    $startupAppIncentive->cancelled_cheque = $certificate['filename'];
                } else {
                    $startupAppIncentive->cancelled_cheque = $data['old_cancelled_cheque'];
                }
                if($data['payment_proof']['name']!=''){
                    $certificate = $this->uploadFiles('development', $data['payment_proof']);
                    $startupAppIncentive->payment_proof = $certificate['filename'];
                } else {
                    $startupAppIncentive->payment_proof = $data['old_payment_proof'];
                }
                $startupAppIncentive->application_status_id = 1;
                $startupAppIncentive->application_stage_id  = 1;
                $startupAppIncentive->startup_application_id = $application['id'];
                $startupAppIncentive->created = date('Y-m-d H:i:s');
                if($this->StartupAppIncentives->save($startupAppIncentive)){
                    $appIncentive_id = $startupAppIncentive->id;
                    $this->Flash->success(__('Successfully submitted.'));
                    return $this->redirect(['action' => 'developmentPreview',base64_encode($appIncentive_id)]);
                }
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        } else {
            $this->Flash->error(__('You have not applied any Startup.'));
            $this->redirect(['controller' => 'Dashboard']);
        }
        $this->loadModel('Designations');
        $designations = $this->Designations->find('list')->where(['status'=>1])->order(['name ASC']);
        $this->set(compact('startupAppIncentive','application','designations'));
    }

    public function developmentPreview($id)
    {
        $this->loadModel('StartupAppIncentives');
        $id = base64_decode($id);
        $incentiveData = $this->StartupAppIncentives->findById($id)->first();
        if (empty($incentiveData)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'leaseRentals']);
        }
        $startupAppIncentive = $this->StartupAppIncentives->get($id,['contain'=>['Designations']]);

        if($this->request->is(['post','put'])){
            $data = $this->request->getData();
            $startupAppIncentive->application_status_id = 1;
            $startupAppIncentive->application_stage_id = 1;
            $startupAppIncentive->created = date('Y-m-d H:i:s');
            if($this->StartupAppIncentives->save($startupAppIncentive)){
                $appIncentive_id = $startupAppIncentive->id;
                $reference_no = $this->appReferenceNo($appIncentive_id);
                $query = $this->StartupAppIncentives->query();
                $query->update()
                    ->set(['reference_number' => $reference_no])
                    ->where(['id' => $appIncentive_id])
                    ->execute();
                $this->Flash->success(__("Thanks for your application, Please note Reference number ( $reference_no ) for further communication. "));
                return $this->redirect(['controller'=>'Dashboard','action' => 'index']);
            }
            $this->Flash->error(__('Some error occurred. Please, try again.'));
        }
        $this->set(compact('startupAppIncentive'));
    }

    public function appReferenceNo($id,$user_id = NULL)
    {
        $this->loadModel('StartupApplications');
	if($this->isDevice){
	    $application = $this->StartupApplications->find()->where(['user_id'=>$user_id])->first();
	}else{
	    $application = $this->StartupApplications->find()->where(['user_id'=>$this->Auth->user('id')])->first();
	}
        $string = '';
        $string.= $application->recognition_certificate_no.'/APD/';
        $string.= str_pad(($id), 5, 0, STR_PAD_LEFT);
        return $string;
    }

    public function innovationPromotionEligibility(){
        
    }

    public function PatentIncentives($id='')
    {
        $this->loadModel('StartupApplications');
        $application = $this->StartupApplications->find()->where(['user_id'=>$this->Auth->user('id')])->first();
        if(!empty($application)){
            if (empty($application['recognition_certificate_no'])) {
                $this->Flash->error(__('Your Startup Application is being considered but has not yet been approved.'));
                $this->redirect(['controller' => 'Dashboard']);
            }
            $this->loadModel('StartupPatentIncentives');
            $id = base64_decode($id);
            $incentiveData = $this->StartupPatentIncentives->findById($id)->first();
            if (empty($incentiveData)) {
                $startupPatentIncentive = $this->StartupPatentIncentives->newEntity();
            } else {
                $startupPatentIncentive = $this->StartupPatentIncentives->get($id);
            }
            if($this->request->is(['post','put'])){
                $data = $this->request->getData();
                $startupPatentIncentive = $this->StartupPatentIncentives->patchEntity($startupPatentIncentive,$data);
                $startupPatentIncentive->mobile_number = $data['mobile_number'];
                $startupPatentIncentive->total_expenditure = $data['total_expenditure'];
                if($data['registration_certificate']['name']!=''){
                    $certificate = $this->uploadFiles('patents', $data['registration_certificate']);
                    $startupPatentIncentive->registration_certificate = $certificate['filename'];
                } else {
                    $startupPatentIncentive->registration_certificate = $data['old_registration_certificate'];
                }
                if($data['authorization_letter']['name']!=''){
                    $certificate = $this->uploadFiles('patents', $data['authorization_letter']);
                    $startupPatentIncentive->authorization_letter = $certificate['filename'];
                } else {
                    $startupPatentIncentive->authorization_letter = $data['old_authorization_letter'];
                }
                if($data['undertaking']['name']!=''){
                    $certificate = $this->uploadFiles('patents', $data['undertaking']);
                    $startupPatentIncentive->undertaking = $certificate['filename'];
                } else {
                    $startupPatentIncentive->undertaking = $data['old_undertaking'];
                }
                if($data['application_form']['name']!=''){
                    $certificate = $this->uploadFiles('patents', $data['application_form']);
                    $startupPatentIncentive->application_form = $certificate['filename'];
                } else {
                    $startupPatentIncentive->application_form = $data['old_application_form'];
                }
                if($data['petent_registraion']['name']!=''){
                    $certificate = $this->uploadFiles('patents', $data['petent_registraion']);
                    $startupPatentIncentive->petent_registraion = $certificate['filename'];
                } else {
                    $startupPatentIncentive->petent_registraion = $data['old_petent_registraion'];
                }
                if($data['expenditure_statement']['name']!=''){
                    $certificate = $this->uploadFiles('patents', $data['expenditure_statement']);
                    $startupPatentIncentive->expenditure_statement = $certificate['filename'];
                } else {
                    $startupPatentIncentive->expenditure_statement = $data['old_expenditure_statement'];
                }
                if($data['original_invoice']['name']!=''){
                    $certificate = $this->uploadFiles('patents', $data['original_invoice']);
                    $startupPatentIncentive->original_invoice = $certificate['filename'];
                } else {
                    $startupPatentIncentive->original_invoice = $data['old_original_invoice'];
                } 
                if($data['cancelled_cheque']['name']!=''){
                    $certificate = $this->uploadFiles('patents', $data['cancelled_cheque']);
                    $startupPatentIncentive->cancelled_cheque = $certificate['filename'];
                } else {
                    $startupPatentIncentive->cancelled_cheque = $data['old_cancelled_cheque'];
                }
                if($data['payment_proof']['name']!=''){
                    $certificate = $this->uploadFiles('patents', $data['payment_proof']);
                    $startupPatentIncentive->payment_proof = $certificate['filename'];
                } else {
                    $startupPatentIncentive->payment_proof = $data['old_payment_proof'];
                } 
                if($data['sanction_refusal_letter']['name']!=''){
                    $certificate = $this->uploadFiles('patents', $data['sanction_refusal_letter']);
                    $startupPatentIncentive->sanction_refusal_letter = $certificate['filename'];
                }  else {
                    $startupPatentIncentive->sanction_refusal_letter = $data['old_sanction_refusal_letter'];
                }
                $startupPatentIncentive->application_status_id = 1;
                $startupPatentIncentive->application_stage_id  = 1;
                $startupPatentIncentive->startup_application_id = $application['id'];
                $startupPatentIncentive->created = date('Y-m-d H:i:s');
                if($this->StartupPatentIncentives->save($startupPatentIncentive)){
                    $appIncentive_id = $startupPatentIncentive->id;
                    $this->Flash->success(__('Successfully submitted.'));
                    return $this->redirect(['action' => 'patentIncentivePreview',base64_encode($appIncentive_id)]);
                }
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        } else {
            $this->Flash->error(__('You have not applied any Startup.'));
            $this->redirect(['controller' => 'Dashboard']);
        }
        $this->loadModel('Designations');
        $designations = $this->Designations->find('list')->where(['status'=>1])->order(['name ASC']);
        $this->set(compact('startupPatentIncentive','application','designations'));
    }

    public function patentIncentivePreview($id)
    {
        $this->loadModel('StartupPatentIncentives');
        $id = base64_decode($id);
        $incentiveData = $this->StartupPatentIncentives->findById($id)->first();
        if (empty($incentiveData)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'PatentIncentives']);
        }
        $startupPatentIncentive = $this->StartupPatentIncentives->get($id,['contain'=>['Designations']]);

        if($this->request->is(['post','put'])){
            $data = $this->request->getData();
            $startupPatentIncentive->application_status_id = 1;
            $startupPatentIncentive->application_stage_id = 1;
            $startupPatentIncentive->created = date('Y-m-d H:i:s');
            if($this->StartupPatentIncentives->save($startupPatentIncentive)){
                $appIncentive_id = $startupPatentIncentive->id;
                $reference_no = $this->patentReferenceNo($appIncentive_id);
                $query = $this->StartupPatentIncentives->query();
                $query->update()
                    ->set(['reference_number' => $reference_no])
                    ->where(['id' => $appIncentive_id])
                    ->execute();
                $this->Flash->success(__("Thanks for your application, Please note Reference number ( $reference_no ) for further communication. "));
                return $this->redirect(['controller'=>'Dashboard','action' => 'index']);
            }
            $this->Flash->error(__('Some error occurred. Please, try again.'));
        }
        $this->set(compact('startupPatentIncentive'));
    }

    public function patentReferenceNo($id)
    {
        $string = '';
        $string.= 'P/'.date('dmY').'/';
        $string.= str_pad(($id), 5, 0, STR_PAD_LEFT);
        return $string;
    }

    public function QualityCertifications($id='')
    {
        $this->loadModel('StartupApplications');
        $application = $this->StartupApplications->find()->where(['user_id'=>$this->Auth->user('id')])->first();
        if(!empty($application)){
            if (empty($application['recognition_certificate_no'])) {
                $this->Flash->error(__('Your Startup Application is being considered but has not yet been approved.'));
                $this->redirect(['controller' => 'Dashboard']);
            }
            $this->loadModel('StartupQualityCertifications');
            $id = base64_decode($id);
            $incentiveData = $this->StartupQualityCertifications->findById($id)->first();
            if (empty($incentiveData)) {
                $startupQCIncentive = $this->StartupQualityCertifications->newEntity();
            } else {
                $startupQCIncentive = $this->StartupQualityCertifications->get($id);
            }
            if($this->request->is(['post','put'])){
                $data = $this->request->getData();
                $startupQCIncentive = $this->StartupQualityCertifications->patchEntity($startupQCIncentive,$data);
                $startupQCIncentive->total_expenditure = $data['total_expenditure'];
                if($data['registration_certificate']['name']!=''){
                    $certificate = $this->uploadFiles('quality', $data['registration_certificate']);
                    $startupQCIncentive->registration_certificate = $certificate['filename'];
                } else {
                    $startupQCIncentive->registration_certificate = $data['old_registration_certificate'];
                }
                if($data['authorization_letter']['name']!=''){
                    $certificate = $this->uploadFiles('quality', $data['authorization_letter']);
                    $startupQCIncentive->authorization_letter = $certificate['filename'];
                } else {
                    $startupQCIncentive->authorization_letter = $data['old_authorization_letter'];
                }
                if($data['undertaking']['name']!=''){
                    $certificate = $this->uploadFiles('quality', $data['undertaking']);
                    $startupQCIncentive->undertaking = $certificate['filename'];
                } else {
                    $startupQCIncentive->undertaking = $data['old_undertaking'];
                }
                if($data['application_form']['name']!=''){
                    $certificate = $this->uploadFiles('quality', $data['application_form']);
                    $startupQCIncentive->application_form = $certificate['filename'];
                } else {
                    $startupQCIncentive->application_form = $data['old_application_form'];
                }
                if($data['quality_certificate']['name']!=''){
                    $certificate = $this->uploadFiles('quality', $data['quality_certificate']);
                    $startupQCIncentive->quality_certificate = $certificate['filename'];
                } else {
                    $startupQCIncentive->quality_certificate = $data['old_quality_certificate'];
                }
                if($data['cancelled_cheque']['name']!=''){
                    $certificate = $this->uploadFiles('quality', $data['cancelled_cheque']);
                    $startupQCIncentive->cancelled_cheque = $certificate['filename'];
                } else {
                    $startupQCIncentive->cancelled_cheque = $data['old_cancelled_cheque'];
                }
                if($data['detailed_statement']['name']!=''){
                    $certificate = $this->uploadFiles('quality', $data['detailed_statement']);
                    $startupQCIncentive->detailed_statement = $certificate['filename'];
                } else {
                    $startupQCIncentive->detailed_statement = $data['old_detailed_statement'];
                }
                if($data['original_invoice']['name']!=''){
                    $certificate = $this->uploadFiles('quality', $data['original_invoice']);
                    $startupQCIncentive->original_invoice = $certificate['filename'];
                } else {
                    $startupQCIncentive->original_invoice = $data['old_original_invoice'];
                }
                if($data['payment_proof']['name']!=''){
                    $certificate = $this->uploadFiles('quality', $data['payment_proof']);
                    $startupQCIncentive->payment_proof = $certificate['filename'];
                } else {
                    $startupQCIncentive->payment_proof = $data['old_payment_proof'];
                }
                $startupQCIncentive->application_status_id = 1;
                $startupQCIncentive->application_stage_id  = 1;
                $startupQCIncentive->startup_application_id = $application['id'];
                $startupQCIncentive->created = date('Y-m-d H:i:s');
                if($this->StartupQualityCertifications->save($startupQCIncentive)){
                    $appIncentive_id = $startupQCIncentive->id;
                    $this->Flash->success(__('Successfully submitted.'));
                    return $this->redirect(['action' => 'QualityCertificationPreview',base64_encode($appIncentive_id)]);
                }
                $this->Flash->error(__('Some error occurred. Please, try again.'));
            }
        } else {
            $this->Flash->error(__('You have not applied any Startup.'));
            $this->redirect(['controller' => 'Dashboard']);
        }
        $this->loadModel('Designations');
        $designations = $this->Designations->find('list')->where(['status'=>1])->order(['name ASC']);
        $this->set(compact('startupQCIncentive','application','designations'));
    }

    public function QualityCertificationPreview($id)
    {
        $this->loadModel('StartupQualityCertifications');
        $id = base64_decode($id);
        $incentiveData = $this->StartupQualityCertifications->findById($id)->first();
        if (empty($incentiveData)) {
            $this->Flash->error(__('Somthing went wrong.'));
            return $this->redirect(['action' => 'QualityCertifications']);
        }
        $startupQCIncentive = $this->StartupQualityCertifications->get($id,['contain'=>['Designations']]);

        if($this->request->is(['post','put'])){
            $data = $this->request->getData();
            $startupQCIncentive->application_status_id = 1;
            $startupQCIncentive->application_stage_id = 1;
            $startupQCIncentive->created = date('Y-m-d H:i:s');
            if($this->StartupQualityCertifications->save($startupQCIncentive)){
                $appIncentive_id = $startupQCIncentive->id;
                $reference_no = $this->qualityReferenceNo($appIncentive_id);
                $query = $this->StartupQualityCertifications->query();
                $query->update()
                    ->set(['reference_number' => $reference_no])
                    ->where(['id' => $appIncentive_id])
                    ->execute();
                $this->Flash->success(__("Thanks for your application, Please note Reference number ( $reference_no ) for further communication. "));
                return $this->redirect(['controller'=>'Dashboard','action' => 'index']);
            }
            $this->Flash->error(__('Some error occurred. Please, try again.'));
        }
        $this->set(compact('startupQCIncentive'));
    }

    public function qualityReferenceNo($id)
    {
        $string = '';
        $string.= 'Q/'.date('dmY').'/';
        $string.= str_pad(($id), 5, 0, STR_PAD_LEFT);
        return $string;
    }


}