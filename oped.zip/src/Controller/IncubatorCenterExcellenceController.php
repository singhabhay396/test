<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Event\Event;
use Cake\Routing\Router;

/**
 * IncubatorCenterExcellence Controller
 *
 * @property \App\Model\Table\IncubatorCenterExcellenceTable $IncubatorCenterExcellence
 *
 * @method \App\Model\Entity\IncubatorCenterExcellence[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class IncubatorCenterExcellenceController extends AppController
{
    public function initialize()
    {
        parent::initialize();
        $this->viewBuilder()->setLayout('frontend');
        $this->Auth->allow(['index']);
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
    }

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        if($this->isDevice) {
            $this->request->allowMethod(['get']);
            
            $_status = false;
            $_message = '';
			
			$totalCurrentCounts = 0;
			$totalCurrentPages = 0;
			$currentPageSize = 0;
			$currentPageIndex = 0;
            
            $totalUpcomingCounts = 0;
			$totalUpcomingPages = 0;
			$upcomingPageSize = 0;
			$upcomingPageIndex = 0;
		}
        try{
			$centerExcellence_current = $this->paginate($this->IncubatorCenterExcellence->find()->where(['status'=>1,'type'=>1]));
            if($this->isDevice) {
                $centerExcellence_current_paging = $this->Paginator->getPaginator()->getPagingParams();
            }
            
            $centerExcellence_upcoming = $this->paginate($this->IncubatorCenterExcellence->find()->where(['status'=>1,'type'=>2]));
            if($this->isDevice) {
                $centerExcellence_upcoming_paging = $this->Paginator->getPaginator()->getPagingParams();
            }
		}catch(HttpNotFoundException $e){
			$centerExcellence_current = array();
            $centerExcellence_upcoming = array();
		}
        //echo "<pre>";print_r($centerExcellence_upcoming);exit;
        $center_excellence_data = array();
        if($this->isDevice) {
			//$paging = $this->Paginator->getPaginator()->getPagingParams();
            //echo "<pre>";print_r($centerExcellence_upcoming_paging);exit;
			if (!empty($centerExcellence_current_paging['IncubatorCenterExcellence'])) {
				$totalCurrentCounts = $centerExcellence_current_paging['IncubatorCenterExcellence']['count'];
				$totalCurrentPages = $centerExcellence_current_paging['IncubatorCenterExcellence']['pageCount'];
				$currentPageSize  = $centerExcellence_current_paging['IncubatorCenterExcellence']['perPage'];
				$currentPageIndex = $centerExcellence_current_paging['IncubatorCenterExcellence']['current'];
			}
            if (!empty($centerExcellence_upcoming_paging['IncubatorCenterExcellence'])) {
				$totalUpcomingCounts = $centerExcellence_upcoming_paging['IncubatorCenterExcellence']['count'];
				$totalUpcomingPages = $centerExcellence_upcoming_paging['IncubatorCenterExcellence']['pageCount'];
				$upcomingPageSize  = $centerExcellence_upcoming_paging['IncubatorCenterExcellence']['perPage'];
				$upcomingPageIndex = $centerExcellence_upcoming_paging['IncubatorCenterExcellence']['current'];
			}
			
            if(
                ($totalCurrentCounts != 0 || $totalUpcomingCounts != 0) &&
                (!empty($centerExcellence_current) || !empty($centerExcellence_upcoming))
            ){
				$_status = true;
				$_message = 'Incubator Center Excellence Found';
				if(!empty($centerExcellence_current)){
                    foreach($centerExcellence_current as $cec){
                        $current_urls = array();
                        if(!empty($cec->url)){
                            $url_explode = explode(',',$cec->url);
                            if(!empty($url_explode)){
                                foreach($url_explode as $url){
                                    $current_urls[] = trim($url);
                                }
                            }
                        }
                        $cec->url = $current_urls;
                        $cec->image = Router::url('/',true) . 'files/center_excellence/' . $cec->image;
						$cec->created = $cec->created->format('Y-m-d');
						$cec->modified = $cec->modified->format('Y-m-d');
                        
                        $center_excellence_data['current'][] = $cec;
					}
				}
                if(!empty($centerExcellence_upcoming)){
					foreach($centerExcellence_upcoming as $ceu){
                        $upcoming_urls = array();
                        if(!empty($ceu->url)){
                            $url_explode = explode(',',$ceu->url);
                            if(!empty($url_explode)){
                                foreach($url_explode as $url){
                                    $upcoming_urls[] = trim($url);
                                }
                            }
                        }
                        $ceu->url = $upcoming_urls;
                        $ceu->image = Router::url('/',true) . 'files/center_excellence/' . $ceu->image;
						$ceu->created = $ceu->created->format('Y-m-d');
						$ceu->modified = $ceu->modified->format('Y-m-d');
                        
                        $center_excellence_data['upcoming'][] = $ceu;
					}
				}
			}else{
				$_message = 'Incubator Center Excellence not found';
			}
            
			//echo "<pre>";print_r($event);exit;
			$this->set(compact(
				'_status','_message','totalCurrentCounts','totalCurrentPages','currentPageSize','currentPageIndex',
                'totalUpcomingCounts','totalUpcomingPages','upcomingPageSize','upcomingPageIndex',
                'center_excellence_data'
			));
			$this->set('_serialize', [
				'_status','_message','totalCurrentCounts','totalCurrentPages','currentPageSize','currentPageIndex',
                'totalUpcomingCounts','totalUpcomingPages','upcomingPageSize','upcomingPageIndex',
                'center_excellence_data'
			]);
		}else{
            $this->set(compact('centerExcellence_current','centerExcellence_upcoming'));
        }
    }

    /**
     * View method
     *
     * @param string|null $id Incubator Center Excellence id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $incubatorCenterExcellence = $this->IncubatorCenterExcellence->get($id, [
            'contain' => ['IncubatorCenterExcellenceTranslation']
        ]);

        $this->set('incubatorCenterExcellence', $incubatorCenterExcellence);
    }
}
