<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * IncubatorMentorTraining Entity
 *
 * @property int $id
 * @property int $incubator_application_id
 * @property string $incubator_name
 * @property string $registration_number
 * @property \Cake\I18n\FrozenDate $date_of_registration
 * @property string $name
 * @property int $designation_id
 * @property string $email
 * @property string $mobile_number
 * @property \Cake\I18n\FrozenDate $date_of_commencement
 * @property string $actual_expense
 * @property string $incentive_amount
 * @property string|null $other_information
 * @property string $registration_certificate
 * @property string $applicant_certificate
 * @property string $association_memorandum
 * @property string $authorization_letter
 * @property string $undertaking_letter
 * @property string $proof_incubator_operation
 * @property string|null $ca_certificate
 * @property string|null $certificate_from_hod
 * @property string|null $mentor_details
 * @property string|null $key_mentors_list
 * @property string|null $participants_attendance
 * @property string|null $photographs_videos
 * @property string $cancelled_cheque
 * @property string|null $claimed_expenses_bill
 * @property string|null $payment_proof
 * @property string|null $performance_report
 * @property string|null $admin_comment
 * @property \Cake\I18n\FrozenDate|null $admin_comment_date
 * @property string|null $screening_committee_comment
 * @property \Cake\I18n\FrozenDate|null $screening_committee_date
 * @property string|null $steering_committee_comment
 * @property \Cake\I18n\FrozenDate|null $approval_date
 * @property string|null $application_number
 * @property string|null $reference_number
 * @property int $application_status_id
 * @property int $application_stage_id
 * @property \Cake\I18n\FrozenTime $created
 * @property \Cake\I18n\FrozenTime $updated
 *
 * @property \App\Model\Entity\IncubatorApplication $incubator_application
 * @property \App\Model\Entity\Designation $designation
 * @property \App\Model\Entity\ApplicationStatus $application_status
 * @property \App\Model\Entity\ApplicationStage $application_stage
 */
class IncubatorMentorTraining extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'incubator_application_id' => true,
        'incubator_name' => true,
        'registration_number' => true,
        'date_of_registration' => true,
        'name' => true,
        'designation_id' => true,
        'email' => true,
        'mobile_number' => true,
        'date_of_commencement' => true,
        'actual_expense' => true,
        'incentive_amount' => true,
        'other_information' => true,
        'registration_certificate' => true,
        'applicant_certificate' => true,
        'association_memorandum' => true,
        'authorization_letter' => true,
        'undertaking_letter' => true,
        'proof_incubator_operation' => true,
        'ca_certificate' => true,
        'certificate_from_hod' => true,
        'mentor_details' => true,
        'key_mentors_list' => true,
        'participants_attendance' => true,
        'photographs_videos' => true,
        'cancelled_cheque' => true,
        'claimed_expenses_bill' => true,
        'payment_proof' => true,
        'performance_report' => true,
        'admin_comment' => true,
        'admin_comment_date' => true,
        'screening_committee_comment' => true,
        'screening_committee_date' => true,
        'steering_committee_comment' => true,
        'approval_date' => true,
        'application_number' => true,
        'reference_number' => true,
        'sanction_amount' => true,
        'application_status_id' => true,
        'application_stage_id' => true,
        'created' => true,
        'updated' => true,
        'incubator_application' => true,
        'designation' => true,
        'application_status' => true,
        'application_stage' => true
    ];
}
