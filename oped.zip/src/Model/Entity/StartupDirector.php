<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * StartupDirector Entity
 *
 * @property int $id
 * @property int $startup_application_id
 * @property string $name
 * @property string $designation
 * @property bool $gender
 * @property int $nationality
 * @property string $din_director
 * @property string $pan_director
 * @property string $address
 * @property int $state_id
 * @property int $district_id
 * @property string $postal_code
 * @property string $mobile
 * @property string $landline
 * @property string $email
 * @property string|null $id_proof
 * @property string|null $residential_proof
 * @property \Cake\I18n\FrozenTime $created
 *
 * @property \App\Model\Entity\StartupApplication $startup_application
 * @property \App\Model\Entity\State $state
 * @property \App\Model\Entity\District $district
 */
class StartupDirector extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'startup_application_id' => true,
        'name' => true,
        'designation' => true,
        'gender' => true,
        'nationality' => true,
        'din_director' => true,
        'pan_director' => true,
        'address' => true,
        'state_id' => true,
        'district_id' => true,
        'postal_code' => true,
        'mobile' => true,
        'landline' => true,
        'email' => true,
        'id_proof' => true,
        'residential_proof' => true,
        'created' => true,
        'startup_application' => true,
        'state' => true,
        'district' => true
    ];
}
