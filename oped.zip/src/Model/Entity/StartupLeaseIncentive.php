<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * StartupLeaseIncentive Entity
 *
 * @property int $id
 * @property int $startup_application_id
 * @property string $startup_name
 * @property string $registration_number
 * @property \Cake\I18n\FrozenDate $date_of_registration
 * @property string $name
 * @property int $designation_id
 * @property string $email
 * @property string $mobile_number
 * @property \Cake\I18n\FrozenDate $date_of_commencement
 * @property \Cake\I18n\FrozenDate $being_claimed_date
 * @property \Cake\I18n\FrozenDate $end_claimed_date
 * @property int $office_type_id
 * @property string $space_address
 * @property float $rental_amount
 * @property float $incentive_amount
 * @property string|null $other_information
 * @property string $registration_certificate
 * @property string $authorization_letter
 * @property string $undertaking_letter
 * @property string $proof_startup_operation
 * @property string $cancelled_cheque
 * @property string $space_proof
 * @property string $space_photographs
 * @property string $rent_receipts
 * @property string $payment_proof
 * @property string|null $admin_reason
 * @property string|null $screening_committee_reason
 * @property string|null $steering_committee_reason
 * @property string $application_number
 * @property string $reference_number
 * @property int|null $application_status_id
 * @property int $application_stage_id
 * @property \Cake\I18n\FrozenTime $created
 * @property \Cake\I18n\FrozenTime $updated
 *
 * @property \App\Model\Entity\StartupApplication $startup_application
 * @property \App\Model\Entity\Designation $designation
 * @property \App\Model\Entity\ApplicationStatus $application_status
 * @property \App\Model\Entity\StartupStage $startup_stage
 */
class StartupLeaseIncentive extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'startup_application_id' => true,
        'startup_name' => true,
        'registration_number' => true,
        'date_of_registration' => true,
        'name' => true,
        'designation_id' => true,
        'email' => true,
        'mobile_number' => true,
        'date_of_commencement' => true,
        'being_claimed_date' => true,
        'end_claimed_date' => true,
        'office_type_id' => true,
        'space_address' => true,
        'rental_amount' => true,
        'incentive_amount' => true,
        'other_information' => true,
        'registration_certificate' => true,
        'authorization_letter' => true,
        'undertaking_letter' => true,
        'proof_startup_operation' => true,
        'cancelled_cheque' => true,
        'space_proof' => true,
        'space_photographs' => true,
        'rent_receipts' => true,
        'payment_proof' => true,
        'admin_reason' => true,
        'screening_committee_reason' => true,
        'steering_committee_reason' => true,
        'application_number' => true,
        'reference_number' => true,
        'application_status_id' => true,
        'application_stage_id' => true,
        'created' => true,
        'updated' => true,
        'sanction_amount' => true,
        'startup_application' => true,
        'designation' => true,
        'application_status' => true,
        'startup_stage' => true
    ];
}
