<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * StartupApplication Entity
 *
 * @property int $id
 * @property int $user_id
 * @property int $whether_registered_as_startup_with_dipp
 * @property string $dipp_registration_number
 * @property \Cake\I18n\FrozenDate $date_of_registration
 * @property int $industry_id
 * @property int $sector_id
 * @property string|null $category_id
 * @property string $name_of_startup
 * @property int $type_of_incorporation_authority
 * @property int $nature_of_startup_id
 * @property string $cin_llpin
 * @property \Cake\I18n\FrozenDate $date_of_incorporation
 * @property string $pan_of_startup
 * @property string $registered_address
 * @property int $registered_state_id
 * @property int $registered_district_id
 * @property string $registered_block
 * @property int $registered_postal_code
 * @property string|null $registered_latitude
 * @property string|null $registered_longitude
 * @property string $corporate_address
 * @property int $corporate_state_id
 * @property int $corporate_district_id
 * @property string $corporate_block
 * @property int $corporate_postal_code
 * @property string|null $corporate_latitude
 * @property string|null $corporate_longitude
 * @property string $regional_address
 * @property int $regional_state_id
 * @property int $regional_district_id
 * @property string $regional_block
 * @property int $regional_postal_code
 * @property string|null $regional_latitude
 * @property string|null $regional_longitude
 * @property string|null $contact_details_of_entity
 * @property string $telephone
 * @property string $email_id
 * @property string|null $fax
 * @property string $website
 * @property string $name_of_account_holder
 * @property string $name_of_bank
 * @property string $account_number
 * @property string $ifsc_code
 * @property string|null $branch_address
 * @property int $are_you_an_incubatee
 * @property string|null $name_of_incubator
 * @property string|null $address_of_incubator
 * @property string|null $name_of_im
 * @property string|null $contact_details_of_im
 * @property \Cake\I18n\FrozenDate $start_date_of_incubation
 * @property \Cake\I18n\FrozenDate $end_date_of_incubation
 * @property string|null $registration_certificate
 * @property string|null $pan_number_of_startup
 * @property string|null $balance_sheet_of_startup
 * @property string|null $dipp_startup_registration
 * @property string|null $letter_of_authorization
 * @property string|null $undertaking
 * @property string|null $self_declaration
 * @property string|null $certificate_from_incubator
 * @property string $name_of_the_product
 * @property string $industry_of_product
 * @property string $product_description
 * @property string $sector_of_product
 * @property int $category_of_product
 * @property string $innovativeness_in_concept
 * @property string $target_market_and_users
 * @property string $usefulness_of_product
 * @property string $features_of_product
 * @property string $compliance_to_national
 * @property string $product_patent_details
 * @property int $similar_product_available
 * @property int $current_stage_of_your_startup
 * @property int $male_employees
 * @property int $female_employees
 * @property string|null $introduction
 * @property string|null $innovativeness
 * @property string|null $admin_reject_reason
 * @property string|null $screening_committee_reject_reason
 * @property string|null $steering_committee_reject_reason
 * @property string|null $recognition_certificate_no
 * @property int $application_status_id
 * @property int $startup_stage_id
 * @property string|null $reference_no
 * @property \Cake\I18n\FrozenTime $created
 * @property \Cake\I18n\FrozenTime $updated
 *
 * @property \App\Model\Entity\User $user
 * @property \App\Model\Entity\State $registered_state
 * @property \App\Model\Entity\District $registered_district
 * @property \App\Model\Entity\State $corporate_state
 * @property \App\Model\Entity\District $corporate_district
 * @property \App\Model\Entity\State $regional_state
 * @property \App\Model\Entity\District $regional_district
 * @property \App\Model\Entity\StartupStage $startup_stage
 * @property \App\Model\Entity\ProductShowcase[] $product_showcases
 * @property \App\Model\Entity\StartupObservation[] $startup_observations
 */
class StartupApplication extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        '*' => true,
    ];
}
