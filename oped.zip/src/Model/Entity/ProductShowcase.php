<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * ProductShowcase Entity
 *
 * @property int $id
 * @property int $user_id
 * @property int $startup_application_id
 * @property string $product_name
 * @property int $product_status
 * @property string $details
 * @property string|null $logo
 * @property string|null $website_link
 * @property string|null $contact_info
 * @property bool $is_declaration_checked
 * @property int|null $status
 * @property string|null $reason_of_status
 * @property \Cake\I18n\FrozenTime $created
 * @property \Cake\I18n\FrozenTime $updated
 *
 * @property \App\Model\Entity\StartupApplication $startup_application
 */
class ProductShowcase extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'user_id' => true,
        'startup_application_id' => true,
        'product_name' => true,
        'product_status' => true,
        'details' => true,
        'logo' => true,
        'website_link' => true,
        'contact_info' => true,
        'is_declaration_checked' => true,
        'status' => true,
        'reason_of_status' => true,
        'created' => true,
        'updated' => true,
        'startup_application' => true
    ];
}
