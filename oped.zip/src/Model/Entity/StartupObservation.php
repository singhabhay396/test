<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * StartupObservation Entity
 *
 * @property int $id
 * @property int $user_id
 * @property int $startup_application_id
 * @property string $observations_text
 * @property \Cake\I18n\FrozenTime $requested_date
 * @property \Cake\I18n\FrozenTime $reply_before_date
 * @property string|null $reply_text
 * @property int|null $reply_date
 * @property \Cake\I18n\FrozenTime|null $created
 *
 * @property \App\Model\Entity\User $user
 * @property \App\Model\Entity\StartupApplication $startup_application
 */
class StartupObservation extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'user_id' => true,
        'startup_application_id' => true,
        'observations_text' => true,
        'requested_date' => true,
        'reply_before_date' => true,
        'reply_text' => true,
        'reply_date' => true,
        'created' => true,
        'user' => true,
        'startup_application' => true
    ];
}
