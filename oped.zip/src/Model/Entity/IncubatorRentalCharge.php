<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * IncubatorRentalCharge Entity
 *
 * @property int $id
 * @property int $incubator_application_id
 * @property string $incubator_name
 * @property string $registration_number
 * @property \Cake\I18n\FrozenDate $date_of_registration
 * @property string $name
 * @property int $designation_id
 * @property string $email
 * @property string $mobile_number
 * @property \Cake\I18n\FrozenDate $date_of_commencement
 * @property \Cake\I18n\FrozenDate $lease_registration_date
 * @property string $lease_rent_charge_amount
 * @property string $amount_incurred
 * @property string $total_amount_paid
 * @property string|null $other_information
 * @property string $registration_certificate
 * @property string $applicant_certificate
 * @property string $association_memorandum
 * @property string $authorization_letter
 * @property string $undertaking_letter
 * @property string|null $ca_certificate
 * @property string|null $certificate_from_hod
 * @property string $proof_incubator_operation
 * @property string|null $space_availability_proof
 * @property string $cancelled_cheque
 * @property string|null $photographs
 * @property string|null $rent_receipts
 * @property string|null $claimed_expenses_bill
 * @property string|null $payment_proof
 * @property string|null $performance_report
 * @property string|null $admin_comment
 * @property \Cake\I18n\FrozenDate|null $admin_comment_date
 * @property string|null $screening_committee_comment
 * @property \Cake\I18n\FrozenDate|null $screening_committee_date
 * @property string|null $steering_committee_comment
 * @property \Cake\I18n\FrozenDate|null $approval_date
 * @property string|null $application_number
 * @property string|null $reference_number
 * @property int $application_status_id
 * @property int $application_stage_id
 * @property float|null $sanction_amount
 * @property \Cake\I18n\FrozenTime $created
 * @property \Cake\I18n\FrozenTime $updated
 *
 * @property \App\Model\Entity\IncubatorApplication $incubator_application
 * @property \App\Model\Entity\Designation $designation
 * @property \App\Model\Entity\ApplicationStatus $application_status
 * @property \App\Model\Entity\ApplicationStage $application_stage
 */
class IncubatorRentalCharge extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'incubator_application_id' => true,
        'incubator_name' => true,
        'registration_number' => true,
        'date_of_registration' => true,
        'name' => true,
        'designation_id' => true,
        'email' => true,
        'mobile_number' => true,
        'date_of_commencement' => true,
        'lease_registration_date' => true,
        'lease_rent_charge_amount' => true,
        'amount_incurred' => true,
        'total_amount_paid' => true,
        'other_information' => true,
        'registration_certificate' => true,
        'applicant_certificate' => true,
        'association_memorandum' => true,
        'authorization_letter' => true,
        'undertaking_letter' => true,
        'ca_certificate' => true,
        'certificate_from_hod' => true,
        'proof_incubator_operation' => true,
        'space_availability_proof' => true,
        'cancelled_cheque' => true,
        'photographs' => true,
        'rent_receipts' => true,
        'claimed_expenses_bill' => true,
        'payment_proof' => true,
        'performance_report' => true,
        'admin_comment' => true,
        'admin_comment_date' => true,
        'screening_committee_comment' => true,
        'screening_committee_date' => true,
        'steering_committee_comment' => true,
        'approval_date' => true,
        'application_number' => true,
        'reference_number' => true,
        'application_status_id' => true,
        'application_stage_id' => true,
        'sanction_amount' => true,
        'created' => true,
        'updated' => true,
        'incubator_application' => true,
        'designation' => true,
        'application_status' => true,
        'application_stage' => true
    ];
}
