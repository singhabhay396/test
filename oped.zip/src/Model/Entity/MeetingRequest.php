<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * MeetingRequest Entity
 *
 * @property int $id
 * @property int $startup_application_id
 * @property int $meeting_persion_id
 * @property int $meeting_persion_type_id
 * @property int $user_id
 * @property string $person_name
 * @property string $designation
 * @property string $contact_no
 * @property string $email
 * @property \Cake\I18n\FrozenTime $meeting_datetime
 * @property string $agenda
 * @property string $agenda_description
 * @property \Cake\I18n\FrozenTime $created_date
 * @property \Cake\I18n\FrozenTime $updated_date
 *
 * @property \App\Model\Entity\StartupApplication $startup_application
 * @property \App\Model\Entity\MeetingPersion $meeting_persion
 * @property \App\Model\Entity\MeetingPersionType $meeting_persion_type
 * @property \App\Model\Entity\User $user
 */
class MeetingRequest extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'startup_application_id' => true,
        'meeting_persion_id' => true,
        'meeting_persion_type_id' => true,
        'user_id' => true,
        'person_name' => true,
        'designation' => true,
        'contact_no' => true,
        'email' => true,
        'meeting_datetime' => true,
        'agenda' => true,
        'agenda_description' => true,
        'created_date' => true,
        'updated_date' => true,
        'startup_application' => true,
        'meeting_persion' => true,
        'meeting_persion_type' => true,
        'user' => true
    ];
}
