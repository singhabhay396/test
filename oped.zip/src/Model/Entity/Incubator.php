<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Incubator Entity
 *
 * @property int $id
 * @property int $user_id
 * @property string|null $reference_no
 * @property string $name_of_entity
 * @property int $form_of_entity
 * @property int $type_of_entity
 * @property string|null $host_name
 * @property string|null $host_address
 * @property string|null $host_contact_person
 * @property int|null $host_designation
 * @property string|null $host_contact_details
 * @property string|null $host_any_other_details
 * @property int|null $registered_type_of_entity
 * @property string|null $registered_name
 * @property string|null $registered_address
 * @property string|null $registered_contact_person
 * @property int|null $registered_designation
 * @property string $latitude
 * @property string $longitude
 * @property string|null $contact_details
 * @property \Cake\I18n\FrozenDate $date_of_incorporation
 * @property string $any_other_details
 * @property string|null $pan_number
 * @property string|null $cin_or_llp
 * @property string|null $complete_address
 * @property int|null $registered_state_id
 * @property int|null $registered_district_id
 * @property string|null $block
 * @property string|null $postal_code
 * @property string|null $contact_person
 * @property int|null $designation
 * @property int|null $telephone
 * @property string|null $email_id
 * @property string|null $fax
 * @property string|null $website
 * @property string|null $name_of_bank
 * @property string|null $account_holder
 * @property int|null $account_no
 * @property string|null $ifsc_code
 * @property string|null $branch_address
 * @property string $entity_incorp_reg_cert
 * @property string $entity_pan
 * @property string $entity_authorization
 * @property string $entity_undertaking
 * @property string|null $key_personal_name
 * @property int|null $key_personal_designation_id
 * @property int|null $key_personal_gender
 * @property int|null $key_personal_nationality
 * @property int|null $key_personal_landline
 * @property int|null $key_personal_mobile
 * @property string|null $key_personal_email
 * @property string|null $thematic_focusarea
 * @property int $ownership_type
 * @property int $lease_duration
 * @property \Cake\I18n\FrozenDate $start_date
 * @property \Cake\I18n\FrozenDate $end_date
 * @property int $operational_status
 * @property string $built_up_space
 * @property \Cake\I18n\FrozenDate $proposed_date
 * @property int $no_of_seats_proposed
 * @property string $existing_built_up_space
 * @property \Cake\I18n\FrozenDate $date_of_commencement
 * @property int $total_no_of_seats
 * @property string $total_no_of_startups_incubated
 * @property string $detailed_project_report
 * @property string $business_model
 * @property string $floor_plans
 * @property string $proof_of_ownership
 * @property string $photographs
 * @property string $employee_details_doc
 * @property string|null $admin_comment
 * @property string|null $screening_committee_comment
 * @property string|null $steering_committee_comment
 * @property int $application_status_id
 * @property int $incubator_stage_id
 * @property \Cake\I18n\FrozenTime $modified
 * @property \Cake\I18n\FrozenTime $created
 *
 * @property \App\Model\Entity\User $user
 * @property \App\Model\Entity\State $state
 * @property \App\Model\Entity\StartupStage $startup_stage
 * @property \App\Model\Entity\Role $role
 */
class Incubator extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        '*' => true,
    ];
}
