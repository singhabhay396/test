<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * IncubatorCompititionAssistance Entity
 *
 * @property int $id
 * @property int $incubator_application_id
 * @property string $incubator_name
 * @property string $registration_number
 * @property string $name
 * @property int $designation_id
 * @property string $email
 * @property string $mobile_number
 * @property \Cake\I18n\FrozenDate $date_of_commencement
 * @property string $incubators_thematic
 * @property float $assistance_amount
 * @property string $event_name
 * @property \Cake\I18n\FrozenDate $event_date
 * @property string $event_venue
 * @property string $other_information
 * @property string $registration_certificate
 * @property string|null $applicant_certificate
 * @property string|null $association_memorandum
 * @property string $authorization_letter
 * @property string $undertaking_letter
 * @property string $ca_certificate
 * @property string $certificate_from_hod
 * @property string $proof_incubator_operation
 * @property string $cancelled_cheque
 * @property string|null $admin_comment
 * @property \Cake\I18n\FrozenDate|null $admin_comment_date
 * @property string|null $screening_committee_comment
 * @property \Cake\I18n\FrozenDate|null $screening_committee_date
 * @property string|null $steering_committee_comment
 * @property \Cake\I18n\FrozenDate|null $approval_date
 * @property string|null $application_number
 * @property string|null $reference_number
 * @property int|null $application_status_id
 * @property int|null $application_stage_id
 * @property \Cake\I18n\FrozenTime $created
 * @property \Cake\I18n\FrozenTime|null $updated
 *
 * @property \App\Model\Entity\IncubatorApplication $incubator_application
 * @property \App\Model\Entity\Designation $designation
 * @property \App\Model\Entity\ApplicationStatus $application_status
 * @property \App\Model\Entity\ApplicationStage $application_stage
 */
class IncubatorCompititionAssistance extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'incubator_application_id' => true,
        'incubator_name' => true,
        'registration_number' => true,
        'registration_date' => true,
        'name' => true,
        'designation_id' => true,
        'email' => true,
        'mobile_number' => true,
        'date_of_commencement' => true,
        'incubators_thematic' => true,
        'assistance_amount' => true,
        'event_name' => true,
        'event_date' => true,
        'event_venue' => true,
        'other_information' => true,
        'registration_certificate' => true,
        'applicant_certificate' => true,
        'association_memorandum' => true,
        'authorization_letter' => true,
        'undertaking_letter' => true,
        'ca_certificate' => true,
        'certificate_from_hod' => true,
        'proof_incubator_operation' => true,
        'cancelled_cheque' => true,
        'admin_comment' => true,
        'admin_comment_date' => true,
        'screening_committee_comment' => true,
        'screening_committee_date' => true,
        'steering_committee_comment' => true,
        'approval_date' => true,
        'application_number' => true,
        'reference_number' => true,
        'sanction_amount' => true,
        'application_status_id' => true,
        'application_stage_id' => true,
        'created' => true,
        'updated' => true,
        'incubator_application' => true,
        'designation' => true,
        'application_status' => true,
        'application_stage' => true
    ];
}
