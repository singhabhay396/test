<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * StartupQualityCertification Entity
 *
 * @property int $id
 * @property string $startup_name
 * @property string $registration_number
 * @property \Cake\I18n\FrozenDate $date_of_registration
 * @property string $name
 * @property int $designation_id
 * @property string $email
 * @property string $mobile
 * @property int $quality_certifications_national
 * @property int $quality_certifications_international
 * @property int $quality_certification_number
 * @property string $quality_certification_detail
 * @property string $application_filling_number
 * @property string $competent_authority_name
 * @property string $quality_auditor_name
 * @property string $quality_auditor_address
 * @property int $total_expenditure
 * @property int $claimed_financial_amount
 * @property string $other_information
 * @property string $registration_certificate
 * @property string $authorization_letter
 * @property string $undertaking
 * @property string $application_form
 * @property string $quality_certificate
 * @property string $cancelled_cheque
 * @property string $detailed_statement
 * @property string $original_invoice
 * @property string $payment_proof
 * @property string|null $admin_reason
 * @property string|null $screening_committee_reason
 * @property string|null $steering_committee_reason
 * @property string|null $application_number
 * @property string|null $reference_number
 * @property int|null $application_status_id
 * @property int|null $application_stage_id
 * @property \Cake\I18n\FrozenTime|null $created
 * @property \Cake\I18n\FrozenTime|null $updated
 *
 * @property \App\Model\Entity\Designation $designation
 * @property \App\Model\Entity\ApplicationStatus $application_status
 * @property \App\Model\Entity\StartupStage $startup_stage
 */
class StartupQualityCertification extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'startup_name' => true,
        'registration_number' => true,
        'date_of_registration' => true,
        'name' => true,
        'designation_id' => true,
        'email' => true,
        'mobile' => true,
        'quality_certifications_national' => true,
        'quality_certifications_international' => true,
        'quality_certification_number' => true,
        'quality_certification_detail' => true,
        'application_filling_number' => true,
        'competent_authority_name' => true,
        'quality_auditor_name' => true,
        'quality_auditor_address' => true,
        'total_expenditure' => true,
        'claimed_financial_amount' => true,
        'other_information' => true,
        'registration_certificate' => true,
        'authorization_letter' => true,
        'undertaking' => true,
        'application_form' => true,
        'quality_certificate' => true,
        'cancelled_cheque' => true,
        'detailed_statement' => true,
        'original_invoice' => true,
        'payment_proof' => true,
        'admin_reason' => true,
        'screening_committee_reason' => true,
        'steering_committee_reason' => true,
        'application_number' => true,
        'reference_number' => true,
        'application_status_id' => true,
        'application_stage_id' => true,
        'created' => true,
        'updated' => true,
        'designation' => true,
        'application_status' => true,
        'startup_stage' => true
    ];
}
