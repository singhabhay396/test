<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * IncubatorStampDuty Entity
 *
 * @property int $id
 * @property int $incubator_application_id
 * @property string $incubator_name
 * @property string $registration_number
 * @property \Cake\I18n\FrozenDate $registration_date
 * @property string $name
 * @property int $designation_id
 * @property string $email
 * @property string $mobile_number
 * @property string $land_and_mutation_detail
 * @property \Cake\I18n\FrozenDate $date_of_commencement
 * @property \Cake\I18n\FrozenDate $date_of_stamp_duty_registration
 * @property \Cake\I18n\FrozenDate $date_of_mutations
 * @property string $concerned_sub_registrar
 * @property float $amount_of_stamp_duty
 * @property float $amount_of_incentive
 * @property string|null $other_information
 * @property string $registration_certificate
 * @property string|null $applicant_certificate
 * @property string|null $association_memorandum
 * @property string $authorization_letter
 * @property string $undertaking_letter
 * @property string $proof_incubator_operation
 * @property string $cancelled_cheque
 * @property string $space_availability_proof
 * @property string $sale_deed_registered
 * @property string $lease_agreement_registered
 * @property string $sale_deed_mutation
 * @property string $nakal_aks_shajra
 * @property string $verification_report
 * @property string $payment_proof
 * @property string $photographs
 * @property string $performance_report
 * @property string|null $admin_comment
 * @property \Cake\I18n\FrozenDate|null $admin_comment_date
 * @property string|null $screening_committee_comment
 * @property \Cake\I18n\FrozenDate|null $screening_committee_date
 * @property string|null $steering_committee_comment
 * @property \Cake\I18n\FrozenDate|null $approval_date
 * @property string|null $application_number
 * @property string|null $reference_number
 * @property float|null $sanction_amount
 * @property int|null $application_status_id
 * @property int|null $application_stage_id
 * @property \Cake\I18n\FrozenTime $created
 * @property \Cake\I18n\FrozenTime|null $updated
 *
 * @property \App\Model\Entity\IncubatorApplication $incubator_application
 * @property \App\Model\Entity\Designation $designation
 * @property \App\Model\Entity\ApplicationStatus $application_status
 * @property \App\Model\Entity\ApplicationStage $application_stage
 */
class IncubatorStampDuty extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'incubator_application_id' => true,
        'incubator_name' => true,
        'registration_number' => true,
        'registration_date' => true,
        'name' => true,
        'designation_id' => true,
        'email' => true,
        'mobile_number' => true,
        'land_and_mutation_detail' => true,
        'date_of_commencement' => true,
        'date_of_stamp_duty_registration' => true,
        'date_of_mutations' => true,
        'concerned_sub_registrar' => true,
        'amount_of_stamp_duty' => true,
        'amount_of_incentive' => true,
        'other_information' => true,
        'registration_certificate' => true,
        'applicant_certificate' => true,
        'association_memorandum' => true,
        'authorization_letter' => true,
        'undertaking_letter' => true,
        'proof_incubator_operation' => true,
        'cancelled_cheque' => true,
        'space_availability_proof' => true,
        'sale_deed_registered' => true,
        'lease_agreement_registered' => true,
        'sale_deed_mutation' => true,
        'nakal_aks_shajra' => true,
        'verification_report' => true,
        'payment_proof' => true,
        'photographs' => true,
        'performance_report' => true,
        'admin_comment' => true,
        'admin_comment_date' => true,
        'screening_committee_comment' => true,
        'screening_committee_date' => true,
        'steering_committee_comment' => true,
        'approval_date' => true,
        'application_number' => true,
        'reference_number' => true,
        'sanction_amount' => true,
        'application_status_id' => true,
        'application_stage_id' => true,
        'created' => true,
        'updated' => true,
        'incubator_application' => true,
        'designation' => true,
        'application_status' => true,
        'application_stage' => true
    ];
}
