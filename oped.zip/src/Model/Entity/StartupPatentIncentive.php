<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * StartupPatentIncentive Entity
 *
 * @property int $id
 * @property int $startup_application_id
 * @property string $startup_name
 * @property string $registration_number
 * @property \Cake\I18n\FrozenDate $date_of_registration
 * @property string $name
 * @property int $designation_id
 * @property string $email
 * @property string $mobile_number
 * @property int $patents_granted_national
 * @property int $patents_granted_international
 * @property int $number_of_patents
 * @property int $application_filling
 * @property string $application_filling_number
 * @property \Cake\I18n\FrozenDate $date_of_filling_application
 * @property string $inventor_name
 * @property string $inventor_qualification
 * @property int $inventor_age
 * @property int $rd_indigenous
 * @property string $collaborative
 * @property int $patent_attorney
 * @property int $total_expenditure
 * @property int $financial_assistance
 * @property string $other_information
 * @property string $invention_title
 * @property string $invention_description
 * @property string $invention_technical
 * @property string $invention_advantage
 * @property string $invention_novel_features
 * @property string $brief_description_commercialization
 * @property string $potential_market
 * @property string $petent_attorney_name
 * @property string $petent_attorney_adderess
 * @property string $petent_attorney_experience
 * @property string $attorney_name
 * @property string $attorney_mobile
 * @property string $attorney_email
 * @property int $root_filling
 * @property string $registration_certificate
 * @property string $authorization_letter
 * @property string $undertaking
 * @property string $application_form
 * @property string $petent_registraion
 * @property string $expenditure_statement
 * @property string $original_invoice
 * @property string $cancelled_cheque
 * @property string $payment_proof
 * @property string $sanction_refusal_letter
 * @property string|null $admin_reason
 * @property string|null $screening_committee_reason
 * @property string|null $steering_committee_reason
 * @property string|null $application_number
 * @property string|null $reference_number
 * @property int|null $application_status_id
 * @property int|null $application_stage_id
 * @property \Cake\I18n\FrozenTime $created
 * @property \Cake\I18n\FrozenTime $updated
 *
 * @property \App\Model\Entity\StartupApplication $startup_application
 * @property \App\Model\Entity\Designation $designation
 * @property \App\Model\Entity\ApplicationStatus $application_status
 * @property \App\Model\Entity\StartupStage $startup_stage
 */
class StartupPatentIncentive extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'startup_application_id' => true,
        'startup_name' => true,
        'registration_number' => true,
        'date_of_registration' => true,
        'name' => true,
        'designation_id' => true,
        'email' => true,
        'mobile_number' => true,
        'patents_granted_national' => true,
        'patents_granted_international' => true,
        'number_of_patents' => true,
        'application_filling' => true,
        'application_filling_number' => true,
        'date_of_filling_application' => true,
        'inventor_name' => true,
        'inventor_qualification' => true,
        'inventor_age' => true,
        'rd_indigenous' => true,
        'collaborative' => true,
        'patent_attorney' => true,
        'total_expenditure' => true,
        'financial_assistance' => true,
        'other_information' => true,
        'invention_title' => true,
        'invention_description' => true,
        'invention_technical' => true,
        'invention_advantage' => true,
        'invention_novel_features' => true,
        'brief_description_commercialization' => true,
        'potential_market' => true,
        'petent_attorney_name' => true,
        'petent_attorney_adderess' => true,
        'petent_attorney_experience' => true,
        'attorney_name' => true,
        'attorney_mobile' => true,
        'attorney_email' => true,
        'root_filling' => true,
        'registration_certificate' => true,
        'authorization_letter' => true,
        'undertaking' => true,
        'application_form' => true,
        'petent_registraion' => true,
        'expenditure_statement' => true,
        'original_invoice' => true,
        'cancelled_cheque' => true,
        'payment_proof' => true,
        'sanction_refusal_letter' => true,
        'admin_reason' => true,
        'screening_committee_reason' => true,
        'steering_committee_reason' => true,
        'application_number' => true,
        'reference_number' => true,
        'application_status_id' => true,
        'application_stage_id' => true,
        'created' => true,
        'updated' => true,
        'startup_application' => true,
        'designation' => true,
        'application_status' => true,
        'startup_stage' => true
    ];
}
