<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\Cache\Cache;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Careers Model
 *
 * @property \App\Model\Table\UsersTable|\Cake\ORM\Association\BelongsTo $Users
 * @property \App\Model\Table\CareerDocumentsTable|\Cake\ORM\Association\HasMany $CareerDocuments
 * @property \App\Model\Table\CareerTranslationsTable|\Cake\ORM\Association\HasMany $CareerTranslations
 *
 * @method \App\Model\Entity\Career get($primaryKey, $options = [])
 * @method \App\Model\Entity\Career newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Career[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Career|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Career|bool saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Career patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Career[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Career findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class CareersTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('careers');
        $this->setDisplayField('title');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

        $this->belongsTo('Users', [
            'foreignKey' => 'user_id',
            'joinType' => 'INNER'
        ]);
        $this->hasMany('CareerDocuments', [
            'foreignKey' => 'career_id',
            'className'  => 'CareerDocuments',
        ]);
        $this->hasMany('CareerTranslations', [
            'foreignKey' => 'career_id',
            'className'  => 'CareerTranslations',
        ]);
        $this->belongsTo('CareerTranslation', [
            'foreignKey' => 'id',
            'bindingKey' => 'career_id',
            'joinType'   => 'LEFT',
            'className'  => 'CareerTranslations',
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        $validator
            ->scalar('title')
            ->requirePresence('title', 'create')
            ->notEmpty('title');

        $validator
            ->scalar('slug')
            ->maxLength('slug', 250)
            ->allowEmpty('slug');

        $validator
            ->scalar('content')
            ->maxLength('content', 4294967295)
            ->allowEmpty('content');

        $validator
            ->scalar('excerpt')
            ->allowEmpty('excerpt');

        $validator
            ->scalar('meta_title')
            ->allowEmpty('meta_title');

        $validator
            ->scalar('meta_keywords')
            ->allowEmpty('meta_keywords');

        $validator
            ->scalar('meta_description')
            ->allowEmpty('meta_description');

        /*$validator
            ->date('start_date')
            ->requirePresence('start_date', 'create')
            ->notEmpty('start_date');

        $validator
            ->date('expiry_date')
            ->requirePresence('expiry_date', 'create')
            ->notEmpty('expiry_date');*/

        $validator
            ->scalar('url')
            ->allowEmpty('url');

        $validator
            ->boolean('status')
            ->requirePresence('status', 'create')
            ->notEmpty('status');

        $validator
            ->boolean('is_archive')
            ->requirePresence('is_archive', 'create')
            ->notEmpty('is_archive');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['user_id'], 'Users'));
        $rules->add($rules->isUnique(['url']));

        return $rules;
    }

    public function afterSave($event, $entity, $options = [])
    {
        Cache::clearGroup('silver-menu', 'silvermenu');
        $this->careerCache();
    }

    public function afterDelete($event, $entity, $options = [])
    {
        Cache::clearGroup('silver-menu', 'silvermenu');
        $this->careerCache();
    }
    
    public function careerCache()
    {
        Cache::clearGroup('silver-career', 'careers');
        $rewriteRules = $this->find('all')
            ->select(["id", "title", "slug", "url"])
            ->contain(['CareerTranslations' => function ($q) {
                $q->select(['career_id', 'language_id', 'culture', 'url']);
                $q->where(['url IS NOT NULL', 'url !=' => '']);
                return $q;
            }])
            ->where(['status' => 1])
            ->enableHydration(false)
            ->toArray();
        Cache::write('rewrite_rules', $rewriteRules, 'careers');
        return $rewriteRules;
    }

}
