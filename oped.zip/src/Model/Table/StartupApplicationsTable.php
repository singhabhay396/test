<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * StartupApplications Model
 *
 * @property \App\Model\Table\UsersTable|\Cake\ORM\Association\BelongsTo $Users
 * @property |\Cake\ORM\Association\BelongsTo $Industries
 * @property |\Cake\ORM\Association\BelongsTo $Sectors
 * @property |\Cake\ORM\Association\BelongsTo $Categories
 * @property |\Cake\ORM\Association\BelongsTo $NatureOfStartups
 * @property \App\Model\Table\StatesTable|\Cake\ORM\Association\BelongsTo $RegisteredStates
 * @property \App\Model\Table\DistrictsTable|\Cake\ORM\Association\BelongsTo $RegisteredDistricts
 * @property \App\Model\Table\StatesTable|\Cake\ORM\Association\BelongsTo $CorporateStates
 * @property \App\Model\Table\DistrictsTable|\Cake\ORM\Association\BelongsTo $CorporateDistricts
 * @property \App\Model\Table\StatesTable|\Cake\ORM\Association\BelongsTo $RegionalStates
 * @property \App\Model\Table\DistrictsTable|\Cake\ORM\Association\BelongsTo $RegionalDistricts
 * @property |\Cake\ORM\Association\BelongsTo $Emails
 * @property |\Cake\ORM\Association\BelongsTo $ApplicationStatuses
 * @property \App\Model\Table\StartupStagesTable|\Cake\ORM\Association\BelongsTo $StartupStages
 * @property \App\Model\Table\ProductShowcasesTable|\Cake\ORM\Association\HasMany $ProductShowcases
 * @property |\Cake\ORM\Association\HasMany $StartupDirectors
 * @property \App\Model\Table\StartupObservationsTable|\Cake\ORM\Association\HasMany $StartupObservations
 *
 * @method \App\Model\Entity\StartupApplication get($primaryKey, $options = [])
 * @method \App\Model\Entity\StartupApplication newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\StartupApplication[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\StartupApplication|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\StartupApplication|bool saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\StartupApplication patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\StartupApplication[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\StartupApplication findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class StartupApplicationsTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('startup_applications');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

        $this->belongsTo('Users', [
            'foreignKey' => 'user_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('Industries', [
            'foreignKey' => 'industry_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('Sectors', [
            'foreignKey' => 'sector_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('NatureOfStartups', [
            'foreignKey' => 'nature_of_startup_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('RegisteredStates', [
            'foreignKey' => 'registered_state_id',
            'joinType' => 'INNER',
            'className'  => 'States',
        ]);
        $this->belongsTo('RegisteredDistricts', [
            'foreignKey' => 'registered_district_id',
            'joinType' => 'INNER',
            'className'  => 'Districts',
        ]);
        $this->belongsTo('RegisteredTehsils', [
            'foreignKey' => 'registered_tehsil_id',
            'joinType' => 'LEFT',
            'className'  => 'Tehsils',
        ]);
        $this->belongsTo('CorporateStates', [
            'foreignKey' => 'corporate_state_id',
            'joinType' => 'INNER',
            'className'  => 'States',
        ]);
        $this->belongsTo('CorporateDistricts', [
            'foreignKey' => 'corporate_district_id',
            'joinType' => 'INNER',
            'className'  => 'Districts',
        ]);
        $this->belongsTo('CorporateTehsils', [
            'foreignKey' => 'corporate_tehsil_id',
            'joinType' => 'LEFT',
            'className'  => 'Tehsils',
        ]);
        $this->belongsTo('RegionalStates', [
            'foreignKey' => 'regional_state_id',
            'joinType' => 'INNER',
            'className'  => 'States',
        ]);
        $this->belongsTo('RegionalDistricts', [
            'foreignKey' => 'regional_district_id',
            'joinType' => 'INNER',
            'className'  => 'Districts',
        ]);
        $this->belongsTo('RegionalTehsils', [
            'foreignKey' => 'regional_tehsil_id',
            'joinType' => 'LEFT',
            'className'  => 'Tehsils',
        ]);
        $this->belongsTo('StartupStages', [
            'foreignKey' => 'startup_stage_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('ApplicationStatus', [
            'foreignKey' => 'application_status_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('StartupCategories', [
            'foreignKey' => 'category_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('NatureOfStartup', [
            'foreignKey' => 'nature_of_startup_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('Industries', [
            'foreignKey' => 'industry_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('Sectors', [
            'foreignKey' => 'sector_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('IncorporationAuthorities', [
            'foreignKey' => 'incorporation_authority_id',
            'joinType' => 'LEFT'
        ]);        
        $this->hasMany('ProductShowcases', [
            'foreignKey' => 'startup_application_id'
        ]);
        $this->hasMany('StartupDirectors', [
            'foreignKey' => 'startup_application_id'
        ]);
        $this->hasMany('StartupObservations', [
            'foreignKey' => 'startup_application_id'
        ]);
		$this->belongsTo('IndustriesOfProduct', [
            'foreignKey' => 'industry_of_product',
            'joinType' => 'INNER', 
			'className' => 'Industries'
        ]);
		$this->belongsTo('SectorsOfProduct', [
            'foreignKey' => 'sector_of_product',
            'joinType' => 'INNER', 
			'className' => 'Sectors'
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->allowEmpty('id', 'create');

        /*$validator
            ->integer('whether_registered_as_startup_with_dipp')
            ->requirePresence('whether_registered_as_startup_with_dipp', 'create')
            ->notEmpty('whether_registered_as_startup_with_dipp');

        $validator
            ->scalar('dipp_registration_number')
            ->maxLength('dipp_registration_number', 250)
            ->requirePresence('dipp_registration_number', 'create')
            ->notEmpty('dipp_registration_number');

        $validator
            ->date('date_of_registration')
            ->requirePresence('date_of_registration', 'create')
            ->notEmpty('date_of_registration');

        $validator
            ->scalar('name_of_startup')
            ->maxLength('name_of_startup', 250)
            ->requirePresence('name_of_startup', 'create')
            ->notEmpty('name_of_startup');

        $validator
            ->scalar('cin_llpin')
            ->maxLength('cin_llpin', 250)
            ->requirePresence('cin_llpin', 'create')
            ->notEmpty('cin_llpin');

        $validator
            ->date('date_of_incorporation')
            ->requirePresence('date_of_incorporation', 'create')
            ->notEmpty('date_of_incorporation');

        $validator
            ->scalar('pan_of_startup')
            ->maxLength('pan_of_startup', 250)
            ->requirePresence('pan_of_startup', 'create')
            ->notEmpty('pan_of_startup');

        $validator
            ->scalar('registered_address')
            ->requirePresence('registered_address', 'create')
            ->notEmpty('registered_address');

        $validator
            ->scalar('registered_block')
            ->maxLength('registered_block', 250)
            ->requirePresence('registered_block', 'create')
            ->notEmpty('registered_block');

        $validator
            ->integer('registered_postal_code')
            ->requirePresence('registered_postal_code', 'create')
            ->notEmpty('registered_postal_code');

        $validator
            ->scalar('registered_latitude')
            ->maxLength('registered_latitude', 100)
            ->allowEmpty('registered_latitude');

        $validator
            ->scalar('registered_longitude')
            ->maxLength('registered_longitude', 100)
            ->allowEmpty('registered_longitude');

        $validator
            ->scalar('corporate_address')
            ->requirePresence('corporate_address', 'create')
            ->notEmpty('corporate_address');

        $validator
            ->scalar('corporate_block')
            ->maxLength('corporate_block', 250)
            ->requirePresence('corporate_block', 'create')
            ->notEmpty('corporate_block');

        $validator
            ->integer('corporate_postal_code')
            ->requirePresence('corporate_postal_code', 'create')
            ->notEmpty('corporate_postal_code');

        $validator
            ->scalar('corporate_latitude')
            ->maxLength('corporate_latitude', 100)
            ->allowEmpty('corporate_latitude');

        $validator
            ->scalar('corporate_longitude')
            ->maxLength('corporate_longitude', 100)
            ->allowEmpty('corporate_longitude');

        $validator
            ->scalar('regional_address')
            ->requirePresence('regional_address', 'create')
            ->notEmpty('regional_address');

        $validator
            ->scalar('regional_block')
            ->maxLength('regional_block', 250)
            ->requirePresence('regional_block', 'create')
            ->notEmpty('regional_block');

        $validator
            ->integer('regional_postal_code')
            ->requirePresence('regional_postal_code', 'create')
            ->notEmpty('regional_postal_code');

        $validator
            ->scalar('regional_latitude')
            ->maxLength('regional_latitude', 100)
            ->allowEmpty('regional_latitude');

        $validator
            ->scalar('regional_longitude')
            ->maxLength('regional_longitude', 100)
            ->allowEmpty('regional_longitude');

        $validator
            ->scalar('contact_details_of_entity')
            ->maxLength('contact_details_of_entity', 250)
            ->allowEmpty('contact_details_of_entity');

        $validator
            ->scalar('telephone')
            ->maxLength('telephone', 100)
            ->requirePresence('telephone', 'create')
            ->notEmpty('telephone');

        $validator
            ->scalar('fax')
            ->maxLength('fax', 100)
            ->allowEmpty('fax');

        $validator
            ->scalar('website')
            ->maxLength('website', 200)
            ->requirePresence('website', 'create')
            ->notEmpty('website');

        $validator
            ->scalar('name_of_account_holder')
            ->maxLength('name_of_account_holder', 250)
            ->requirePresence('name_of_account_holder', 'create')
            ->notEmpty('name_of_account_holder');

        $validator
            ->scalar('name_of_bank')
            ->maxLength('name_of_bank', 250)
            ->requirePresence('name_of_bank', 'create')
            ->notEmpty('name_of_bank');

        $validator
            ->scalar('account_number')
            ->maxLength('account_number', 100)
            ->requirePresence('account_number', 'create')
            ->notEmpty('account_number');

        $validator
            ->scalar('ifsc_code')
            ->maxLength('ifsc_code', 100)
            ->requirePresence('ifsc_code', 'create')
            ->notEmpty('ifsc_code');

        $validator
            ->scalar('branch_address')
            ->allowEmpty('branch_address');

        $validator
            ->integer('are_you_an_incubatee')
            ->requirePresence('are_you_an_incubatee', 'create')
            ->notEmpty('are_you_an_incubatee');

        $validator
            ->scalar('name_of_incubator')
            ->maxLength('name_of_incubator', 250)
            ->allowEmpty('name_of_incubator');

        $validator
            ->scalar('address_of_incubator')
            ->maxLength('address_of_incubator', 250)
            ->allowEmpty('address_of_incubator');

        $validator
            ->scalar('name_of_im')
            ->maxLength('name_of_im', 200)
            ->allowEmpty('name_of_im');

        $validator
            ->scalar('contact_details_of_im')
            ->allowEmpty('contact_details_of_im');

        $validator
            ->date('start_date_of_incubation')
            ->requirePresence('start_date_of_incubation', 'create')
            ->notEmpty('start_date_of_incubation');

        $validator
            ->date('end_date_of_incubation')
            ->requirePresence('end_date_of_incubation', 'create')
            ->notEmpty('end_date_of_incubation');

        $validator
            ->scalar('name_of_the_product')
            ->maxLength('name_of_the_product', 250)
            ->requirePresence('name_of_the_product', 'create')
            ->notEmpty('name_of_the_product');

        $validator
            ->scalar('industry_of_product')
            ->maxLength('industry_of_product', 250)
            ->requirePresence('industry_of_product', 'create')
            ->notEmpty('industry_of_product');

        $validator
            ->scalar('product_description')
            ->requirePresence('product_description', 'create')
            ->notEmpty('product_description');

        $validator
            ->scalar('sector_of_product')
            ->maxLength('sector_of_product', 250)
            ->requirePresence('sector_of_product', 'create')
            ->notEmpty('sector_of_product');

        $validator
            ->integer('category_of_product')
            ->requirePresence('category_of_product', 'create')
            ->notEmpty('category_of_product');

        $validator
            ->scalar('innovativeness_in_concept')
            ->maxLength('innovativeness_in_concept', 250)
            ->requirePresence('innovativeness_in_concept', 'create')
            ->notEmpty('innovativeness_in_concept');

        $validator
            ->scalar('target_market_and_users')
            ->maxLength('target_market_and_users', 250)
            ->requirePresence('target_market_and_users', 'create')
            ->notEmpty('target_market_and_users');

        $validator
            ->scalar('usefulness_of_product')
            ->maxLength('usefulness_of_product', 250)
            ->requirePresence('usefulness_of_product', 'create')
            ->notEmpty('usefulness_of_product');

        $validator
            ->scalar('features_of_product')
            ->maxLength('features_of_product', 250)
            ->requirePresence('features_of_product', 'create')
            ->notEmpty('features_of_product');

        $validator
            ->scalar('compliance_to_national')
            ->maxLength('compliance_to_national', 250)
            ->requirePresence('compliance_to_national', 'create')
            ->notEmpty('compliance_to_national');

        $validator
            ->scalar('product_patent_details')
            ->maxLength('product_patent_details', 250)
            ->requirePresence('product_patent_details', 'create')
            ->notEmpty('product_patent_details');

        $validator
            ->integer('similar_product_available')
            ->requirePresence('similar_product_available', 'create')
            ->notEmpty('similar_product_available');

        $validator
            ->integer('current_stage_of_your_startup')
            ->requirePresence('current_stage_of_your_startup', 'create')
            ->notEmpty('current_stage_of_your_startup');

        $validator
            ->integer('male_employees')
            ->requirePresence('male_employees', 'create')
            ->notEmpty('male_employees');

        $validator
            ->integer('female_employees')
            ->requirePresence('female_employees', 'create')
            ->notEmpty('female_employees');

        $validator
            ->scalar('admin_reject_reason')
            ->allowEmpty('admin_reject_reason');

        $validator
            ->scalar('screening_committee_reject_reason')
            ->allowEmpty('screening_committee_reject_reason');

        $validator
            ->scalar('steering_committee_reject_reason')
            ->allowEmpty('steering_committee_reject_reason');

        $validator
            ->scalar('recognition_certificate_no')
            ->maxLength('recognition_certificate_no', 100)
            ->allowEmpty('recognition_certificate_no');

        $validator
            ->scalar('reference_no')
            ->maxLength('reference_no', 250)
            ->allowEmpty('reference_no');*/

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['user_id'], 'Users'));
        /*$rules->add($rules->existsIn(['industry_id'], 'Industries'));
        $rules->add($rules->existsIn(['sector_id'], 'Sectors'));
        $rules->add($rules->existsIn(['nature_of_startup_id'], 'NatureOfStartup'));
        $rules->add($rules->existsIn(['registered_state_id'], 'RegisteredStates'));
        $rules->add($rules->existsIn(['registered_district_id'], 'RegisteredDistricts'));
        $rules->add($rules->existsIn(['corporate_state_id'], 'CorporateStates'));
        $rules->add($rules->existsIn(['corporate_district_id'], 'CorporateDistricts'));
        $rules->add($rules->existsIn(['regional_state_id'], 'RegionalStates'));
        $rules->add($rules->existsIn(['regional_district_id'], 'RegionalDistricts'));
        $rules->add($rules->existsIn(['startup_stage_id'], 'StartupStages'));*/

        return $rules;
    }
}
