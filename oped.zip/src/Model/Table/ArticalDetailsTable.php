<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\Cache\Cache;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;


/**
 * Articles Model
 *
 * @property |\Cake\ORM\Association\BelongsTo $Users
 * @property \App\Model\Table\ArticleTranslationsTable|\Cake\ORM\Association\HasMany $ArticleTranslations
 *
 * @method \App\Model\Entity\Article get($primaryKey, $options = [])
 * @method \App\Model\Entity\Article newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Article[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Article|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Article|bool saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Article patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Article[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Article findOrCreate($search, callable $callback = null, $options = [])
 */
class ArticalDetailsTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('artical_details');
        $this->setDisplayField('title');
        $this->setPrimaryKey('id');
        $this->addBehavior('Status');

        $this->belongsTo('Users', [
            'foreignKey' => 'user_id',
            'joinType' => 'INNER'
        ]);
        $this->hasMany('ArticleTags', [
            'foreignKey' => 'article_id',
            'className'  => 'ArticleTags',
        ]);
		$this->hasMany('Notifications', [
            'foreignKey' => 'artical_id'
        ]);
        $this->belongsTo('Languages', [
            'foreignKey' => 'language_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('ArticleCategories', [
            'foreignKey' => 'category_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('ApplicationStatus', [
            'foreignKey' => 'article_stage_id',
            'joinType' => 'INNER'
        ]);
    }


    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->allowEmpty('id', 'create');
           
       /*  $validator
            ->requirePresence('title')
            ->notEmpty('title', 'Please fill this field')
            ->add('title', [
            'length' => [
            'rule' => ['maxLength', 60],
            'message' => 'Titles need to be at least 10 characters long',
        ]
    ]); */
        /* $validator
            ->requirePresence('introduction')
            ->notEmpty('introduction', 'Please fill this field')
            ->add('introduction', [
            'length' => [
            'rule' => ['maxLength', 250],
            'message' => 'Titles need to be at least 10 characters long',
        ]
    ]);
             $validator
            ->requirePresence('body_desc')
            ->notEmpty('body_desc', 'Please fill this field')
            ->add('body_desc', [
            'length' => [
            'rule' => ['maxLength', 1000],
            'message' => 'Titles need to be at least 10 characters long',
        ]
    ]); */
          /*    $validator
            ->requirePresence('tag_id')
            ->notEmpty('tag_id', 'Please fill this field')
            ->add('tag_id', [
            'length' => [
            'rule' => ['maxLength', 20],
            'message' => 'Titles need to be at least 10 characters long',
        ]
    ]); */

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */

    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['user_id'], 'Users'));
        $rules->add($rules->isUnique(['url']));

        return $rules;
    }

    
}
