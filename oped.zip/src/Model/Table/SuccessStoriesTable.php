<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * SuccessStories Model
 *
 * @property \App\Model\Table\SuccessStoryTranslationTable|\Cake\ORM\Association\HasMany $SuccessStoryTranslation
 *
 * @method \App\Model\Entity\SuccessStory get($primaryKey, $options = [])
 * @method \App\Model\Entity\SuccessStory newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\SuccessStory[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\SuccessStory|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\SuccessStory|bool saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\SuccessStory patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\SuccessStory[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\SuccessStory findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class SuccessStoriesTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('success_stories');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

        $this->hasMany('SuccessStoryTranslation', [
            'foreignKey' => 'success_story_id'
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        $validator
            ->scalar('content')
            ->allowEmpty('content');

        $validator
            ->scalar('excerpt')
            ->maxLength('excerpt', 255)
            ->allowEmpty('excerpt');

        $validator
            ->scalar('image')
            ->maxLength('image', 255)
            ->allowEmpty('image');

        $validator
            ->boolean('status')
            ->requirePresence('status', 'create')
            ->notEmpty('status');

        return $validator;
    }
}
