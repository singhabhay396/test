<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * IncubatorCapitalSubsidyPhaseThree Model
 *
 * @property \App\Model\Table\IncubatorApplicationsTable|\Cake\ORM\Association\BelongsTo $IncubatorApplications
 * @property \App\Model\Table\DesignationsTable|\Cake\ORM\Association\BelongsTo $Designations
 * @property \App\Model\Table\ApplicationStatusesTable|\Cake\ORM\Association\BelongsTo $ApplicationStatuses
 * @property \App\Model\Table\ApplicationStagesTable|\Cake\ORM\Association\BelongsTo $ApplicationStages
 *
 * @method \App\Model\Entity\IncubatorCapitalSubsidyPhaseThree get($primaryKey, $options = [])
 * @method \App\Model\Entity\IncubatorCapitalSubsidyPhaseThree newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\IncubatorCapitalSubsidyPhaseThree[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\IncubatorCapitalSubsidyPhaseThree|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\IncubatorCapitalSubsidyPhaseThree|bool saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\IncubatorCapitalSubsidyPhaseThree patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\IncubatorCapitalSubsidyPhaseThree[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\IncubatorCapitalSubsidyPhaseThree findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class IncubatorCapitalSubsidyPhaseThreeTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('incubator_capital_subsidy_phase_three');
        $this->setDisplayField('name');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

        $this->belongsTo('Incubators', [
            'foreignKey' => 'incubator_application_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('Designations', [
            'foreignKey' => 'designation_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('ApplicationStatus', [
            'foreignKey' => 'application_status_id'
        ]);
        $this->belongsTo('ApplicationStages', [
            'foreignKey' => 'application_stage_id',
            'joinType' => 'INNER',
            'className' => 'StartupStages'
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        $validator
            ->scalar('incubator_name')
            ->maxLength('incubator_name', 200)
            ->requirePresence('incubator_name', 'create')
            ->notEmpty('incubator_name');

        $validator
            ->scalar('registration_number')
            ->maxLength('registration_number', 100)
            ->requirePresence('registration_number', 'create')
            ->notEmpty('registration_number');

        $validator
            ->date('registration_date')
            ->requirePresence('registration_date', 'create')
            ->notEmpty('registration_date');

        $validator
            ->scalar('name')
            ->maxLength('name', 200)
            ->requirePresence('name', 'create')
            ->notEmpty('name');

        $validator
            ->email('email')
            ->requirePresence('email', 'create')
            ->notEmpty('email');

        $validator
            ->integer('mobile_number')
            ->requirePresence('mobile_number', 'create')
            ->notEmpty('mobile_number');

        $validator
            ->integer('incubator_type')
            ->requirePresence('incubator_type', 'create')
            ->notEmpty('incubator_type');

        $validator
            ->date('commencement_date')
            ->allowEmpty('commencement_date');

        $validator
            ->scalar('space_exclusively')
            ->maxLength('space_exclusively', 250)
            ->requirePresence('space_exclusively', 'create')
            ->notEmpty('space_exclusively');

        $validator
            ->integer('total_seats_planned')
            ->requirePresence('total_seats_planned', 'create')
            ->notEmpty('total_seats_planned');

        $validator
            ->integer('total_seats_ready')
            ->requirePresence('total_seats_ready', 'create')
            ->notEmpty('total_seats_ready');

        $validator
            ->integer('total_seats_occupied')
            ->requirePresence('total_seats_occupied', 'create')
            ->notEmpty('total_seats_occupied');

        $validator
            ->integer('startups_incubated')
            ->requirePresence('startups_incubated', 'create')
            ->notEmpty('startups_incubated');

        $validator
            ->integer('under_entrepreneur')
            ->requirePresence('under_entrepreneur', 'create')
            ->notEmpty('under_entrepreneur');

        $validator
            ->numeric('sanctioned_amount')
            ->requirePresence('sanctioned_amount', 'create')
            ->notEmpty('sanctioned_amount');

        $validator
            ->numeric('approved_incentive_amount')
            ->requirePresence('approved_incentive_amount', 'create')
            ->notEmpty('approved_incentive_amount');

        $validator
            ->integer('other_scheme')
            ->requirePresence('other_scheme', 'create')
            ->notEmpty('other_scheme');

        $validator
            ->scalar('scheme_details')
            ->allowEmpty('scheme_details');

        $validator
            ->numeric('amount_sanctioned')
            ->allowEmpty('amount_sanctioned');

        $validator
            ->scalar('total_expenditure')
            ->allowEmpty('total_expenditure');

        $validator
            ->numeric('incentive_requested')
            ->requirePresence('incentive_requested', 'create')
            ->notEmpty('incentive_requested');

        $validator
            ->scalar('other_information')
            ->allowEmpty('other_information');

        $validator
            ->scalar('admin_comment')
            ->allowEmpty('admin_comment');

        $validator
            ->date('admin_comment_date')
            ->allowEmpty('admin_comment_date');

        $validator
            ->scalar('screening_committee_comment')
            ->allowEmpty('screening_committee_comment');

        $validator
            ->date('screening_committee_date')
            ->allowEmpty('screening_committee_date');

        $validator
            ->scalar('steering_committee_comment')
            ->allowEmpty('steering_committee_comment');

        $validator
            ->date('approval_date')
            ->allowEmpty('approval_date');

        $validator
            ->scalar('application_number')
            ->maxLength('application_number', 50)
            ->allowEmpty('application_number');

        $validator
            ->scalar('reference_number')
            ->maxLength('reference_number', 50)
            ->allowEmpty('reference_number');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['incubator_application_id'], 'Incubators'));
        $rules->add($rules->existsIn(['designation_id'], 'Designations'));
        $rules->add($rules->existsIn(['application_status_id'], 'ApplicationStatus'));
        $rules->add($rules->existsIn(['application_stage_id'], 'ApplicationStages'));

        return $rules;
    }
}
