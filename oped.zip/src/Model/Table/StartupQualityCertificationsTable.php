<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * StartupQualityCertifications Model
 *
 * @property \App\Model\Table\DesignationsTable|\Cake\ORM\Association\BelongsTo $Designations
 * @property \App\Model\Table\ApplicationStatusTable|\Cake\ORM\Association\BelongsTo $ApplicationStatus
 * @property \App\Model\Table\StartupStagesTable|\Cake\ORM\Association\BelongsTo $StartupStages
 *
 * @method \App\Model\Entity\StartupQualityCertification get($primaryKey, $options = [])
 * @method \App\Model\Entity\StartupQualityCertification newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\StartupQualityCertification[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\StartupQualityCertification|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\StartupQualityCertification|bool saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\StartupQualityCertification patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\StartupQualityCertification[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\StartupQualityCertification findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class StartupQualityCertificationsTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('startup_quality_certifications');
        $this->setDisplayField('name');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

        $this->belongsTo('StartupApplications', [
            'foreignKey' => 'startup_application_id',
            'joinType' => 'INNER'
        ]);
        
        $this->belongsTo('Designations', [
            'foreignKey' => 'designation_id',
            'joinType' => 'INNER' 
        ]);
        $this->belongsTo('ApplicationStatus', [
            'foreignKey' => 'application_status_id'
        ]);
        $this->belongsTo('ApplicationStages', [
            'foreignKey' => 'application_stage_id',
            'joinType' => 'INNER',
            'className' => 'StartupStages'
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->nonNegativeInteger('id')
            ->allowEmpty('id', 'create');

        $validator
            ->scalar('startup_name')
            ->maxLength('startup_name', 250)
            ->requirePresence('startup_name', 'create')
            ->notEmpty('startup_name');

        $validator
            ->scalar('registration_number')
            ->maxLength('registration_number', 50)
            ->requirePresence('registration_number', 'create')
            ->notEmpty('registration_number');

        $validator
            ->date('date_of_registration')
            ->requirePresence('date_of_registration', 'create')
            ->notEmpty('date_of_registration');

        $validator
            ->scalar('name')
            ->maxLength('name', 250)
            ->requirePresence('name', 'create')
            ->notEmpty('name');

        $validator
            ->email('email')
            ->requirePresence('email', 'create')
            ->notEmpty('email');

        $validator
            ->scalar('mobile')
            ->maxLength('mobile', 15)
            ->requirePresence('mobile', 'create')
            ->notEmpty('mobile');

        $validator
            ->integer('quality_certifications_national')
            ->requirePresence('quality_certifications_national', 'create')
            ->notEmpty('quality_certifications_national');

        $validator
            ->integer('quality_certifications_international')
            ->requirePresence('quality_certifications_international', 'create')
            ->notEmpty('quality_certifications_international');

        $validator
            ->integer('quality_certification_number')
            ->requirePresence('quality_certification_number', 'create')
            ->notEmpty('quality_certification_number');

        $validator
            ->scalar('quality_certification_detail')
            ->requirePresence('quality_certification_detail', 'create')
            ->notEmpty('quality_certification_detail');

        $validator
            ->scalar('application_filling_number')
            ->maxLength('application_filling_number', 250)
            ->requirePresence('application_filling_number', 'create')
            ->notEmpty('application_filling_number');

        $validator
            ->scalar('competent_authority_name')
            ->maxLength('competent_authority_name', 250)
            ->requirePresence('competent_authority_name', 'create')
            ->notEmpty('competent_authority_name');

        $validator
            ->scalar('quality_auditor_name')
            ->maxLength('quality_auditor_name', 250)
            ->requirePresence('quality_auditor_name', 'create')
            ->notEmpty('quality_auditor_name');

        $validator
            ->scalar('quality_auditor_address')
            ->requirePresence('quality_auditor_address', 'create')
            ->notEmpty('quality_auditor_address');

        $validator
            ->integer('total_expenditure')
            ->requirePresence('total_expenditure', 'create')
            ->notEmpty('total_expenditure');

        $validator
            ->integer('claimed_financial_amount')
            ->requirePresence('claimed_financial_amount', 'create')
            ->notEmpty('claimed_financial_amount');

        $validator
            ->scalar('other_information')
            ->requirePresence('other_information', 'create')
            ->notEmpty('other_information');

        $validator
            ->scalar('admin_reason')
            ->allowEmpty('admin_reason');

        $validator
            ->scalar('screening_committee_reason')
            ->allowEmpty('screening_committee_reason');

        $validator
            ->scalar('steering_committee_reason')
            ->allowEmpty('steering_committee_reason');

        $validator
            ->scalar('application_number')
            ->maxLength('application_number', 50)
            ->allowEmpty('application_number');

        $validator
            ->scalar('reference_number')
            ->maxLength('reference_number', 50)
            ->allowEmpty('reference_number');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        //$rules->add($rules->isUnique(['email']));
        $rules->add($rules->existsIn(['designation_id'], 'Designations'));
        $rules->add($rules->existsIn(['application_status_id'], 'ApplicationStatus'));
        $rules->add($rules->existsIn(['application_stage_id'], 'ApplicationStages'));

        return $rules;
    }
}
