<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Circulars Model
 *
 * @property \App\Model\Table\UsersTable|\Cake\ORM\Association\BelongsTo $Users
 * @property \App\Model\Table\CircularDocumentsTable|\Cake\ORM\Association\HasMany $CircularDocuments
 * @property \App\Model\Table\CircularTranslationsTable|\Cake\ORM\Association\HasMany $CircularTranslations
 *
 * @method \App\Model\Entity\Circular get($primaryKey, $options = [])
 * @method \App\Model\Entity\Circular newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Circular[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Circular|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Circular|bool saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Circular patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Circular[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Circular findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class CircularsTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('circulars');
        $this->setDisplayField('title');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

        $this->belongsTo('Users', [
            'foreignKey' => 'user_id',
            'joinType' => 'INNER'
        ]);
        $this->hasMany('CircularDocuments', [
            'foreignKey' => 'circular_id',
            'className'  => 'CircularDocuments',
        ]);
        $this->hasMany('CircularTranslations', [
            'foreignKey' => 'circular_id',
            'className'  => 'CircularTranslations',
        ]);
        $this->belongsTo('CircularTranslation', [
            'foreignKey' => 'id',
            'bindingKey' => 'circular_id',
            'joinType'   => 'LEFT',
            'className'  => 'CircularTranslations',
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->allowEmpty('id', 'create');

        $validator
            ->scalar('title')
            ->maxLength('title', 255)
            ->requirePresence('title', 'create')
            ->notEmpty('title');

        $validator
            ->scalar('slug')
            ->allowEmpty('slug');

        $validator
            ->scalar('content')
            ->maxLength('content', 4294967295)
            ->requirePresence('content', 'create')
            ->notEmpty('content');

        $validator
            ->scalar('url')
            ->allowEmpty('url');
        
        $validator
            ->dateTime('circulation_date')
            ->requirePresence('circulation_date', 'create')
            ->notEmpty('circulation_date');

        $validator
            ->dateTime('last_date')
            ->requirePresence('last_date', 'create')
            ->notEmpty('last_date');

        $validator
            ->scalar('remarks')
            ->allowEmpty('remarks');

        $validator
            ->boolean('status')
            ->requirePresence('status', 'create')
            ->notEmpty('status');

        $validator
            ->boolean('is_archive')
            ->requirePresence('is_archive', 'create')
            ->notEmpty('is_archive');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['user_id'], 'Users'));

        return $rules;
    }
}
