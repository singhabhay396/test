<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\Cache\Cache;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Tenders Model
 *
 * @property \App\Model\Table\UsersTable|\Cake\ORM\Association\BelongsTo $Users
 * @property \App\Model\Table\TenderTranslationsTable|\Cake\ORM\Association\HasMany $TenderTranslations
 *
 * @method \App\Model\Entity\Tender get($primaryKey, $options = [])
 * @method \App\Model\Entity\Tender newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Tender[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Tender|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Tender|bool saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Tender patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Tender[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Tender findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class TendersTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('tenders');
        $this->setDisplayField('title');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

        $this->belongsTo('Users', [
            'foreignKey' => 'user_id',
            'joinType' => 'INNER'
        ]);
        $this->hasMany('TenderDocuments', [
            'foreignKey' => 'tender_id',
            'className'  => 'TenderDocuments',
        ]);
        $this->hasMany('TenderTranslations', [
            'foreignKey' => 'tender_id',
            'className'  => 'TenderTranslations',
        ]);

        $this->belongsTo('TenderTranslation', [
            'foreignKey' => 'id',
            'bindingKey' => 'tender_id',
            'joinType'   => 'LEFT',
            'className'  => 'TenderTranslations',
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->allowEmpty('id', 'create');

        $validator
            ->scalar('title')
            ->maxLength('title', 255)
            ->requirePresence('title', 'create')
            ->notEmpty('title');

        $validator
            ->scalar('slug')
            ->allowEmpty('slug');

        $validator
            ->scalar('content')
            ->maxLength('content', 4294967295)
            ->requirePresence('content', 'create')
            ->notEmpty('content');

        $validator
            ->scalar('url')
            ->allowEmpty('url');

        /*$validator
            ->dateTime('tender_date')
            ->requirePresence('tender_date', 'create')
            ->notEmpty('tender_date');

        $validator
            ->dateTime('last_date')
            ->requirePresence('last_date', 'create')
            ->notEmpty('last_date');

        $validator
            ->scalar('tender_document')
            ->maxLength('tender_document', 255)
            ->allowEmpty('tender_document');

        $validator
            ->scalar('corrigendum')
            ->maxLength('corrigendum', 255)
            ->allowEmpty('corrigendum');*/

        $validator
            ->scalar('remarks')
            ->allowEmpty('remarks');

        $validator
            ->boolean('is_archive')
            ->requirePresence('is_archive', 'create')
            ->notEmpty('is_archive');
            
        $validator
            ->boolean('status')
            ->requirePresence('status', 'create')
            ->notEmpty('status');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['user_id'], 'Users'));
        $rules->add($rules->isUnique(['url']));

        return $rules;
    }

    public function afterSave($event, $entity, $options = [])
    {
        Cache::clearGroup('silver-menu', 'silvermenu');
        $this->tenderCache();
    }

    public function afterDelete($event, $entity, $options = [])
    {
        Cache::clearGroup('silver-menu', 'silvermenu');
        $this->tenderCache();
    }
    
    public function tenderCache()
    {
        Cache::clearGroup('silver-tender', 'tenders');
        $rewriteRules = $this->find('all')
            ->select(["id", "title", "slug", "url"])
            ->contain(['TenderTranslations' => function ($q) {
                $q->select(['tender_id', 'language_id', 'culture', 'url']);
                $q->where(['url IS NOT NULL', 'url !=' => '']);
                return $q;
            }])
            ->where(['status' => 1])
            ->enableHydration(false)
            ->toArray();
        Cache::write('rewrite_rules', $rewriteRules, 'tenders');
        return $rewriteRules;
    }

}
