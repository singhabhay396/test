<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Incubators Model
 *
 * @property \App\Model\Table\UsersTable|\Cake\ORM\Association\BelongsTo $Users
 * @property |\Cake\ORM\Association\BelongsTo $RegisteredStates
 * @property |\Cake\ORM\Association\BelongsTo $RegisteredDistricts
 * @property |\Cake\ORM\Association\BelongsTo $Emails
 * @property |\Cake\ORM\Association\BelongsTo $KeyPersonalDesignations
 * @property |\Cake\ORM\Association\BelongsTo $ApplicationStatuses
 * @property |\Cake\ORM\Association\BelongsTo $IncubatorStages
 *
 * @method \App\Model\Entity\Incubator get($primaryKey, $options = [])
 * @method \App\Model\Entity\Incubator newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Incubator[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Incubator|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Incubator|bool saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Incubator patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Incubator[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Incubator findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class IncubatorsTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('incubators');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

        $this->belongsTo('Users', [
            'foreignKey' => 'user_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('RegisteredStates', [
            'foreignKey' => 'registered_state_id',
            'className' => 'States'
        ]);
        $this->belongsTo('RegisteredDistricts', [
            'foreignKey' => 'registered_district_id',
            'className'     =>'Districts',
        ]);
        
        $this->belongsTo('KeyPersonalDesignations', [
            'foreignKey' => 'key_personal_designation_id',
            'className'  =>'Designations'
        ]);
        $this->belongsTo('ApplicationStatus', [
            'foreignKey' => 'application_status_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('IncubatorStages', [
            'foreignKey' => 'incubator_stage_id',
            'className' => 'StartupStages',
            'joinType' => 'INNER'
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        $validator
            ->scalar('reference_no')
            ->maxLength('reference_no', 255)
            ->allowEmpty('reference_no');

        $validator
            ->scalar('name_of_entity')
            ->maxLength('name_of_entity', 255)
            ->requirePresence('name_of_entity', 'create')
            ->notEmpty('name_of_entity');

        $validator
            ->integer('form_of_entity')
            ->requirePresence('form_of_entity', 'create')
            ->notEmpty('form_of_entity');

        $validator
            ->integer('type_of_entity')
            ->requirePresence('type_of_entity', 'create')
            ->notEmpty('type_of_entity');

        $validator
            ->scalar('host_name')
            ->maxLength('host_name', 255)
            ->allowEmpty('host_name');

        $validator
            ->scalar('host_address')
            ->allowEmpty('host_address');

        $validator
            ->scalar('host_contact_person')
            ->allowEmpty('host_contact_person');

        $validator
            ->integer('host_designation')
            ->allowEmpty('host_designation');

        $validator
            ->scalar('host_contact_details')
            ->allowEmpty('host_contact_details');

        $validator
            ->scalar('host_any_other_details')
            ->allowEmpty('host_any_other_details');

        $validator
            ->integer('registered_type_of_entity')
            ->allowEmpty('registered_type_of_entity');

        $validator
            ->scalar('registered_name')
            ->maxLength('registered_name', 255)
            ->allowEmpty('registered_name');

        $validator
            ->scalar('registered_address')
            ->allowEmpty('registered_address');

        $validator
            ->scalar('registered_contact_person')
            ->maxLength('registered_contact_person', 255)
            ->allowEmpty('registered_contact_person');

        $validator
            ->integer('registered_designation')
            ->allowEmpty('registered_designation');

        $validator
            ->scalar('latitude')
            ->maxLength('latitude', 255)
            ->allowEmpty('latitude');

        $validator
            ->scalar('longitude')
            ->maxLength('longitude', 255)
            ->allowEmpty('longitude');

        $validator
            ->scalar('contact_details')
            ->allowEmpty('contact_details');

        $validator
            ->date('date_of_incorporation')
            ->requirePresence('date_of_incorporation', 'create')
            ->allowEmpty('date_of_incorporation');

        $validator
            ->scalar('any_other_details')
            ->requirePresence('any_other_details', 'create')
            ->allowEmpty('any_other_details');

        $validator
            ->scalar('pan_number')
            ->maxLength('pan_number', 20)
            ->allowEmpty('pan_number');

        $validator
            ->scalar('cin_or_llp')
            ->maxLength('cin_or_llp', 50)
            ->allowEmpty('cin_or_llp');

        $validator
            ->scalar('complete_address')
            ->maxLength('complete_address', 255)
            ->allowEmpty('complete_address');

        $validator
            ->scalar('block')
            ->maxLength('block', 100)
            ->allowEmpty('block');

        $validator
            ->scalar('postal_code')
            ->maxLength('postal_code', 10)
            ->allowEmpty('postal_code');

        $validator
            ->scalar('contact_person')
            ->maxLength('contact_person', 100)
            ->allowEmpty('contact_person');

        $validator
            ->integer('designation')
            ->allowEmpty('designation');

        $validator
            ->integer('telephone')
            ->allowEmpty('telephone');

        $validator
            ->scalar('fax')
            ->maxLength('fax', 100)
            ->allowEmpty('fax');

        $validator
            ->scalar('website')
            ->maxLength('website', 100)
            ->allowEmpty('website');

        $validator
            ->scalar('name_of_bank')
            ->maxLength('name_of_bank', 100)
            ->allowEmpty('name_of_bank');

        $validator
            ->scalar('account_holder')
            ->maxLength('account_holder', 150)
            ->allowEmpty('account_holder');

        $validator
            ->integer('account_no')
            ->allowEmpty('account_no');

        $validator
            ->scalar('ifsc_code')
            ->maxLength('ifsc_code', 20)
            ->allowEmpty('ifsc_code');

        $validator
            ->scalar('branch_address')
            ->allowEmpty('branch_address');

        $validator
            ->scalar('key_personal_name')
            ->maxLength('key_personal_name', 100)
            ->allowEmpty('key_personal_name');

        $validator
            ->integer('key_personal_gender')
            ->allowEmpty('key_personal_gender');

        $validator
            ->integer('key_personal_nationality')
            ->allowEmpty('key_personal_nationality');

        $validator
            ->integer('key_personal_landline')
            ->allowEmpty('key_personal_landline');

        $validator
            ->integer('key_personal_mobile')
            ->allowEmpty('key_personal_mobile');

        $validator
            ->scalar('key_personal_email')
            ->maxLength('key_personal_email', 100)
            ->allowEmpty('key_personal_email');

        $validator
            ->scalar('thematic_focusarea')
            ->maxLength('thematic_focusarea', 255)
            ->allowEmpty('thematic_focusarea');

        $validator
            ->integer('ownership_type')
            ->requirePresence('ownership_type', 'create')
            ->notEmpty('ownership_type');

        $validator
            ->integer('lease_duration')
            ->requirePresence('lease_duration', 'create')
            ->allowEmpty('lease_duration');

        $validator
            ->date('start_date')
            ->requirePresence('start_date', 'create')
            ->allowEmpty('start_date');

        $validator
            ->date('end_date')
            ->requirePresence('end_date', 'create')
            ->allowEmpty('end_date');

        $validator
            ->integer('operational_status')
            ->requirePresence('operational_status', 'create')
            ->notEmpty('operational_status');

        $validator
            ->scalar('built_up_space')
            ->maxLength('built_up_space', 255)
            ->requirePresence('built_up_space', 'create')
            ->notEmpty('built_up_space');

        $validator
            ->date('proposed_date')
            ->requirePresence('proposed_date', 'create')
            ->notEmpty('proposed_date');

        $validator
            ->integer('no_of_seats_proposed')
            ->requirePresence('no_of_seats_proposed', 'create')
            ->notEmpty('no_of_seats_proposed');

        $validator
            ->scalar('existing_built_up_space')
            ->maxLength('existing_built_up_space', 255)
            ->requirePresence('existing_built_up_space', 'create')
            ->allowEmpty('existing_built_up_space');

        $validator
            ->date('date_of_commencement')
            ->requirePresence('date_of_commencement', 'create')
            ->allowEmpty('date_of_commencement');

        $validator
            ->integer('total_no_of_seats')
            ->requirePresence('total_no_of_seats', 'create')
            ->allowEmpty('total_no_of_seats');

        $validator
            ->scalar('total_no_of_startups_incubated')
            ->maxLength('total_no_of_startups_incubated', 255)
            ->requirePresence('total_no_of_startups_incubated', 'create')
            ->allowEmpty('total_no_of_startups_incubated');

        

        

        $validator
            ->scalar('admin_comment')
            ->allowEmpty('admin_comment');

        $validator
            ->scalar('screening_committee_comment')
            ->allowEmpty('screening_committee_comment');

        $validator
            ->scalar('steering_committee_comment')
            ->allowEmpty('steering_committee_comment');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['user_id'], 'Users'));
        $rules->add($rules->existsIn(['registered_state_id'], 'RegisteredStates'));
        $rules->add($rules->existsIn(['registered_district_id'], 'RegisteredDistricts'));
        $rules->add($rules->existsIn(['key_personal_designation_id'], 'KeyPersonalDesignations'));
        $rules->add($rules->existsIn(['application_status_id'], 'ApplicationStatus'));
        $rules->add($rules->existsIn(['incubator_stage_id'], 'IncubatorStages'));

        return $rules;
    }
}
