<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * StartupAppIncentives Model
 *
 * @property \App\Model\Table\StartupApplicationsTable|\Cake\ORM\Association\BelongsTo $StartupApplications
 * @property \App\Model\Table\DesignationsTable|\Cake\ORM\Association\BelongsTo $Designations
 * @property |\Cake\ORM\Association\BelongsTo $ApplicationStatuses
 * @property |\Cake\ORM\Association\BelongsTo $ApplicationStages
 *
 * @method \App\Model\Entity\StartupAppIncentive get($primaryKey, $options = [])
 * @method \App\Model\Entity\StartupAppIncentive newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\StartupAppIncentive[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\StartupAppIncentive|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\StartupAppIncentive|bool saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\StartupAppIncentive patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\StartupAppIncentive[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\StartupAppIncentive findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class StartupAppIncentivesTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('startup_app_incentives');
        $this->setDisplayField('name');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

        $this->belongsTo('StartupApplications', [
            'foreignKey' => 'startup_application_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('Designations', [
            'foreignKey' => 'designation_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('ApplicationStatus', [
            'foreignKey' => 'application_status_id'
        ]);
        $this->belongsTo('ApplicationStages', [
            'foreignKey' => 'application_stage_id',
            'joinType' => 'INNER',
            'className' => 'StartupStages'
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->nonNegativeInteger('id')
            ->allowEmpty('id', 'create');

        $validator
            ->scalar('startup_name')
            ->maxLength('startup_name', 255)
            ->requirePresence('startup_name', 'create')
            ->notEmpty('startup_name');

        $validator
            ->scalar('registration_number')
            ->maxLength('registration_number', 100)
            ->requirePresence('registration_number', 'create')
            ->notEmpty('registration_number');

        $validator
            ->date('date_of_registration')
            ->requirePresence('date_of_registration', 'create')
            ->notEmpty('date_of_registration');

        $validator
            ->scalar('name')
            ->maxLength('name', 255)
            ->requirePresence('name', 'create')
            ->notEmpty('name');

        $validator
            ->email('email')
            ->requirePresence('email', 'create')
            ->notEmpty('email');

        $validator
            ->scalar('mobile_number')
            ->maxLength('mobile_number', 12)
            ->requirePresence('mobile_number', 'create')
            ->notEmpty('mobile_number');

        $validator
            ->scalar('empanelment_number')
            ->maxLength('empanelment_number', 200)
            ->requirePresence('empanelment_number', 'create')
            ->notEmpty('empanelment_number');

        $validator
            ->numeric('total_expenditure')
            ->requirePresence('total_expenditure', 'create')
            ->notEmpty('total_expenditure');

        $validator
            ->numeric('incentive_amount')
            ->requirePresence('incentive_amount', 'create')
            ->notEmpty('incentive_amount');        

        $validator
            ->numeric('sanction_amount')
            ->allowEmpty('sanction_amount');

        $validator
            ->scalar('other_information')
            ->allowEmpty('other_information');
        
        $validator
            ->scalar('admin_reason')
            ->allowEmpty('admin_reason');

        $validator
            ->scalar('screening_committee_reason')
            ->allowEmpty('screening_committee_reason');

        $validator
            ->scalar('steering_committee_reason')
            ->allowEmpty('steering_committee_reason');

        $validator
            ->scalar('application_number')
            ->maxLength('application_number', 50)
            ->allowEmpty('application_number');

        $validator
            ->scalar('reference_number')
            ->maxLength('reference_number', 50)
            ->allowEmpty('reference_number');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['startup_application_id'], 'StartupApplications'));
        $rules->add($rules->existsIn(['designation_id'], 'Designations'));
        $rules->add($rules->existsIn(['application_status_id'], 'ApplicationStatus'));
        $rules->add($rules->existsIn(['application_stage_id'], 'ApplicationStages'));

        return $rules;
    }
}
