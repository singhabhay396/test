<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * PolicyDownloads Model
 *
 * @method \App\Model\Entity\PolicyDownload get($primaryKey, $options = [])
 * @method \App\Model\Entity\PolicyDownload newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\PolicyDownload[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\PolicyDownload|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\PolicyDownload|bool saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\PolicyDownload patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\PolicyDownload[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\PolicyDownload findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class PolicyDownloadsTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('policy_downloads');
        $this->setDisplayField('title');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

        $this->hasMany('PolicyDownloadTranslations', [
            'foreignKey' => 'policy_download_id'
        ]);
        $this->belongsTo('PolicyDownloadTranslation', [
            'foreignKey' => 'id',
            'bindingKey' => 'policy_download_id',
            'joinType'   => 'LEFT',
            'className'  => 'PolicyDownloadTranslations',
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        $validator
            ->scalar('title')
            ->maxLength('title', 255)
            ->requirePresence('title', 'create')
            ->notEmpty('title');

        $validator
            ->scalar('excerpt')
            ->allowEmpty('excerpt');

        $validator
            ->date('policy_date')
            ->allowEmpty('policy_date');

        $validator
            ->scalar('file_name')
            ->allowEmpty('file_name');

        return $validator;
    }
}
