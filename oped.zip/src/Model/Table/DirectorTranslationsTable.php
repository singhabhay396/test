<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * DirectorTranslations Model
 *
 * @property \App\Model\Table\DirectorsTable|\Cake\ORM\Association\BelongsTo $Directors
 * @property \App\Model\Table\LanguagesTable|\Cake\ORM\Association\BelongsTo $Languages
 *
 * @method \App\Model\Entity\DirectorTranslation get($primaryKey, $options = [])
 * @method \App\Model\Entity\DirectorTranslation newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\DirectorTranslation[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\DirectorTranslation|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\DirectorTranslation|bool saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\DirectorTranslation patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\DirectorTranslation[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\DirectorTranslation findOrCreate($search, callable $callback = null, $options = [])
 */
class DirectorTranslationsTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('director_translations');
        $this->setDisplayField('title');
        $this->setPrimaryKey('id');

        $this->belongsTo('Directors', [
            'foreignKey' => 'director_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('Languages', [
            'foreignKey' => 'language_id',
            'joinType' => 'INNER'
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        $validator
            ->scalar('culture')
            ->maxLength('culture', 10)
            ->requirePresence('culture', 'create')
            ->notEmpty('culture');

        $validator
            ->scalar('title')
            ->maxLength('title', 250)
            ->allowEmpty('title');

        $validator
            ->scalar('excerpt')
            ->allowEmpty('excerpt');

        $validator
            ->scalar('content')
            ->maxLength('content', 4294967295)
            ->allowEmpty('content');
			
		$validator
            ->scalar('education')
            ->maxLength('education', 250)
            ->allowEmpty('education');	

        $validator
            ->scalar('url')
            ->maxLength('url', 250)
            ->allowEmpty('url');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['director_id'], 'Directors'));
        $rules->add($rules->existsIn(['language_id'], 'Languages'));

        return $rules;
    }
}
