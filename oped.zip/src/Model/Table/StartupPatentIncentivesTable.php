<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * StartupPatentIncentives Model
 *
 * @property \App\Model\Table\StartupApplicationsTable|\Cake\ORM\Association\BelongsTo $StartupApplications
 * @property \App\Model\Table\DesignationsTable|\Cake\ORM\Association\BelongsTo $Designations
 * @property \App\Model\Table\ApplicationStatusTable|\Cake\ORM\Association\BelongsTo $ApplicationStatus
 * @property \App\Model\Table\StartupStagesTable|\Cake\ORM\Association\BelongsTo $StartupStages
 *
 * @method \App\Model\Entity\StartupPatentIncentive get($primaryKey, $options = [])
 * @method \App\Model\Entity\StartupPatentIncentive newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\StartupPatentIncentive[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\StartupPatentIncentive|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\StartupPatentIncentive|bool saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\StartupPatentIncentive patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\StartupPatentIncentive[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\StartupPatentIncentive findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class StartupPatentIncentivesTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('startup_patent_incentives');
        $this->setDisplayField('name');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

        $this->belongsTo('StartupApplications', [
            'foreignKey' => 'startup_application_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('Designations', [
            'foreignKey' => 'designation_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('ApplicationStatus', [
            'foreignKey' => 'application_status_id'
        ]);
        $this->belongsTo('ApplicationStages', [
            'foreignKey' => 'application_stage_id',
            'joinType' => 'INNER',
            'className' => 'StartupStages'
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->allowEmpty('id', 'create');

        $validator
            ->scalar('startup_name')
            ->maxLength('startup_name', 255)
            ->requirePresence('startup_name', 'create')
            ->notEmpty('startup_name');

        $validator
            ->scalar('registration_number')
            ->maxLength('registration_number', 100)
            ->requirePresence('registration_number', 'create')
            ->notEmpty('registration_number');

        $validator
            ->date('date_of_registration')
            ->requirePresence('date_of_registration', 'create')
            ->notEmpty('date_of_registration');

        $validator
            ->scalar('name')
            ->maxLength('name', 100)
            ->requirePresence('name', 'create')
            ->notEmpty('name');

        $validator
            ->email('email')
            ->requirePresence('email', 'create')
            ->notEmpty('email');

        $validator
            ->scalar('mobile_number')
            ->maxLength('mobile_number', 12)
            ->requirePresence('mobile_number', 'create')
            ->notEmpty('mobile_number');

        $validator
            ->integer('patents_granted_national')
            ->requirePresence('patents_granted_national', 'create')
            ->notEmpty('patents_granted_national');

        $validator
            ->integer('patents_granted_international')
            ->requirePresence('patents_granted_international', 'create')
            ->notEmpty('patents_granted_international');

        $validator
            ->integer('number_of_patents')
            ->requirePresence('number_of_patents', 'create')
            ->notEmpty('number_of_patents');

        $validator
            ->integer('application_filling')
            ->requirePresence('application_filling', 'create')
            ->notEmpty('application_filling');

        $validator
            ->scalar('application_filling_number')
            ->maxLength('application_filling_number', 200)
            ->requirePresence('application_filling_number', 'create')
            ->notEmpty('application_filling_number');

        $validator
            ->date('date_of_filling_application')
            ->requirePresence('date_of_filling_application', 'create')
            ->notEmpty('date_of_filling_application');

        $validator
            ->scalar('inventor_name')
            ->maxLength('inventor_name', 100)
            ->requirePresence('inventor_name', 'create')
            ->notEmpty('inventor_name');

        $validator
            ->scalar('inventor_qualification')
            ->maxLength('inventor_qualification', 200)
            ->requirePresence('inventor_qualification', 'create')
            ->notEmpty('inventor_qualification');

        $validator
            ->requirePresence('inventor_age', 'create')
            ->notEmpty('inventor_age');

        $validator
            ->requirePresence('rd_indigenous', 'create')
            ->notEmpty('rd_indigenous');

        $validator
            ->scalar('collaborative')
            ->requirePresence('collaborative', 'create')
            ->notEmpty('collaborative');

        $validator
            ->integer('patent_attorney')
            ->requirePresence('patent_attorney', 'create')
            ->notEmpty('patent_attorney');

        $validator
            ->integer('total_expenditure')
            ->requirePresence('total_expenditure', 'create')
            ->notEmpty('total_expenditure');

        $validator
            ->integer('financial_assistance')
            ->requirePresence('financial_assistance', 'create')
            ->notEmpty('financial_assistance');

        $validator
            ->scalar('other_information')
            ->requirePresence('other_information', 'create')
            ->notEmpty('other_information');

        $validator
            ->scalar('invention_title')
            ->maxLength('invention_title', 200)
            ->requirePresence('invention_title', 'create')
            ->notEmpty('invention_title');

        $validator
            ->scalar('invention_description')
            ->requirePresence('invention_description', 'create')
            ->notEmpty('invention_description');

        $validator
            ->scalar('invention_technical')
            ->requirePresence('invention_technical', 'create')
            ->notEmpty('invention_technical');

        $validator
            ->scalar('invention_advantage')
            ->requirePresence('invention_advantage', 'create')
            ->notEmpty('invention_advantage');

        $validator
            ->scalar('invention_novel_features')
            ->requirePresence('invention_novel_features', 'create')
            ->notEmpty('invention_novel_features');

        $validator
            ->scalar('brief_description_commercialization')
            ->requirePresence('brief_description_commercialization', 'create')
            ->notEmpty('brief_description_commercialization');

        $validator
            ->scalar('potential_market')
            ->requirePresence('potential_market', 'create')
            ->notEmpty('potential_market');

        $validator
            ->scalar('petent_attorney_name')
            ->maxLength('petent_attorney_name', 250)
            ->requirePresence('petent_attorney_name', 'create')
            ->notEmpty('petent_attorney_name');

        $validator
            ->scalar('petent_attorney_adderess')
            ->requirePresence('petent_attorney_adderess', 'create')
            ->notEmpty('petent_attorney_adderess');

        $validator
            ->scalar('petent_attorney_experience')
            ->requirePresence('petent_attorney_experience', 'create')
            ->notEmpty('petent_attorney_experience');

        $validator
            ->scalar('attorney_name')
            ->maxLength('attorney_name', 100)
            ->requirePresence('attorney_name', 'create')
            ->notEmpty('attorney_name');

        $validator
            ->scalar('attorney_mobile')
            ->maxLength('attorney_mobile', 15)
            ->requirePresence('attorney_mobile', 'create')
            ->notEmpty('attorney_mobile');

        $validator
            ->scalar('attorney_email')
            ->maxLength('attorney_email', 50)
            ->requirePresence('attorney_email', 'create')
            ->notEmpty('attorney_email');

        $validator
            ->integer('root_filling')
            ->requirePresence('root_filling', 'create')
            ->notEmpty('root_filling');

        $validator
            ->scalar('admin_reason')
            ->allowEmpty('admin_reason');

        $validator
            ->scalar('screening_committee_reason')
            ->allowEmpty('screening_committee_reason');

        $validator
            ->scalar('steering_committee_reason')
            ->allowEmpty('steering_committee_reason');

        $validator
            ->scalar('application_number')
            ->maxLength('application_number', 50)
            ->allowEmpty('application_number');

        $validator
            ->scalar('reference_number')
            ->maxLength('reference_number', 50)
            ->allowEmpty('reference_number');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['startup_application_id'], 'StartupApplications'));
        $rules->add($rules->existsIn(['designation_id'], 'Designations'));
        $rules->add($rules->existsIn(['application_status_id'], 'ApplicationStatus'));
        $rules->add($rules->existsIn(['application_stage_id'], 'ApplicationStages'));

        return $rules;
    }
}
