<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * TestimonialTranslations Model
 *
 * @property \App\Model\Table\TestimonialsTable|\Cake\ORM\Association\BelongsTo $Testimonials
 * @property \App\Model\Table\LanguagesTable|\Cake\ORM\Association\BelongsTo $Languages
 *
 * @method \App\Model\Entity\TestimonialTranslation get($primaryKey, $options = [])
 * @method \App\Model\Entity\TestimonialTranslation newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\TestimonialTranslation[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\TestimonialTranslation|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\TestimonialTranslation|bool saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\TestimonialTranslation patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\TestimonialTranslation[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\TestimonialTranslation findOrCreate($search, callable $callback = null, $options = [])
 */
class TestimonialTranslationsTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('testimonial_translations');
        $this->setDisplayField('title');
        $this->setPrimaryKey('id');

        $this->belongsTo('Testimonials', [
            'foreignKey' => 'testimonial_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('Languages', [
            'foreignKey' => 'language_id',
            'joinType' => 'INNER'
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        $validator
            ->scalar('culture')
            ->maxLength('culture', 10)
            ->requirePresence('culture', 'create')
            ->notEmpty('culture');

        $validator
            ->scalar('title')
            ->maxLength('title', 250)
            ->allowEmpty('title');

        $validator
            ->scalar('description')
            ->maxLength('description', 4294967295)
            ->allowEmpty('description');

        $validator
            ->scalar('excerpt')
            ->allowEmpty('excerpt');

        $validator
            ->scalar('client_designation')
            ->maxLength('client_designation', 250)
            ->allowEmpty('client_designation');

        $validator
            ->scalar('client_name')
            ->maxLength('client_name', 250)
            ->allowEmpty('client_name');

        $validator
            ->scalar('company_name')
            ->maxLength('company_name', 250)
            ->allowEmpty('company_name');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['testimonial_id'], 'Testimonials'));
        $rules->add($rules->existsIn(['language_id'], 'Languages'));

        return $rules;
    }
}
