<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\Cache\Cache;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Partnerships Model
 *
 * @property \App\Model\Table\UsersTable|\Cake\ORM\Association\BelongsTo $Users
 * @property \App\Model\Table\PartnershipTranslationsTable|\Cake\ORM\Association\HasMany $PartnershipTranslations
 *
 * @method \App\Model\Entity\Partnership get($primaryKey, $options = [])
 * @method \App\Model\Entity\Partnership newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Partnership[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Partnership|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Partnership|bool saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Partnership patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Partnership[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Partnership findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class PartnershipsTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('partnerships');
        $this->setDisplayField('title');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

        $this->belongsTo('Users', [
            'foreignKey' => 'user_id',
            'joinType' => 'INNER'
        ]);

        $this->belongsTo('PartnershipTranslation', [
            'foreignKey' => 'id',
            'bindingKey' => 'partnership_id',
            'joinType'   => 'LEFT',
            'className'  => 'PartnershipTranslations',
        ]);

        $this->hasMany('PartnershipTranslations', [
            'foreignKey' => 'partnership_id'
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        $validator
            ->scalar('title')
            ->maxLength('title', 250)
            ->requirePresence('title', 'create')
            ->notEmpty('title');

        $validator
            ->scalar('subtitle')
            ->maxLength('subtitle', 250)
            ->allowEmpty('subtitle');

        $validator
            ->scalar('excerpt')
            ->allowEmpty('excerpt');

        $validator
            ->scalar('content')
            ->maxLength('content', 4294967295)
            ->allowEmpty('content');

        $validator
            ->scalar('meta_title')
            ->maxLength('meta_title', 250)
            ->allowEmpty('meta_title');
        
        $validator
            ->scalar('website_link')
            ->maxLength('website_link', 250)
            ->allowEmpty('website_link');

        $validator
            ->scalar('meta_keywords')
            ->allowEmpty('meta_keywords');

        $validator
            ->scalar('meta_description')
            ->allowEmpty('meta_description');

        $validator
            ->scalar('url')
            ->allowEmpty('url');

        $validator
            ->scalar('slug')
            ->maxLength('slug', 250)
            ->allowEmpty('slug');

        $validator
            ->scalar('logo_image')
            ->maxLength('logo_image', 250)
            ->requirePresence('logo_image', 'create')
            ->notEmpty('logo_image');

        $validator
            ->integer('sort_order')
            ->allowEmpty('sort_order');

        $validator
            ->boolean('status')
            ->requirePresence('status', 'create')
            ->notEmpty('status');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['user_id'], 'Users'));

        return $rules;
    }

    public function afterSave($event, $entity, $options = [])
    {
        Cache::clearGroup('silver-menu', 'silvermenu');
        $this->partnershipCache();
    }

    public function afterDelete($event, $entity, $options = [])
    {
        Cache::clearGroup('silver-menu', 'silvermenu');
        $this->partnershipCache();
    }
    
    public function partnershipCache()
    {
        Cache::clearGroup('silver-partnership', 'partnerships');
        $rewriteRules = $this->find('all')
            ->select(["id", "title", "slug", "url"])
            ->contain(['PartnershipTranslations' => function ($q) {
                $q->select(['partnership_id', 'language_id', 'culture', 'url']);
                $q->where(['url IS NOT NULL', 'url !=' => '']);
                return $q;
            }])
            ->where(['status' => 1])
            ->enableHydration(false)
            ->toArray();
        Cache::write('rewrite_rules', $rewriteRules, 'partnerships');
        return $rewriteRules;
    }
}
