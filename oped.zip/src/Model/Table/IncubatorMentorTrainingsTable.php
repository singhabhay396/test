<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * IncubatorMentorTrainings Model
 *
 * @property \App\Model\Table\IncubatorApplicationsTable|\Cake\ORM\Association\BelongsTo $IncubatorApplications
 * @property \App\Model\Table\DesignationsTable|\Cake\ORM\Association\BelongsTo $Designations
 * @property \App\Model\Table\ApplicationStatusesTable|\Cake\ORM\Association\BelongsTo $ApplicationStatuses
 * @property \App\Model\Table\ApplicationStagesTable|\Cake\ORM\Association\BelongsTo $ApplicationStages
 *
 * @method \App\Model\Entity\IncubatorMentorTraining get($primaryKey, $options = [])
 * @method \App\Model\Entity\IncubatorMentorTraining newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\IncubatorMentorTraining[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\IncubatorMentorTraining|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\IncubatorMentorTraining|bool saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\IncubatorMentorTraining patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\IncubatorMentorTraining[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\IncubatorMentorTraining findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class IncubatorMentorTrainingsTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('incubator_mentor_trainings');
        $this->setDisplayField('name');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

        $this->belongsTo('Incubators', [
            'foreignKey' => 'incubator_application_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('Designations', [
            'foreignKey' => 'designation_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('ApplicationStatus', [
            'foreignKey' => 'application_status_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('ApplicationStages', [
            'foreignKey' => 'application_stage_id',
            'joinType' => 'INNER',
            'className' => 'StartupStages'
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        $validator
            ->scalar('incubator_name')
            ->maxLength('incubator_name', 250)
            ->requirePresence('incubator_name', 'create')
            ->notEmpty('incubator_name');

        $validator
            ->scalar('registration_number')
            ->maxLength('registration_number', 250)
            ->requirePresence('registration_number', 'create')
            ->notEmpty('registration_number');

        $validator
            ->date('date_of_registration')
            ->requirePresence('date_of_registration', 'create')
            ->notEmpty('date_of_registration');

        $validator
            ->scalar('name')
            ->maxLength('name', 200)
            ->requirePresence('name', 'create')
            ->notEmpty('name');

        $validator
            ->email('email')
            ->requirePresence('email', 'create')
            ->notEmpty('email');

        $validator
            ->scalar('mobile_number')
            ->maxLength('mobile_number', 15)
            ->requirePresence('mobile_number', 'create')
            ->notEmpty('mobile_number');

        $validator
            ->date('date_of_commencement')
            ->requirePresence('date_of_commencement', 'create')
            ->notEmpty('date_of_commencement');

        $validator
            ->scalar('actual_expense')
            ->maxLength('actual_expense', 50)
            ->requirePresence('actual_expense', 'create')
            ->notEmpty('actual_expense');

        $validator
            ->scalar('incentive_amount')
            ->maxLength('incentive_amount', 50)
            ->requirePresence('incentive_amount', 'create')
            ->notEmpty('incentive_amount');

        $validator
            ->scalar('other_information')
            ->allowEmpty('other_information');

        $validator
            ->scalar('admin_comment')
            ->allowEmpty('admin_comment');

        $validator
            ->date('admin_comment_date')
            ->allowEmpty('admin_comment_date');

        $validator
            ->scalar('screening_committee_comment')
            ->allowEmpty('screening_committee_comment');

        $validator
            ->date('screening_committee_date')
            ->allowEmpty('screening_committee_date');

        $validator
            ->scalar('steering_committee_comment')
            ->allowEmpty('steering_committee_comment');

        $validator
            ->date('approval_date')
            ->allowEmpty('approval_date');

        $validator
            ->scalar('application_number')
            ->maxLength('application_number', 50)
            ->allowEmpty('application_number');

        $validator
            ->scalar('reference_number')
            ->maxLength('reference_number', 50)
            ->allowEmpty('reference_number');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        //$rules->add($rules->isUnique(['email']));
        $rules->add($rules->existsIn(['incubator_application_id'], 'Incubators'));
        $rules->add($rules->existsIn(['designation_id'], 'Designations'));
        $rules->add($rules->existsIn(['application_status_id'], 'ApplicationStatus'));
        $rules->add($rules->existsIn(['application_stage_id'], 'ApplicationStages'));

        return $rules;
    }
}
