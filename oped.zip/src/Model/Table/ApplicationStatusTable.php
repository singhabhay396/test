<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

class ApplicationStatusTable extends Table
{

    public function initialize(array $config)
    {
        parent::initialize($config);
        $this->setTable('application_status');      
        $this->setPrimaryKey('id');  
        $this->setDisplayField('title');

        $this->belongsTo('ArticalDetails', [
            'foreignKey' => 'id',
            'joinType' => 'INNER'
        ]);
    }

}
