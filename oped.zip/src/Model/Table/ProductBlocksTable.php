<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * ProductBlocks Model
 *
 * @property \App\Model\Table\ProductsTable|\Cake\ORM\Association\BelongsTo $Products
 * @property \App\Model\Table\ProductBlockTranslationsTable|\Cake\ORM\Association\HasMany $ProductBlockTranslations
 *
 * @method \App\Model\Entity\ProductBlock get($primaryKey, $options = [])
 * @method \App\Model\Entity\ProductBlock newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\ProductBlock[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\ProductBlock|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\ProductBlock|bool saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\ProductBlock patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\ProductBlock[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\ProductBlock findOrCreate($search, callable $callback = null, $options = [])
 */
class ProductBlocksTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('product_blocks');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->belongsTo('Products', [
            'foreignKey' => 'product_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('Languages', [
            'foreignKey' => 'language_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('ProductBlockTranslations', [
            'foreignKey' => 'id',
            'bindingKey' => 'product_block_id',
            'joinType'   => 'LEFT',
            'className'  => 'ProductBlockTranslationss',
        ]);
        $this->hasMany('ProductBlockTranslationss', [
            'foreignKey' => 'product_block_id',
            'className'  => 'ProductBlockTranslationss',
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->allowEmpty('id', 'create');

        $validator
            ->scalar('culture')
            ->maxLength('culture', 10)
            ->requirePresence('culture', 'create')
            ->notEmpty('culture');

        $validator
            ->scalar('block_label')
            ->maxLength('block_label', 255)
            ->requirePresence('block_label', 'create')
            ->notEmpty('block_label');

        $validator
            ->scalar('block_content')
            ->maxLength('block_content', 16777215)
            ->requirePresence('block_content', 'create')
            ->notEmpty('block_content');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['product_id'], 'Products'));
        $rules->add($rules->existsIn(['language_id'], 'Languages'));

        return $rules;
    }
}
