<?php

namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Incubators Model
 *
 * @property \App\Model\Table\UsersTable|\Cake\ORM\Association\BelongsTo $Users
 * @property |\Cake\ORM\Association\BelongsTo $RegisteredStates
 * @property |\Cake\ORM\Association\BelongsTo $RegisteredDistricts
 * @property |\Cake\ORM\Association\BelongsTo $Emails
 * @property |\Cake\ORM\Association\BelongsTo $KeyPersonalDesignations
 * @property |\Cake\ORM\Association\BelongsTo $ApplicationStatuses
 * @property |\Cake\ORM\Association\BelongsTo $IncubatorStages
 *
 * @method \App\Model\Entity\Incubator get($primaryKey, $options = [])
 * @method \App\Model\Entity\Incubator newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Incubator[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Incubator|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Incubator|bool saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Incubator patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Incubator[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Incubator findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class MeetingSchedulesTable extends Table {

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config) {
        parent::initialize($config);

        $this->setTable('meeting_schedules');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');
        $this->belongsTo('MenteesDetails', [
            'foreignKey' => 'mentees_id',
            'className' => 'MentorMentees'
        ]);   
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator) {
        $validator
                ->integer('id')
                ->allowEmpty('id', 'create');

        

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules) {
        $rules->add($rules->existsIn(['user_id'], 'Users'));
        /* $rules->add($rules->existsIn(['registered_state_id'], 'RegisteredStates'));
          $rules->add($rules->existsIn(['registered_district_id'], 'RegisteredDistricts'));
          $rules->add($rules->existsIn(['key_personal_designation_id'], 'KeyPersonalDesignations'));
          $rules->add($rules->existsIn(['application_status_id'], 'ApplicationStatus'));
          $rules->add($rules->existsIn(['incubator_stage_id'], 'IncubatorStages')); */

        return $rules;
    }

}
