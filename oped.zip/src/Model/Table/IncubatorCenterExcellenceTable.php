<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * IncubatorCenterExcellence Model
 *
 * @property \App\Model\Table\IncubatorCenterExcellenceTranslationTable|\Cake\ORM\Association\HasMany $IncubatorCenterExcellenceTranslation
 *
 * @method \App\Model\Entity\IncubatorCenterExcellence get($primaryKey, $options = [])
 * @method \App\Model\Entity\IncubatorCenterExcellence newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\IncubatorCenterExcellence[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\IncubatorCenterExcellence|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\IncubatorCenterExcellence|bool saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\IncubatorCenterExcellence patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\IncubatorCenterExcellence[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\IncubatorCenterExcellence findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class IncubatorCenterExcellenceTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('incubator_center_excellence');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

        $this->hasMany('IncubatorCenterExcellenceTranslation', [
            'foreignKey' => 'incubator_center_excellence_id'
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        $validator
            ->scalar('content')
            ->requirePresence('content', 'create')
            ->notEmpty('content');

        $validator
            ->scalar('url')
            ->allowEmpty('url');

        /*$validator
            ->scalar('image')
            ->maxLength('image', 255)
            ->requirePresence('image', 'create')
            ->notEmpty('image');*/

        $validator
            ->boolean('status')
            ->requirePresence('status', 'create')
            ->notEmpty('status');

        return $validator;
    }
}
