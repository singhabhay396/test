<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\Cache\Cache;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Directors Model
 *
 * @property \App\Model\Table\UsersTable|\Cake\ORM\Association\BelongsTo $Users
 * @property \App\Model\Table\DirectorTranslationsTable|\Cake\ORM\Association\HasMany $DirectorTranslations
 *

 * @method \App\Model\Entity\Director get($primaryKey, $options = [])
 * @method \App\Model\Entity\Director newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Director[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Director|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Director|bool saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Director patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Director[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Director findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class DirectorsTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('directors');
        $this->setDisplayField('title');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

        $this->belongsTo('Users', [
            'foreignKey' => 'user_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('DirectorTranslation', [
            'foreignKey' => 'id',
            'bindingKey' => 'director_id',
            'joinType'   => 'LEFT',
            'className'  => 'DirectorTranslations',
        ]);
        $this->hasMany('DirectorTranslations', [
            'foreignKey' => 'director_id',
            'className'  => 'DirectorTranslations',
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        $validator
            ->scalar('title')
            ->maxLength('title', 250)
            ->requirePresence('title', 'create')
            ->notEmpty('title');

        $validator
            ->scalar('excerpt')
            ->allowEmpty('excerpt');

        $validator
            ->scalar('content')
            ->maxLength('content', 4294967295)
            ->allowEmpty('content');
			
		$validator
            ->scalar('education')
            ->maxLength('education', 250)
            ->requirePresence('education', 'create') 
            ->allowEmpty('education');	

        $validator
            ->scalar('url')
            ->maxLength('url', 250)
            ->allowEmpty('url');

        $validator
            ->boolean('is_main')
            ->requirePresence('is_main', 'create')
            ->notEmpty('is_main');

        $validator
            ->boolean('status')
            ->requirePresence('status', 'create')
            ->notEmpty('status');
			
		$validator
            ->integer('sort_order')
            ->allowEmpty('sort_order');		

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['user_id'], 'Users'));
        $rules->add($rules->isUnique(['url']));

        return $rules;
    }

    public function afterSave($event, $entity, $options = [])
    {
        Cache::clearGroup('silver-menu', 'silvermenu');
        $this->directorCache();
    }

    public function afterDelete($event, $entity, $options = [])
    {
        Cache::clearGroup('silver-menu', 'silvermenu');
        $this->directorCache();
    }
    
    public function directorCache()
    {
        Cache::clearGroup('silver-directors', 'directors');
        $rewriteRules = $this->find('all')
            ->select(["id", "title", "url"])
            ->contain(['DirectorTranslations' => function ($q) {
                $q->select(['director_id', 'language_id', 'culture', 'url']);
                $q->where(['url IS NOT NULL', 'url !=' => '']);
                return $q;
            }])
            ->where(['status' => 1])
            ->enableHydration(false)
            ->toArray();
        Cache::write('rewrite_rules', $rewriteRules, 'directors');
        return $rewriteRules;
    }
}
