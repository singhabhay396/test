<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * StartupDirectors Model
 *
 * @property \App\Model\Table\StartupApplicationsTable|\Cake\ORM\Association\BelongsTo $StartupApplications
 * @property \App\Model\Table\StatesTable|\Cake\ORM\Association\BelongsTo $States
 * @property \App\Model\Table\DistrictsTable|\Cake\ORM\Association\BelongsTo $Districts
 *
 * @method \App\Model\Entity\StartupDirector get($primaryKey, $options = [])
 * @method \App\Model\Entity\StartupDirector newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\StartupDirector[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\StartupDirector|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\StartupDirector|bool saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\StartupDirector patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\StartupDirector[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\StartupDirector findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class StartupDirectorsTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('startup_directors');
        $this->setDisplayField('name');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

        $this->belongsTo('StartupApplications', [
            'foreignKey' => 'startup_application_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('DirectorStates', [
            'foreignKey' => 'state_id',
            'joinType' => 'INNER',
            'className' =>'States'
        ]);
        $this->belongsTo('DirectorDistricts', [
            'foreignKey' => 'district_id',
            'joinType' => 'INNER',
            'className' => 'Districts',
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        /*$validator
            ->scalar('name')
            ->maxLength('name', 200)
            ->requirePresence('name', 'create')
            ->notEmpty('name');

        $validator
            ->scalar('designation')
            ->maxLength('designation', 200)
            ->requirePresence('designation', 'create')
            ->notEmpty('designation');

        $validator
            ->requirePresence('gender', 'create')
            ->notEmpty('gender');

        $validator
            ->requirePresence('nationality', 'create')
            ->notEmpty('nationality');

        $validator
            ->scalar('din_director')
            ->maxLength('din_director', 100)
            ->requirePresence('din_director', 'create')
            ->notEmpty('din_director');

        $validator
            ->scalar('pan_director')
            ->maxLength('pan_director', 20)
            ->requirePresence('pan_director', 'create')
            ->notEmpty('pan_director');

        $validator
            ->scalar('address')
            ->requirePresence('address', 'create')
            ->notEmpty('address');

        $validator
            ->scalar('postal_code')
            ->maxLength('postal_code', 12)
            ->requirePresence('postal_code', 'create')
            ->notEmpty('postal_code');

        $validator
            ->scalar('mobile')
            ->maxLength('mobile', 12)
            ->requirePresence('mobile', 'create')
            ->notEmpty('mobile');

        $validator
            ->scalar('landline')
            ->maxLength('landline', 12)
            ->requirePresence('landline', 'create')
            ->notEmpty('landline');

        $validator
            ->email('email')
            ->requirePresence('email', 'create')
            ->notEmpty('email');*/

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->isUnique(['email']));
        $rules->add($rules->existsIn(['startup_application_id'], 'StartupApplications'));
        /*$rules->add($rules->existsIn(['state_id'], 'States'));
        $rules->add($rules->existsIn(['district_id'], 'Districts'));*/

        return $rules;
    }
}
