-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 01, 2023 at 03:05 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.3.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test_book`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(11) NOT NULL,
  `name` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `name`) VALUES
(1, 'Cakephp'),
(2, 'Java'),
(3, 'Java Script'),
(4, 'Laravel');

-- --------------------------------------------------------

--
-- Table structure for table `book_collections`
--

CREATE TABLE `book_collections` (
  `id` int(11) NOT NULL,
  `name` varchar(256) NOT NULL,
  `lib_collection_id` int(11) NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `book_collections`
--

INSERT INTO `book_collections` (`id`, `name`, `lib_collection_id`, `start_date`, `end_date`) VALUES
(1, 'Cakephp', 1, '2023-06-30', '2023-07-07'),
(2, 'Laravel', 2, '2023-06-29', '2023-07-17'),
(3, 'PHP', 3, '2023-06-29', '2023-07-17'),
(4, 'Yii', 4, '2023-06-29', '2023-07-17');

-- --------------------------------------------------------

--
-- Table structure for table `book_image`
--

CREATE TABLE `book_image` (
  `id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `filename` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `book_image`
--

INSERT INTO `book_image` (`id`, `book_id`, `filename`) VALUES
(1, 1, 'cake_image.jpg'),
(2, 2, 'java.jpg'),
(3, 3, 'java_script.jpg'),
(4, 4, 'laravel.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `book_items`
--

CREATE TABLE `book_items` (
  `id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `book_collection_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `book_items`
--

INSERT INTO `book_items` (`id`, `book_id`, `book_collection_id`) VALUES
(1, 1, 1),
(2, 2, 2),
(3, 3, 2),
(4, 3, 3),
(5, 2, 3),
(6, 4, 3),
(7, 3, 4),
(8, 1, 4),
(9, 2, 4),
(10, 4, 4);

-- --------------------------------------------------------

--
-- Table structure for table `lib_collections`
--

CREATE TABLE `lib_collections` (
  `id` int(11) NOT NULL,
  `name` varchar(256) NOT NULL,
  `lib_count` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `lib_collections`
--

INSERT INTO `lib_collections` (`id`, `name`, `lib_count`) VALUES
(1, 'Lib', 1),
(2, 'Lib', 2),
(3, 'Lib', 3),
(4, 'Lib', 4);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `book_collections`
--
ALTER TABLE `book_collections`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `book_image`
--
ALTER TABLE `book_image`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `book_items`
--
ALTER TABLE `book_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lib_collections`
--
ALTER TABLE `lib_collections`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `book_collections`
--
ALTER TABLE `book_collections`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `book_image`
--
ALTER TABLE `book_image`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `book_items`
--
ALTER TABLE `book_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
