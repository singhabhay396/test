<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

class BookCollectionsTable extends Table
{

    public function initialize(array $config)
    {
        parent::initialize($config);
        $this->setTable('book_collections');
        $this->setPrimaryKey('id');
        $this->addBehavior('Timestamp');
		$this->hasMany('BookItems', [
            'foreignKey' => 'book_collection_id',
            'joinType' => 'Left'
        ]);
		$this->belongsTo('LibCollections', [
            'foreignKey' => 'id',
        ]);
        
        
       
        
        
    }

}
