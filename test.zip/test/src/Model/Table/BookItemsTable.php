<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

class BookItemsTable extends Table
{

    public function initialize(array $config)
    {
        parent::initialize($config);
        $this->setTable('book_items');
        $this->setPrimaryKey('id');
        $this->addBehavior('Timestamp');
		$this->belongsTo('Books', [
            'foreignKey' => 'id',
        ]);
		$this->belongsTo('BookCollections', [
            'foreignKey' => 'id',

        ]);
        
        
       
        
        
    }

}
