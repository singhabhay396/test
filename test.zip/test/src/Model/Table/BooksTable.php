<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

class BooksTable extends Table
{

    public function initialize(array $config)
    {
        parent::initialize($config);
        $this->setTable('books');
        $this->setPrimaryKey('id');
        $this->addBehavior('Timestamp');
		$this->belongsToMany('BookItems', [
            'foreignKey' => 'book_id',
            'joinType' => 'INNER'
        ]);
		$this->hasOne('BookImage', [
            'foreignKey' => 'book_id',
            'joinType' => 'INNER'
        ]);
        
        
       
        
        
    }

}
