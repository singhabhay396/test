<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

class LibCollectionsTable extends Table
{

    public function initialize(array $config)
    {
        parent::initialize($config);
        $this->setTable('lib_collections');
        $this->setPrimaryKey('id');
        $this->addBehavior('Timestamp');
		$this->hasOne('BookCollections', [
            'foreignKey' => 'lib_collection_id',
            'joinType' => 'INNER'
        ]);
        
        
       
        
        
    }

}
